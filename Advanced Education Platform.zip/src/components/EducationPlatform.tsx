import React, { useState } from 'react'
import { 
  BookOpen, Clock, Star, Play, CheckCircle, 
  Trophy, Target, Video, FileText, Brain,
  GraduationCap, BarChart3, TrendingUp, Lightbulb,
  DollarSign, Bitcoin, Settings, PieChart
} from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from './ui/card'
import { Button } from './ui/button'
import { Badge } from './ui/badge'
import { Progress } from './ui/progress'
import { Separator } from './ui/separator'
import { useLanguage } from './useLanguage'
import { LanguageSelector } from './LanguageSelector'
import { LevelFilter } from './LevelFilter'
import { courses, Course } from './courseData'
import { getCoursesForLanguage } from './courseDataHelper'
import { CourseDetail } from './CourseDetail'
import economicsImage from 'figma:asset/fe7101b1b2fce2a4e52f2169b6f68196b409a369.png'
import personalFinanceImage from 'figma:asset/958baec8100fc925fcf8bbb1481f245b38756057.png'
import financialMarketsImage from 'figma:asset/ec8e55773a4c202a595ac3447fce52eada6a7367.png'
import fundamentalAnalysisImage from 'figma:asset/b7e9896ac04f15ab869b0a50bccad3c6f9aa7578.png'
import technicalAnalysisImage from 'figma:asset/62c51089983d0d87c1c3f7708323923f172aef9b.png'
import riskManagementImage from 'figma:asset/100abeba31c71c42f12f439013a987958c8c9e0b.png'
import tradingPsychologyImage from 'figma:asset/e9109a09b195ea03d85d537805b8c292ee5822b2.png'
import algorithmicTradingImage from 'figma:asset/0c7854f42c56fb51fa01b34c2e3f23507b1333b2.png'
import derivativesMarketsImage from 'figma:asset/6e12fca68f4df9a4733ee1275cd11eed0f6629a9.png'
import advancedTechnicalAnalysisImage from 'figma:asset/48ace4a350b55e435c13e4d1768c20ccdae70f98.png'

export function EducationPlatform() {
  const [selectedLevel, setSelectedLevel] = useState('all')
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null)
  const { language, t } = useLanguage()
  const localizedCourses = getCoursesForLanguage(language)

  // Get duration and time unit formatted for current language
  const formatDuration = (duration: string) => {
    const timeUnit = t('course.hours')
    return `${duration} ${timeUnit}`
  }

  const formatLastUpdated = (days: string) => {
    const timeAgo = {
      '1': { 
        tr: '1 hafta önce', 
        en: '1 week ago', 
        es: 'hace 1 semana', 
        fr: 'il y a 1 semaine', 
        ru: '1 неделю назад',
        de: 'vor 1 Woche',
        pt: 'há 1 semana'
      },
      '2': { 
        tr: '2 gün önce', 
        en: '2 days ago', 
        es: 'hace 2 días', 
        fr: 'il y a 2 jours', 
        ru: '2 дня назад',
        de: 'vor 2 Tagen',
        pt: 'há 2 dias'
      },
      '3': { 
        tr: '3 gün önce', 
        en: '3 days ago', 
        es: 'hace 3 días', 
        fr: 'il y a 3 jours', 
        ru: '3 дня назад',
        de: 'vor 3 Tagen',
        pt: 'há 3 dias'
      },
      '4': { 
        tr: '4 gün önce', 
        en: '4 days ago', 
        es: 'hace 4 días', 
        fr: 'il y a 4 jours', 
        ru: '4 дня назад',
        de: 'vor 4 Tagen',
        pt: 'há 4 dias'
      },
      '5': { 
        tr: '5 gün önce', 
        en: '5 days ago', 
        es: 'hace 5 días', 
        fr: 'il y a 5 jours', 
        ru: '5 дней назад',
        de: 'vor 5 Tagen',
        pt: 'há 5 dias'
      }
    }
    return timeAgo[days as keyof typeof timeAgo]?.[language] || `${days} days ago`
  }

  const courseCounts = {
    all: localizedCourses.length,
    Beginner: localizedCourses.filter(c => c.level === 'Beginner').length,
    Intermediate: localizedCourses.filter(c => c.level === 'Intermediate').length,
    Advanced: localizedCourses.filter(c => c.level === 'Advanced').length
  }

  const filteredCourses = selectedLevel === 'all' 
    ? localizedCourses 
    : localizedCourses.filter(course => course.level === selectedLevel)

  const getLevelColor = (level: string) => {
    switch (level.toLowerCase()) {
      case 'beginner': return 'bg-green-100 text-green-800 border-green-200'
      case 'intermediate': return 'bg-yellow-100 text-yellow-800 border-yellow-200'
      case 'advanced': return 'bg-red-100 text-red-800 border-red-200'
      default: return 'bg-gray-100 text-gray-800 border-gray-200'
    }
  }
  
  const getLevelText = (level: string) => {
    switch (level.toLowerCase()) {
      case 'beginner': return t('level.beginner')
      case 'intermediate': return t('level.intermediate')
      case 'advanced': return t('level.advanced')
      default: return level
    }
  }

  const getContentTypeIcon = (type: string) => {
    switch (type) {
      case 'video': return <Video className="w-3 h-3" />
      case 'text': return <FileText className="w-3 h-3" />
      case 'quiz': return <Target className="w-3 h-3" />
      case 'practice': return <Play className="w-3 h-3" />
      case 'calculator': return <DollarSign className="w-3 h-3" />
      case 'simulation': return <BarChart3 className="w-3 h-3" />
      default: return <BookOpen className="w-3 h-3" />
    }
  }

  const TradingIllustration = ({ category, course }: { category?: string; course?: Course }) => {
    const getImageForCategory = (cat: string) => {
      switch (cat) {
        case 'Personal Finance':
          return 'https://images.unsplash.com/photo-1698584200770-3838c3690a27?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwZXJzb25hbCUyMGZpbmFuY2UlMjBtb25leSUyMG1hbmFnZW1lbnQlMjBidWRnZXQlMjBzYXZpbmdzfGVufDF8fHx8MTc1NzE5NDk1M3ww&ixlib=rb-4.1.0&q=80&w=1080'
        case 'Markets':
        case 'Financial Markets':
          return 'https://images.unsplash.com/photo-1643962579365-3a9222e923b8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmaW5hbmNpYWwlMjBtYXJrZXRzJTIwdHJhZGluZyUyMGNoYXJ0cyUyMHByb2Zlc3Npb25hbHxlbnwxfHx8fDE3NTcxOTQ5NDR8MA&ixlib=rb-4.1.0&q=80&w=1080'
        case 'Fundamental':
        case 'Fundamental Analysis':
          return 'https://images.unsplash.com/photo-1574884280706-7342ca3d4231?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmdW5kYW1lbnRhbCUyMGFuYWx5c2lzJTIwZmluYW5jaWFsJTIwc3RhdGVtZW50cyUyMGJ1c2luZXNzfGVufDF8fHx8MTc1NzE5NDk1MHww&ixlib=rb-4.1.0&q=80&w=1080'
        case 'Analysis':
        case 'Technical Analysis':
        case 'Crypto':
          return 'https://images.unsplash.com/photo-1748609700323-483a007ed311?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWNobmljYWwlMjBhbmFseXNpcyUyMGNyeXB0b2N1cnJlbmN5JTIwYml0Y29pbiUyMGNoYXJ0c3xlbnwxfHx8fDE3NTcxOTQ5NDd8MA&ixlib=rb-4.1.0&q=80&w=1080'
        case 'Risk':
        case 'Risk Management':
          return 'https://images.unsplash.com/photo-1705313381918-b394c4761d37?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyaXNrJTIwbWFuYWdlbWVudCUyMGZpbmFuY2lhbCUyMHByb3RlY3Rpb24lMjBpbnN1cmFuY2V8ZW58MXx8fHwxNzU3MTk0OTU2fDA&ixlib=rb-4.1.0&q=80&w=1080'
        case 'Psychology':
        case 'Trading Psychology':
          return 'https://images.unsplash.com/photo-1647613561332-3d88a6a0048e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0cmFkaW5nJTIwcHN5Y2hvbG9neSUyMG1pbmQlMjBicmFpbiUyMG5ldXJvc2NpZW5jZXxlbnwxfHx8fDE3NTcxOTQ5NjB8MA&ixlib=rb-4.1.0&q=80&w=1080'
        case 'Algorithmic':
        case 'Algorithmic Trading':
          return 'https://images.unsplash.com/photo-1710584805097-4e116679213f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhbGdvcml0aG1pYyUyMHRyYWRpbmclMjBhcnRpZmljaWFsJTIwaW50ZWxsaWdlbmNlJTIwcm9ib3QlMjBhdXRvbWF0aW9ufGVufDF8fHx8MTc1NzE5NDk2Mnww&ixlib=rb-4.1.0&q=80&w=1080'
        case 'Derivatives':
          return 'https://images.unsplash.com/photo-1704969724140-0a7a390dba73?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZXJpdmF0aXZlcyUyMGZ1dHVyZXMlMjBvcHRpb25zJTIwdHJhZGluZyUyMGNvbnRyYWN0c3xlbnwxfHx8fDE3NTcxOTQ5NjZ8MA&ixlib=rb-4.1.0&q=80&w=1080'
        case 'Economics':
          return 'https://images.unsplash.com/photo-1695462131550-8cb031785a6f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlY29ub21pY3MlMjBnbG9iYWwlMjBlY29ub215JTIwYnVzaW5lc3MlMjBncm93dGglMjBjaGFydHN8ZW58MXx8fHwxNzU3MTk0OTY4fDA&ixlib=rb-4.1.0&q=80&w=1080'
        default:
          return 'https://images.unsplash.com/photo-1643962579365-3a9222e923b8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmaW5hbmNpYWwlMjBtYXJrZXRzJTIwdHJhZGluZyUyMGNoYXJ0cyUyMHByb2Zlc3Npb25hbHxlbnwxfHx8fDE3NTcxOTQ5NDR8MA&ixlib=rb-4.1.0&q=80&w=1080'
      }
    }

    // For Personal Finance, use the custom imported image
    if (category === 'Personal Finance') {
      return (
        <div className="relative w-full h-full overflow-hidden rounded-t-lg">
          <img 
            src={personalFinanceImage} 
            alt="Personal Finance 3D Illustration" 
            className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
          />
          {/* Gradient overlay for better text readability */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-black/5 to-transparent"></div>
          
          {/* Category icon overlay */}
          <div className="absolute bottom-3 right-3 w-8 h-8 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
            <DollarSign className="w-4 h-4 text-white" />
          </div>
        </div>
      )
    }

    // For Financial Markets, use the custom 3D financial data visualization
    if (category === 'Markets' || category === 'Financial Markets') {
      return (
        <div className="relative w-full h-full overflow-hidden rounded-t-lg">
          <img 
            src={financialMarketsImage} 
            alt="Financial Markets 3D Data Visualization" 
            className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
          />
          {/* Gradient overlay for better text readability */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-black/5 to-transparent"></div>
          
          {/* Category icon overlay */}
          <div className="absolute bottom-3 right-3 w-8 h-8 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
            <TrendingUp className="w-4 h-4 text-white" />
          </div>
        </div>
      )
    }

    // For Fundamental Analysis, use the custom 3D financial dashboard visualization
    if (category === 'Fundamental' || category === 'Fundamental Analysis') {
      return (
        <div className="relative w-full h-full overflow-hidden rounded-t-lg">
          <img 
            src={fundamentalAnalysisImage} 
            alt="Fundamental Analysis 3D Dashboard Visualization" 
            className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
          />
          {/* Gradient overlay for better text readability */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-black/5 to-transparent"></div>
          
          {/* Category icon overlay */}
          <div className="absolute bottom-3 right-3 w-8 h-8 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
            <Target className="w-4 h-4 text-white" />
          </div>
        </div>
      )
    }

    // For Economics, use the custom 3D global economy visualization
    if (category === 'Economics') {
      return (
        <div className="relative w-full h-full overflow-hidden rounded-t-lg">
          <img 
            src={economicsImage} 
            alt="Economics 3D Global Economy Visualization" 
            className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
          />
          {/* Gradient overlay for better text readability */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-black/5 to-transparent"></div>
          
          {/* Category icon overlay */}
          <div className="absolute bottom-3 right-3 w-8 h-8 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
            <BarChart3 className="w-4 h-4 text-white" />
          </div>
        </div>
      )
    }

    // For Technical Analysis, use the custom 3D chart analysis visualization
    if (category === 'Analysis' || category === 'Technical Analysis') {
      return (
        <div className="relative w-full h-full overflow-hidden rounded-t-lg">
          <img 
            src={technicalAnalysisImage} 
            alt="Technical Analysis 3D Chart Visualization" 
            className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
          />
          {/* Gradient overlay for better text readability */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-black/5 to-transparent"></div>
          
          {/* Category icon overlay */}
          <div className="absolute bottom-3 right-3 w-8 h-8 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
            <BarChart3 className="w-4 h-4 text-white" />
          </div>
        </div>
      )
    }

    // For Risk Management, use the custom 3D shield protection visualization
    if (category === 'Risk' || category === 'Risk Management') {
      return (
        <div className="relative w-full h-full overflow-hidden rounded-t-lg">
          <img 
            src={riskManagementImage} 
            alt="Risk Management 3D Shield Protection Visualization" 
            className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
          />
          {/* Gradient overlay for better text readability */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-black/5 to-transparent"></div>
          
          {/* Category icon overlay */}
          <div className="absolute bottom-3 right-3 w-8 h-8 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
            <Trophy className="w-4 h-4 text-white" />
          </div>
        </div>
      )
    }

    // For Trading Psychology, use the custom 3D brain neural visualization
    if (category === 'Psychology' || category === 'Trading Psychology') {
      return (
        <div className="relative w-full h-full overflow-hidden rounded-t-lg">
          <img 
            src={tradingPsychologyImage} 
            alt="Trading Psychology 3D Brain Neural Network Visualization" 
            className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
          />
          {/* Gradient overlay for better text readability */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-black/5 to-transparent"></div>
          
          {/* Category icon overlay */}
          <div className="absolute bottom-3 right-3 w-8 h-8 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
            <Brain className="w-4 h-4 text-white" />
          </div>
        </div>
      )
    }

    // For Algorithmic Trading, use the custom 3D code flow and data visualization
    if (category === 'Algorithmic' || category === 'Algorithmic Trading') {
      return (
        <div className="relative w-full h-full overflow-hidden rounded-t-lg">
          <img 
            src={algorithmicTradingImage} 
            alt="Algorithmic Trading 3D Code Flow and Data Visualization" 
            className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
          />
          {/* Gradient overlay for better text readability */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-black/5 to-transparent"></div>
          
          {/* Category icon overlay */}
          <div className="absolute bottom-3 right-3 w-8 h-8 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
            <Settings className="w-4 h-4 text-white" />
          </div>
        </div>
      )
    }

    // For Derivatives Markets, use the custom 3D isometric balance and charts visualization
    if (category === 'Derivatives') {
      return (
        <div className="relative w-full h-full overflow-hidden rounded-t-lg">
          <img 
            src={derivativesMarketsImage} 
            alt="Derivatives Markets 3D Isometric Balance and Charts Visualization" 
            className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
          />
          {/* Gradient overlay for better text readability */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-black/5 to-transparent"></div>
          
          {/* Category icon overlay */}
          <div className="absolute bottom-3 right-3 w-8 h-8 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
            <PieChart className="w-4 h-4 text-white" />
          </div>
        </div>
      )
    }

    // For Advanced Technical Analysis, use the comprehensive chart visualization
    if (category === 'Analysis' && 
        (course?.title?.tr?.includes('İleri') || course?.title?.en?.includes('Advanced'))) {
      return (
        <div className="relative w-full h-full overflow-hidden rounded-t-lg">
          <img 
            src={advancedTechnicalAnalysisImage} 
            alt="Advanced Technical Analysis Comprehensive Chart Visualization" 
            className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
          />
          {/* Gradient overlay for better text readability */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-black/5 to-transparent"></div>
          
          {/* Category icon overlay */}
          <div className="absolute bottom-3 right-3 w-8 h-8 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
            <BarChart3 className="w-4 h-4 text-white" />
          </div>
        </div>
      )
    }

    // For other categories, use professional Unsplash images
    const imageUrl = getImageForCategory(category || '')
    
    return (
      <div className="relative w-full h-full overflow-hidden rounded-t-lg">
        {/* Professional background image */}
        <div className="absolute inset-0">
          <img 
            src={imageUrl}
            alt={`${category} Professional Illustration`}
            className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
            onError={(e) => {
              // Fallback to default chart visualization if image fails to load
              const target = e.target as HTMLImageElement
              target.style.display = 'none'
            }}
          />
        </div>
        
        {/* Gradient overlay for better text readability */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/30 via-black/10 to-transparent"></div>
        
        {/* Category icon overlay */}
        <div className="absolute bottom-3 right-3 w-8 h-8 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
          {category === 'Personal Finance' && <DollarSign className="w-4 h-4 text-white" />}
          {(category === 'Markets' || category === 'Financial Markets') && <TrendingUp className="w-4 h-4 text-white" />}
          {(category === 'Fundamental' || category === 'Fundamental Analysis') && <Target className="w-4 h-4 text-white" />}
          {(category === 'Analysis' || category === 'Technical Analysis') && <BarChart3 className="w-4 h-4 text-white" />}
          {category === 'Crypto' && <Bitcoin className="w-4 h-4 text-white" />}
          {(category === 'Risk' || category === 'Risk Management') && <Trophy className="w-4 h-4 text-white" />}
          {(category === 'Psychology' || category === 'Trading Psychology') && <Brain className="w-4 h-4 text-white" />}
          {(category === 'Algorithmic' || category === 'Algorithmic Trading') && <Settings className="w-4 h-4 text-white" />}
          {category === 'Derivatives' && <PieChart className="w-4 h-4 text-white" />}
          {!category && <BookOpen className="w-4 h-4 text-white" />}
        </div>
      </div>
    )
  }



  // Handle course selection
  const handleCourseSelect = (courseId: number) => {
    const course = courses.find(c => c.id === courseId)
    if (course) {
      setSelectedCourse(course)
    }
  }

  // Handle back to course list
  const handleBackToCourses = () => {
    setSelectedCourse(null)
  }

  // If a course is selected, show the course detail page
  if (selectedCourse) {
    return <CourseDetail course={selectedCourse} onBack={handleBackToCourses} />
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Fixed Language Selector - Top Right */}
      <div className="fixed top-4 right-4 z-50">
        <LanguageSelector />
      </div>

      {/* Hero Section */}
      <section className="py-8 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center space-y-4 mb-8">
            <h1 className="text-4xl md:text-6xl font-bold text-foreground leading-tight">
              {t('platform.title')}
            </h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
              {t('platform.subtitle')}
            </p>
            <div className="flex justify-center">
              <div className="text-sm text-muted-foreground bg-muted/50 px-4 py-2 rounded-full">
                {filteredCourses.length} {filteredCourses.length === 1 ? t('course.course') : t('course.courses')} 
                {selectedLevel !== 'all' && (
                  <span className="ml-2 text-primary font-medium">
                    ({selectedLevel === 'Beginner' && t('level.beginner')}
                    {selectedLevel === 'Intermediate' && t('level.intermediate')}
                    {selectedLevel === 'Advanced' && t('level.advanced')})
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Courses Grid */}
      <section className="py-4 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 relative">
            {filteredCourses.map((course, index) => (
              <div key={`${course.id}-${language}`} className="relative">
                {/* Level Filter positioned over Personal Finance card (first card) */}
                {index === 0 && (
                  <div className="absolute -top-16 right-0 z-50">
                    <LevelFilter 
                      selectedLevel={selectedLevel}
                      onLevelChange={setSelectedLevel}
                      courseCounts={courseCounts}
                    />
                  </div>
                )}
                
                <Card className="group hover:shadow-lg transition-all duration-300 overflow-hidden h-full">
                {/* Course Header with Illustration */}
                <div className="relative h-48 bg-gradient-to-br from-slate-50 to-slate-100 border-b overflow-hidden">
                  {/* Background pattern */}
                  <div className="absolute inset-0 opacity-5">
                    <div className="absolute inset-0" style={{
                      backgroundImage: `radial-gradient(circle at 25% 25%, rgba(59, 130, 246, 0.1) 0%, transparent 50%)`,
                      backgroundSize: '40px 40px'
                    }}></div>
                  </div>
                  
                  <TradingIllustration category={course.category} course={course} />
                  
                  {/* Level Badge */}
                  <div className="absolute top-4 left-4">
                    <Badge variant="outline" className={`${getLevelColor(course.level)} backdrop-blur-sm bg-white/80`}>
                      {getLevelText(course.level)}
                    </Badge>
                  </div>
                  
                  {/* Category Badge */}
                  <div className="absolute top-4 right-4">
                    <Badge variant="secondary" className="backdrop-blur-sm bg-white/80 text-slate-700">
                      {course.category}
                    </Badge>
                  </div>
                  
                  {/* Gradient overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/5 via-transparent to-transparent"></div>
                </div>

                <CardHeader className="pb-3">
                  <CardTitle className="line-clamp-2 group-hover:text-primary transition-colors text-lg">
                    {course.title[language]}
                  </CardTitle>
                  <CardDescription className="line-clamp-2 text-sm">
                    {course.description[language]}
                  </CardDescription>
                </CardHeader>

                <CardContent className="space-y-3 pt-0">
                  {/* Course Meta */}
                  <div className="flex items-center justify-between text-sm text-muted-foreground bg-muted/50 rounded-lg p-3">
                    <div className="flex items-center space-x-1">
                      <Clock className="w-3 h-3" />
                      <span>{formatDuration(course.duration)}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <BookOpen className="w-3 h-3" />
                      <span>{course.lessons} {t('course.lessons')}</span>
                    </div>
                  </div>

                  {/* Rating & Enrollment */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div className="flex items-center space-x-1">
                        <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                        <span className="text-sm font-medium">{course.rating}</span>
                      </div>
                      <div className="text-xs text-muted-foreground">
                        ({course.enrolled.toLocaleString()})
                      </div>
                    </div>
                    
                    {/* Content Types */}
                    <div className="flex items-center space-x-1">
                      {course.contentTypes.slice(0, 3).map((type, i) => (
                        <div key={`${course.id}-content-${i}`} className="p-1 bg-background rounded border" title={type}>
                          {getContentTypeIcon(type)}
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Features */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      {course.hasQuiz && (
                        <div className="flex items-center space-x-1 text-green-600">
                          <Target className="w-4 h-4" />
                          <span className="text-xs">Quiz</span>
                        </div>
                      )}
                    </div>
                    
                    <div className="text-xs text-muted-foreground">
                      {formatLastUpdated(course.lastUpdated)}
                    </div>
                  </div>

                  {/* Learning Outcomes */}
                  <div className="bg-primary/5 rounded-lg p-2">
                    <div className="text-xs font-medium text-primary mb-1 flex items-center">
                      <Lightbulb className="w-3 h-3 mr-1" />
                      {t('course.outcomes')}
                    </div>
                    <ul className="text-xs text-muted-foreground space-y-0.5">
                      {course.outcomes[language]?.slice(0, 2).map((outcome, i) => (
                        <li key={`${course.id}-outcome-${i}`} className="flex items-start space-x-1">
                          <CheckCircle className="w-3 h-3 mt-0.5 text-green-500 flex-shrink-0" />
                          <span className="line-clamp-1">{outcome}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Progress Bar (if course is started) */}
                  {course.progress > 0 && (
                    <div className="space-y-2">
                      <div className="flex justify-between text-xs">
                        <span className="text-muted-foreground flex items-center space-x-1">
                          <CheckCircle className="w-3 h-3 text-green-500" />
                          <span>{t('course.progress')}</span>
                        </span>
                        <span className="font-medium">{course.progress}%</span>
                      </div>
                      <Progress value={course.progress} className="h-2" />
                    </div>
                  )}
                </CardContent>

                <CardFooter className="pt-3">
                  <Button 
                    key={`${course.id}-${language}`}
                    className={`w-full transition-all duration-300 ${
                      course.progress > 0 
                        ? 'bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white' 
                        : 'bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white'
                    }`}
                    variant="default"
                    onClick={() => handleCourseSelect(course.id)}
                  >
                    {course.progress > 0 ? (
                      <>
                        <Play className="w-4 h-4 mr-2" />
                        {t('course.continue')}
                      </>
                    ) : (
                      <>
                        <BookOpen className="w-4 h-4 mr-2" />
                        {t('course.start')}
                      </>
                    )}
                  </Button>
                </CardFooter>
                </Card>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}