import { DollarSign, Target, TrendingUp, BarChart3, LineChart, Coins, ShieldCheck, Zap, Heart, Coffee, Brain } from 'lucide-react'

export const personalFinanceSlides = [
  {
    title: { 
      tr: 'Kişisel Finans Nedir?', 
      en: 'What is Personal Finance?', 
      es: '¿Qué son las Finanzas Personales?', 
      fr: 'Qu\'est-ce que la Finance Personnelle?', 
      ru: 'Что такое личные финансы?' 
    },
    content: { 
      tr: [
        '• Kişisel finans, aylık gelirinizi (25.000-50.000 TL maaş, yan gelir, yatırım getirisi) planlı şekilde yönetmek, günlük harcamalarınızı (market 4.000 TL, faturalar 2.500 TL, ulaşım 800 TL) kontrol altında tutmak, tasarruf hedefleri belirleyerek düzenli para biriktirmek ve uzun vadeli finansal güvenlik için akıllı yatırımlar yapmak anlamına gelir',
        '• Temel prensipler: Her ay Gelir > Gider dengesini korumak (örn: 40.000 TL gelir varsa 32.000 TL harcayıp 8.000 TL biriktirmek), 1-5-10 yıllık finansal hedefler belirlemek (tatil, ev, emeklilik) ve beklenmedik durumlar için risk yönetimi yaparak kendimizi korumak',
        '• Finansal özgürlük sağlar: Kredi kartı borcu, tüketici kredisi gibi yüksek faizli borçlarınız olmadığında, iş yerinde baskı hissetmeden "hayır" diyebilir, hobilerinize zaman ayırabilir ve istediğiniz hayat tarzını sürdürebilirsiniz',
        '• Stres azaltır: Mali güvenlik sayesinde fatura ödeme endişesi yaşamaz, ani masraflar (araba tamiri 8.000 TL, sağlık gideri 5.000 TL) karşısında panik yapmaz, gelecek planları konusunda kendine güvenir ve daha mutlu, huzurlu bir yaşam sürersiniz'
      ],
      en: [
        '• Personal finance means managing your monthly income ($6,000-$12,000 salary, side income, investment returns) in a planned manner, controlling daily expenses (groceries $1,200, bills $800, transportation $400), setting savings goals and making smart investments for long-term financial security',
        '• Basic principles: Maintain Income > Expenses balance each month (e.g., $8,000 income spend $6,400 save $1,600), set 1-5-10 year financial goals (vacation, house, retirement), and manage risks for protection against unexpected situations',
        '• Provides financial freedom: When you have no high-interest debt like credit cards or consumer loans, you can say "no" at work without pressure, spend time on hobbies, and maintain your desired lifestyle',
        '• Reduces stress: Financial security means no bill payment anxiety, no panic over sudden expenses (car repair $2,500, medical bills $1,500), confidence in future plans, and a happier, more peaceful life'
      ],
      es: [
        '• Las finanzas personales significan gestionar tus ingresos mensuales (€2,500-€5,000 salario, ingresos secundarios, retornos de inversión) de manera planificada, controlar gastos diarios (supermercado €700, facturas €400, transporte €180), establecer objetivos de ahorro y hacer inversiones inteligentes para seguridad financiera a largo plazo',
        '• Principios básicos: Mantener balance Ingresos > Gastos cada mes (ej: €4,000 ingresos gastar €3,200 ahorrar €800), establecer objetivos financieros de 1-5-10 años (vacaciones, casa, jubilación), y gestionar riesgos para protección contra situaciones inesperadas',
        '• Proporciona libertad financiera: Cuando no tienes deudas de alto interés como tarjetas de crédito o préstamos al consumidor, puedes decir "no" en el trabajo sin presión, dedicar tiempo a aficiones y mantener el estilo de vida deseado',
        '• Reduce el estrés: La seguridad financiera significa no tener ansiedad por pagar facturas, no entrar en pánico por gastos súbitos (reparación auto €1,800, gastos médicos €1,200), confianza en planes futuros y una vida más feliz y tranquila'
      ],
      fr: [
        '• La finance personnelle signifie gérer vos revenus mensuels (€3,000-€6,000 salaire, revenus secondaires, retours d\'investissement) de manière planifiée, contrôler les dépenses quotidiennes (courses €800, factures €450, transport €200), fixer des objectifs d\'épargne et faire des investissements intelligents pour la sécurité financière à long terme',
        '• Principes de base: Maintenir l\'équilibre Revenus > Dépenses chaque mois (ex: €4,500 revenus dépenser €3,600 épargner €900), fixer des objectifs financiers de 1-5-10 ans (vacances, maison, retraite), et gérer les risques pour se protéger contre les situations imprévues',
        '• Fournit la liberté financière: Quand vous n\'avez pas de dettes à taux élevé comme les cartes de crédit ou prêts à la consommation, vous pouvez dire "non" au travail sans pression, consacrer du temps aux loisirs et maintenir le style de vie souhaité',
        '• Réduit le stress: La sécurité financière signifie pas d\'anxiété pour payer les factures, pas de panique face aux dépenses soudaines (réparation auto €2,000, frais médicaux €1,400), confiance dans les projets d\'avenir et une vie plus heureuse et paisible'
      ],
      ru: [
        '• Личные финансы означают управление ежемесячными доходами (80,000-150,000 руб зарплата, дополнительные доходы, инвестиционные доходы) планомерно, контроль ежедневных расходов (продукты 25,000 руб, счета 15,000 руб, транспорт 5,000 руб), постановка целей сбережений и умные инвестиции для долгосрочной финансовой безопасности',
        '• Основные принципы: Поддерживать баланс Доходы > Расходы каждый месяц (напр: 120,000 руб доход тратить 96,000 откладывать 24,000), ставить финансовые цели на 1-5-10 лет (отпуск, дом, пенсия), и управлять рисками для защиты от неожиданных ситуаций',
        '• Обеспечивает финансовую свободу: Когда у вас нет высокопроцентных долгов как кредитные карты или потребительские кредиты, вы можете сказать "нет" на работе без давления, тратить время на хобби и поддерживать желаемый образ жизни',
        '• Снижает стресс: Финансовая безопасность означает отсутствие беспокойства о счетах, отсутствие паники от внезапных расходов (ремонт авто 80,000 руб, медицинские счета 50,000 руб), уверенность в будущих планах и более счастливую, мирную жизнь'
      ]
    },
    example: { 
      tr: '💡 2025\'te Türkiye\'de enflasyon %47 seviyesindeyken, ortalama bir aile kişisel finans planı yaparak reel bazda yıllık %8 tasarruf artışı sağladı (kaynak: TÜİK raporları).',
      en: '💡 In 2025, while inflation in the US was around 3.2%, an average family achieved 6% annual savings growth by making a personal finance plan against inflation (source: Federal Reserve reports).',
      es: '💡 En 2025, mientras la inflación en España rondaba el 2.8%, una familia promedio logró un crecimiento del 5% en ahorros anuales haciendo un plan de finanzas personales contra la inflación (fuente: Banco de España).',
      fr: '💡 En 2025, alors que l\'inflation en France était d\'environ 2.5%, une famille moyenne a réalisé une croissance de 4.8% d\'épargne annuelle en élaborant un plan de finance personnelle contre l\'inflation (source: Banque de France).',
      ru: '💡 В 2025 году, когда инфляция в России была около 6.5%, средняя семья добилась 9% годового роста сбережений, составив план личных финансов против инфляции (источник: Центробанк РФ).'
    },
    icon: <DollarSign className="w-16 h-16 text-green-500" />,
  },
  {
    title: { 
      tr: 'Finansal Hedefler Belirleme', 
      en: 'Setting Financial Goals', 
      es: 'Establecer Objetivos Financieros', 
      fr: 'Fixer des Objectifs Financiers', 
      ru: 'Постановка финансовых целей' 
    },
    content: { 
      tr: [
        '• Kısa vadeli hedefler (6-12 ay): Yıllık tatil için 35.000 TL biriktirmek, 3 aylık acil fon oluşturmak (90.000 TL), yeni telefon/laptop almak (25.000-60.000 TL) gibi somut ve kısa sürede ulaşılabilir hedefler belirleyin',
        '• Orta vadeli hedefler (2-5 yıl): Ev peşinatı için 400.000-800.000 TL biriktirmek, sıfır araç almak için 1.200.000 TL bütçe oluşturmak, master eğitimi için 200.000 TL fon kurmak gibi önemli yaşam değişiklikleri için planlama yapın',
        '• Uzun vadeli hedefler (5+ yıl): Emeklilik için aylık 8.000 TL BES/yatırım yapmak, çocukların üniversite eğitimi için 800.000 TL fon oluşturmak, kendi işinizi kurmak için 2.000.000 TL sermaye biriktirmek gibi hayallerinizi gerçekleştirecek büyük hedefler koyun',
        '• SMART kuralı uygulaması: "1 yılda tatil için 42.000 TL biriktireceğim" → Spesifik (tatil), Ölçülebilir (42.000 TL), Ulaşılabilir (aylık 3.500 TL), İlgili (kişisel mutluluk), Zaman sınırlı (1 yıl) şeklinde net hedefler belirleyin'
      ],
      en: [
        '• Short-term goals (6-12 months): Save $8,000 for annual vacation, build 3-month emergency fund ($18,000), buy new phone/laptop ($1,500-$4,000) - concrete goals achievable in short time',
        '• Medium-term goals (2-5 years): Save $120,000-$200,000 for house down payment, budget $45,000-$65,000 for new car, create $35,000 fund for master\'s degree - plan for important life changes',
        '• Long-term goals (5+ years): Invest $1,200/month for retirement in 401k/IRA, create $250,000 education fund for children, save $500,000 capital to start your own business - big goals to realize your dreams',
        '• SMART rule application: "I will save $9,600 for vacation in 1 year" → Specific (vacation), Measurable ($9,600), Achievable ($800/month), Relevant (personal happiness), Time-bound (1 year)'
      ],
      es: [
        '• Objetivos a corto plazo (6-12 meses): Ahorrar €6,000 para vacaciones anuales, construir fondo de emergencia de 3 meses (€15,000), comprar nuevo teléfono/portátil (€1,200-€3,000) - objetivos concretos alcanzables en poco tiempo',
        '• Objetivos a mediano plazo (2-5 años): Ahorrar €80,000-€130,000 para enganche de casa, presupuestar €35,000-€55,000 para auto nuevo, crear fondo de €25,000 para máster - planificar cambios importantes de vida',
        '• Objetivos a largo plazo (5+ años): Invertir €800/mes para jubilación en planes de pensiones, crear fondo educativo de €180,000 para hijos, ahorrar €350,000 capital para iniciar negocio propio - grandes objetivos para realizar sueños',
        '• Aplicación regla SMART: "Ahorraré €7,200 para vacaciones en 1 año" → Específico (vacaciones), Medible (€7,200), Alcanzable (€600/mes), Relevante (felicidad personal), Con límite tiempo (1 año)'
      ],
      fr: [
        '• Objectifs à court terme (6-12 mois): Économiser €7,500 pour vacances annuelles, constituer fonds d\'urgence 3 mois (€18,000), acheter nouveau téléphone/ordinateur (€1,400-€3,500) - objectifs concrets atteignables rapidement',
        '• Objectifs à moyen terme (2-5 ans): Économiser €90,000-€150,000 pour acompte maison, budgéter €40,000-€60,000 pour voiture neuve, créer fonds €30,000 pour master - planifier changements vie importants',
        '• Objectifs à long terme (5+ ans): Investir €1,000/mois pour retraite dans PER/assurance-vie, créer fonds éducation €200,000 pour enfants, économiser €400,000 capital pour créer entreprise - grands objectifs réaliser rêves',
        '• Application règle SMART: "J\'économiserai €8,400 pour vacances en 1 an" → Spécifique (vacances), Mesurable (€8,400), Atteignable (€700/mois), Pertinent (bonheur personnel), Temporellement défini (1 an)'
      ],
      ru: [
        '• Краткосрочные цели (6-12 месяцев): Накопить 400,000 руб на годовой отпуск, создать фонд экстренных ситуаций на 3 месяца (1,200,000 руб), купить новый телефон/ноутбук (80,000-200,000 руб) - конкретные цели, достижимые за короткое время',
        '• Среднесрочные цели (2-5 лет): Накопить 5,000,000-8,000,000 руб для первоначального взноса за дом, заложить 3,500,000-5,500,000 руб на новую машину, создать фонд 1,500,000 руб для магистратуры - планирование важных жизненных изменений',
        '• Долгосрочные цели (5+ лет): Инвестировать 60,000 руб/месяц для пенсии в ИИС/НПФ, создать образовательный фонд 12,000,000 руб для детей, накопить 25,000,000 руб капитала для старта собственного бизнеса - большие цели для реализации мечт',
        '• Применение правила SMART: "Я накоплю 480,000 руб на отпуск за 1 год" → Конкретный (отпуск), Измеримый (480,000 руб), Достижимый (40,000 руб/месяц), Релевантный (личное счастье), Ограниченный по времени (1 год)'
      ]
    },
    example: { 
      tr: '🎯 2025\'te Türkiye\'de gençler, ev alma hedefi için aylık 15.000 TL biriktirerek 5 yılda %20 peş ödemesi topluyor; örneğin, bir yazılımcı bu yöntemle İstanbul\'da daire aldı.',
      en: '🎯 In 2025, young Americans save $2,000/month for home buying goal, collecting 20% down payment in 5 years; for example, a software developer bought a condo in Austin with this method.',
      es: '🎯 En 2025, jóvenes españoles ahorran €1,300/mes para objetivo de comprar casa, acumulando 20% de enganche en 5 años; por ejemplo, un desarrollador de software compró un piso en Madrid con este método.',
      fr: '🎯 En 2025, les jeunes français économisent €1,500/mois pour objectif d\'achat maison, accumulant 20% d\'acompte en 5 ans; par exemple, un développeur logiciel a acheté un appartement à Lyon avec cette méthode.',
      ru: '🎯 В 2025 году молодые россияне откладывают 100,000 руб/месяц для цели покупки дома, накапливая 20% первоначального взноса за 5 лет; например, разработчик ПО купил квартиру в Москве этим методом.'
    },
    icon: <Target className="w-16 h-16 text-blue-500" />,
  },
  {
    title: { 
      tr: 'Gelir Kaynaklarını Çeşitlendirme', 
      en: 'Diversifying Income Sources', 
      es: 'Diversificar Fuentes de Ingresos', 
      fr: 'Diversifier les Sources de Revenus', 
      ru: 'Диверсификация источников дохода' 
    },
    content: { 
      tr: [
        '• Ana gelir kaynağı: Tam zamanlı işinizden aldığınız aylık net maaş (örn: 30.000-60.000 TL), kendi işinizden elde ettiğiniz düzenli aylık gelir veya ortaklık payları. Bu gelir yaşam giderlerinizin %80\'ini karşılamalı',
        '• Yan gelir kaynakları: Akşam/hafta sonu freelance işleri (grafik tasarım, yazılım, çeviri), online ders verme, danışmanlık, e-ticaret mağazası işletme. Hedef: Ana gelirin %20-30\'u kadar ek gelir (6.000-15.000 TL)',
        '• Pasif gelir imkânları: Kiraladığınız daireden aylık gelir (8.000-20.000 TL), hisse senedi temettüleri (yıllık %8-15), vadeli hesap/tahvil faizi (yıllık %45-50), kitap/içerik royalty gelirleri. Uzun vadede ana gelirle eşitlenmeyi hedefleyin',
        '• Risk azaltma stratejisi: İş kaybı durumunda yan gelirleriniz temel ihtiyaçlarınızı karşılasın. Pasif gelirleriniz artarsa finansal bağımsızlığa yaklaşırsınız. 3 farklı gelir kaynağına sahip olmak ideal güvenlik sağlar'
      ],
      en: [
        '• Main income source: Monthly net salary from full-time job ($7,000-$14,000), regular monthly income from your business or partnership shares. This income should cover 80% of your living expenses',
        '• Side income sources: Evening/weekend freelance work (graphic design, software, translation), online tutoring, consulting, e-commerce store operation. Target: 20-30% additional income relative to main income ($1,400-$2,800)',
        '• Passive income opportunities: Monthly income from rental property ($2,500-$5,000), stock dividends (6-9% annually), savings account/bond interest (4-6% annually), book/content royalties. Aim to match main income long-term',
        '• Risk reduction strategy: In case of job loss, side incomes should cover basic needs. As passive income grows, you approach financial independence. Having 3 different income sources provides ideal security'
      ],
      es: [
        '• Fuente principal de ingresos: Salario neto mensual de trabajo tiempo completo (€3,500-€7,000), ingreso mensual regular de tu negocio o participaciones societarias. Este ingreso debe cubrir 80% de gastos de vida',
        '• Fuentes de ingresos secundarios: Trabajo freelance nocturno/fines de semana (diseño gráfico, software, traducción), tutoría online, consultoría, operación tienda e-commerce. Objetivo: 20-30% ingreso adicional relativo al principal (€700-€1,400)',
        '• Oportunidades ingresos pasivos: Ingreso mensual de propiedad alquilada (€1,500-€3,200), dividendos acciones (4-7% anual), interés cuenta ahorro/bonos (2-4% anual), regalías libros/contenido. Apuntar igualar ingreso principal largo plazo',
        '• Estrategia reducción riesgo: En caso pérdida empleo, ingresos secundarios deben cubrir necesidades básicas. Conforme crecen ingresos pasivos, te acercas independencia financiera. Tener 3 fuentes ingresos diferentes proporciona seguridad ideal'
      ],
      fr: [
        '• Source principale de revenus: Salaire net mensuel d\'emploi temps plein (€4,000-€8,000), revenus mensuels réguliers de votre entreprise ou parts de partenariat. Ce revenu devrait couvrir 80% de vos dépenses de vie',
        '• Sources de revenus secondaires: Travail freelance soir/week-end (design graphique, logiciel, traduction), tutorat en ligne, conseil, exploitation boutique e-commerce. Objectif: 20-30% revenus supplémentaires par rapport au principal (€800-€1,600)',
        '• Opportunités revenus passifs: Revenus mensuels de propriété locative (€1,800-€3,800), dividendes actions (3-6% annuel), intérêts compte épargne/obligations (2-4% annuel), redevances livres/contenu. Viser égaler revenu principal long terme',
        '• Stratégie réduction risque: En cas perte emploi, revenus secondaires devraient couvrir besoins basiques. À mesure que revenus passifs croissent, vous approchez indépendance financière. Avoir 3 sources revenus différentes fournit sécurité idéale'
      ],
      ru: [
        '• Основной источник дохода: Ежемесячная чистая зарплата с работы полный день (150,000-300,000 руб), регулярный месячный доход от собственного бизнеса или долей в партнерстве. Этот доход должен покрывать 80% ваших жизненных расходов',
        '• Побочные источники дохода: Вечерняя/выходная фриланс работа (графический дизайн, программирование, переводы), онлайн репетиторство, консультации, управление интернет-магазином. Цель: 20-30% дополнительного дохода относительно основного (30,000-60,000 руб)',
        '• Возможности пассивного дохода: Ежемесячный доход от сдачи жилья (80,000-180,000 руб), дивиденды по акциям (8-12% годовых), проценты по депозитам/облигациям (15-20% годовых), роялти от книг/контента. Стремитесь сравняться с основным доходом долгосрочно',
        '• Стратегия снижения рисков: В случае потери работы побочные доходы должны покрывать базовые потребности. По мере роста пассивных доходов приближаетесь к финансовой независимости. Наличие 3 разных источников дохода обеспечивает идеальную безопасность'
      ]
    },
    example: { 
      tr: '💼 2025\'te freelance platformlarında (Upwork) çalışanlar, ana maaşlarına ek %30 gelir elde ediyor; örneğin, bir grafik tasarımcı aylık 12.000 TL ekstra kazanıyor.',
      en: '💼 In 2025, workers on freelance platforms (Upwork) earn 30% additional income on top of their main salaries; for example, a graphic designer earns an extra $2,400 monthly.',
      es: '💼 En 2025, trabajadores en plataformas freelance (Upwork) obtienen 30% ingresos adicionales sobre sus salarios principales; por ejemplo, un diseñador gráfico gana €1,800 extra mensualmente.',
      fr: '💼 En 2025, les travailleurs sur plateformes freelance (Upwork) gagnent 30% revenus supplémentaires en plus de leurs salaires principaux; par exemple, un graphiste gagne €2,100 supplémentaires mensuellement.',
      ru: '💼 В 2025 году работники на фриланс-платформах (Upwork) получают 30% дополнительного дохода сверх основной зарплаты; например, графический дизайнер зарабатывает дополнительно 120,000 руб в месяц.'
    },
    icon: <TrendingUp className="w-16 h-16 text-purple-500" />,
  }
]