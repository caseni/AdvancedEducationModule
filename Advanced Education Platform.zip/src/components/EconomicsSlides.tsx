import { Lightbulb, TrendingUp, BarChart3, Target, LineChart, DollarSign, Trophy, Brain, Globe, Users, Activity, Zap, Coffee, HeartHandshake, Star, Building, Layers, Eye, Building2, BookOpen } from 'lucide-react'

export const economicsSlides = [
  {
    title: { 
      tr: 'Ekonomi Nedir?', 
      en: 'What is Economics?', 
      es: '¿Qué es la Economía?', 
      fr: 'Qu\'est-ce que l\'Économie?', 
      ru: 'Что такое экономика?' 
    },
    content: { 
      tr: [
        '• Ekonomi, sınırlı olan kaynaklarımızı (para, zaman, emek) sınırsız ihtiyaçlarımızı karşılamak için nasıl kullandığımızı inceleyen bir bilimdir.',
        '• Her seçim, başka bir şeyden vazgeçmek anlamına gelir. Buna "fırsat maliyeti" denir.',
        '• Ekonominin amacı, kaynakları en verimli şekilde kullanarak hem bireylerin hem toplumun refahını artırmaktır.',
        '• Günlük hayatta bütçe yaparken, devletler de politika belirlerken ekonomiyi kullanır.'
      ],
      en: [
        '• Economics studies how we use limited resources (money, time, labor) to meet unlimited needs.',
        '• Every choice means giving up something else. This is called "opportunity cost".',
        '• The goal of economics is to increase both individual and societal welfare by using resources most efficiently.',
        '• Individuals use it for budgeting, governments use it for policy making.'
      ],
      es: [
        '• La economía estudia cómo usamos recursos limitados (dinero, tiempo, trabajo) para satisfacer necesidades ilimitadas.',
        '• Cada elección significa renunciar a algo más. Esto se llama "costo de oportunidad".',
        '• El objetivo de la economía es aumentar el bienestar individual y social usando recursos de manera más eficiente.',
        '• Los individuos la usan para presupuestar, los gobiernos para hacer políticas.'
      ],
      fr: [
        '• L\'économie étudie comment nous utilisons des ressources limitées (argent, temps, travail) pour répondre à des besoins illimités.',
        '• Chaque choix signifie renoncer à autre chose. Cela s\'appelle "coût d\'opportunité".',
        '• L\'objectif de l\'économie est d\'augmenter le bien-être individuel et social en utilisant les ressources de manière plus efficace.',
        '• Les individus l\'utilisent pour budgétiser, les gouvernements pour faire des politiques.'
      ],
      ru: [
        '• Экономика изучает, как мы используем ограниченные ресурсы (деньги, время, труд) для удовлетворения неограниченных потребностей.',
        '• Каждый выбор означает отказ от чего-то другого. Это называется "альтернативной стоимостью".',
        '• Цель экономики - повысить индивидуальное и социальное благосостояние, эффективно используя ресурсы.',
        '• Люди используют ее для составления бюджета, правительства - для выработки политики.'
      ]
    },
    example: { 
      tr: '🎯 Telefon almak için 5000 TL harcarsanız, o parayla tatile gidemezsiniz - bu fırsat maliyetidir.',
      en: '🎯 If you spend 5000 TL on a phone, you can\'t go on vacation with that money - this is opportunity cost.',
      es: '🎯 Si gastas 5000 TL en un teléfono, no puedes ir de vacaciones con ese dinero - esto es costo de oportunidad.',
      fr: '🎯 Si vous dépensez 5000 TL pour un téléphone, vous ne pouvez pas partir en vacances avec cet argent - c\'est le coût d\'opportunité.',
      ru: '🎯 Если вы потратите 5000 лир на телефон, вы не сможете поехать в отпуск на эти деньги - это альтернативная стоимость.'
    },
    icon: <Lightbulb className="w-16 h-16 text-yellow-500" />
  },
  {
    title: { 
      tr: 'Mikroekonomi ve Makroekonomi', 
      en: 'Microeconomics and Macroeconomics', 
      es: 'Microeconomía y Macroeconomía', 
      fr: 'Microéconomie et Macroéconomie', 
      ru: 'Микроэкономика и макроэкономика' 
    },
    content: { 
      tr: [
        '• Mikroekonomi, bireylerin, ailelerin ve şirketlerin nasıl karar verdiğine bakar. Örneğin bir firmanın fiyat belirlemesi.',
        '• Makroekonomi ise tüm ülke ekonomisini inceler: büyüme, enflasyon, işsizlik gibi göstergelere odaklanır.',
        '• Kısacası, mikro ağaçları, makro ise ormanı görmektir.'
      ],
      en: [
        '• Microeconomics looks at how individuals, families and companies make decisions. For example, a firm\'s pricing.',
        '• Macroeconomics examines the entire country\'s economy: focuses on indicators like growth, inflation, unemployment.',
        '• In short, micro sees the trees, macro sees the forest.'
      ],
      es: [
        '• La microeconomía examina cómo los individuos, familias y empresas toman decisiones. Por ejemplo, la fijación de precios de una empresa.',
        '• La macroeconomía examina toda la economía del país: se enfoca en indicadores como crecimiento, inflación, desempleo.',
        '• En resumen, micro ve los árboles, macro ve el bosque.'
      ],
      fr: [
        '• La microéconomie examine comment les individus, familles et entreprises prennent des décisions. Par exemple, la fixation des prix d\'une entreprise.',
        '• La macroéconomie examine toute l\'économie du pays: se concentre sur des indicateurs comme la croissance, l\'inflation, le chômage.',
        '• En bref, micro voit les arbres, macro voit la forêt.'
      ],
      ru: [
        '• Микроэкономика изучает, как принимают решения отдельные люди, семьи и компании. Например, ценообразование фирмы.',
        '• Макроэкономика изучает всю экономику страны: фокусируется на показателях, таких как рост, инфляция, безработица.',
        '• Короче говоря, микро видит деревья, макро видит лес.'
      ]
    },
    example: { 
      tr: '🔍 Bir kafe sahibi kahve fiyatını artırması mikroekonomi; tüm ülkede kahve fiyatlarının artması makroekonomi.',
      en: '🔍 A cafe owner raising coffee prices is microeconomics; coffee prices rising across the country is macroeconomics.',
      es: '🔍 Un dueño de café subiendo precios es microeconomía; precios de café subiendo en todo el país es macroeconomía.',
      fr: '🔍 Un propriétaire de café augmentant les prix est microéconomie; les prix du café augmentant dans tout le pays est macroéconomie.',
      ru: '🔍 Владелец кафе, повышающий цены на кофе - это микроэкономика; рост цен на кофе по всей стране - это макроэкономика.'
    },
    icon: <TrendingUp className="w-16 h-16 text-purple-500" />
  },
  {
    title: { 
      tr: 'Arz ve Talep', 
      en: 'Supply and Demand', 
      es: 'Oferta y Demanda', 
      fr: 'Offre et Demande', 
      ru: 'Спрос и предложение' 
    },
    content: { 
      tr: [
        '• Talep yasasına göre, fiyat düştükçe insanlar daha çok satın almak ister.',
        '• Arz yasasına göre ise, fiyat yükseldikçe üreticiler daha çok üretir.',
        '• Bu iki güç piyasada bir denge noktası bulur: "denge fiyatı".',
        '• Örneğin, ekmek fiyatı çok yükselirse talep azalır, üretici daha az satar; fiyat düşünce denge yeniden kurulur.'
      ],
      en: [
        '• According to demand law, as price falls, people want to buy more.',
        '• According to supply law, as price rises, producers want to produce more.',
        '• These two forces find an equilibrium point in the market: "equilibrium price".',
        '• For example, if bread price rises too much, demand decreases, producer sells less; when price falls, equilibrium is restored.'
      ],
      es: [
        '• Según la ley de demanda, cuando baja el precio, la gente quiere comprar más.',
        '• Según la ley de oferta, cuando sube el precio, los productores quieren producir más.',
        '• Estas dos fuerzas encuentran un punto de equilibrio en el mercado: "precio de equilibrio".',
        '• Por ejemplo, si el precio del pan sube mucho, la demanda disminuye, el productor vende menos; cuando baja el precio, se restaura el equilibrio.'
      ],
      fr: [
        '• Selon la loi de la demande, quand le prix baisse, les gens veulent acheter plus.',
        '• Selon la loi de l\'offre, quand le prix monte, les producteurs veulent produire plus.',
        '• Ces deux forces trouvent un point d\'équilibre sur le marché: "prix d\'équilibre".',
        '• Par exemple, si le prix du pain monte trop, la demande diminue, le producteur vend moins; quand le prix baisse, l\'équilibre est restauré.'
      ],
      ru: [
        '• Согласно закону спроса, когда цена падает, люди хотят покупать больше.',
        '• Согласно закону предложения, когда цена растет, производители хотят производить больше.',
        '• Эти две силы находят точку равновесия на рынке: "равновесная цена".',
        '• Например, если цена на хлеб слишком поднимется, спрос уменьшится, производитель продаст меньше; когда цена падает, равновесие восстанавливается.'
      ]
    },
    example: { 
      tr: '🍎 Elma hasadı bol olunca fiyatlar düşer, herkes daha çok elma alır - arz ve talep dengesi.',
      en: '🍎 When apple harvest is abundant, prices fall, everyone buys more apples - supply and demand balance.',
      es: '🍎 Cuando la cosecha de manzanas es abundante, los precios bajan, todos compran más manzanas - equilibrio de oferta y demanda.',
      fr: '🍎 Quand la récolte de pommes est abondante, les prix baissent, tout le monde achète plus de pommes - équilibre offre et demande.',
      ru: '🍎 Когда урожай яблок обильный, цены падают, все покупают больше яблок - баланс спроса и предложения.'
    },
    icon: <BarChart3 className="w-16 h-16 text-blue-500" />
  },
  {
    title: { 
      tr: 'Piyasa Dengesi ve Değişimler', 
      en: 'Market Equilibrium and Changes', 
      es: 'Equilibrio de Mercado y Cambios', 
      fr: 'Équilibre de Marché et Changements', 
      ru: 'Рыночное равновесие и изменения' 
    },
    content: { 
      tr: [
        '• Arz ve talep sürekli değiştiği için denge fiyatı da değişir.',
        '• Devlet bazen tavan fiyat (örneğin kira sınırlaması) veya taban fiyat (örneğin tarım destekleri) belirleyerek piyasaya müdahale eder.',
        '• Bu müdahaleler bazen kıtlık, bazen fazlalık yaratabilir.'
      ],
      en: [
        '• Since supply and demand constantly change, equilibrium price also changes.',
        '• Government sometimes intervenes in the market by setting price ceiling (e.g. rent control) or price floor (e.g. agricultural supports).',
        '• These interventions can sometimes create shortage, sometimes surplus.'
      ],
      es: [
        '• Como la oferta y demanda cambian constantemente, el precio de equilibrio también cambia.',
        '• El gobierno a veces interviene en el mercado estableciendo techo de precios (ej. control de alquiler) o precio mínimo (ej. apoyos agrícolas).',
        '• Estas intervenciones a veces pueden crear escasez, a veces excedente.'
      ],
      fr: [
        '• Comme l\'offre et la demande changent constamment, le prix d\'équilibre change aussi.',
        '• Le gouvernement intervient parfois sur le marché en fixant un plafond de prix (ex. contrôle des loyers) ou un prix plancher (ex. soutiens agricoles).',
        '• Ces interventions peuvent parfois créer une pénurie, parfois un surplus.'
      ],
      ru: [
        '• Поскольку спрос и предложение постоянно меняются, равновесная цена также меняется.',
        '• Правительство иногда вмешивается в рынок, устанавливая потолок цен (например, контроль арендной платы) или минимальную цену (например, сельскохозяйственные субсидии).',
        '• Эти вмешательства иногда могут создавать дефицит, иногда избыток.'
      ]
    },
    example: { 
      tr: '🏠 Devlet kira tavanı koyarsa ev sahipleri kiraya vermek istemez, ev kıtlığı olur.',
      en: '🏠 If government sets rent ceiling, landlords don\'t want to rent out, housing shortage occurs.',
      es: '🏠 Si el gobierno establece techo de alquiler, los propietarios no quieren alquilar, ocurre escasez de vivienda.',
      fr: '🏠 Si le gouvernement fixe un plafond de loyer, les propriétaires ne veulent pas louer, une pénurie de logements se produit.',
      ru: '🏠 Если правительство установит потолок арендной платы, арендодатели не захотят сдавать в аренду, возникнет дефицит жилья.'
    },
    icon: <Target className="w-16 h-16 text-green-500" />
  },
  {
    title: { 
      tr: 'Esneklik (Elastikiyet)', 
      en: 'Elasticity', 
      es: 'Elasticidad', 
      fr: 'Élasticité', 
      ru: 'Эластичность' 
    },
    content: { 
      tr: [
        '• Bir ürünün fiyatı değiştiğinde talep ne kadar değişiyor?',
        '• Fiyat artınca talep çok az değişiyorsa ürün "esnek değil" (örneğin benzin).',
        '• Fiyat artınca talep hızla düşüyorsa ürün "esnek" (örneğin lüks tatil).',
        '• Bu bilgi hem şirketler hem devletler için önemlidir çünkü fiyatlama ve vergi politikalarını etkiler.'
      ],
      en: [
        '• How much does demand change when a product\'s price changes?',
        '• If demand changes very little when price increases, product is "inelastic" (e.g. gasoline).',
        '• If demand drops rapidly when price increases, product is "elastic" (e.g. luxury vacation).',
        '• This information is important for both companies and governments as it affects pricing and tax policies.'
      ],
      es: [
        '• ¿Cuánto cambia la demanda cuando cambia el precio de un producto?',
        '• Si la demanda cambia muy poco cuando sube el precio, el producto es "inelástico" (ej. gasolina).',
        '• Si la demanda baja rápidamente cuando sube el precio, el producto es "elástico" (ej. vacaciones de lujo).',
        '• Esta información es importante tanto para empresas como gobiernos ya que afecta las políticas de precios e impuestos.'
      ],
      fr: [
        '• Combien la demande change-t-elle quand le prix d\'un produit change?',
        '• Si la demande change très peu quand le prix augmente, le produit est "inélastique" (ex. essence).',
        '• Si la demande chute rapidement quand le prix augmente, le produit est "élastique" (ex. vacances de luxe).',
        '• Cette information est importante pour les entreprises et gouvernements car elle affecte les politiques de prix et d\'impôts.'
      ],
      ru: [
        '• Насколько изменяется спрос при изменении цены товара?',
        '• Если спрос изменяется очень мало при росте цены, товар "неэластичный" (например, бензин).',
        '• Если спрос быстро падает при росте цены, товар "эластичный" (например, роскошный отпуск).',
        '• Эта информация важна как для компаний, так и для правительств, поскольку влияет на ценовую и налоговую политику.'
      ]
    },
    example: { 
      tr: '⛽ Benzin fiyatı %10 artsa bile insanlar arabalarını kullanmaya devam eder - esnek değil.',
      en: '⛽ Even if gasoline price increases 10%, people continue using their cars - inelastic.',
      es: '⛽ Incluso si el precio de la gasolina aumenta 10%, la gente sigue usando sus autos - inelástico.',
      fr: '⛽ Même si le prix de l\'essence augmente de 10%, les gens continuent d\'utiliser leurs voitures - inélastique.',
      ru: '⛽ Даже если цена на бензин вырастет на 10%, люди продолжают пользоваться автомобилями - неэластично.'
    },
    icon: <LineChart className="w-16 h-16 text-orange-500" />
  },
  {
    title: { 
      tr: 'Üretim ve Maliyetler', 
      en: 'Production and Costs', 
      es: 'Producción y Costos', 
      fr: 'Production et Coûts', 
      ru: 'Производство и затраты' 
    },
    content: { 
      tr: [
        '• Şirketler üretim yaparken sabit giderler (kira gibi) ve değişken giderler (ham madde gibi) olur.',
        '• Her ek üretim, bir "ekstra maliyet" doğurur.',
        '• Belli bir noktaya kadar üretim büyüdükçe maliyetler düşer (ölçek ekonomisi), ama bir noktadan sonra tekrar yükselmeye başlar.'
      ],
      en: [
        '• When companies produce, they have fixed costs (like rent) and variable costs (like raw materials).',
        '• Each additional production creates an "extra cost".',
        '• Up to a certain point, as production grows, costs decrease (economies of scale), but after a point they start rising again.'
      ],
      es: [
        '• Cuando las empresas producen, tienen costos fijos (como alquiler) y costos variables (como materias primas).',
        '• Cada producción adicional crea un "costo extra".',
        '• Hasta cierto punto, a medida que crece la producción, los costos disminuyen (economías de escala), pero después de un punto empiezan a subir de nuevo.'
      ],
      fr: [
        '• Quand les entreprises produisent, elles ont des coûts fixes (comme le loyer) et des coûts variables (comme les matières premières).',
        '• Chaque production supplémentaire crée un "coût supplémentaire".',
        '• Jusqu\'à un certain point, à mesure que la production augmente, les coûts diminuent (économies d\'échelle), mais après un point ils recommencent à augmenter.'
      ],
      ru: [
        '• При производстве у компаний есть постоянные затраты (как аренда) и переменные затраты (как сырье).',
        '• Каждое дополнительное производство создает "дополнительные затраты".',
        '• До определенного момента, по мере роста производства, затраты снижаются (эффект масштаба), но после определенного момента они снова начинают расти.'
      ]
    },
    example: { 
      tr: '🏭 Küçük bir fırın günde 100 ekmek yapıyorsa her ekmek 5 TL, 1000 ekmek yapıyorsa 3 TL olur.',
      en: '🏭 If a small bakery makes 100 breads per day, each bread costs 5 TL, if it makes 1000 breads, it becomes 3 TL.',
      es: '🏭 Si una panadería pequeña hace 100 panes por día, cada pan cuesta 5 TL, si hace 1000 panes, se vuelve 3 TL.',
      fr: '🏭 Si une petite boulangerie fait 100 pains par jour, chaque pain coûte 5 TL, si elle fait 1000 pains, cela devient 3 TL.',
      ru: '🏭 Если небольшая пекарня делает 100 хлебов в день, каждый хлеб стоит 5 лир, если делает 1000 хлебов, становится 3 лиры.'
    },
    icon: <DollarSign className="w-16 h-16 text-green-500" />
  },
  {
    title: { 
      tr: 'Piyasa Türleri', 
      en: 'Market Types', 
      es: 'Tipos de Mercado', 
      fr: 'Types de Marchés', 
      ru: 'Типы рынков' 
    },
    content: { 
      tr: [
        '• Tam Rekabet: Çok firma, benzer ürünler. Kimse fiyatı tek başına belirleyemez.',
        '• Monopol (Tekel): Tek satıcı, fiyatı kendi belirler.',
        '• Oligopol: Az sayıda büyük firma (örneğin teknoloji devleri).',
        '• Monopolcü Rekabet: Çok firma ama ürünler farklılaştırılmış (örneğin kahve markaları).'
      ],
      en: [
        '• Perfect Competition: Many firms, similar products. No one can determine price alone.',
        '• Monopoly: Single seller, determines price itself.',
        '• Oligopoly: Few large firms (e.g. technology giants).',
        '• Monopolistic Competition: Many firms but products are differentiated (e.g. coffee brands).'
      ],
      es: [
        '• Competencia Perfecta: Muchas empresas, productos similares. Nadie puede determinar el precio solo.',
        '• Monopolio: Vendedor único, determina el precio por sí mismo.',
        '• Oligopolio: Pocas empresas grandes (ej. gigantes tecnológicos).',
        '• Competencia Monopolística: Muchas empresas pero productos diferenciados (ej. marcas de café).'
      ],
      fr: [
        '• Concurrence Parfaite: Beaucoup d\'entreprises, produits similaires. Personne ne peut déterminer le prix seul.',
        '• Monopole: Vendeur unique, détermine le prix lui-même.',
        '• Oligopole: Peu de grandes entreprises (ex. géants technologiques).',
        '• Concurrence Monopolistique: Beaucoup d\'entreprises mais produits différenciés (ex. marques de café).'
      ],
      ru: [
        '• Совершенная конкуренция: Много фирм, похожие продукты. Никто не может определить цену в одиночку.',
        '• Монополия: Единственный продавец, сам определяет цену.',
        '• Олигополия: Несколько крупных фирм (например, технологические гиганты).',
        '• Монополистическая конкуренция: Много фирм, но продукты дифференцированы (например, кофейные бренды).'
      ]
    },
    example: { 
      tr: '📱 Telefon piyasası oligopol - Apple, Samsung gibi az sayıda dev firma var.',
      en: '📱 Phone market is oligopoly - there are few giant firms like Apple, Samsung.',
      es: '📱 El mercado de teléfonos es oligopolio - hay pocas empresas gigantes como Apple, Samsung.',
      fr: '📱 Le marché des téléphones est un oligopole - il y a peu d\'entreprises géantes comme Apple, Samsung.',
      ru: '📱 Рынок телефонов - это олигополия - есть несколько гигантских фирм, таких как Apple, Samsung.'
    },
    icon: <Trophy className="w-16 h-16 text-yellow-500" />
  },
  {
    title: { 
      tr: 'Milli Gelir (GSYH)', 
      en: 'National Income (GDP)', 
      es: 'Ingreso Nacional (PIB)', 
      fr: 'Revenu National (PIB)', 
      ru: 'Национальный доход (ВВП)' 
    },
    content: { 
      tr: [
        '• Bir ülkenin bir yılda ürettiği tüm mal ve hizmetlerin toplam değeridir.',
        '• GSYH büyüdükçe ekonomi büyüyor demektir.',
        '• Kişi başına düşen GSYH, o ülkedeki yaşam standartlarını gösterir ama gelir dağılımını ölçmez.'
      ],
      en: [
        '• It is the total value of all goods and services produced by a country in one year.',
        '• As GDP grows, it means the economy is growing.',
        '• GDP per capita shows living standards in that country but doesn\'t measure income distribution.'
      ],
      es: [
        '• Es el valor total de todos los bienes y servicios producidos por un país en un año.',
        '• A medida que crece el PIB, significa que la economía está creciendo.',
        '• El PIB per cápita muestra estándares de vida en ese país pero no mide la distribución del ingreso.'
      ],
      fr: [
        '• C\'est la valeur totale de tous les biens et services produits par un pays en une année.',
        '• À mesure que le PIB croît, cela signifie que l\'économie croît.',
        '• Le PIB par habitant montre les standards de vie dans ce pays mais ne mesure pas la distribution des revenus.'
      ],
      ru: [
        '• Это общая стоимость всех товаров и услуг, произведенных страной за один год.',
        '• По мере роста ВВП это означает, что экономика растет.',
        '• ВВП на душу населения показывает уровень жизни в этой стране, но не измеряет распределение доходов.'
      ]
    },
    example: { 
      tr: '🇹🇷 Türkiye\'nin 2024 GSYH\'si yaklaşık 900 milyar dolar, kişi başına 10.500 dolar.',
      en: '🇹🇷 Turkey\'s 2024 GDP is approximately 900 billion dollars, 10,500 dollars per capita.',
      es: '🇹🇷 El PIB de Turquía en 2024 es aproximadamente 900 mil millones de dólares, 10,500 dólares per cápita.',
      fr: '🇹🇷 Le PIB de la Turquie en 2024 est d\'environ 900 milliards de dollars, 10 500 dollars par habitant.',
      ru: '🇹🇷 ВВП Турции в 2024 году составляет примерно 900 миллиардов долларов, 10 500 долларов на душу населения.'
    },
    icon: <Brain className="w-16 h-16 text-blue-600" />
  },
  {
    title: { 
      tr: 'Ekonomik Büyümenin Kaynakları', 
      en: 'Sources of Economic Growth', 
      es: 'Fuentes del Crecimiento Económico', 
      fr: 'Sources de la Croissance Économique', 
      ru: 'Источники экономического роста' 
    },
    content: { 
      tr: [
        '• İnsanların eğitimli ve sağlıklı olması → verimlilik artar.',
        '• Fabrika, makine ve altyapı yatırımları → üretim kapasitesi artar.',
        '• Teknoloji ve yenilik → daha hızlı ve verimli üretim.',
        '• Güçlü kurumlar ve iyi kurallar → güven ortamı sağlar.'
      ],
      en: [
        '• People being educated and healthy → productivity increases.',
        '• Factory, machinery and infrastructure investments → production capacity increases.',
        '• Technology and innovation → faster and more efficient production.',
        '• Strong institutions and good rules → provide trust environment.'
      ],
      es: [
        '• Personas educadas y saludables → aumenta la productividad.',
        '• Inversiones en fábricas, maquinaria e infraestructura → aumenta la capacidad de producción.',
        '• Tecnología e innovación → producción más rápida y eficiente.',
        '• Instituciones fuertes y buenas reglas → proporcionan ambiente de confianza.'
      ],
      fr: [
        '• Personnes éduquées et en bonne santé → productivité augmente.',
        '• Investissements en usines, machines et infrastructure → capacité de production augmente.',
        '• Technologie et innovation → production plus rapide et efficace.',
        '• Institutions fortes et bonnes règles → fournissent environnement de confiance.'
      ],
      ru: [
        '• Образованные и здоровые люди → повышается производительность.',
        '• Инвестиции в фабрики, машины и инфраструктуру → увеличивается производственная мощность.',
        '• Технологии и инновации → более быстрое и эффективное производство.',
        '• Сильные институты и хорошие правила → обеспечивают доверительную среду.'
      ]
    },
    example: { 
      tr: '🎓 Güney Kore eğitime yatırım yaparak 1960\'lardan bugüne gelişmiş ülke oldu.',
      en: '🎓 South Korea became a developed country from the 1960s to today by investing in education.',
      es: '🎓 Corea del Sur se convirtió en un país desarrollado desde los años 60 hasta hoy invirtiendo en educación.',
      fr: '🎓 La Corée du Sud est devenue un pays développé des années 1960 à aujourd\'hui en investissant dans l\'éducation.',
      ru: '🎓 Южная Корея стала развитой страной с 1960-х годов до наших дней, инвестируя в образование.'
    },
    icon: <Activity className="w-16 h-16 text-green-600" />
  },
  {
    title: { 
      tr: 'Enflasyon ve Deflasyon', 
      en: 'Inflation and Deflation', 
      es: 'Inflación y Deflación', 
      fr: 'Inflation et Déflation', 
      ru: 'Инфляция и дефляция' 
    },
    content: { 
      tr: [
        '• Enflasyon: Fiyatların genel olarak sürekli artması.',
        '• Deflasyon: Fiyatların sürekli düşmesi.',
        '• Hafif enflasyon ekonomiye canlılık getirir ama aşırı enflasyon alım gücünü yok eder.',
        '• Merkez bankaları bu yüzden fiyat istikrarını sağlamaya çalışır.'
      ],
      en: [
        '• Inflation: General and continuous increase in prices.',
        '• Deflation: Continuous decrease in prices.',
        '• Mild inflation brings vitality to economy but excessive inflation destroys purchasing power.',
        '• Central banks therefore try to ensure price stability.'
      ],
      es: [
        '• Inflación: Aumento general y continuo de precios.',
        '• Deflación: Disminución continua de precios.',
        '• La inflación leve trae vitalidad a la economía pero la inflación excesiva destruye el poder adquisitivo.',
        '• Los bancos centrales por lo tanto tratan de asegurar estabilidad de precios.'
      ],
      fr: [
        '• Inflation: Augmentation générale et continue des prix.',
        '• Déflation: Diminution continue des prix.',
        '• L\'inflation légère apporte vitalité à l\'économie mais l\'inflation excessive détruit le pouvoir d\'achat.',
        '• Les banques centrales essaient donc d\'assurer la stabilité des prix.'
      ],
      ru: [
        '• Инфляция: Общий и непрерывный рост цен.',
        '• Дефляция: Непрерывное снижение цен.',
        '• Умеренная инфляция придает экономике жизненную силу, но чрезмерная инфляция разрушает покупательную способность.',
        '• Центральные банки поэтому стараются обеспечить стабильность цен.'
      ]
    },
    example: { 
      tr: '📈 2023\'te Türkiye\'de enflasyon %65\'e çıktı, insanların alım gücü çok azaldı.',
      en: '📈 In 2023, inflation in Turkey rose to 65%, people\'s purchasing power decreased significantly.',
      es: '📈 En 2023, la inflación en Turquía subió al 65%, el poder adquisitivo de la gente disminuyó significativamente.',
      fr: '📈 En 2023, l\'inflation en Turquie est montée à 65%, le pouvoir d\'achat des gens a considérablement diminué.',
      ru: '📈 В 2023 году инфляция в Турции выросла до 65%, покупательная способность людей значительно снизилась.'
    },
    icon: <TrendingUp className="w-16 h-16 text-red-500" />
  },
  {
    title: { 
      tr: 'İşsizlik Türleri', 
      en: 'Types of Unemployment', 
      es: 'Tipos de Desempleo', 
      fr: 'Types de Chômage', 
      ru: 'Типы безработицы' 
    },
    content: { 
      tr: [
        '• Geçici işsizlik: İnsanların iş aradığı dönem.',
        '• Yapısal işsizlik: Teknoloji değişimiyle bazı işlerin ortadan kalkması.',
        '• Döngüsel işsizlik: Ekonomi durgunken artar, canlanınca azalır.',
        '• Sağlıklı ekonomilerde küçük bir işsizlik her zaman vardır.'
      ],
      en: [
        '• Temporary unemployment: Period when people are looking for jobs.',
        '• Structural unemployment: Some jobs disappearing due to technological change.',
        '• Cyclical unemployment: Increases when economy is stagnant, decreases when it revives.',
        '• In healthy economies, there is always some small unemployment.'
      ],
      es: [
        '• Desempleo temporal: Período cuando la gente busca trabajo.',
        '• Desempleo estructural: Algunos trabajos desaparecen debido al cambio tecnológico.',
        '• Desempleo cíclico: Aumenta cuando la economía está estancada, disminuye cuando se revive.',
        '• En economías saludables, siempre hay algo de desempleo pequeño.'
      ],
      fr: [
        '• Chômage temporaire: Période où les gens cherchent du travail.',
        '• Chômage structurel: Certains emplois disparaissent à cause du changement technologique.',
        '• Chômage cyclique: Augmente quand l\'économie stagne, diminue quand elle se relance.',
        '• Dans les économies saines, il y a toujours un petit chômage.'
      ],
      ru: [
        '• Временная безработица: Период, когда люди ищут работу.',
        '• Структурная безработица: Некоторые рабочие места исчезают из-за технологических изменений.',
        '• Циклическая безработица: Увеличивается, когда экономика стагнирует, уменьшается при восстановлении.',
        '• В здоровых экономиках всегда есть небольшая безработица.'
      ]
    },
    example: { 
      tr: '🤖 Yapay zeka gelişince kasiyerlik işleri azaldı - bu yapısal işsizlik.',
      en: '🤖 As AI developed, cashier jobs decreased - this is structural unemployment.',
      es: '🤖 A medida que se desarrolló la IA, los trabajos de cajero disminuyeron - esto es desempleo estructural.',
      fr: '🤖 À mesure que l\'IA s\'est développée, les emplois de caissier ont diminué - c\'est du chômage structurel.',
      ru: '🤖 По мере развития ИИ рабочие места кассиров сократились - это структурная безработица.'
    },
    icon: <Users className="w-16 h-16 text-orange-600" />
  },
  {
    title: { 
      tr: 'Para Politikası ve Merkez Bankası', 
      en: 'Monetary Policy and Central Bank', 
      es: 'Política Monetaria y Banco Central', 
      fr: 'Politique Monétaire et Banque Centrale', 
      ru: 'Денежно-кредитная политика и центральный банк' 
    },
    content: { 
      tr: [
        '• Merkez bankaları faiz oranlarını ve para miktarını ayarlayarak enflasyonu ve büyümeyi kontrol eder.',
        '• Faizler düşerse kredi almak kolaylaşır, ekonomi canlanır.',
        '• Faizler yükselirse harcamalar azalır, enflasyon düşer.'
      ],
      en: [
        '• Central banks control inflation and growth by adjusting interest rates and money supply.',
        '• If interest rates fall, borrowing becomes easier, economy revives.',
        '• If interest rates rise, spending decreases, inflation falls.'
      ],
      es: [
        '• Los bancos centrales controlan la inflación y el crecimiento ajustando las tasas de interés y la oferta monetaria.',
        '• Si las tasas de interés bajan, pedir prestado se vuelve más fácil, la economía se revive.',
        '• Si las tasas de interés suben, el gasto disminuye, la inflación baja.'
      ],
      fr: [
        '• Les banques centrales contrôlent l\'inflation et la croissance en ajustant les taux d\'intérêt et l\'offre de monnaie.',
        '• Si les taux d\'intérêt baissent, emprunter devient plus facile, l\'économie se relance.',
        '• Si les taux d\'intérêt montent, les dépenses diminuent, l\'inflation baisse.'
      ],
      ru: [
        '• Центральные банки контролируют инфляцию и рост, регулируя процентные ставки и денежную массу.',
        '• Если процентные ставки падают, заимствование становится легче, экономика оживляется.',
        '• Если процентные ставки растут, расходы уменьшаются, инфляция падает.'
      ]
    },
    example: { 
      tr: '🏦 Fed faizi düşürünce Amerikalılar daha çok kredi aldı, konut piyasası canlandı.',
      en: '🏦 When Fed lowered interest rates, Americans took more loans, housing market revived.',
      es: '🏦 Cuando la Fed bajó las tasas de interés, los estadounidenses tomaron más préstamos, el mercado inmobiliario se revivió.',
      fr: '🏦 Quand la Fed a baissé les taux d\'intérêt, les Américains ont pris plus de prêts, le marché immobilier s\'est relancé.',
      ru: '🏦 Когда ФРС снизила процентные ставки, американцы взяли больше кредитов, рынок недвижимости оживился.'
    },
    icon: <Zap className="w-16 h-16 text-blue-600" />
  },
  {
    title: { 
      tr: 'Maliye Politikası ve Devletin Rolü', 
      en: 'Fiscal Policy and Government\'s Role', 
      es: 'Política Fiscal y Rol del Gobierno', 
      fr: 'Politique Fiscale et Rôle du Gouvernement', 
      ru: 'Фискальная политика и роль государства' 
    },
    content: { 
      tr: [
        '• Devlet vergiler ve harcamalar yoluyla ekonomiyi yönlendirir.',
        '• Kriz döneminde yatırımlar artırılıp vergi indirilebilir.',
        '• Ama uzun vadede aşırı borçlanma risk yaratır.'
      ],
      en: [
        '• Government guides economy through taxes and spending.',
        '• During crisis, investments can be increased and taxes reduced.',
        '• But excessive borrowing creates risk in long term.'
      ],
      es: [
        '• El gobierno guía la economía a través de impuestos y gastos.',
        '• Durante crisis, las inversiones pueden aumentarse y los impuestos reducirse.',
        '• Pero el endeudamiento excesivo crea riesgo a largo plazo.'
      ],
      fr: [
        '• Le gouvernement guide l\'économie par les impôts et les dépenses.',
        '• Pendant la crise, les investissements peuvent être augmentés et les impôts réduits.',
        '• Mais l\'endettement excessif crée un risque à long terme.'
      ],
      ru: [
        '• Правительство направляет экономику через налоги и расходы.',
        '• Во время кризиса инвестиции могут быть увеличены, а налоги снижены.',
        '• Но чрезмерное заимствование создает риск в долгосрочной перспективе.'
      ]
    },
    example: { 
      tr: '💰 COVID sırasında devletler vatandaşlara nakit yardım yaparak ekonomiyi destekledi.',
      en: '💰 During COVID, governments supported economy by providing cash assistance to citizens.',
      es: '💰 Durante COVID, los gobiernos apoyaron la economía proporcionando asistencia en efectivo a los ciudadanos.',
      fr: '💰 Pendant COVID, les gouvernements ont soutenu l\'économie en fournissant une aide en espèces aux citoyens.',
      ru: '💰 Во время COVID правительства поддержали экономику, оказывая денежную помощь гражданам.'
    },
    icon: <Building className="w-16 h-16 text-purple-600" />
  },
  {
    title: { 
      tr: 'Uluslararası Ticaret ve Küreselleşme', 
      en: 'International Trade and Globalization', 
      es: 'Comercio Internacional y Globalización', 
      fr: 'Commerce International et Mondialisation', 
      ru: 'Международная торговля и глобализация' 
    },
    content: { 
      tr: [
        '• Ülkeler, hangi üründe daha verimli ise onu üretip ihraç eder, diğerlerini ithal eder.',
        '• Bu sayede hem tüketiciler ucuz ve çeşitli ürünlere kavuşur hem de ekonomiler büyür.',
        '• Ama ticaret savaşları ve korumacı politikalar bu sistemi zorlayabilir.'
      ],
      en: [
        '• Countries produce and export what they are more efficient at, import others.',
        '• This way both consumers get cheap and diverse products and economies grow.',
        '• But trade wars and protectionist policies can strain this system.'
      ],
      es: [
        '• Los países producen y exportan en lo que son más eficientes, importan otros.',
        '• De esta manera tanto los consumidores obtienen productos baratos y diversos como las economías crecen.',
        '• Pero las guerras comerciales y políticas proteccionistas pueden tensar este sistema.'
      ],
      fr: [
        '• Les pays produisent et exportent ce dans quoi ils sont plus efficaces, importent d\'autres.',
        '• De cette façon, les consommateurs obtiennent des produits bon marché et diversifiés et les économies croissent.',
        '• Mais les guerres commerciales et politiques protectionnistes peuvent tendre ce système.'
      ],
      ru: [
        '• Страны производят и экспортируют то, в чем они более эффективны, импортируют другое.',
        '• Таким образом, потребители получают дешевые и разнообразные продукты, а экономики растут.',
        '• Но торговые войны и протекционистская политика могут напрягать эту систему.'
      ]
    },
    example: { 
      tr: '🌍 Çin elektronik üretiminde, Almanya otomobilde, Kolombiya kahvede uzmanlaştı.',
      en: '🌍 China specialized in electronics, Germany in automobiles, Colombia in coffee.',
      es: '🌍 China se especializó en electrónicos, Alemania en automóviles, Colombia en café.',
      fr: '🌍 La Chine s\'est spécialisée dans l\'électronique, l\'Allemagne dans l\'automobile, la Colombie dans le café.',
      ru: '🌍 Китай специализируется на электронике, Германия на автомобилях, Колумбия на кофе.'
    },
    icon: <Globe className="w-16 h-16 text-green-600" />
  },
  {
    title: { 
      tr: 'Davranışsal Ekonomi', 
      en: 'Behavioral Economics', 
      es: 'Economía del Comportamiento', 
      fr: 'Économie Comportementale', 
      ru: 'Поведенческая экономика' 
    },
    content: { 
      tr: [
        '• İnsanlar her zaman mantıklı karar vermez.',
        '• Psikoloji, ekonomi kararlarımızı etkiler.',
        '• Örneğin, kaybetmekten kaçınma, fazla güvenme veya başkalarının davranışlarını taklit etme gibi önyargılar vardır.'
      ],
      en: [
        '• People don\'t always make rational decisions.',
        '• Psychology affects our economic decisions.',
        '• For example, there are biases like loss aversion, overconfidence, or imitating others\' behaviors.'
      ],
      es: [
        '• Las personas no siempre toman decisiones racionales.',
        '• La psicología afecta nuestras decisiones económicas.',
        '• Por ejemplo, hay sesgos como aversión a la pérdida, exceso de confianza, o imitar comportamientos de otros.'
      ],
      fr: [
        '• Les gens ne prennent pas toujours des décisions rationnelles.',
        '• La psychologie affecte nos décisions économiques.',
        '• Par exemple, il y a des biais comme l\'aversion aux pertes, l\'excès de confiance, ou imiter les comportements d\'autrui.'
      ],
      ru: [
        '• Люди не всегда принимают рациональные решения.',
        '• Психология влияет на наши экономические решения.',
        '• Например, есть предрассудки, такие как неприятие потерь, самоуверенность или подражание поведению других.'
      ]
    },
    example: { 
      tr: '🧠 İnsanlar 1000 TL kazanmaktan çok, 1000 TL kaybetmekten korkar - kaybetme korkusu.',
      en: '🧠 People fear losing 1000 TL more than they desire gaining 1000 TL - loss aversion.',
      es: '🧠 La gente teme perder 1000 TL más de lo que desea ganar 1000 TL - aversión a la pérdida.',
      fr: '🧠 Les gens craignent de perdre 1000 TL plus qu\'ils ne désirent gagner 1000 TL - aversion aux pertes.',
      ru: '🧠 Люди боятся потерять 1000 лир больше, чем хотят получить 1000 лир - неприятие потерь.'
    },
    icon: <Coffee className="w-16 h-16 text-brown-600" />
  },
  {
    title: { 
      tr: 'Çevre ve Sürdürülebilirlik', 
      en: 'Environment and Sustainability', 
      es: 'Medio Ambiente y Sostenibilidad', 
      fr: 'Environnement et Durabilité', 
      ru: 'Окружающая среда и устойчивость' 
    },
    content: { 
      tr: [
        '• Üretim bazen çevreye zarar verir. Bu "dışsal maliyet"tir.',
        '• Karbon vergisi veya yeşil yatırımlar ile çevre korunabilir.',
        '• Gelecek nesiller için sürdürülebilir büyüme hedeflenir.'
      ],
      en: [
        '• Production sometimes harms environment. This is "external cost".',
        '• Environment can be protected with carbon tax or green investments.',
        '• Sustainable growth is targeted for future generations.'
      ],
      es: [
        '• La producción a veces daña el medio ambiente. Este es "costo externo".',
        '• El medio ambiente puede protegerse con impuesto al carbono o inversiones verdes.',
        '• Se busca crecimiento sostenible para futuras generaciones.'
      ],
      fr: [
        '• La production nuit parfois à l\'environnement. C\'est un "coût externe".',
        '• L\'environnement peut être protégé avec taxe carbone ou investissements verts.',
        '• Croissance durable est visée pour les générations futures.'
      ],
      ru: [
        '• Производство иногда вредит окружающей среде. Это "внешние издержки".',
        '• Окружающую среду можно защитить с помощью углеродного налога или зеленых инвестиций.',
        '• Устойчивый рост нацелен на будущие поколения.'
      ]
    },
    example: { 
      tr: '🌱 Tesla elektrikli araçlarla hem kar etti hem çevre dostu ürün sundu.',
      en: '🌱 Tesla both made profit and offered environmentally friendly products with electric vehicles.',
      es: '🌱 Tesla tanto obtuvo ganancias como ofreció productos amigables con el medio ambiente con vehículos eléctricos.',
      fr: '🌱 Tesla a à la fois fait du profit et offert des produits respectueux de l\'environnement avec des véhicules électriques.',
      ru: '🌱 Tesla и получила прибыль, и предложила экологически чистые продукты с электромобилями.'
    },
    icon: <HeartHandshake className="w-16 h-16 text-green-500" />
  },
  {
    title: { 
      tr: 'Dijital Ekonomi ve Kripto Paralar', 
      en: 'Digital Economy and Cryptocurrencies', 
      es: 'Economía Digital y Criptomonedas', 
      fr: 'Économie Numérique et Cryptomonnaies', 
      ru: 'Цифровая экономика и криптовалюты' 
    },
    content: { 
      tr: [
        '• Blockchain teknolojisi aracısız güvenli işlem imkânı sunar.',
        '• Kripto paralar, dijital varlıklar ve merkez bankası dijital paraları yeni ekonomik düzeni şekillendiriyor.',
        '• Ama denetim ve güvenlik hâlâ tartışma konusu.'
      ],
      en: [
        '• Blockchain technology offers secure transactions without intermediaries.',
        '• Cryptocurrencies, digital assets and central bank digital currencies are shaping new economic order.',
        '• But regulation and security are still debated.'
      ],
      es: [
        '• La tecnología blockchain ofrece transacciones seguras sin intermediarios.',
        '• Las criptomonedas, activos digitales y monedas digitales de bancos centrales están formando nuevo orden económico.',
        '• Pero regulación y seguridad aún se debaten.'
      ],
      fr: [
        '• La technologie blockchain offre des transactions sécurisées sans intermédiaires.',
        '• Les cryptomonnaies, actifs numériques et monnaies numériques de banques centrales façonnent un nouvel ordre économique.',
        '• Mais réglementation et sécurité sont encore débattues.'
      ],
      ru: [
        '• Технология блокчейн предлагает безопасные транзакции без посредников.',
        '• Криптовалюты, цифровые активы и цифровые валюты центральных банков формируют новый экономический порядок.',
        '• Но регулирование и безопасность все еще обсуждаются.'
      ]
    },
    example: { 
      tr: '₿ Bitcoin 2024\'te 100.000 doları aştı, El Salvador onu ulusal para yaptı.',
      en: '₿ Bitcoin exceeded $100,000 in 2024, El Salvador made it national currency.',
      es: '₿ Bitcoin superó los $100,000 en 2024, El Salvador lo hizo moneda nacional.',
      fr: '₿ Bitcoin a dépassé 100 000$ en 2024, El Salvador en a fait une monnaie nationale.',
      ru: '₿ Биткойн превысил $100,000 в 2024 году, Сальвадор сделал его национальной валютой.'
    },
    icon: <Star className="w-16 h-16 text-yellow-600" />
  },
  {
    title: { 
      tr: 'Ekonomik Krizler', 
      en: 'Economic Crises', 
      es: 'Crisis Económicas', 
      fr: 'Crises Économiques', 
      ru: 'Экономические кризисы' 
    },
    content: { 
      tr: [
        '• Krizler genelde aşırı borçlanma, balonlar veya dış şoklardan çıkar.',
        '• Çözüm için devletler para ve maliye politikalarıyla ekonomiyi destekler.',
        '• Geçmiş krizlerden alınan derslerle daha güçlü kurallar geliştirilmiştir.'
      ],
      en: [
        '• Crises generally arise from excessive borrowing, bubbles or external shocks.',
        '• For solution, governments support economy with monetary and fiscal policies.',
        '• Stronger rules have been developed with lessons learned from past crises.'
      ],
      es: [
        '• Las crisis generalmente surgen de endeudamiento excesivo, burbujas o choques externos.',
        '• Para solución, los gobiernos apoyan la economía con políticas monetarias y fiscales.',
        '• Se han desarrollado reglas más fuertes con lecciones aprendidas de crisis pasadas.'
      ],
      fr: [
        '• Les crises résultent généralement d\'endettement excessif, bulles ou chocs externes.',
        '• Pour solution, les gouvernements soutiennent l\'économie avec politiques monétaires et fiscales.',
        '• Des règles plus fortes ont été développées avec les leçons apprises des crises passées.'
      ],
      ru: [
        '• Кризисы обычно возникают из-за чрезмерного заимствования, пузырей или внешних шоков.',
        '• Для решения правительства поддерживают экономику денежно-кредитной и фискальной политикой.',
        '• Более строгие правила были разработаны на основе уроков прошлых кризисов.'
      ]
    },
    example: { 
      tr: '📉 2008 konut krizi ABD\'den tüm dünyaya yayıldı, bankalar kurtarıldı.',
      en: '📉 2008 housing crisis spread from US to entire world, banks were bailed out.',
      es: '📉 La crisis inmobiliaria de 2008 se extendió de EE.UU. a todo el mundo, los bancos fueron rescatados.',
      fr: '📉 La crise immobilière de 2008 s\'est propagée des États-Unis au monde entier, les banques ont été renflouées.',
      ru: '📉 Жилищный кризис 2008 года распространился из США на весь мир, банки были спасены.'
    },
    icon: <Layers className="w-16 h-16 text-red-600" />
  },
  {
    title: { 
      tr: 'Ekonominin Geleceği', 
      en: 'Future of Economy', 
      es: 'Futuro de la Economía', 
      fr: 'Avenir de l\'Économie', 
      ru: 'Будущее экономики' 
    },
    content: { 
      tr: [
        '• Yapay zeka, dijitalleşme ve yeşil ekonomi önümüzdeki dönemi şekillendirecek.',
        '• Yeni iş modelleri, farklı çalışma şekilleri (uzaktan, esnek) yaygınlaşacak.',
        '• İklim değişikliği, yaşlanan nüfus ve küresel güç dengeleri ise yeni sınavlar olacak.'
      ],
      en: [
        '• Artificial intelligence, digitalization and green economy will shape the coming period.',
        '• New business models, different working styles (remote, flexible) will become widespread.',
        '• Climate change, aging population and global power balances will be new challenges.'
      ],
      es: [
        '• La inteligencia artificial, digitalización y economía verde darán forma al período venidero.',
        '• Nuevos modelos de negocio, estilos de trabajo diferentes (remoto, flexible) se generalizarán.',
        '• Cambio climático, población envejecida y balances de poder globales serán nuevos desafíos.'
      ],
      fr: [
        '• L\'intelligence artificielle, numérisation et économie verte façonneront la période à venir.',
        '• Nouveaux modèles d\'affaires, styles de travail différents (à distance, flexible) se généraliseront.',
        '• Changement climatique, population vieillissante et équilibres de pouvoir mondiaux seront de nouveaux défis.'
      ],
      ru: [
        '• Искусственный интеллект, цифровизация и зеленая экономика будут формировать предстоящий период.',
        '• Новые бизнес-модели, различные стили работы (удаленная, гибкая) станут широко распространенными.',
        '• Изменение климата, стареющее население и глобальные балансы сил станут новыми вызовами.'
      ]
    },
    example: { 
      tr: '🚀 2030\'da işlerin %40\'ı uzaktan yapılacak, yapay zeka ekonomiyi dönüştürecek.',
      en: '🚀 By 2030, 40% of jobs will be done remotely, AI will transform economy.',
      es: '🚀 Para 2030, 40% de los trabajos se harán remotamente, la IA transformará la economía.',
      fr: '🚀 D\'ici 2030, 40% des emplois seront faits à distance, l\'IA transformera l\'économie.',
      ru: '🚀 К 2030 году 40% рабочих мест будут выполняться удаленно, ИИ преобразует экономику.'
    },
    icon: <BookOpen className="w-16 h-16 text-purple-600" />
  }
]