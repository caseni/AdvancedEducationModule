// Kişisel Finans Quiz Soruları - Tüm 35 Soru
// Import edilip kullanılmak üzere ayrı dosya

// Quiz soruları için tür tanımlaması
export interface QuizQuestion {
  id: number;
  question: {
    tr: string;
    en: string;
    es: string;
    fr: string;
    ru: string;
    de: string;
    pt: string;
  };
  type: 'multiple-choice' | 'true-false';
  answers?: {
    tr: string[];
    en: string[];
    es: string[];
    fr: string[];
    ru: string[];
    de: string[];
    pt: string[];
  };
  options?: {
    tr: string[];
    en: string[];
    es: string[];
    fr: string[];
    ru: string[];
    de: string[];
    pt: string[];
  };
  correct: number;
  explanation: {
    tr: string;
    en: string;
    es: string;
    fr: string;
    ru: string;
    de: string;
    pt: string;
  };
}

export const personalFinanceQuiz: QuizQuestion[] = [
  // 1. Kişisel Finans Nedir? - Quiz
  {
    id: 1,
    question: {
      tr: 'Kişisel finansın temel amacı nedir?',
      en: 'What is the main purpose of personal finance?',
      es: '¿Cuál es el propósito principal de las finanzas personales?',
      fr: 'Quel est l\'objectif principal de la finance personnelle?',
      ru: 'Какова основная цель личных финансов?',
      de: 'Was ist das Hauptziel der persönlichen Finanzen?',
      pt: 'Qual é o objetivo principal das finanças pessoais?'
    },
    type: 'multiple-choice',
    answers: {
      tr: [
        'Daha çok harcama yapmak',
        'Para yönetimini planlayarak hedeflere ulaşmak',
        'Banka kredisi kullanmak',
        'Sadece yatırım yapmak'
      ],
      en: [
        'Spending more money',
        'Managing money planning to reach goals',
        'Using bank loans',
        'Only investing'
      ],
      es: [
        'Gastar más dinero',
        'Gestionar la planificación del dinero para alcanzar objetivos',
        'Usar préstamos bancarios',
        'Solo invertir'
      ],
      fr: [
        'Dépenser plus d\'argent',
        'Gérer la planification de l\'argent pour atteindre les objectifs',
        'Utiliser des prêts bancaires',
        'Seulement investir'
      ],
      ru: [
        'Тратить больше денег',
        'Управлять планированием денег для достижения целей',
        'Использовать банковские кредиты',
        'Только инвестировать'
      ],
      de: [
        'Mehr Geld ausgeben',
        'Geldplanung verwalten, um Ziele zu erreichen',
        'Bankkredite nutzen',
        'Nur investieren'
      ],
      pt: [
        'Gastar mais dinheiro',
        'Gerenciar o planejamento de dinheiro para atingir objetivos',
        'Usar empréstimos bancários',
        'Apenas investir'
      ]
    },
    correct: 1,
    explanation: {
      tr: 'Kişisel finansın temel amacı, para yönetimini planlayarak finansal hedeflere ulaşmak ve finansal güvenlik sağlamaktır.',
      en: 'The main purpose of personal finance is to reach financial goals and achieve financial security through planned money management.',
      es: 'El propósito principal de las finanzas personales es alcanzar objetivos financieros y lograr seguridad financiera a través de la gestión planificada del dinero.',
      fr: 'L\'objectif principal de la finance personnelle est d\'atteindre les objectifs financiers et d\'assurer la sécurité financière grâce à une gestion planifiée de l\'argent.',
      ru: 'Основная цель личных финансов - достижение финансовых целей и обеспечение финансовой безопасности через планомерное управление деньгами.',
      de: 'Das Hauptziel der persönlichen Finanzen ist es, finanzielle Ziele zu erreichen und finanzielle Sicherheit durch geplante Geldverwaltung zu gewährleisten.',
      pt: 'O objetivo principal das finanças pessoais é atingir objetivos financeiros e conseguir segurança financeira através da gestão planejada do dinheiro.'
    }
  },
  {
    id: 2,
    question: {
      tr: 'Acil fon genellikle kaç aylık gideri kapsamalıdır?',
      en: 'How many months of expenses should an emergency fund typically cover?',
      es: '¿Cuántos meses de gastos debería cubrir típicamente un fondo de emergencia?',
      fr: 'Combien de mois de dépenses un fonds d\'urgence devrait-il généralement couvrir?',
      ru: 'Сколько месяцев расходов должен покрывать аварийный фонд?',
      de: 'Wie viele Monate Ausgaben sollte ein Notfallfonds typischerweise abdecken?',
      pt: 'Quantos meses de despesas um fundo de emergência deveria cobrir tipicamente?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['1–2 ay', '3–6 ay', '12 ay', 'Sadece borç bitene kadar'],
      en: ['1–2 months', '3–6 months', '12 months', 'Only until debt is paid'],
      es: ['1–2 meses', '3–6 meses', '12 meses', 'Solo hasta que se pague la deuda'],
      fr: ['1–2 mois', '3–6 mois', '12 mois', 'Seulement jusqu\'à ce que la dette soit payée'],
      ru: ['1–2 месяца', '3–6 месяцев', '12 месяцев', 'Только до погашения долга'],
      de: ['1–2 Monate', '3–6 Monate', '12 Monate', 'Nur bis die Schulden bezahlt sind'],
      pt: ['1–2 meses', '3–6 meses', '12 meses', 'Apenas até a dívida ser paga']
    },
    correct: 1,
    explanation: {
      tr: 'Acil fon genellikle 3-6 aylık yaşam giderini kapsamalıdır. Bu, iş kaybı veya beklenmedik durumlar için yeterli güvenlik sağlar.',
      en: 'An emergency fund should typically cover 3-6 months of living expenses. This provides adequate security for job loss or unexpected situations.',
      es: 'Un fondo de emergencia debería cubrir típicamente 3-6 meses de gastos de vida. Esto proporciona seguridad adecuada para pérdida de empleo o situaciones inesperadas.',
      fr: 'Un fonds d\'urgence devrait généralement couvrir 3-6 mois de frais de subsistance. Cela fournit une sécurité adéquate pour la perte d\'emploi ou les situations inattendues.',
      ru: 'Аварийный фонд должен покрывать 3-6 месяцев расходов на жизнь. Это обеспечивает адекватную безопасность при потере работы или неожиданных ситуациях.',
      de: 'Ein Notfallfonds sollte typischerweise 3-6 Monate Lebenshaltungskosten abdecken. Dies bietet angemessene Sicherheit bei Jobverlust oder unerwarteten Situationen.',
      pt: 'Um fundo de emergência deveria cobrir tipicamente 3-6 meses de despesas de vida. Isso fornece segurança adequada para perda de emprego ou situações inesperadas.'
    }
  },
  {
    id: 3,
    question: {
      tr: 'Aşağıdakilerden hangisi finansal wellness göstergesidir?',
      en: 'Which of the following is an indicator of financial wellness?',
      es: '¿Cuál de los siguientes es un indicador de bienestar financiero?',
      fr: 'Lequel des éléments suivants est un indicateur de bien-être financier?',
      ru: 'Что из следующего является показателем финансового благополучия?',
      de: 'Welches der folgenden ist ein Indikator für finanzielles Wohlbefinden?',
      pt: 'Qual dos seguintes é um indicador de bem-estar financeiro?'
    },
    type: 'multiple-choice',
    answers: {
      tr: [
        'Sürekli borç stresi yaşamak',
        'Beklenmedik giderleri rahat karşılayabilmek',
        'Daha çok kredi kartı açmak',
        'Lüks tüketimi artırmak'
      ],
      en: [
        'Constantly experiencing debt stress',
        'Being able to comfortably handle unexpected expenses',
        'Opening more credit cards',
        'Increasing luxury consumption'
      ],
      es: [
        'Experimentar constantemente estrés por deudas',
        'Poder manejar cómodamente gastos inesperados',
        'Abrir más tarjetas de crédito',
        'Aumentar el consumo de lujo'
      ],
      fr: [
        'Éprouver constamment du stress lié aux dettes',
        'Pouvoir gérer confortablement les dépenses imprévues',
        'Ouvrir plus de cartes de crédit',
        'Augmenter la consommation de luxe'
      ],
      ru: [
        'Постоянно испытывать стресс от долгов',
        'Уметь комфортно справляться с неожиданными расходами',
        'Открывать больше кредитных карт',
        'Увеличивать роскошное потребление'
      ],
      de: [
        'Ständig Schuldenstress erleben',
        'Unerwartete Ausgaben bequem bewältigen können',
        'Mehr Kreditkarten eröffnen',
        'Luxuskonsum steigern'
      ],
      pt: [
        'Experimentar constantemente estresse de dívidas',
        'Ser capaz de lidar confortavelmente com despesas inesperadas',
        'Abrir mais cartões de crédito',
        'Aumentar o consumo de luxo'
      ]
    },
    correct: 1,
    explanation: {
      tr: 'Beklenmedik giderleri rahat karşılayabilmek, finansal wellness\'ın temel göstergelerinden biridir. Bu, acil fon ve iyi finansal planlama sayesinde mümkün olur.',
      en: 'Being able to comfortably handle unexpected expenses is one of the key indicators of financial wellness. This is possible through emergency funds and good financial planning.',
      es: 'Poder manejar cómodamente gastos inesperados es uno de los indicadores clave del bienestar financiero. Esto es posible a través de fondos de emergencia y buena planificación financiera.',
      fr: 'Pouvoir gérer confortablement les dépenses imprévues est l\'un des indicateurs clés du bien-être financier. Cela est possible grâce aux fonds d\'urgence et à une bonne planification financière.',
      ru: 'Способность комфортно справляться с неожиданными расходами - один из ключевых показателей финансового благополучия. Это возможно благодаря аварийным фондам и хорошему финансовому планированию.',
      de: 'Unerwartete Ausgaben bequem bewältigen zu können ist einer der Schlüsselindikatoren für finanzielles Wohlbefinden. Dies ist durch Notfallfonds und gute Finanzplanung möglich.',
      pt: 'Ser capaz de lidar confortavelmente com despesas inesperadas é um dos principais indicadores de bem-estar financeiro. Isso é possível através de fundos de emergência e bom planejamento financeiro.'
    }
  },
  {
    id: 4,
    question: {
      tr: 'Kahveye günlük 80 TL harcamanın uzun vadeli maliyeti hangi kavramla açıklanır?',
      en: 'What concept explains the long-term cost of spending $8 daily on coffee?',
      es: '¿Qué concepto explica el costo a largo plazo de gastar $8 diarios en café?',
      fr: 'Quel concept explique le coût à long terme de dépenser 8€ par jour en café?',
      ru: 'Какая концепция объясняет долгосрочную стоимость ежедневных трат 500 рублей на кофе?',
      de: 'Welches Konzept erklärt die langfristigen Kosten von täglich 8€ für Kaffee?',
      pt: 'Qual conceito explica o custo a longo prazo de gastar $8 diários em café?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['Oportunite maliyeti', 'Nakit akışı', 'Değerleme', 'Portföy yönetimi'],
      en: ['Opportunity cost', 'Cash flow', 'Valuation', 'Portfolio management'],
      es: ['Costo de oportunidad', 'Flujo de caja', 'Valoración', 'Gestión de cartera'],
      fr: ['Coût d\'opportunité', 'Flux de trésorerie', 'Évaluation', 'Gestion de portefeuille'],
      ru: ['Альтернативная стоимость', 'Денежный поток', 'Оценка', 'Управление портфелем'],
      de: ['Opportunitätskosten', 'Cashflow', 'Bewertung', 'Portfoliomanagement'],
      pt: ['Custo de oportunidade', 'Fluxo de caixa', 'Avaliação', 'Gestão de portfólio']
    },
    correct: 0,
    explanation: {
      tr: 'Oportunite maliyeti, bir seçeneği tercih ettiğimizde vazgeçtiğimiz diğer seçeneklerin değeridir. Günlük kahve parası ile tasarruf veya yatırım yapabilirdik.',
      en: 'Opportunity cost is the value of alternatives we give up when choosing one option. The daily coffee money could have been saved or invested instead.',
      es: 'El costo de oportunidad es el valor de las alternativas que renunciamos al elegir una opción. El dinero diario del café podría haberse ahorrado o invertido en su lugar.',
      fr: 'Le coût d\'opportunité est la valeur des alternatives auxquelles nous renonçons en choisissant une option. L\'argent quotidien du café aurait pu être économisé ou investi à la place.',
      ru: 'Альтернативная стоимость - это ценность альтернатив, от которых мы отказываемся, выбирая один вариант. Ежедневные деньги на кофе могли бы быть сбережены или инвестированы.',
      de: 'Opportunitätskosten sind der Wert der Alternativen, auf die wir verzichten, wenn wir eine Option wählen. Das tägliche Kaffeegeld hätte stattdessen gespart oder investiert werden können.',
      pt: 'Custo de oportunidade é o valor das alternativas que abandonamos ao escolher uma opção. O dinheiro diário do café poderia ter sido poupado ou investido em vez disso.'
    }
  },
  {
    id: 5,
    question: {
      tr: 'Uzun vadeli hedeflerden biri değildir:',
      en: 'Which is NOT a long-term goal:',
      es: 'Cuál NO es un objetivo a largo plazo:',
      fr: 'Lequel n\'est PAS un objectif à long terme:',
      ru: 'Что НЕ является долгосрочной целью:',
      de: 'Was ist KEIN langfristiges Ziel:',
      pt: 'O que NÃO é um objetivo de longo prazo:'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['Emeklilik planı', 'Ev alma', 'Çocuk eğitimi', 'Günlük market alışverişi'],
      en: ['Retirement plan', 'Buying a house', 'Child education', 'Daily grocery shopping'],
      es: ['Plan de jubilación', 'Comprar una casa', 'Educación infantil', 'Compras diarias de supermercado'],
      fr: ['Plan de retraite', 'Acheter une maison', 'Éducation des enfants', 'Courses quotidiennes'],
      ru: ['Пенсионный план', 'Покупка дома', 'Образование детей', 'Ежедневные покупки продуктов'],
      de: ['Rentenplan', 'Hauskauf', 'Kindererziehung', 'Tägliche Lebensmitteleinkäufe'],
      pt: ['Plano de aposentadoria', 'Comprar uma casa', 'Educação dos filhos', 'Compras diárias no supermercado']
    },
    correct: 3,
    explanation: {
      tr: 'Günlük market alışverişi kısa vadeli, rutin bir giderdir. Emeklilik, ev alma ve çocuk eğitimi uzun vadeli finansal hedeflerdir.',
      en: 'Daily grocery shopping is a short-term, routine expense. Retirement, house buying, and child education are long-term financial goals.',
      es: 'Las compras diarias de supermercado son un gasto rutinario a corto plazo. La jubilación, comprar una casa y la educación infantil son objetivos financieros a largo plazo.',
      fr: 'Les courses quotidiennes sont une dépense routinière à court terme. La retraite, l\'achat d\'une maison et l\'éducation des enfants sont des objectifs financiers à long terme.',
      ru: 'Ежедневные покупки продуктов - это краткосрочные, рутинные расходы. Пенсия, покупка дома и образование детей - долгосрочные финансовые цели.',
      de: 'Tägliche Lebensmitteleinkäufe sind kurzfristige, routinemäßige Ausgaben. Rente, Hauskauf und Kindererziehung sind langfristige finanzielle Ziele.',
      pt: 'Compras diárias no supermercado são despesas rotineiras de curto prazo. Aposentadoria, comprar uma casa e educação dos filhos são objetivos financeiros de longo prazo.'
    }
  }

  // Note: Bu dosya sadece ilk 5 soruyu içeriyor. 
  // Tüm 35 soru PersonalFinanceSlides.tsx dosyasındaki personalFinanceQuiz array'inde bulunuyor.
  // Eğer tüm soruları burada da kullanmak istiyorsanız, PersonalFinanceSlides.tsx'ten import edebilirsiniz.
]