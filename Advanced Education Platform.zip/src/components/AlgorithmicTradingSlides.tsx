import { Bot, Zap, Settings, TrendingUp, Shield, AlertTriangle, Database, Target, Smartphone, TestTube, Gauge, Brain, Cog, Scale, DollarSign, AlertCircle, Users, GraduationCap, Rocket, Play } from 'lucide-react'

export const algorithmicTradingSlides = [
  {
    title: { 
      tr: 'Algoritmik İşlem Nedir?', 
      en: 'What is Algorithmic Trading?', 
      es: '¿Qué es el Trading Algorítmico?', 
      fr: 'Qu\'est-ce que le Trading Algorithmique?', 
      ru: 'Что такое алгоритмическая торговля?' 
    },
    content: { 
      tr: [
        '• Algoritmik işlem, bilgisayarların bizim yerimize alım-satım yapmasıdır.',
        '• Programlar belirli kurallara göre fiyatları takip eder, fırsat gördüğünde alır ya da satar.',
        '• Bunu saniyeden bile kısa sürede, üstelik duygulara kapılmadan yapar.'
      ],
      en: [
        '• Algorithmic trading is computers doing buy-sell transactions for us.',
        '• Programs follow prices according to specific rules, buy or sell when they see opportunities.',
        '• They do this in less than seconds, without getting emotional.'
      ],
      es: [
        '• El trading algorítmico es que las computadoras hagan transacciones de compra-venta por nosotros.',
        '• Los programas siguen precios según reglas específicas, compran o venden cuando ven oportunidades.',
        '• Lo hacen en menos de segundos, sin ponerse emocionales.'
      ],
      fr: [
        '• Le trading algorithmique, c\'est que les ordinateurs fassent des transactions d\'achat-vente pour nous.',
        '• Les programmes suivent les prix selon des règles spécifiques, achètent ou vendent quand ils voient des opportunités.',
        '• Ils le font en moins de secondes, sans devenir émotionnels.'
      ],
      ru: [
        '• Алгоритмическая торговля - это когда компьютеры совершают сделки купли-продажи за нас.',
        '• Программы следят за ценами по определенным правилам, покупают или продают при появлении возможностей.',
        '• Они делают это менее чем за секунды, не поддаваясь эмоциям.'
      ]
    },
    example: { 
      tr: '🤖 Bir robot, borsada işlemlerin %70\'ini yapıyor; daha hızlı, daha ucuz ve daha güvenilir oluyor.',
      en: '🤖 A robot conducts 70% of stock market transactions; becoming faster, cheaper and more reliable.',
      es: '🤖 Un robot realiza el 70% de las transacciones bursátiles; volviéndose más rápido, más barato y más confiable.',
      fr: '🤖 Un robot effectue 70% des transactions boursières; devenant plus rapide, moins cher et plus fiable.',
      ru: '🤖 Робот проводит 70% биржевых сделок; становясь быстрее, дешевле и надежнее.'
    },
    icon: <Bot className="w-16 h-16 text-blue-500" />
  },
  {
    title: { 
      tr: 'Neden Algoritmik İşlem Kullanılır?', 
      en: 'Why Use Algorithmic Trading?', 
      es: '¿Por qué usar Trading Algorítmico?', 
      fr: 'Pourquoi utiliser le Trading Algorithmique?', 
      ru: 'Почему используется алгоритмическая торговля?' 
    },
    content: { 
      tr: [
        '• İnsan duygularından bağımsız çalışır (panik satış yok, acele alım yok).',
        '• Bizden çok daha hızlıdır; fırsatları kaçırmaz.',
        '• Aynı anda onlarca piyasayı takip edebilir.',
        '• Sürekli aynı kuralları uygular, tutarlı davranır.',
        '• İşlem maliyetlerini düşürür.'
      ],
      en: [
        '• Works independently of human emotions (no panic selling, no hasty buying).',
        '• Much faster than us; doesn\'t miss opportunities.',
        '• Can monitor dozens of markets simultaneously.',
        '• Constantly applies same rules, behaves consistently.',
        '• Reduces transaction costs.'
      ],
      es: [
        '• Funciona independientemente de emociones humanas (no venta de pánico, no compra apresurada).',
        '• Mucho más rápido que nosotros; no pierde oportunidades.',
        '• Puede monitorear docenas de mercados simultáneamente.',
        '• Constantemente aplica mismas reglas, se comporta consistentemente.',
        '• Reduce costos de transacción.'
      ],
      fr: [
        '• Fonctionne indépendamment des émotions humaines (pas de vente de panique, pas d\'achat précipité).',
        '• Beaucoup plus rapide que nous; ne rate pas d\'opportunités.',
        '• Peut surveiller des dizaines de marchés simultanément.',
        '• Applique constamment les mêmes règles, se comporte de manière cohérente.',
        '• Réduit les coûts de transaction.'
      ],
      ru: [
        '• Работает независимо от человеческих эмоций (никаких панических продаж, никаких поспешных покупок).',
        '• Намного быстрее нас; не упускает возможности.',
        '• Может одновременно отслеживать десятки рынков.',
        '• Постоянно применяет одни и те же правила, ведет себя последовательно.',
        '• Снижает транзакционные издержки.'
      ]
    },
    example: { 
      tr: '⚡ Algoritmalar sayesinde yatırımcılar ortalama %10 daha fazla kazanç elde etti.',
      en: '⚡ Thanks to algorithms, investors achieved average 10% more profit.',
      es: '⚡ Gracias a algoritmos, inversores lograron promedio 10% más ganancia.',
      fr: '⚡ Grâce aux algorithmes, les investisseurs ont obtenu en moyenne 10% de profit en plus.',
      ru: '⚡ Благодаря алгоритмам инвесторы получили в среднем на 10% больше прибыли.'
    },
    icon: <Zap className="w-16 h-16 text-yellow-500" />
  },
  {
    title: { 
      tr: 'Algoritmik İşlem Nasıl Çalışır?', 
      en: 'How Does Algorithmic Trading Work?', 
      es: '¿Cómo funciona el Trading Algorítmico?', 
      fr: 'Comment fonctionne le Trading Algorithmique?', 
      ru: 'Как работает алгоритмическая торговля?' 
    },
    content: { 
      tr: [
        '• Önce strateji belirlenir (ör. fiyat düşünce al, çıkınca sat).',
        '• Bilgisayar anlık fiyatları takip eder.',
        '• Uygun zamanı görünce otomatik alım veya satım yapar.',
        '• İşlem sonrası sonuçları raporlar.'
      ],
      en: [
        '• First strategy is determined (e.g. buy when price falls, sell when it rises).',
        '• Computer monitors real-time prices.',
        '• When it sees the right time, automatically makes buy or sell orders.',
        '• Reports results after transactions.'
      ],
      es: [
        '• Primero se determina estrategia (ej. comprar cuando precio baja, vender cuando sube).',
        '• La computadora monitorea precios en tiempo real.',
        '• Cuando ve el momento correcto, automáticamente hace órdenes de compra o venta.',
        '• Reporta resultados después de transacciones.'
      ],
      fr: [
        '• D\'abord la stratégie est déterminée (ex. acheter quand prix baisse, vendre quand il monte).',
        '• L\'ordinateur surveille les prix en temps réel.',
        '• Quand il voit le bon moment, fait automatiquement des ordres d\'achat ou vente.',
        '• Rapporte résultats après transactions.'
      ],
      ru: [
        '• Сначала определяется стратегия (например, покупать при падении цены, продавать при росте).',
        '• Компьютер отслеживает цены в реальном времени.',
        '• Когда видит подходящий момент, автоматически размещает ордера на покупку или продажу.',
        '• Отчитывается о результатах после сделок.'
      ]
    },
    example: { 
      tr: '⚙️ Bir algoritma, Apple hissesini ucuzken alarak birkaç gün içinde %8 kazanç sağladı.',
      en: '⚙️ An algorithm made 8% profit in few days by buying Apple stock when it was cheap.',
      es: '⚙️ Un algoritmo obtuvo 8% de ganancia en pocos días comprando acciones de Apple cuando estaban baratas.',
      fr: '⚙️ Un algorithme a fait 8% de profit en quelques jours en achetant des actions Apple quand elles étaient bon marché.',
      ru: '⚙️ Алгоритм получил 8% прибыли за несколько дней, купив акции Apple, когда они были дешевыми.'
    },
    icon: <Settings className="w-16 h-16 text-purple-500" />
  },
  {
    title: { 
      tr: 'Algoritmik İşlem Türleri', 
      en: 'Types of Algorithmic Trading', 
      es: 'Tipos de Trading Algorítmico', 
      fr: 'Types de Trading Algorithmique', 
      ru: 'Типы алгоритмической торговли' 
    },
    content: { 
      tr: [
        '• Hızlı İşlemler: Mikro saniyelerde al-sat yapar.',
        '• Büyük Emir Bölme: Kocaman emirleri küçük parçalara ayırarak piyasayı etkilemeden gerçekleştirir.',
        '• İstatistiksel Stratejiler: Fiyat farklarını yakalayıp kâr elde eder.',
        '• Arbitraj: Aynı ürün farklı borsalarda farklı fiyatlardaysa, ucuzdan alıp pahalıya satar.',
        '• Piyasa Yapıcı: Sürekli alım-satım teklifi vererek piyasaya likidite sağlar.'
      ],
      en: [
        '• High-Speed Trading: Makes buy-sell transactions in microseconds.',
        '• Large Order Splitting: Breaks huge orders into small pieces to execute without affecting market.',
        '• Statistical Strategies: Catches price differences and makes profit.',
        '• Arbitrage: If same product has different prices on different exchanges, buys cheap and sells expensive.',
        '• Market Making: Provides liquidity to market by continuously offering buy-sell quotes.'
      ],
      es: [
        '• Trading de Alta Velocidad: Hace transacciones de compra-venta en microsegundos.',
        '• División de Órdenes Grandes: Divide órdenes enormes en piezas pequeñas para ejecutar sin afectar mercado.',
        '• Estrategias Estadísticas: Captura diferencias de precio y obtiene ganancia.',
        '• Arbitraje: Si mismo producto tiene precios diferentes en diferentes intercambios, compra barato y vende caro.',
        '• Creación de Mercado: Proporciona liquidez al mercado ofreciendo continuamente cotizaciones de compra-venta.'
      ],
      fr: [
        '• Trading Haute Vitesse: Fait des transactions d\'achat-vente en microsecondes.',
        '• Division de Gros Ordres: Divise énormes ordres en petites pièces pour exécuter sans affecter marché.',
        '• Stratégies Statistiques: Capture différences de prix et fait profit.',
        '• Arbitrage: Si même produit a prix différents sur différentes bourses, achète pas cher et vend cher.',
        '• Création de Marché: Fournit liquidité au marché en offrant continuellement cotations d\'achat-vente.'
      ],
      ru: [
        '• Высокоскоростная торговля: Совершает сделки купли-продажи в микросекундах.',
        '• Разделение крупных ордеров: Разбивает огромные ордера на мелкие части для исполнения без влияния на рынок.',
        '• Статистические стратегии: Ловит ценовые различия и получает прибыль.',
        '• Арбитраж: Если один и тот же продукт имеет разные цены на разных биржах, покупает дешево и продает дорого.',
        '• Маркет-мейкинг: Обеспечивает ликвидность рынку, постоянно предлагая котировки купли-продажи.'
      ]
    },
    example: { 
      tr: '📈 Kripto piyasasında hızlı işlemler %20 daha fazla kazandırdı.',
      en: '📈 High-speed trading in crypto markets brought 20% more profit.',
      es: '📈 Trading de alta velocidad en mercados cripto trajo 20% más ganancia.',
      fr: '📈 Trading haute vitesse sur marchés crypto a apporté 20% plus de profit.',
      ru: '📈 Высокоскоростная торговля на криптовалютных рынках принесла на 20% больше прибыли.'
    },
    icon: <TrendingUp className="w-16 h-16 text-green-500" />
  },
  {
    title: { 
      tr: 'Risk Yönetimi ve Güvenlik', 
      en: 'Risk Management and Security', 
      es: 'Gestión de Riesgos y Seguridad', 
      fr: 'Gestion des Risques et Sécurité', 
      ru: 'Управление рисками и безопасность' 
    },
    content: { 
      tr: [
        '• Emir büyüklüğüne sınır koyulur.',
        '• Zararı belli bir seviyede kesen "stop-loss" kuralları vardır.',
        '• Ani piyasa hareketlerinde sistem kendini durdurabilir.',
        '• Modeller sürekli test edilerek güncellenir.',
        '• Siber güvenlik önlemleriyle korunur.'
      ],
      en: [
        '• Limits are set on order sizes.',
        '• There are "stop-loss" rules that cut losses at certain level.',
        '• System can stop itself during sudden market movements.',
        '• Models are continuously tested and updated.',
        '• Protected with cyber security measures.'
      ],
      es: [
        '• Se establecen límites en tamaños de órdenes.',
        '• Hay reglas de "stop-loss" que cortan pérdidas en cierto nivel.',
        '• El sistema puede detenerse durante movimientos súbitos del mercado.',
        '• Los modelos se prueban y actualizan continuamente.',
        '• Protegido con medidas de ciberseguridad.'
      ],
      fr: [
        '• Des limites sont fixées sur les tailles d\'ordres.',
        '• Il y a des règles de "stop-loss" qui coupent les pertes à certain niveau.',
        '• Le système peut s\'arrêter pendant mouvements soudains du marché.',
        '• Les modèles sont continuellement testés et mis à jour.',
        '• Protégé avec mesures de cybersécurité.'
      ],
      ru: [
        '• Устанавливаются лимиты на размеры ордеров.',
        '• Есть правила "стоп-лосс", которые сокращают потери на определенном уровне.',
        '• Система может остановить себя во время резких движений рынка.',
        '• Модели постоянно тестируются и обновляются.',
        '• Защищены мерами кибербезопасности.'
      ]
    },
    example: { 
      tr: '🛡️ Bir algoritma, %5 zarar görünce kendini otomatik kapattı.',  
      en: '🛡️ An algorithm automatically shut itself down when it saw 5% loss.',
      es: '🛡️ Un algoritmo se cerró automáticamente cuando vio 5% de pérdida.',
      fr: '🛡️ Un algorithme s\'est fermé automatiquement quand il a vu 5% de perte.',
      ru: '🛡️ Алгоритм автоматически отключился, когда увидел 5% потерь.'
    },
    icon: <Shield className="w-16 h-16 text-red-500" />
  },
  {
    title: { 
      tr: 'Veri ve Teknoloji Altyapısı', 
      en: 'Data and Technology Infrastructure', 
      es: 'Infraestructura de Datos y Tecnología', 
      fr: 'Infrastructure de Données et Technologie', 
      ru: 'Инфраструктура данных и технологий' 
    },
    content: { 
      tr: [
        '• Sürekli fiyat verileri toplanır.',
        '• Sosyal medya, uydu görüntüleri gibi alternatif kaynaklar da kullanılabilir.',
        '• Güçlü bilgisayarlar ve bulut sistemleri gerekir.',
        '• Kodlama genelde Python gibi dillerle yapılır.',
        '• Hızlı internet bağlantısı başarı için kritik önemdedir.'
      ],
      en: [
        '• Continuous price data is collected.',
        '• Alternative sources like social media, satellite images can also be used.',
        '• Powerful computers and cloud systems are needed.',
        '• Coding is usually done with languages like Python.',
        '• Fast internet connection is critically important for success.'
      ],
      es: [
        '• Se recopilan datos de precios continuos.',
        '• También se pueden usar fuentes alternativas como redes sociales, imágenes satelitales.',
        '• Se necesitan computadoras potentes y sistemas en la nube.',
        '• La codificación usualmente se hace con lenguajes como Python.',
        '• Conexión rápida a internet es críticamente importante para el éxito.'
      ],
      fr: [
        '• Des données de prix continues sont collectées.',
        '• Des sources alternatives comme réseaux sociaux, images satellite peuvent aussi être utilisées.',
        '• Des ordinateurs puissants et systèmes cloud sont nécessaires.',
        '• Le codage se fait habituellement avec des langages comme Python.',
        '• Connexion internet rapide est critiquement importante pour le succès.'
      ],
      ru: [
        '• Собираются непрерывные ценовые данные.',
        '• Также могут использоваться альтернативные источники, такие как социальные сети, спутниковые изображения.',
        '• Нужны мощные компьютеры и облачные системы.',
        '• Кодирование обычно выполняется на языках типа Python.',
        '• Быстрое интернет-соединение критически важно для успеха.'
      ]
    },
    example: { 
      tr: '💾 Amazon\'un bulut sistemleri, algoritmik işlemlerin yarısından fazlasını destekliyor.',
      en: '💾 Amazon\'s cloud systems support more than half of algorithmic trading.',
      es: '💾 Los sistemas en la nube de Amazon apoyan más de la mitad del trading algorítmico.',
      fr: '💾 Les systèmes cloud d\'Amazon supportent plus de la moitié du trading algorithmique.',
      ru: '💾 Облачные системы Amazon поддерживают более половины алгоритмической торговли.'
    },
    icon: <Database className="w-16 h-16 text-cyan-500" />
  },
  {
    title: { 
      tr: 'Strateji Geliştirme ve Test', 
      en: 'Strategy Development and Testing', 
      es: 'Desarrollo y Prueba de Estrategias', 
      fr: 'Développement et Test de Stratégies', 
      ru: 'Разработка и тестирование стратегий' 
    },
    content: { 
      tr: [
        '• Önce bir fikir üretilir (ör. fiyat çok düştüyse al).',
        '• Geçmiş veriler üzerinde test edilir.',
        '• Hatalar düzeltilir, gereksiz karmaşıklık azaltılır.',
        '• Sanal ortamda deneme yapılır.',
        '• Başarılıysa gerçek parayla küçük çaplı başlanır.'
      ],
      en: [
        '• First an idea is generated (e.g. buy if price dropped too much).',
        '• Tested on historical data.',
        '• Errors are corrected, unnecessary complexity is reduced.',
        '• Trial is done in virtual environment.',
        '• If successful, started small-scale with real money.'
      ],
      es: [
        '• Primero se genera una idea (ej. comprar si precio bajó demasiado).',
        '• Se prueba en datos históricos.',
        '• Se corrigen errores, se reduce complejidad innecesaria.',
        '• Se hace prueba en ambiente virtual.',
        '• Si es exitoso, se comienza a pequeña escala con dinero real.'
      ],
      fr: [
        '• D\'abord une idée est générée (ex. acheter si prix a trop baissé).',
        '• Testée sur données historiques.',
        '• Les erreurs sont corrigées, complexité inutile est réduite.',
        '• Essai est fait en environnement virtuel.',
        '• Si réussi, commencé à petite échelle avec argent réel.'
      ],
      ru: [
        '• Сначала генерируется идея (например, покупать, если цена слишком упала).',
        '• Тестируется на исторических данных.',
        '• Исправляются ошибки, снижается ненужная сложность.',
        '• Проводится испытание в виртуальной среде.',
        '• Если успешно, начинается в малом масштабе с реальными деньгами.'
      ]
    },
    example: { 
      tr: '🧪 Bir strateji, 5 yıllık testte her yıl ortalama %15 getiri sağladı.',
      en: '🧪 A strategy provided average 15% return each year in 5-year test.',
      es: '🧪 Una estrategia proporcionó promedio 15% de retorno cada año en prueba de 5 años.',
      fr: '🧪 Une stratégie a fourni en moyenne 15% de rendement chaque année dans test de 5 ans.',
      ru: '🧪 Стратегия обеспечивала в ср��днем 15% доходности каждый год в 5-летнем тесте.'
    },
    icon: <TestTube className="w-16 h-16 text-purple-500" />
  },
  {
    title: { 
      tr: 'Performans Ölçümü ve İyileştirme', 
      en: 'Performance Measurement and Improvement', 
      es: 'Medición de Rendimiento y Mejora', 
      fr: 'Mesure de Performance et Amélioration', 
      ru: 'Измерение производительности и улучшение' 
    },
    content: { 
      tr: [
        '• Ne kadar kazandırdığına bakılır.',
        '• Ne kadar risk aldığı ölçülür.',
        '• Emirlerin ne kadar hızlı ve doğru gerçekleştiği analiz edilir.',
        '• Parametreler düzenlenir, strateji sürekli geliştirilir.'
      ],
      en: [
        '• How much profit it generated is examined.',
        '• How much risk it took is measured.',
        '• How fast and accurate orders were executed is analyzed.',
        '• Parameters are adjusted, strategy is continuously improved.'
      ],
      es: [
        '• Se examina cuánta ganancia generó.',
        '• Se mide cuánto riesgo tomó.',
        '• Se analiza qué tan rápido y preciso se ejecutaron las órdenes.',
        '• Se ajustan parámetros, la estrategia se mejora continuamente.'
      ],
      fr: [
        '• Combien de profit il a généré est examiné.',
        '• Combien de risque il a pris est mesuré.',
        '• À quelle vitesse et précision les ordres ont été exécutés est analysé.',
        '• Les paramètres sont ajustés, la stratégie est continuellement améliorée.'
      ],
      ru: [
        '• Изучается, сколько прибыли он принес.',
        '• Измеряется, сколько риска он взял.',
        '• Анализируется, насколько быстро и точно исполнялись ордера.',
        '• Параметры корректируются, стратегия постоянно улучшается.'
      ]
    },
    example: { 
      tr: '📊 İyileştirme sonrası bir algoritmanın performansı %30 arttı.',
      en: '📊 After improvement, an algorithm\'s performance increased by 30%.',
      es: '📊 Después de mejora, el rendimiento de un algoritmo aumentó en 30%.',
      fr: '📊 Après amélioration, la performance d\'un algorithme a augmenté de 30%.',
      ru: '📊 После улучшения производительность алгоритма выросла на 30%.'
    },
    icon: <Gauge className="w-16 h-16 text-orange-500" />
  },
  {
    title: { 
      tr: 'Yapay Zeka ile Algoritmalar', 
      en: 'AI-Powered Algorithms', 
      es: 'Algoritmos con Inteligencia Artificial', 
      fr: 'Algorithmes avec Intelligence Artificielle', 
      ru: 'Алгоритмы с искусственным интеллектом' 
    },
    content: { 
      tr: [
        '• Geçmiş verilere bakarak fiyat tahmini yapabilir.',
        '• Sosyal medya yorumlarını analiz ederek piyasa duygusunu ölçebilir.',
        '• Derin öğrenme ile grafiklerden desenleri tanıyabilir.',
        '• Hatalarını öğrenip zamanla kendini geliştirebilir.'
      ],
      en: [
        '• Can make price predictions by looking at historical data.',
        '• Can measure market sentiment by analyzing social media comments.',
        '• Can recognize patterns from charts through deep learning.',
        '• Can learn from mistakes and improve itself over time.'
      ],
      es: [
        '• Puede hacer predicciones de precio mirando datos históricos.',
        '• Puede medir sentimiento del mercado analizando comentarios de redes sociales.',
        '• Puede reconocer patrones de gráficos a través de aprendizaje profundo.',
        '• Puede aprender de errores y mejorarse con el tiempo.'
      ],
      fr: [
        '• Peut faire des prédictions de prix en regardant données historiques.',
        '• Peut mesurer sentiment du marché en analysant commentaires réseaux sociaux.',
        '• Peut reconnaître patterns des graphiques par apprentissage profond.',
        '• Peut apprendre des erreurs et s\'améliorer avec le temps.'
      ],
      ru: [
        '• Может делать прогнозы цен, глядя на исторические данные.',
        '• Может измерять рыночные настроения, анализируя комментарии в социальных сетях.',
        '• Может распознавать паттерны на графиках через глубокое обучение.',
        '• Может учиться на ошибках и совершенствоваться со временем.'
      ]
    },
    example: { 
      tr: '🤖 Yapay zeka destekli bir sistem, haber analizleriyle %12 ek kazanç sağladı.',
      en: '🤖 An AI-powered system provided 12% additional profit through news analysis.',
      es: '🤖 Un sistema con IA proporcionó 12% de ganancia adicional a través de análisis de noticias.',
      fr: '🤖 Un système avec IA a fourni 12% de profit supplémentaire par analyse de nouvelles.',
      ru: '🤖 Система с ИИ обеспечила 12% дополнительной прибыли через анализ новостей.'
    },
    icon: <Brain className="w-16 h-16 text-pink-500" />
  },
  {
    title: { 
      tr: 'Kurallar ve Düzenlemeler', 
      en: 'Rules and Regulations', 
      es: 'Reglas y Regulaciones', 
      fr: 'Règles et Réglementations', 
      ru: 'Правила и регулирование' 
    },
    content: { 
      tr: [
        '• Piyasalar, algoritmaların kötüye kullanılmaması için kurallar koyar.',
        '• Ani fiyat oynaklıklarında "devre kesici" uygulanır.',
        '• Algoritmalar düzenli rapor vermek zorundadır.',
        '• Farklı ülkelerde farklı regülasyonlar olabilir.'
      ],
      en: [
        '• Markets set rules to prevent misuse of algorithms.',
        '• "Circuit breakers" are applied during sudden price volatility.',
        '• Algorithms must provide regular reports.',
        '• Different countries may have different regulations.'
      ],
      es: [
        '• Los mercados establecen reglas para prevenir mal uso de algoritmos.',
        '• Se aplican "disyuntores" durante volatilidad súbita de precios.',
        '• Los algoritmos deben proporcionar reportes regulares.',
        '• Diferentes países pueden tener diferentes regulaciones.'
      ],
      fr: [
        '• Les marchés établissent règles pour prévenir mauvais usage des algorithmes.',
        '• Des "disjoncteurs" sont appliqués pendant volatilité soudaine des prix.',
        '• Les algorithmes doivent fournir rapports réguliers.',
        '• Différents pays peuvent avoir différentes réglementations.'
      ],
      ru: [
        '• Рынки устанавливают правила для предотвращения злоупотребления алгоритмами.',
        '• "Автоматы защиты" применяются во время резкой волатильности цен.',
        '• Алгоритмы должны предоставлять регулярные отчеты.',
        '• В разных странах могут быть разные регулирования.'
      ]
    },
    example: { 
      tr: '🏛️ ABD\'de denetim kurumu, algoritmaların çoğunu kurallara uygun buldu.',
      en: '🏛️ In USA, regulatory authority found most algorithms compliant with rules.',
      es: '🏛️ En EE.UU., autoridad regulatoria encontró mayoría de algoritmos cumpliendo reglas.',
      fr: '🏛️ Aux États-Unis, autorité réglementaire a trouvé plupart des algorithmes conformes aux règles.',
      ru: '🏛️ В США регуляторный орган признал большинство алгоритмов соответствующими правилам.'
    },
    icon: <Scale className="w-16 h-16 text-blue-600" />
  },
  {
    title: { 
      tr: 'Maliyetler ve Beklenen Getiri', 
      en: 'Costs and Expected Returns', 
      es: 'Costos y Retornos Esperados', 
      fr: 'Coûts et Rendements Attendus', 
      ru: 'Затраты и ожидаемая доходность' 
    },
    content: { 
      tr: [
        '• Güçlü bilgisayar ve veri hizmetleri maliyetlidir.',
        '• İyi yazılımcılar ve araştırmacılar gerekir.',
        '• İşlem başına küçük masraflar vardır.',
        '• Yıllık getiri %10–20 civarında olabilir, ama risk de vardır.'
      ],
      en: [
        '• Powerful computers and data services are costly.',
        '• Good programmers and researchers are needed.',
        '• There are small costs per transaction.',
        '• Annual return can be around 10-20%, but there\'s also risk.'
      ],
      es: [
        '• Computadoras potentes y servicios de datos son costosos.',
        '• Se necesitan buenos programadores e investigadores.',
        '• Hay pequeños costos por transacción.',
        '• El retorno anual puede ser alrededor de 10-20%, pero también hay riesgo.'
      ],
      fr: [
        '• Ordinateurs puissants et services de données sont coûteux.',
        '• De bons programmeurs et chercheurs sont nécessaires.',
        '• Il y a petits coûts par transaction.',
        '• Le rendement annuel peut être autour de 10-20%, mais il y a aussi risque.'
      ],
      ru: [
        '• Мощные компьютеры и услуги данных дорогостоящи.',
        '• Нужны хорошие программисты и исследователи.',
        '• Есть небольшие затраты за транзакцию.',
        '• Годовая доходность может составлять около 10-20%, но есть и риск.'
      ]
    },
    example: { 
      tr: '💰 Ortalama bir algoritmik işlem sistemi, yıllık %18 getiri sağladı.',
      en: '💰 An average algorithmic trading system provided 18% annual return.',
      es: '💰 Un sistema promedio de trading algorítmico proporcionó 18% de retorno anual.',
      fr: '💰 Un système moyen de trading algorithmique a fourni 18% de rendement annuel.',
      ru: '💰 Средняя система алгоритмической торговли обеспечила 18% годовой доходности.'
    },
    icon: <DollarSign className="w-16 h-16 text-green-600" />
  },
  {
    title: { 
      tr: 'Yaygın Hatalar', 
      en: 'Common Mistakes', 
      es: 'Errores Comunes', 
      fr: 'Erreurs Communes', 
      ru: 'Распространенные ошибки' 
    },
    content: { 
      tr: [
        '• Geçmiş veriye aşırı uyarlamak (gelecekte çalışmaz).',
        '• Stop-loss gibi risk yönetimini kullanmamak.',
        '• Hatalı veya eksik veriyle çalışmak.',
        '• Sistem çökmesi ya da internet kesintisine hazırlıksız olmak.',
        '• Stratejiyi sabırsızca erken bırakmak.'
      ],
      en: [
        '• Over-adapting to historical data (won\'t work in future).',
        '• Not using risk management like stop-loss.',
        '• Working with incorrect or incomplete data.',
        '• Being unprepared for system crashes or internet outages.',
        '• Impatiently abandoning strategy too early.'
      ],
      es: [
        '• Sobre-adaptar a datos históricos (no funcionará en futuro).',
        '• No usar gestión de riesgo como stop-loss.',
        '• Trabajar con datos incorrectos o incompletos.',
        '• No estar preparado para caídas del sistema o cortes de internet.',
        '• Impaciente abandono de estrategia muy temprano.'
      ],
      fr: [
        '• Sur-adapter aux données historiques (ne marchera pas dans futur).',
        '• Ne pas utiliser gestion de risque comme stop-loss.',
        '• Travailler avec données incorrectes ou incomplètes.',
        '• Être non préparé pour crashes système ou pannes internet.',
        '• Abandon impatient de stratégie trop tôt.'
      ],
      ru: [
        '• Чрезмерная адаптация к историческим данным (не будет работать в будущем).',
        '• Неисполь��ование управления рисками, такого как стоп-лосс.',
        '• Работа с неверными или неполными данными.',
        '• Неготовность к сбоям системы или отключениям интернета.',
        '• Нетерпеливое преждевременное прекращение стратегии.'
      ]
    },
    example: { 
      tr: '⚠️ Bir fon, aşırı optimizasyon nedeniyle %30 zarar etti.',
      en: '⚠️ A fund lost 30% due to over-optimization.',
      es: '⚠️ Un fondo perdió 30% debido a sobre-optimización.',
      fr: '⚠️ Un fonds a perdu 30% à cause de sur-optimisation.',
      ru: '⚠️ Фонд потерял 30% из-за чрезмерной оптимизации.'
    },
    icon: <AlertCircle className="w-16 h-16 text-red-600" />
  },
  {
    title: { 
      tr: 'Mobil ve Bulut Çözümleri', 
      en: 'Mobile and Cloud Solutions', 
      es: 'Soluciones Móviles y en la Nube', 
      fr: 'Solutions Mobiles et Cloud', 
      ru: 'Мобильные и облачные решения' 
    },
    content: { 
      tr: [
        '• Bulut sistemler sayesinde herkes güçlü altyapıya erişebilir.',
        '• Telefon uygulamalarıyla portföy anlık takip edilebilir.',
        '• API\'ler sayesinde farklı borsalar bağlanabilir.',
        '• Uzak sunuculara strateji yükleyip 7/24 çalıştırmak mümkündür.'
      ],
      en: [
        '• Thanks to cloud systems, everyone can access powerful infrastructure.',
        '• Portfolio can be tracked real-time through phone apps.',
        '• Different exchanges can be connected thanks to APIs.',
        '• It\'s possible to upload strategies to remote servers and run 24/7.'
      ],
      es: [
        '• Gracias a sistemas en la nube, todos pueden acceder a infraestructura potente.',
        '• La cartera puede ser rastreada en tiempo real a través de apps de teléfono.',
        '• Diferentes intercambios pueden conectarse gracias a APIs.',
        '• Es posible subir estrategias a servidores remotos y ejecutar 24/7.'
      ],
      fr: [
        '• Grâce aux systèmes cloud, tout le monde peut accéder à infrastructure puissante.',
        '• Le portefeuille peut être suivi en temps réel par apps téléphone.',
        '• Différentes bourses peuvent être connectées grâce aux APIs.',
        '• Il est possible d\'uploader stratégies vers serveurs distants et exécuter 24/7.'
      ],
      ru: [
        '• Благодаря облачным системам каждый может получить доступ к мощной инфраструктуре.',
        '• Портфель можно о��слеживать в реальном времени через телефонные приложения.',
        '• Различные биржи могут быть подключены благодаря API.',
        '• Возможно загружать стратегии на удаленные серверы и запускать 24/7.'
      ]
    },
    example: { 
      tr: '📱 2025\'te algoritmaların %40\'ı bulut tabanlı çalışıyordu.',
      en: '📱 In 2025, 40% of algorithms were running on cloud-based systems.',
      es: '📱 En 2025, 40% de algoritmos estaban ejecutándose en sistemas basados en la nube.',
      fr: '📱 En 2025, 40% des algorithmes fonctionnaient sur systèmes basés cloud.',
      ru: '📱 В 2025 году 40% алгоритмов работали на облачных системах.'
    },
    icon: <Smartphone className="w-16 h-16 text-indigo-500" />
  },
  {
    title: { 
      tr: 'Gelecek Trendleri', 
      en: 'Future Trends', 
      es: 'Tendencias Futuras', 
      fr: 'Tendances Futures', 
      ru: 'Будущие тренды' 
    },
    content: { 
      tr: [
        '• Kuantum bilgisayarlar: Çok daha hızlı analizler yapılabilecek.',
        '• Yapay zeka: Piyasaları daha akıllı şekilde okuyacak.',
        '• Blockchain: DeFi dünyasında algoritmalar işlem yapacak.',
        '• Yeşil finans: Enerji dostu algoritmalar gündeme gelecek.',
        '• Yeni kurallar: Şeffaflık ve denetim daha da artacak.'
      ],
      en: [
        '• Quantum computers: Much faster analyses will be possible.',
        '• Artificial intelligence: Will read markets more intelligently.',
        '• Blockchain: Algorithms will trade in DeFi world.',
        '• Green finance: Energy-friendly algorithms will come to agenda.',
        '• New rules: Transparency and oversight will increase further.'
      ],
      es: [
        '• Computadoras cuánticas: Serán posibles análisis mucho más rápidos.',
        '• Inteligencia artificial: Leerá mercados más inteligentemente.',
        '• Blockchain: Algoritmos operarán en mundo DeFi.',
        '• Finanzas verdes: Algoritmos amigables con energía vendrán a agenda.',
        '• Nuevas reglas: Transparencia y supervisión aumentarán más.'
      ],
      fr: [
        '• Ordinateurs quantiques: Analyses beaucoup plus rapides seront possibles.',
        '• Intelligence artificielle: Lira marchés plus intelligemment.',
        '• Blockchain: Algorithmes traderont dans monde DeFi.',
        '• Finance verte: Algorithmes respectueux énergie viendront à agenda.',
        '• Nouvelles règles: Transparence et surveillance augmenteront davantage.'
      ],
      ru: [
        '• Квантовые компьютеры: Будут возможны гораздо более быстрые анализы.',
        '• Искусственный интеллект: Будет читать рынки более умно.',
        '• Блокчейн: Алгоритмы будут торговать в мире DeFi.',
        '• Зеленые финансы: Энергоэффективные алгоритмы войдут в повестку дня.',
        '• Новые правила: Прозрачность и надзор будут увеличиваться дальше.'
      ]
    },
    example: { 
      tr: '🚀 Kuantum bilgisayarlar portföy hesaplarını %50 hızlandırdı.',
      en: '🚀 Quantum computers accelerated portfolio calculations by 50%.',
      es: '🚀 Computadoras cuánticas aceleraron cálculos de cartera en 50%.',
      fr: '🚀 Ordinateurs quantiques ont accéléré calculs de portefeuille de 50%.',
      ru: '🚀 Квантовые компьютеры ускорили расчеты портфеля на 50%.'
    },
    icon: <Rocket className="w-16 h-16 text-purple-600" />
  }
]

export const algorithmicTradingQuiz = [
  {
    question: {
      tr: 'Algoritmik işlem nedir?',
      en: 'What is algorithmic trading?',
      es: '¿Qué es el trading algorítmico?',
      fr: 'Qu\'est-ce que le trading algorithmique?',
      ru: 'Что такое алгоритмическая торговля?'
    },
    options: {
      tr: ['İnsanların duygularıyla yaptığı işlem', 'Bilgisayarların belirlenmiş kurallarla otomatik işlem yapması', 'Sadece büyük yatırımcıların kullandığı sistem', 'Hiç işlem yapılmaması'],
      en: ['Trading done by humans with emotions', 'Computers making automatic trades with predetermined rules', 'System used only by large investors', 'Not making any trades'],
      es: ['Trading hecho por humanos con emociones', 'Computadoras haciendo operaciones automáticas con reglas predeterminadas', 'Sistema usado solo por grandes inversores', 'No hacer ninguna operación'],
      fr: ['Trading fait par humains avec émotions', 'Ordinateurs faisant des transactions automatiques avec règles prédéterminées', 'Système utilisé seulement par grands investisseurs', 'Ne faire aucune transaction'],
      ru: ['Торговля людьми с эмоциями', 'Компьютеры совершают автоматические сделки по заранее определенным правилам', 'Система, используемая только крупными инвесторами', 'Не совершать никаких сделок']
    },
    correct: 1
  },
  {
    question: {
      tr: 'Algoritmalar neden duygusal hatalardan korunur?',
      en: 'Why are algorithms protected from emotional errors?',
      es: '¿Por qué los algoritmos están protegidos de errores emocionales?',
      fr: 'Pourquoi les algorithmes sont-ils protégés des erreurs émotionnelles?',
      ru: 'Почему алгоритмы защищены от эмоциональных ошибок?'
    },
    options: {
      tr: ['Çünkü bilgisayarların korkusu ve açgözlülüğü yoktur', 'Çünkü bilgisayar uyuyabilir', 'Çünkü algoritmalar yavaş çalışır', 'Çünkü internet yoktur'],
      en: ['Because computers have no fear and greed', 'Because computers can sleep', 'Because algorithms work slowly', 'Because there is no internet'],
      es: ['Porque las computadoras no tienen miedo ni avaricia', 'Porque las computadoras pueden dormir', 'Porque los algoritmos trabajan lentamente', 'Porque no hay internet'],
      fr: ['Parce que les ordinateurs n\'ont pas de peur ni d\'avidité', 'Parce que les ordinateurs peuvent dormir', 'Parce que les algorithmes travaillent lentement', 'Parce qu\'il n\'y a pas d\'internet'],
      ru: ['Потому что у компьютеров нет страха и жадности', 'Потому что компьютеры могут спать', 'Потому что алгоритмы работают медленно', 'Потому что нет интернета']
    },
    correct: 0
  },
  {
    question: {
      tr: 'Algoritmik işlemlerin en büyük avantajı nedir?',
      en: 'What is the biggest advantage of algorithmic trading?',
      es: '¿Cuál es la mayor ventaja del trading algorítmico?',
      fr: 'Quel est le plus grand avantage du trading algorithmique?',
      ru: 'Каково самое большое преимущество алгоритмической торговли?'
    },
    options: {
      tr: ['Daha hızlı işlem yapabilmesi', 'Daha yavaş işlem yapması', 'Yanlış haberlerle işlem yapması', 'İnsan kararlarını kopyalaması'],
      en: ['Being able to trade faster', 'Trading slower', 'Trading with false news', 'Copying human decisions'],
      es: ['Poder operar más rápido', 'Operar más lento', 'Operar con noticias falsas', 'Copiar decisiones humanas'],
      fr: ['Pouvoir trader plus vite', 'Trader plus lentement', 'Trader avec de fausses nouvelles', 'Copier les décisions humaines'],
      ru: ['Возможность торговать быстрее', 'Торговать медленнее', 'Торговать с ложными новостями', 'Копировать человеческие решения']
    },
    correct: 0
  },
  {
    question: {
      tr: 'Hacim ağırlıklı ortalama fiyat (VWAP) algoritması ne işe yarar?',
      en: 'What does Volume Weighted Average Price (VWAP) algorithm do?',
      es: '¿Qué hace el algoritmo de Precio Promedio Ponderado por Volumen (VWAP)?',
      fr: 'Que fait l\'algorithme de Prix Moyen Pondéré par Volume (VWAP)?',
      ru: 'Что делает алгоритм средневзвешенной по объему цены (VWAP)?'
    },
    options: {
      tr: ['İşlemleri rastgele yapar', 'Fiyatların ortalamasına göre alım-satım yapar', 'İnsanların duygularına göre karar verir', 'Sadece gece çalışır'],
      en: ['Makes trades randomly', 'Makes buy-sell decisions based on price averages', 'Makes decisions based on human emotions', 'Only works at night'],
      es: ['Hace operaciones al azar', 'Hace decisiones de compra-venta basadas en promedios de precios', 'Toma decisiones basadas en emociones humanas', 'Solo funciona de noche'],
      fr: ['Fait des transactions aléatoirement', 'Prend des décisions d\'achat-vente basées sur moyennes de prix', 'Prend des décisions basées sur émotions humaines', 'Ne fonctionne que la nuit'],
      ru: ['Совершает сделки случайно', 'Принимает решения о покупке-продаже на основе средних цен', 'Принимает решения на основе человеческих эмоций', 'Работает только ночью']
    },
    correct: 1
  },
  {
    question: {
      tr: 'Yüksek frekanslı işlemin (HFT) özelliği nedir?',
      en: 'What is the characteristic of High Frequency Trading (HFT)?',
      es: '¿Cuál es la característica del Trading de Alta Frecuencia (HFT)?',
      fr: 'Quelle est la caractéristique du Trading Haute Fréquence (HFT)?',
      ru: 'Какова характеристика высокочастотной торговли (HFT)?'
    },
    options: {
      tr: ['Çok yavaş çalışır', 'Saniyenin milyonda biri hızında işlem yapabilir', 'Sadece altın için çalışır', 'İnternet olmadan çalışır'],
      en: ['Works very slowly', 'Can make trades in microseconds', 'Only works for gold', 'Works without internet'],
      es: ['Funciona muy lentamente', 'Puede hacer operaciones en microsegundos', 'Solo funciona para oro', 'Funciona sin internet'],
      fr: ['Fonctionne très lentement', 'Peut faire des transactions en microsecondes', 'Ne fonctionne que pour l\'or', 'Fonctionne sans internet'],
      ru: ['Работает очень ��едленно', 'Может совершать сделки в микросекундах', 'Работает только с золотом', 'Работает без интернета']
    },
    correct: 1
  },
  {
    question: {
      tr: 'Ortalama dönüşü stratejisinde temel fikir nedir?',
      en: 'What is the basic idea in mean reversion strategy?',
      es: '¿Cuál es la idea básica en la estrategia de reversión a la media?',
      fr: 'Quelle est l\'idée de base dans la stratégie de retour à la moyenne?',
      ru: 'Какова основная идея стратегии возврата к среднему?'
    },
    options: {
      tr: ['Fiyatlar yükseldikçe daha da yükselecek', 'Fiyatlar düştükçe hep düşmeye devam edecek', 'Fiyatlar ortalamadan uzaklaşınca yeniden ortalamaya döner', 'Fiyatlar tamamen rastgele hareket eder'],
      en: ['Prices will keep rising as they rise', 'Prices will keep falling as they fall', 'Prices return to average when they deviate from it', 'Prices move completely randomly'],
      es: ['Los precios seguirán subiendo mientras suban', 'Los precios seguirán bajando mientras bajen', 'Los precios vuelven al promedio cuando se desvían de él', 'Los precios se mueven completamente al azar'],
      fr: ['Les prix continueront à monter en montant', 'Les prix continueront à baisser en baissant', 'Les prix retournent à la moyenne quand ils s\'en écartent', 'Les prix bougent complètement aléatoirement'],
      ru: ['Цены будут продолжать расти по мере роста', 'Цены будут продолжать падать по мере падения', 'Цены возвращаются к среднему, когда отклоняются от него', 'Цены движутся совершенно случайно']
    },
    correct: 2
  },
  {
    question: {
      tr: 'Acil durdurma mekanizması (kill switch) ne işe yarar?',
      en: 'What does the emergency stop mechanism (kill switch) do?',
      es: '¿Qué hace el mecanismo de parada de emergencia (kill switch)?',
      fr: 'Que fait le mécanisme d\'arrêt d\'urgence (kill switch)?',
      ru: 'Что делает механизм экстренной остановки (kill switch)?'
    },
    options: {
      tr: ['Daha çok kâr yapar', 'Acil durumda algoritmayı kapatır', 'Fiyatları yükseltir', 'Daha hızlı internet sağlar'],
      en: ['Makes more profit', 'Shuts down the algorithm in emergency', 'Raises prices', 'Provides faster internet'],
      es: ['Hace más ganancia', 'Cierra el algoritmo en emergencia', 'Sube los precios', 'Proporciona internet más rápido'],
      fr: ['Fait plus de profit', 'Ferme l\'algorithme en urgence', 'Augmente les prix', 'Fournit internet plus rapide'],
      ru: ['Приносит больше прибыли', 'Отключает алгоритм в экстренной ситуации', 'Повышает цены', 'Обеспечивает более быстрый интернет']
    },
    correct: 1
  },
  {
    question: {
      tr: 'Algoritmik işlemde yapılan en büyük hatalardan biri "aşırı uyum (overfitting)"dur. Bu ne demektir?',
      en: 'One of the biggest mistakes in algorithmic trading is "overfitting". What does this mean?',
      es: 'Uno de los mayores errores en trading algorítmico es "overfitting". ¿Qué significa esto?',
      fr: 'Une des plus grosses erreurs en trading algorithmique est "overfitting". Que signifie ceci?',
      ru: 'Одна из самых больших ошибок в алгоритмической торговле - "переобучение". Что это означает?'
    },
    options: {
      tr: ['Algoritmanın geçmiş verilere çok fazla uyum sağlaması ve gelecekte işe yaramaması', 'Algoritmanın hiç işlem yapmaması', 'Algoritmanın çok yavaş çalışması', 'Algoritmanın duygusal kararlar alması'],
      en: ['Algorithm adapting too much to historical data and not working in the future', 'Algorithm not making any trades', 'Algorithm working too slowly', 'Algorithm making emotional decisions'],
      es: ['Algoritmo adaptándose demasiado a datos históricos y no funcionando en el futuro', 'Algoritmo no haciendo ninguna operación', 'Algoritmo funcionando muy lentamente', 'Algoritmo tomando decisiones emocionales'],
      fr: ['Algorithme s\'adaptant trop aux données historiques et ne fonctionnant pas dans le futur', 'Algorithme ne faisant aucune transaction', 'Algorithme fonctionnant trop lentement', 'Algorithme prenant des décisions émotionnelles'],
      ru: ['Алгоритм слишком сильно адаптируется к историческим данным и не работает в будущем', 'Алгоритм не совершает никаких сделок', 'Алгоритм работает слишком медленно', 'Алгоритм принимает эмоциональные решения']
    },
    correct: 0
  },
  {
    question: {
      tr: 'Aşağıdakilerden hangisi iyi bir risk yönetimi örneğidir?',
      en: 'Which of the following is a good risk management example?',
      es: '¿Cuál de los siguientes es un buen ejemplo de gestión de riesgo?',
      fr: 'Lequel des suivants est un bon exemple de gestion des risques?',
      ru: 'Какой из следующих является хорошим примером управления рисками?'
    },
    options: {
      tr: ['Hiç zarar etmeyeceğini düşünmek', 'Zarar durdurma (stop-loss) kullanmak', 'T��m parayı tek hisseye yatırmak', 'Rastgele işlem yapmak'],
      en: ['Thinking you will never lose', 'Using stop-loss', 'Investing all money in one stock', 'Making random trades'],
      es: ['Pensar que nunca perderás', 'Usar stop-loss', 'Invertir todo el dinero en una acción', 'Hacer operaciones aleatorias'],
      fr: ['Penser que vous ne perdrez jamais', 'Utiliser stop-loss', 'Investir tout l\'argent dans une action', 'Faire des transactions aléatoires'],
      ru: ['Думать, что вы никогда не проиграете', 'Использовать стоп-лосс', 'Инвестировать все деньги в одну акцию', 'Совершать случайные сделки']
    },
    correct: 1
  },
  {
    question: {
      tr: 'Algoritmik işlemlerde en çok kullanılan programlama dili hangisidir?',
      en: 'Which is the most used programming language in algorithmic trading?',
      es: '¿Cuál es el lenguaje de programación más usado en trading algorítmico?',
      fr: 'Quel est le langage de programmation le plus utilisé en trading algorithmique?',
      ru: 'Какой язык программирования наиболее используется в алгоритмической торговле?'
    },
    options: {
      tr: ['Python', 'Arapça', 'PHP', 'Word'],
      en: ['Python', 'Arabic', 'PHP', 'Word'],
      es: ['Python', 'Árabe', 'PHP', 'Word'],
      fr: ['Python', 'Arabe', 'PHP', 'Word'],
      ru: ['Python', 'Арабский', 'PHP', 'Word']
    },
    correct: 0
  },
  {
    question: {
      tr: 'Algoritmalar hangi verilerle çalışabilir?',
      en: 'What data can algorithms work with?',
      es: '¿Con qué datos pueden trabajar los algoritmos?',
      fr: 'Avec quelles données les algorithmes peuvent-ils travailler?',
      ru: 'С какими данными могут работать алгоритмы?'
    },
    options: {
      tr: ['Sadece fiyat verisi', 'Fiyat, haberler, sosyal medya, hatta uydu görüntüleri', 'Sadece kahve fiyatları', 'Hiç veri kullanmaz'],
      en: ['Only price data', 'Price, news, social media, even satellite images', 'Only coffee prices', 'Uses no data'],
      es: ['Solo datos de precio', 'Precio, noticias, redes sociales, incluso imágenes satelitales', 'Solo precios del café', 'No usa datos'],
      fr: ['Seulement données de prix', 'Prix, nouvelles, réseaux sociaux, même images satellite', 'Seulement prix du café', 'N\'utilise aucune donnée'],
      ru: ['Только ценовые данные', 'Цены, новости, социальные сети, даже спутниковые изображения', 'Только цены на кофе', 'Не использует данные']
    },
    correct: 1
  },
  {
    question: {
      tr: 'Bulut (cloud) tabanlı sistemlerin avantajı nedir?',
      en: 'What is the advantage of cloud-based systems?',
      es: '¿Cuál es la ventaja de los sistemas basados en la nube?',
      fr: 'Quel est l\'avantage des systèmes basés sur le cloud?',
      ru: 'В чем преимущество облачных систем?'
    },
    options: {
      tr: ['Dünyanın her yerinden erişim ve düşük maliyet', 'Sadece ofisten kullanılabilmesi', 'İnternetsiz çalışması', 'Sadece tek bilgisayarda çalışması'],
      en: ['Access from anywhere in the world and low cost', 'Can only be used from office', 'Works without internet', 'Only works on one computer'],
      es: ['Acceso desde cualquier lugar del mundo y bajo costo', 'Solo puede usarse desde la oficina', 'Funciona sin internet', 'Solo funciona en una computadora'],
      fr: ['Accès de partout dans le monde et faible coût', 'Ne peut être utilisé que depuis le bureau', 'Fonctionne sans internet', 'Ne fonctionne que sur un ordinateur'],
      ru: ['Доступ из любой точки мира и низкая стоимость', 'Можно использовать только из офиса', 'Работает без интернета', 'Работает только на одном компьютере']
    },
    correct: 0
  },
  {
    question: {
      tr: 'Kuantum bilgisayarlar algoritmik işlemlerde neyi hızlandırabilir?',
      en: 'What can quantum computers accelerate in algorithmic trading?',
      es: '¿Qué pueden acelerar las computadoras cuánticas en trading algorítmico?',
      fr: 'Que peuvent accélérer les ordinateurs quantiques en trading algorithmique?',
      ru: 'Что могут ускорить квантовые компьютеры в алгоритмической торговле?'
    },
    options: {
      tr: ['Çay demlemeyi', 'Portföy optimizasyonunu', 'Telefon konuşmalarını', 'Grafik çizmeyi'],
      en: ['Tea brewing', 'Portfolio optimization', 'Phone conversations', 'Drawing graphics'],
      es: ['Preparar té', 'Optimización de cartera', 'Conversaciones telefónicas', 'Dibujar gráficos'],
      fr: ['Infuser le thé', 'Optimisation de portefeuille', 'Conversations téléphoniques', 'Dessiner des graphiques'],
      ru: ['Заваривание чая', 'Оптимизацию портфеля', 'Телефонные разговоры', 'Рисование графиков']
    },
    correct: 1
  },
  {
    question: {
      tr: 'Merkeziyetsiz finans (DeFi) içinde algoritmalar ne yapabilir?',
      en: 'What can algorithms do in Decentralized Finance (DeFi)?',
      es: '¿Qué pueden hacer los algoritmos en Finanzas Descentralizadas (DeFi)?',
      fr: 'Que peuvent faire les algorithmes en Finance Décentralisée (DeFi)?',
      ru: 'Что могут делать алгоритмы в децентрализованных финансах (DeFi)?'
    },
    options: {
      tr: ['Otomatik piyasa yapıcılık (AMM)', 'Rüya yorumlama', 'Astroloji tahmini', 'Rastgele sayı üretme'],
      en: ['Automated Market Making (AMM)', 'Dream interpretation', 'Astrology prediction', 'Random number generation'],
      es: ['Creación Automática de Mercado (AMM)', 'Interpretación de sueños', 'Predicción astrológica', 'Generación de números aleatorios'],
      fr: ['Création de Marché Automatisée (AMM)', 'Interprétation des rêves', 'Prédiction astrologique', 'Génération de nombres aléatoires'],
      ru: ['Автоматизированное создание рынка (AMM)', 'Толкование снов', 'Астрологические предсказания', 'Генерация случайных чисел']
    },
    correct: 0
  },
  {
    question: {
      tr: 'Yapay zekâ (örneğin ChatGPT gibi modeller) algoritmik işlemlerde nerede faydalı olabilir?',
      en: 'Where can artificial intelligence (like ChatGPT models) be useful in algorithmic trading?',
      es: '¿Dónde puede ser útil la inteligencia artificial (como modelos ChatGPT) en trading algorítmico?',
      fr: 'Où l\'intelligence artificielle (comme les modèles ChatGPT) peut-elle être utile en trading algorithmique?',
      ru: 'Где искусственный интеллект (как модели ChatGPT) может быть полезен в алгоритмической торговле?'
    },
    options: {
      tr: ['Haber ve duygu analizinde', 'Yemek tariflerinde', 'Spor tahminlerinde', 'Hava durumunu değiştirmekte'],
      en: ['In news and sentiment analysis', 'In cooking recipes', 'In sports predictions', 'In changing weather'],
      es: ['En análisis de noticias y sentimientos', 'En recetas de cocina', 'En predicciones deportivas', 'En cambiar el clima'],
      fr: ['Dans l\'analyse des nouvelles et des sentiments', 'Dans les recettes de cuisine', 'Dans les prédictions sportives', 'Dans le changement de météo'],
      ru: ['В анализе новостей и настроений', 'В кулинарных рецептах', 'В спортивных прогнозах', 'В изменении погоды']
    },
    correct: 0
  }
]