import { BarChart3, TrendingUp, Target, Calculator, FileText, DollarSign, PieChart, Settings, Building, Zap, Shield, Users, Lightbulb, Activity, Brain } from 'lucide-react'

export const fundamentalAnalysisSlides = [
  {
    title: { 
      tr: 'Temel Analiz Nedir?', 
      en: 'What is Fundamental Analysis?', 
      es: '¿Qué es el Análisis Fundamental?', 
      fr: 'Qu\'est-ce que l\'Analyse Fondamentale?', 
      ru: 'Что такое фундаментальный анализ?' 
    },
    content: { 
      tr: [
        '• Temel analiz, şirketlerin, sektörlerin ve ülkelerin finansal sağlığını inceleyerek bir varlığın gerçek değerini bulma yöntemidir.',
        '• Amaç, hesapladığınız gerçek değeri piyasa fiyatıyla karşılaştırıp alım veya satış kararları almaktır.',
        '• Bu analizde finansal tablolar, makro veriler, sektör raporları ve yönetim değerlendirmesi kullanılır.'
      ],
      en: [
        '• Fundamental analysis is a method of finding the true value of an asset by examining the financial health of companies, sectors, and countries.',
        '• The goal is to compare the calculated true value with market price to make buy or sell decisions.',
        '• This analysis uses financial statements, macro data, sector reports and management assessment.'
      ],
      es: [
        '• El análisis fundamental es un método para encontrar el valor real de un activo examinando la salud financiera de empresas, sectores y países.',
        '• El objetivo es comparar el valor real calculado con el precio de mercado para tomar decisiones de compra o venta.',
        '• Este análisis utiliza estados financieros, datos macro, informes sectoriales y evaluación de gestión.'
      ],
      fr: [
        '• L\'analyse fondamentale est une méthode pour trouver la vraie valeur d\'un actif en examinant la santé financière des entreprises, secteurs et pays.',
        '• L\'objectif est de comparer la vraie valeur calculée avec le prix du marché pour prendre des décisions d\'achat ou de vente.',
        '• Cette analyse utilise des états financiers, données macro, rapports sectoriels et évaluation de gestion.'
      ],
      ru: [
        '• Фундаментальный анализ - это метод определения истинной стоимости актива путем изучения финансового здоровья компаний, секторов и стран.',
        '• Цель - сравнить рассчитанную истинную стоимость с рыночной ценой для принятия решений о покупке или продаже.',
        '• Этот анализ использует финансовые отчеты, макро данные, отраслевые отчеты и оценку управления.'
      ]
    },
    example: { 
      tr: '📊 Apple\'ın 2025 değerlemesi: P/E 28, güçlü iPhone satışları destekliyor.',
      en: '📊 Apple\'s 2025 valuation: P/E 28, supported by strong iPhone sales.',
      es: '📊 Valoración de Apple 2025: P/E 28, respaldada por fuertes ventas de iPhone.',
      fr: '📊 Évaluation d\'Apple 2025: P/E 28, soutenue by de fortes ventes d\'iPhone.',
      ru: '📊 Оценка Apple 2025: P/E 28, поддерживается сильными продажами iPhone.'
    },
    icon: <BarChart3 className="w-16 h-16 text-blue-500" />
  },
  {
    title: { 
      tr: 'Temel Analizin Temel İlkeleri', 
      en: 'Basic Principles of Fundamental Analysis', 
      es: 'Principios Básicos del Análisis Fundamental', 
      fr: 'Principes de Base de l\'Analyse Fondamentale', 
      ru: 'Основные принципы фундаментального анализа' 
    },
    content: { 
      tr: [
        '• Temel analiz, şirketin bugünkü durumunu ve gelecekteki nakit üretme gücünü değerlendirir.',
        '• Makro faktörler: GSYH, enflasyon, faiz oranları',
        '• Mikro faktörler: şirketin kârı, borcu, yönetimi ve sektörel karşılaştırmalar önem taşır.',
        '• Genellikle 1 yıldan uzun vadeli yatırımlar için uygundur.'
      ],
      en: [
        '• Fundamental analysis evaluates company\'s current situation and future cash generation power.',
        '• Macro factors: GDP, inflation, interest rates',
        '• Micro factors: company profit, debt, management and sectoral comparisons are important.',
        '• Generally suitable for investments longer than 1 year.'
      ],
      es: [
        '• El análisis fundamental evalúa la situación actual de la empresa y su poder futuro de generación de efectivo.',
        '• Factores macro: PIB, inflación, tasas de interés',
        '• Factores micro: ganancia de la empresa, deuda, gestión y comparaciones sectoriales son importantes.',
        '• Generalmente adecuado para inversiones de más de 1 año.'
      ],
      fr: [
        '• L\'analyse fondamentale évalue la situation actuelle de l\'entreprise et son pouvoir futur de génération de trésorerie.',
        '• Facteurs macro: PIB, inflation, taux d\'intérêt',
        '• Facteurs micro: profit de l\'entreprise, dette, gestion et comparaisons sectorielles sont importantes.',
        '• Généralement adapté aux investissements de plus d\'1 an.'
      ],
      ru: [
        '• Фундаментальный анализ оценивает текущую ситуацию компании и будущую способность генерации денежных средств.',
        '• Макро факторы: ВВП, инфляция, процентные ставки',
        '• Микро факторы: прибыль компании, долг, управление и отраслевые сравнения важны.',
        '• Обычно подходит для инвестиций длительностью более 1 года.'
      ]
    },
    example: { 
      tr: '📈 Microsoft\'un bulut büyümesi 2025\'te değerlemesini %20 artırdı.',
      en: '📈 Microsoft\'s cloud growth increased valuation by 20% in 2025.',
      es: '📈 El crecimiento en la nube de Microsoft aumentó la valoración en 20% en 2025.',
      fr: '📈 La croissance cloud de Microsoft a augmenté l\'évaluation de 20% en 2025.',
      ru: '📈 Рост облачных технологий Microsoft увеличил оценку на 20% в 2025 году.'
    },
    icon: <TrendingUp className="w-16 h-16 text-green-500" />
  },
  {
    title: { 
      tr: 'Makroekonomik Faktörler', 
      en: 'Macroeconomic Factors', 
      es: 'Factores Macroeconómicos', 
      fr: 'Facteurs Macroéconomiques', 
      ru: 'Макроэкономические факторы' 
    },
    content: { 
      tr: [
        '• Ekonomik büyüme (<tooltip term="GSYH">Gayri Safi Yurtiçi Hasıla - bir ülkenin belirli dönemde ürettiği toplam mal ve hizmetlerin değeri</tooltip>), enflasyon ve faiz oranları şirket kârlarını etkiler.',
        '• Döviz kurları ihracatçı ve ithalatçı şirketleri farklı etkiler.',
        '• Analistler bu göstergelerin sektörlere etkisini değerlendirir.'
      ],
      en: [
        '• Economic growth (GDP), inflation and interest rates affect company profits.',
        '• Exchange rates affect exporter and importer companies differently.',
        '• Analysts evaluate the impact of these indicators on sectors.'
      ],
      es: [
        '• El crecimiento económico (PIB), inflación y tasas de interés afectan las ganancias de las empresas.',
        '• Los tipos de cambio afectan de manera diferente a empresas exportadoras e importadoras.',
        '• Los analistas evalúan el impacto de estos indicadores en los sectores.'
      ],
      fr: [
        '• La croissance économique (PIB), inflation et taux d\'intérêt affectent les profits des entreprises.',
        '• Les taux de change affectent différemment les entreprises exportatrices et importatrices.',
        '• Les analystes évaluent l\'impact de ces indicateurs sur les secteurs.'
      ],
      ru: [
        '• Экономический рост (ВВП), инфляция и процентные ставки влияют на прибыль компаний.',
        '• Обменные курсы по-разному влияют на экспортирующие и импортирующие компании.',
        '• Аналитики оценивают влияние этих показателей на сектора.'
      ]
    },
    example: { 
      tr: '📊 2025\'te ABD GSYH\'si %2.1 büyüdü; teknoloji hisseleri %15 yükseldi.',
      en: '📊 In 2025, US GDP grew 2.1%; technology stocks rose 15%.',
      es: '📊 En 2025, el PIB de EE.UU. creció 2.1%; las acciones tecnológicas subieron 15%.',
      fr: '📊 En 2025, le PIB américain a augmenté de 2,1% ; les actions technologiques ont augmenté de 15%.',
      ru: '📊 В 2025 году ВВП США вырос на 2,1%; технологические акции выросли на 15%.'
    },
    icon: <Target className="w-16 h-16 text-purple-500" />
  },
  {
    title: { 
      tr: 'Sektörel Analiz', 
      en: 'Sector Analysis', 
      es: 'Análisis Sectorial', 
      fr: 'Analyse Sectorielle', 
      ru: 'Отраслевой анализ' 
    },
    content: { 
      tr: [
        '• Her sektörün büyüme hızı, rekabet düzeyi ve düzenleme riski farklıdır.',
        '• Sektör yaşam döngüsü (gelişim, olgunluk, gerileme) ve megatrendler (<tooltip term="AI">Yapay Zeka - insan zekasını taklit eden bilgisayar sistemleri</tooltip>, yenilenebilir enerji) takip edin.',
        '• Lider şirketlerin pazar payı, maliyet avantajı ve yenilik kapasitesi karşılaştırılmalıdır.'
      ],
      en: [
        '• Each sector has different growth rate, competition level and regulation risk.',
        '• Follow sector lifecycle (development, maturity, decline) and megatrends (<tooltip term="AI">Artificial Intelligence - computer systems that mimic human intelligence</tooltip>, renewable energy).',
        '• Market share, cost advantage and innovation capacity of leading companies should be compared.'
      ],
      es: [
        '• Cada sector tiene diferente tasa de crecimiento, nivel de competencia y riesgo de regulación.',
        '• Seguir ciclo de vida sectorial (desarrollo, madurez, declive) y megatendencias (<tooltip term="IA">Inteligencia Artificial - sistemas informáticos que imitan la inteligencia humana</tooltip>, energía renovable).',
        '• Se debe comparar participación de mercado, ventaja de costos y capacidad de innovación de empresas líderes.'
      ],
      fr: [
        '• Chaque secteur a un taux de croissance, niveau de concurrence et risque de réglementation différents.',
        '• Suivre cycle de vie sectoriel (développement, maturité, déclin) et mégatendances (<tooltip term="IA">Intelligence Artificielle - systèmes informatiques qui imitent l\'intelligence humaine</tooltip>, énergie renouvelable).',
        '• La part de marché, l\'avantage coût et la capacité d\'innovation des entreprises leaders doivent être comparés.'
      ],
      ru: [
        '• Каждый сектор имеет разную скорость роста, уровень конкуренции и регулятивный риск.',
        '• Следить за жизненным циклом сектора (развитие, зрелость, упадок) и мегатренды (<tooltip term="ИИ">Искусственный Интеллект - компьютерные системы, имитирующие человеческий интеллект</tooltip>, возобновляемая энергия).',
        '• Рыночная доля, преимущество в затратах и инновационная способность ведущих компаний должны сравниваться.'
      ]
    },
    example: { 
      tr: '🌱 2025\'te yeşil enerji sektörü %18 büyüdü; lider şirketler öne çıktı.',
      en: '🌱 In 2025, green energy sector grew 18%; leader companies stood out.',
      es: '🌱 En 2025, el sector de energía verde creció 18%; las empresas líderes se destacaron.',
      fr: '🌱 En 2025, le secteur de l\'énergie verte a augmenté de 18% ; les entreprises leaders se sont démarquées.',
      ru: '🌱 В 2025 году сектор зеленой энергии вырос на 18%; лидирующие компании выделились.'
    },
    icon: <Activity className="w-16 h-16 text-green-500" />
  },
  {
    title: { 
      tr: 'Şirket Analizi: Finansal Tablolar', 
      en: 'Company Analysis: Financial Statements', 
      es: 'Análisis de Empresa: Estados Financieros', 
      fr: 'Analyse d\'Entreprise: États Financiers', 
      ru: 'Анализ компании: Финансовые отчеты' 
    },
    content: { 
      tr: [
        '• Gelir tablosu: bir dönemdeki geliri ve kârı gösterir.',
        '• Bilanço: şirketin varlık ve borç durumunu gösterir.',
        '• Nakit akışı: paranın nasıl hareket ettiğini ortaya koyar.',
        '• Üç tablo bir arada değerlendirildiğinde gerçek resim çıkar.'
      ],
      en: [
        '• Income statement: shows revenue and profit for a period.',
        '• Balance sheet: shows company\'s assets and debt situation.',
        '• Cash flow: reveals how money moves.',
        '• The real picture emerges when three statements are evaluated together.'
      ],
      es: [
        '• Estado de resultados: muestra ingresos y ganancias de un período.',
        '• Balance: muestra la situación de activos y deudas de la empresa.',
        '• Flujo de efectivo: revela cómo se mueve el dinero.',
        '• La imagen real surge cuando se evalúan tres estados juntos.'
      ],
      fr: [
        '• Compte de résultat: montre les revenus et profits d\'une période.',
        '• Bilan: montre la situation d\'actifs et dettes de l\'entreprise.',
        '• Flux de trésorerie: révèle comment l\'argent bouge.',
        '• L\'image réelle émerge quand trois états sont évalués ensemble.'
      ],
      ru: [
        '• Отчет о прибылях и убытках: показывает доходы и прибыль за период.',
        '• Баланс: показывает ситуацию с активами и долгами компании.',
        '• Денежный поток: раскрывает, как движутся деньги.',
        '• Реальная картина появляется, когда три отчета оцениваются вместе.'
      ]
    },
    example: { 
      tr: '💰 2025\'te NVIDIA\'nın nakit akışı %35 arttı; AI çipi gelirleri lider.',
      en: '💰 In 2025, NVIDIA\'s cash flow increased 35%; AI chip revenues leading.',
      es: '💰 En 2025, el flujo de efectivo de NVIDIA aumentó 35%; ingresos de chips de IA lideran.',
      fr: '💰 En 2025, le flux de trésorerie de NVIDIA a augmenté de 35% ; les revenus de puces IA en tête.',
      ru: '💰 В 2025 году денежный поток NVIDIA увеличился на 35%; доходы от AI-чипов лидируют.'
    },
    icon: <FileText className="w-16 h-16 text-blue-500" />
  },
  {
    title: { 
      tr: 'Finansal Oranlar: Kârlılık', 
      en: 'Financial Ratios: Profitability', 
      es: 'Ratios Financieros: Rentabilidad', 
      fr: 'Ratios Financiers: Rentabilité', 
      ru: 'Финансовые коэффициенты: Прибыльность' 
    },
    content: { 
      tr: [
        '• Brüt kâr marjı: satış gelirlerinden satılan malın maliyeti çıkarıldıktan sonra kalan oran',
        '• Net kâr marjı: tüm giderler düşüldükten sonra kalan kâr oranı',
        '• Özkaynak getirisi (<tooltip term="ROE">Return on Equity - Özkaynak Getirisi: hissedarların yatırdığı para karşılığında elde edilen getiri oranı</tooltip>): hissedarların yatırdığı para karşılığında elde edilen getiri oranı',
        '• Varlık getirisi (<tooltip term="ROA">Return on Assets - Varlık Getirisi: şirketin toplam varlıklarından elde ettiği getiri oranı</tooltip>): şirketin toplam varlıklarından elde ettiği getiri oranı',
        '• Bu oranları aynı sektördeki şirketlerle ve şirketin geçmişiyle karşılaştırın.'
      ],
      en: [
        '• Gross profit margin: ratio remaining after cost of goods sold is deducted from sales revenue',
        '• Net profit margin: profit ratio remaining after all expenses are deducted',
        '• <tooltip term="ROE">Return on Equity - measures how effectively a company uses shareholders\' equity to generate profit</tooltip>: return rate obtained in exchange for money invested by shareholders',
        '• <tooltip term="ROA">Return on Assets - measures how efficiently a company uses its assets to generate profit</tooltip>: return rate obtained from company\'s total assets',
        '• Compare these ratios with companies in the same sector and company\'s history.'
      ],
      es: [
        '• Margen de ganancia bruta: proporción restante después de deducir el costo de bienes vendidos de los ingresos por ventas',
        '• Margen de ganancia neta: proporción de ganancia restante después de deducir todos los gastos',
        '• <tooltip term="ROE">Return on Equity - Retorno sobre Patrimonio: mide la eficiencia del uso del capital de los accionistas</tooltip>: tasa de retorno obtenida a cambio del dinero invertido por accionistas',
        '• <tooltip term="ROA">Return on Assets - Retorno sobre Activos: mide la eficiencia del uso de los activos de la empresa</tooltip>: tasa de retorno obtenida de los activos totales de la empresa',
        '• Compara estos ratios con empresas del mismo sector e historia de la empresa.'
      ],
      fr: [
        '• Marge de profit brut: proportion restante après déduction du coût des biens vendus du chiffre d\'affaires',
        '• Marge de profit net: proportion de profit restante après déduction de toutes les dépenses',
        '• <tooltip term="ROE">Return on Equity - Retour sur Capitaux Propres: mesure l\'efficacité d\'utilisation du capital des actionnaires</tooltip>: taux de retour obtenu en échange de l\'argent investi par les actionnaires',
        '• <tooltip term="ROA">Return on Assets - Retour sur Actifs: mesure l\'efficacité d\'utilisation des actifs de l\'entreprise</tooltip>: taux de retour obtenu des actifs totaux de l\'entreprise',
        '• Comparez ces ratios avec les entreprises du même secteur et l\'histoire de l\'entreprise.'
      ],
      ru: [
        '• Валовая прибыльность: доля, остающаяся после вычета себестоимости проданных товаров из выручки от продаж',
        '• Чистая прибыльность: доля прибыли, остающаяся после вычета всех расходов',
        '• <tooltip term="ROE">Return on Equity - Рентабельность Собственного Капитала: измеряет эффективность использования капитала акционеров</tooltip>: норма доходности, полученная в обмен на деньги, инвестированные акционерами',
        '• <tooltip term="ROA">Return on Assets - Рентабельность Активов: измеряет эффективность использования активов компании</tooltip>: норма доходности, полученная от общих активов компании',
        '• Сравните эти коэффициенты с компаниями того же сектора и историей компании.'
      ]
    },
    example: { 
      tr: '📈 2025\'te Apple\'ın <tooltip term="ROE">Return on Equity - Özkaynak Getirisi</tooltip>\'si %28; güçlü iPhone 16 satışları destekledi.',
      en: '📈 In 2025, Apple\'s <tooltip term="ROE">Return on Equity</tooltip> was 28%; supported by strong iPhone 16 sales.',
      es: '📈 En 2025, el <tooltip term="ROE">Return on Equity</tooltip> de Apple fue 28%; apoyado por fuertes ventas de iPhone 16.',
      fr: '📈 En 2025, le <tooltip term="ROE">Return on Equity</tooltip> d\'Apple était de 28% ; soutenu par de fortes ventes d\'iPhone 16.',
      ru: '📈 В 2025 году <tooltip term="ROE">Return on Equity</tooltip> Apple составил 28%; поддерживался сильными продажами iPhone 16.'
    },
    icon: <DollarSign className="w-16 h-16 text-green-500" />
  },
  {
    title: { 
      tr: 'Finansal Oranlar: Likidite', 
      en: 'Financial Ratios: Liquidity', 
      es: 'Ratios Financieros: Liquidez', 
      fr: 'Ratios Financiers: Liquidité', 
      ru: 'Финансовые коэффициенты: Ликвидность' 
    },
    content: { 
      tr: [
        '• Cari oran: dönen varlıkların kısa vadeli borçlara oranı',
        '• Hızlı oran: en likit varlıkların kısa vadeli borçlara oranı',
        '• Nakit oran: nakit ve nakit benzerlerinin kısa vadeli borçlara oranı',
        '• Şirketin kısa vadeli borçları karşılama gücünü gösterir. Düşük likidite nakit sıkışması riskini artırır.'
      ],
      en: [
        '• Current ratio: ratio of current assets to short-term debt',
        '• Quick ratio: ratio of most liquid assets to short-term debt',
        '• Cash ratio: ratio of cash and cash equivalents to short-term debt',
        '• Shows company\'s ability to meet short-term debt. Low liquidity increases cash crunch risk.'
      ],
      es: [
        '• Ratio corriente: proporción de activos corrientes a deuda a corto plazo',
        '• Ratio rápido: proporción de activos más líquidos a deuda a corto plazo',
        '• Ratio de efectivo: proporción de efectivo y equivalentes de efectivo a deuda a corto plazo',
        '• Muestra la capacidad de la empresa para cumplir con la deuda a corto plazo. La baja liquidez aumenta el riesgo de crisis de efectivo.'
      ],
      fr: [
        '• Ratio de liquidité générale: proportion d\'actifs courants à la dette à court terme',
        '• Ratio de liquidité réduite: proportion d\'actifs les plus liquides à la dette à court terme',
        '• Ratio de trésorerie: proportion de trésorerie et équivalents de trésorerie à la dette à court terme',
        '• Montre la capacité de l\'entreprise à respecter la dette à court terme. Une faible liquidité augmente le risque de crise de trésorerie.'
      ],
      ru: [
        '• Коэффициент текущей ликвидности: отношение оборотных активов к краткосрочной задолженности',
        '• Коэффициент быстрой ликвидности: отношение наиболее ликвидных активов к краткосрочной задолженности',
        '• Коэффициент абсолютной ликвидности: отношение денежных средств и их эквивалентов к краткосрочной задолженности',
        '• Показывает способность компании выполнять краткосрочные обязательства. Низкая ликвидность увеличивает риск нехватки денежных средств.'
      ]
    },
    example: { 
      tr: '💧 2025\'te Amazon\'un cari oranı 1.1; e-ticaret nakiti güçlü.',
      en: '💧 In 2025, Amazon\'s current ratio was 1.1; e-commerce cash strong.',
      es: '💧 En 2025, el ratio corriente de Amazon fue 1.1; efectivo de comercio electrónico fuerte.',
      fr: '💧 En 2025, le ratio de liquidité générale d\'Amazon était de 1,1 ; trésorerie e-commerce forte.',
      ru: '💧 В 2025 году коэффициент текущей ликвидности Amazon составил 1,1; денежные средства от электронной коммерции сильные.'
    },
    icon: <Target className="w-16 h-16 text-cyan-500" />
  },
  {
    title: { 
      tr: 'Finansal Oranlar: Borçluluk', 
      en: 'Financial Ratios: Leverage', 
      es: 'Ratios Financieros: Apalancamiento', 
      fr: 'Ratios Financiers: Endettement', 
      ru: 'Финансовые коэффициенты: Заемный капитал' 
    },
    content: { 
      tr: [
        '• Borç/özkaynak oranı: toplam borçların özkaynaklara oranı',
        '• Faiz karşılama oranı: faiz ödemelerini karşılayabilme gücü',  
        '• Borç geri ödeme süresi: mevcut nakit akışıyla borçları kaç yılda ödeyebileceği',
        '• Şirketin borç riskini ölçer. Yüksek borç, faiz artışlarında sorun yaratabilir.'
      ],
      en: [
        '• Debt/equity ratio: ratio of total debt to equity',
        '• Interest coverage ratio: ability to cover interest payments',
        '• Debt payback period: how many years it can pay debts with current cash flow',
        '• Measures company\'s debt risk. High debt can create problems when interest rates rise.'
      ],
      es: [
        '• Ratio deuda/patrimonio: proporción de deuda total al patrimonio',
        '• Ratio de cobertura de intereses: capacidad para cubrir pagos de intereses',
        '• Período de pago de deuda: cuántos años puede pagar deudas con flujo de efectivo actual',
        '• Mide el riesgo de deuda de la empresa. La alta deuda puede crear problemas cuando suben las tasas de interés.'
      ],
      fr: [
        '• Ratio dette/capitaux propres: proportion de la dette totale aux capitaux propres',
        '• Ratio de couverture des intérêts: capacité à couvrir les paiements d\'intérêts',
        '• Période de remboursement de la dette: combien d\'années elle peut payer les dettes avec le flux de trésorerie actuel',
        '• Mesure le risque de dette de l\'entreprise. Une dette élevée peut créer des problèmes quand les taux d\'intérêt augmentent.'
      ],
      ru: [
        '• Отношение долга к собственному капиталу: отношение общего долга к собственному капиталу',
        '• Коэффициент покрытия процентов: способность покрывать процентные платежи',
        '• Период погашения долга: сколько лет может погашать долги с текущим денежным потоком',
        '• Измеряет долговой риск компании. Высокий долг может создать проблемы при повышении процентных ставок.'
      ]
    },
    example: { 
      tr: '⚖️ 2025\'te Google\'ın borç/özkaynak oranı 0.1; çok düşük borç riski.',
      en: '⚖️ In 2025, Google\'s debt/equity ratio was 0.1; very low debt risk.',
      es: '⚖️ En 2025, el ratio deuda/patrimonio de Google fue 0.1; riesgo de deuda muy bajo.',
      fr: '⚖️ En 2025, le ratio dette/capitaux propres de Google était de 0,1 ; risque de dette très faible.',
      ru: '⚖️ В 2025 году отношение долга к собственному капиталу Google составило 0,1; очень низкий долговой риск.'
    },
    icon: <Shield className="w-16 h-16 text-orange-500" />
  },
  {
    title: { 
      tr: 'Değerleme: İndirgenmiş Nakit Akımları', 
      en: 'Valuation: Discounted Cash Flow', 
      es: 'Valoración: Flujo de Efectivo Descontado', 
      fr: 'Évaluation: Flux de Trésorerie Actualisés', 
      ru: 'Оценка: Дисконтированный денежный поток' 
    },
    content: { 
      tr: [
        '• İndirgenmiş nakit akımları (<tooltip term="DCF">Discounted Cash Flow - İndirgenmiş Nakit Akımları: gelecekteki nakit akımlarının bugünkü değere indirgenmesi yöntemi</tooltip>): şirketin gelecekte üreteceği serbest nakit akımlarını bugünkü değere indirger.',
        '• Gerçek değeri hesaplamaya çalışır.',
        '• Hesaplama hassastır; varsayımlardaki küçük değişiklikler sonucu büyük ölçüde etkiler.',
        '• İskonto oranı ve terminal değer kritik parametrelerdir.'
      ],
      en: [
        '• <tooltip term="DCF">Discounted Cash Flow - valuation method that calculates present value of future cash flows</tooltip>: discounts future free cash flows that company will generate to present value.',
        '• Tries to calculate true value.',
        '• Calculation is sensitive; small changes in assumptions greatly affect the result.',
        '• Discount rate and terminal value are critical parameters.'
      ],
      es: [
        '• <tooltip term="DCF">Discounted Cash Flow - Flujo de Efectivo Descontado: método de valoración que calcula el valor presente de flujos futuros</tooltip>: descuenta flujos de efectivo libres futuros que generará la empresa a valor presente.',
        '• Trata de calcular el valor verdadero.',
        '• El cálculo es sensible; pequeños cambios en supuestos afectan mucho el resultado.',
        '• Tasa de descuento y valor terminal son parámetros críticos.'
      ],
      fr: [
        '• <tooltip term="DCF">Discounted Cash Flow - Flux de Trésorerie Actualisés: méthode de valorisation qui calcule la valeur actuelle des flux futurs</tooltip>: actualise les flux de trésorerie libres futurs que l\'entreprise générera à la valeur actuelle.',
        '• Essaie de calculer la vraie valeur.',
        '• Le calcul est sensible ; de petits changements dans les hypothèses affectent grandement le résultat.',
        '• Taux d\'actualisation et valeur terminale sont des paramètres critiques.'
      ],
      ru: [
        '• <tooltip term="DCF">Discounted Cash Flow - Дисконтированный Денежный Поток: метод оценки, рассчитывающий текущую стоимость будущих потоков</tooltip>: дисконтирует будущие свободные денежные потоки, которые будет генерировать компания, к текущей стоимости.',
        '• Пытается рассчитать истинную стоимость.',
        '• Расчет чувствителен; небольшие изменения в предположениях сильно влияют на результат.',
        '• Ставка дисконтирования и конечная стоимость являются критическими параметрами.'
      ]
    },
    example: { 
      tr: '🔢 2025\'te Tesla\'nın <tooltip term="DCF">Discounted Cash Flow - İndirgenmiş Nakit Akımları</tooltip> değerlemesi $280/hisse; %10 iskonto oranıyla.',
      en: '🔢 In 2025, Tesla\'s <tooltip term="DCF">Discounted Cash Flow</tooltip> valuation was $280/share; with 10% discount rate.',
      es: '🔢 En 2025, la valoración <tooltip term="DCF">Discounted Cash Flow</tooltip> de Tesla fue $280/acción; con tasa de descuento del 10%.',
      fr: '🔢 En 2025, l\'évaluation <tooltip term="DCF">Discounted Cash Flow</tooltip> de Tesla était de 280$/action ; avec un taux d\'actualisation de 10%.',
      ru: '🔢 В 2025 году оценка <tooltip term="DCF">Discounted Cash Flow</tooltip> Tesla составила $280/акция; со ставкой дисконтирования 10%.'
    },
    icon: <Calculator className="w-16 h-16 text-purple-500" />
  },
  {
    title: { 
      tr: 'Değerleme: Oran Analizi', 
      en: 'Valuation: Ratio Analysis', 
      es: 'Valoración: Análisis de Ratios', 
      fr: 'Évaluation: Analyse des Ratios', 
      ru: 'Оценка: Анализ коэффициентов' 
    },
    content: { 
      tr: [
        '• F/K (Fiyat/Kazanç): hisse fiyatının yıllık kazanca oranı',
        '• F/Ö (Fiyat/Defter): hisse fiyatının defter değerine oranı',
        '• Firma değeri/satışlar: şirketin toplam değerinin yıllık satışlara oranı',
        '• Şirketleri birbirleriyle karşılaştırmak için kullanılır. Tek başına oranlara bakmak yanıltıcı olabilir; sektöre göre değerlendirilmelidir.'
      ],
      en: [
        '• P/E (Price/Earnings): ratio of share price to annual earnings',
        '• P/B (Price/Book): ratio of share price to book value',
        '• Enterprise value/sales: ratio of company\'s total value to annual sales',
        '• Used to compare companies with each other. Looking at ratios alone can be misleading; should be evaluated by sector.'
      ],
      es: [
        '• P/E (Precio/Ganancias): proporción del precio de la acción a las ganancias anuales',
        '• P/B (Precio/Libro): proporción del precio de la acción al valor en libros',
        '• Valor empresarial/ventas: proporción del valor total de la empresa a las ventas anuales',
        '• Se usa para comparar empresas entre sí. Mirar solo ratios puede ser engañoso; debe evaluarse por sector.'
      ],
      fr: [
        '• P/E (Prix/Bénéfices): ratio du prix de l\'action aux bénéfices annuels',
        '• P/B (Prix/Valeur comptable): ratio du prix de l\'action à la valeur comptable',
        '• Valeur d\'entreprise/ventes: ratio de la valeur totale de l\'entreprise aux ventes annuelles',
        '• Utilisé pour comparer les entreprises entre elles. Regarder les ratios seuls peut être trompeur ; doit être évalué par secteur.'
      ],
      ru: [
        '• P/E (Цена/Прибыль): отношение цены акции к годовой прибыли',
        '• P/B (Цена/Балансовая стоимость): отношение цены акции к балансовой стоимости',
        '• Стоимость предприятия/продажи: отношение общей стоимости компании к годовым продажам',
        '• Используется для сравнения компаний друг с другом. Смотреть только на коэффициенты может вводить в заблуждение; должно оцениваться по секторам.'
      ]
    },
    example: { 
      tr: '📊 2025\'te teknoloji sektörü ortalama F/K: 24; Meta F/K: 18 (düşük).',
      en: '📊 In 2025, technology sector average P/E: 24; Meta P/E: 18 (low).',
      es: '📊 En 2025, promedio P/E del sector tecnológico: 24; P/E de Meta: 18 (bajo).',
      fr: '📊 En 2025, moyenne P/E du secteur technologique: 24 ; P/E de Meta: 18 (bas).',
      ru: '📊 В 2025 году средний P/E технологического сектора: 24; P/E Meta: 18 (низкий).'
    },
    icon: <PieChart className="w-16 h-16 text-indigo-500" />
  },
  {
    title: { 
      tr: 'Şirket Yönetimi ve Kalitesi', 
      en: 'Company Management and Quality', 
      es: 'Gestión y Calidad de la Empresa', 
      fr: 'Gestion et Qualité de l\'Entreprise', 
      ru: 'Управление и качество компании' 
    },
    content: { 
      tr: [
        '• Yönetimin geçmiş performansı, şeffaflığı ve stratejik becerileri şirket değerini doğrudan etkiler.',
        '• Güçlü yönetim, kriz dönemlerinde avantaj sağlar.',
        '• CEO ve üst yönetimin sektör deneyimi önemlidir.',
        '• Kurumsal yönetim standartları ve etik değerler değerlendirilmelidir.'
      ],
      en: [
        '• Management\'s past performance, transparency and strategic skills directly affect company value.',
        '• Strong management provides advantage during crisis periods.',
        '• CEO and senior management\'s industry experience is important.',
        '• Corporate governance standards and ethical values should be evaluated.'
      ],
      es: [
        '• El rendimiento pasado, transparencia y habilidades estratégicas de la gestión afectan directamente el valor de la empresa.',
        '• Una gestión fuerte proporciona ventaja durante períodos de crisis.',
        '• La experiencia en la industria del CEO y alta gerencia es importante.',
        '• Se deben evaluar los estándares de gobierno corporativo y valores éticos.'
      ],
      fr: [
        '• La performance passée, la transparence et les compétences stratégiques de la direction affectent directement la valeur de l\'entreprise.',
        '• Une direction forte procure un avantage pendant les périodes de crise.',
        '• L\'expérience sectorielle du PDG et de la haute direction est importante.',
        '• Les normes de gouvernance d\'entreprise et les valeurs éthiques doivent être évaluées.'
      ],
      ru: [
        '• Прошлая производительность, прозрачность и стратегические навыки руководства напрямую влияют на стоимость компании.',
        '• Сильное руководство обеспечивает преимущество в кризисные периоды.',
        '• Отраслевой опыт генерального директора и высшего руководства важен.',
        '• Следует оценивать стандарты корпоративного управления и этические ценности.'
      ]
    },
    example: { 
      tr: '👔 2025\'te Satya Nadella\'nın liderliğinde Microsoft\'un değeri %22 arttı.',
      en: '👔 In 2025, Microsoft\'s value increased 22% under Satya Nadella\'s leadership.',
      es: '👔 En 2025, el valor de Microsoft aumentó 22% bajo el liderazgo de Satya Nadella.',
      fr: '👔 En 2025, la valeur de Microsoft a augmenté de 22% sous la direction de Satya Nadella.',
      ru: '👔 В 2025 году стоимость Microsoft выросла на 22% под руководством Сатьи Наделлы.'
    },
    icon: <Users className="w-16 h-16 text-blue-500" />
  },
  {
    title: { 
      tr: 'Rekabet Avantajı (Ekonomik Hendek)', 
      en: 'Competitive Advantage (Economic Moat)', 
      es: 'Ventaja Competitiva (Foso Económico)', 
      fr: 'Avantage Concurrentiel (Fossé Économique)', 
      ru: 'Конкурентное преимущество (Экономический ров)' 
    },
    content: { 
      tr: [
        '• Ekonomik hendek: güçlü marka, ölçek ekonomisi ve patentler gibi sürekli rekabet avantajı sağlayan özelliklerdir.',
        '• Bu tür avantajlar yatırım riskini azaltır.',
        '• Ağ etkisi, değişim maliyetleri ve maliyet avantajları da ekonomik hendek oluşturur.',
        '• Güçlü hendekler uzun vadeli karlılığı korur.'
      ],
      en: [
        '• Economic moat: features that provide continuous competitive advantage like strong brand, economies of scale and patents.',
        '• Such advantages reduce investment risk.',
        '• Network effect, switching costs and cost advantages also create economic moat.',
        '• Strong moats protect long-term profitability.'
      ],
      es: [
        '• Foso económico: características que proporcionan ventaja competitiva continua como marca fuerte, economías de escala y patentes.',
        '• Tales ventajas reducen el riesgo de inversión.',
        '• Efecto de red, costos de cambio y ventajas de costo también crean foso económico.',
        '• Fosos fuertes protegen la rentabilidad a largo plazo.'
      ],
      fr: [
        '• Fossé économique: caractéristiques qui procurent un avantage concurrentiel continu comme une marque forte, des économies d\'échelle et des brevets.',
        '• De tels avantages réduisent le risque d\'investissement.',
        '• L\'effet réseau, les coûts de changement et les avantages de coût créent aussi un fossé économique.',
        '• Des fossés forts protègent la rentabilité à long terme.'
      ],
      ru: [
        '• Экономический ров: особенности, которые обеспечивают непрерывное конкурентное преимущество, такие как сильный бренд, эффект масштаба и патенты.',
        '• Такие преимущества снижают инвестиционный риск.',
        '• Сетевой эффект, затраты на переключение и преимущества в затратах также создают экономический ров.',
        '• Сильные рвы защищают долгосрочную прибыльность.'
      ]
    },
    example: { 
      tr: '🏰 2025\'te Coca-Cola\'nın marka gücü, rekabetçilere karşı %15 prim sağladı.',
      en: '🏰 In 2025, Coca-Cola\'s brand strength provided 15% premium against competitors.',
      es: '🏰 En 2025, la fuerza de marca de Coca-Cola proporcionó 15% de prima contra competidores.',
      fr: '🏰 En 2025, la force de marque de Coca-Cola a fourni 15% de prime contre les concurrents.',
      ru: '🏰 В 2025 году сила бренда Coca-Cola обеспечила 15% премию против конкурентов.'
    },
    icon: <Shield className="w-16 h-16 text-green-500" />
  },
  {
    title: { 
      tr: 'Makro Göstergeler ve Hisseler', 
      en: 'Macro Indicators and Stocks', 
      es: 'Indicadores Macro y Acciones', 
      fr: 'Indicateurs Macro et Actions', 
      ru: 'Макро показатели и акции' 
    },
    content: { 
      tr: [
        '• Faizler, enflasyon ve işsizlik oranı hisse fiyatlarını etkiler.',
        '• Yüksek faizler, büyüme odaklı şirketlerin değerlemesini baskılayabilir.',
        '• Merkez bankası politikaları piyasa yönünü belirler.',
        '• Jeopolitik olaylar ve ticaret savaşları da dikkate alınmalıdır.'
      ],
      en: [
        '• Interest rates, inflation and unemployment rate affect stock prices.',
        '• High interest rates can suppress valuation of growth-focused companies.',
        '• Central bank policies determine market direction.',
        '• Geopolitical events and trade wars should also be considered.'
      ],
      es: [
        '• Tasas de interés, inflación y tasa de desempleo afectan los precios de las acciones.',
        '• Altas tasas de interés pueden suprimir la valoración de empresas enfocadas en crecimiento.',
        '• Las políticas del banco central determinan la dirección del mercado.',
        '• Eventos geopolíticos y guerras comerciales también deben considerarse.'
      ],
      fr: [
        '• Les taux d\'intérêt, l\'inflation et le taux de chômage affectent les prix des actions.',
        '• Des taux d\'intérêt élevés peuvent supprimer l\'évaluation des entreprises axées sur la croissance.',
        '• Les politiques de la banque centrale déterminent la direction du marché.',
        '• Les événements géopolitiques et les guerres commerciales doivent aussi être considérés.'
      ],
      ru: [
        '• Процентные ставки, инфляция и уровень безработицы влияют на цены акций.',
        '• Высокие процентные ставки могут подавлять оценку компаний, ориентированных на рост.',
        '• Политика центрального банка определяет направление рынка.',
        '• Геополитические события и торговые войны также следует учитывать.'
      ]
    },
    example: { 
      tr: '📈 2025\'te Fed\'in faiz indirimi teknoloji hisselerini %12 artırdı.',
      en: '📈 In 2025, Fed\'s interest rate cut increased technology stocks by 12%.',
      es: '📈 En 2025, el recorte de tasas de la Fed aumentó las acciones tecnológicas en 12%.',
      fr: '📈 En 2025, la baisse des taux de la Fed a augmenté les actions technologiques de 12%.',
      ru: '📈 В 2025 году снижение ставок ФРС увеличило технологические акции на 12%.'
    },
    icon: <TrendingUp className="w-16 h-16 text-purple-500" />
  },
  {
    title: { 
      tr: 'Sektörel Trendler ve Etkileri', 
      en: 'Sectoral Trends and Effects', 
      es: 'Tendencias Sectoriales y Efectos', 
      fr: 'Tendances Sectorielles et Effets', 
      ru: 'Отраслевые тренды и эффекты' 
    },
    content: { 
      tr: [
        '• Megatrendler: AI, yenilenebilir enerji, biyoteknoloji gibi uzun vadeli büyüme fırsatları sunar.',
        '• Aynı zamanda düzenleme ve tedarik zinciri riskleri getirebilir.',
        '• Teknolojik dönüşümler mevcut şirketleri tehdit edebilir.',
        '• Erken trend yakalama rekabet avantajı sağlar.'
      ],
      en: [
        '• Megatrends: AI, renewable energy, biotechnology offer long-term growth opportunities.',
        '• At the same time can bring regulation and supply chain risks.',
        '• Technological transformations can threaten existing companies.',
        '• Early trend catching provides competitive advantage.'
      ],
      es: [
        '• Megatendencias: IA, energía renovable, biotecnología ofrecen oportunidades de crecimiento a largo plazo.',
        '• Al mismo tiempo pueden traer riesgos de regulación y cadena de suministro.',
        '• Las transformaciones tecnológicas pueden amenazar a empresas existentes.',
        '• Capturar tendencias temprano proporciona ventaja competitiva.'
      ],
      fr: [
        '• Mégatendances: IA, énergie renouvelable, biotechnologie offrent des opportunités de croissance à long terme.',
        '• En même temps peuvent apporter des risques de réglementation et de chaîne d\'approvisionnement.',
        '• Les transformations technologiques peuvent menacer les entreprises existantes.',
        '• Capturer les tendances tôt procure un avantage concurrentiel.'
      ],
      ru: [
        '• Мегатренды: ИИ, возобновляемая энергия, биотехнологии предлагают долгосрочные возможности роста.',
        '• В то же время могут принести регулятивные риски и риски цепочки поставок.',
        '• Технологические трансформации могут угрожать существующим компаниям.',
        '• Раннее выявление трендов обеспечивает конкурентное преимущество.'
      ]
    },
    example: { 
      tr: '🚀 2025\'te AI boom\'u NVIDIA\'yı %45 artırdı; çip liderliği korundu.',
      en: '🚀 In 2025, AI boom increased NVIDIA by 45%; chip leadership maintained.',
      es: '🚀 En 2025, el boom de IA aumentó NVIDIA en 45%; liderazgo en chips mantenido.',
      fr: '🚀 En 2025, le boom de l\'IA a augmenté NVIDIA de 45% ; leadership en puces maintenu.',
      ru: '🚀 В 2025 году бум ИИ уве��ичил NVIDIA на 45%; лидерство в чипах сохранено.'
    },
    icon: <Zap className="w-16 h-16 text-yellow-500" />
  },
  {
    title: { 
      tr: 'Temel Analizde Risk Analizi', 
      en: 'Risk Analysis in Fundamental Analysis', 
      es: 'Análisis de Riesgo en Análisis Fundamental', 
      fr: 'Analyse des Risques dans l\'Analyse Fondamentale', 
      ru: 'Анализ рисков в фундаментальном анализе' 
    },
    content: { 
      tr: [
        '• Yüksek borç, negatif operasyonel nakit ve düzenleyici riskler temel analizde takip edilmesi gereken kırmızı bayraklardır.',
        '• Risk yönetimi: stratejileri bu riskleri azaltmaya yardımcı olur.',
        '• Sektörel ve şirkete özgü riskleri ayrı ayrı değerlendirin.',
        '• Çeşitlendirme risk azaltmanın temel yöntemidir.'
      ],
      en: [
        '• High debt, negative operational cash and regulatory risks are red flags that should be monitored in fundamental analysis.',
        '• Risk management: strategies help reduce these risks.',
        '• Evaluate sectoral and company-specific risks separately.',
        '• Diversification is the basic method of risk reduction.'
      ],
      es: [
        '• Deuda alta, efectivo operacional negativo y riesgos regulatorios son banderas rojas que deben monitorearse en análisis fundamental.',
        '• Gestión de riesgo: las estrategias ayudan a reducir estos riesgos.',
        '• Evalúa riesgos sectoriales y específicos de la empresa por separado.',
        '• La diversificación es el método básico de reducción de riesgo.'
      ],
      fr: [
        '• Dette élevée, trésorerie opérationnelle négative et risques réglementaires sont des drapeaux rouges qui doivent être surveillés dans l\'analyse fondamentale.',
        '• Gestion des risques: les stratégies aident à réduire ces risques.',
        '• Évaluez les risques sectoriels et spécifiques à l\'entreprise séparément.',
        '• La diversification est la méthode de base de réduction des risques.'
      ],
      ru: [
        '• Высокий долг, отрицательные операционные денежные средства и регулятивные риски - это красные флаги, которые следует отслеживать в фундаментальном анализе.',
        '• Управление рисками: стратегии помогают снизить эти риски.',
        '• Оценивайте отраслевые и специфические для компании риски отдельно.',
        '��� Диверсификация является основным методом снижения риска.'
      ]
    },
    example: { 
      tr: '⚠️ 2025\'te yüksek borçlu teknoloji şirketleri faiz artışında %30 düştü.',
      en: '⚠️ In 2025, highly indebted technology companies fell 30% during interest rate hike.',
      es: '⚠️ En 2025, las empresas tecnológicas muy endeudadas cayeron 30% durante el aumento de tasas.',
      fr: '⚠️ En 2025, les entreprises technologiques très endettées ont chuté de 30% pendant la hausse des taux.',
      ru: '⚠️ В 2025 году высоко задолженные технологические компании упали на 30% во время повышения ставок.'
    },
    icon: <Brain className="w-16 h-16 text-red-500" />
  }
]

// Temel Analiz Quiz Soruları
export const fundamentalAnalysisQuiz = [
  {
    id: 1,
    question: {
      tr: 'Temel analizin ana hedefi nedir?',
      en: 'What is the main goal of fundamental analysis?',
      es: '¿Cuál es el objetivo principal del análisis fundamental?',
      fr: 'Quel est l\'objectif principal de l\'analyse fondamentale?',
      ru: 'Какова основная цель фундаментального анализа?',
      de: 'Was ist das Hauptziel der Fundamentalanalyse?',
      pt: 'Qual é o objetivo principal da análise fundamental?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['Fiyat hareketlerini tahmin etmek', 'İçsel değeri bulup piyasa fiyatıyla karşılaştırmak', 'Sadece grafiklere bakarak alım-satım yapmak', 'Kısa vadeli scalp işlemleri yapmak'],
      en: ['Predicting price movements', 'Finding intrinsic value and comparing it with market price', 'Trading based only on charts', 'Making short-term scalp trades'],
      es: ['Predecir movimientos de precios', 'Encontrar valor intrínseco y compararlo con precio de mercado', 'Comerciar solo basándose en gráficos', 'Hacer operaciones de scalping a corto plazo'],
      fr: ['Prédire les mouvements de prix', 'Trouver la valeur intrinsèque et la comparer avec le prix du marché', 'Trader uniquement basé sur les graphiques', 'Faire des trades de scalping à court terme'],
      ru: ['Предсказание ценовых движений', 'Нахождение внутренней стоимости и сравнение с рыночной ценой', 'Торговля только на основе графиков', 'Краткосрочные скальпинговые сделки'],
      de: ['Preisbewegungen vorhersagen', 'Inneren Wert finden und mit Marktpreis vergleichen', 'Nur auf Basis von Charts handeln', 'Kurzfristige Scalp-Trades machen'],
      pt: ['Prever movimentos de preços', 'Encontrar valor intrínseco e comparar com preço de mercado', 'Negociar apenas baseado em gráficos', 'Fazer operações de scalp de curto prazo']
    },
    correct: 1,
    explanation: {
      tr: 'Temel analizin ana hedefi, bir varlığın içsel değerini hesaplayarak piyasa fiyatıyla karşılaştırmak ve böylece değerli alım-satım fırsatları bulmaktır.',
      en: 'The main goal of fundamental analysis is to calculate an asset\'s intrinsic value and compare it with market price to find valuable trading opportunities.',
      es: 'El objetivo principal del análisis fundamental es calcular el valor intrínseco de un activo y compararlo con el precio de mercado para encontrar oportunidades de trading valiosas.',
      fr: 'L\'objectif principal de l\'analyse fondamentale est de calculer la valeur intrinsèque d\'un actif et de la comparer avec le prix du marché pour trouver des opportunités de trading précieuses.',
      ru: 'Основная цель фундаментального анализа - рассчитать внутреннюю стоимость актива и сравнить с рыночной ценой для поиска ценных торговых возможностей.',
      de: 'Das Hauptziel der Fundamentalanalyse ist es, den inneren Wert eines Vermögenswerts zu berechnen und mit dem Marktpreis zu vergleichen, um wertvolle Handelsmöglichkeiten zu finden.',
      pt: 'O objetivo principal da análise fundamental é calcular o valor intrínseco de um ativo e compará-lo com o preço de mercado para encontrar oportunidades de negociação valiosas.'
    }
  },
  {
    id: 2,
    question: {
      tr: 'Bir şirketin gelecekte üreteceği nakit akışlarının bugünkü değeri hangi kavramı tanımlar?',
      en: 'What concept is defined by the present value of future cash flows a company will generate?',
      es: '¿Qué concepto se define por el valor presente de los flujos de efectivo futuros que generará una empresa?',
      fr: 'Quel concept est défini par la valeur actuelle des flux de trésorerie futurs qu\'une entreprise va générer?',
      ru: 'Какая концепция определяется текущей стоимостью будущих денежных потоков, которые будет генерировать компания?',
      de: 'Welches Konzept wird durch den Barwert zukünftiger Cashflows definiert, die ein Unternehmen generieren wird?',
      pt: 'Que conceito é definido pelo valor presente dos fluxos de caixa futuros que uma empresa irá gerar?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['Piyasa Değeri', 'İçsel Değer', 'Likidite', 'Volatilite'],
      en: ['Market Value', 'Intrinsic Value', 'Liquidity', 'Volatility'],
      es: ['Valor de Mercado', 'Valor Intrínseco', 'Liquidez', 'Volatilidad'],
      fr: ['Valeur de Marché', 'Valeur Intrinsèque', 'Liquidité', 'Volatilité'],
      ru: ['Рыночная стоимость', 'Внутренняя стоимость', 'Ликвидность', 'Волатильность'],
      de: ['Marktwert', 'Innerer Wert', 'Liquidität', 'Volatilität'],
      pt: ['Valor de Mercado', 'Valor Intrínseco', 'Liquidez', 'Volatilidade']
    },
    correct: 1,
    explanation: {
      tr: 'İçsel değer, bir şirketin gelecekte üreteceği nakit akışlarının bugünkü değeri olarak tanımlanır. Bu, DCF (Discounted Cash Flow) analizinin temelidir.',
      en: 'Intrinsic value is defined as the present value of future cash flows a company will generate. This is the foundation of DCF (Discounted Cash Flow) analysis.',
      es: 'El valor intrínseco se define como el valor presente de los flujos de efectivo futuros que generará una empresa. Esta es la base del análisis DCF (Flujo de Efectivo Descontado).',
      fr: 'La valeur intrinsèque est définie comme la valeur actuelle des flux de trésorerie futurs qu\'une entreprise va générer. C\'est la base de l\'analyse DCF (Flux de Trésorerie Actualisé).',
      ru: 'Внутренняя стоимость определяется как текущая стоимость будущих денежных потоков, которые будет генерировать компания. Это основа DCF (дисконтированных денежных потоков) анализа.',
      de: 'Der innere Wert wird als Barwert zukünftiger Cashflows definiert, die ein Unternehmen generieren wird. Dies ist die Grundlage der DCF (Discounted Cash Flow) Analyse.',
      pt: 'O valor intrínseco é definido como o valor presente dos fluxos de caixa futuros que uma empresa irá gerar. Esta é a base da análise DCF (Fluxo de Caixa Descontado).'
    }
  },
  {
    id: 3,
    question: {
      tr: 'Yükselen faiz oranlarının şirketler üzerindeki tipik etkisi nedir?',
      en: 'What is the typical effect of rising interest rates on companies?',
      es: '¿Cuál es el efecto típico de las tasas de interés crecientes en las empresas?',
      fr: 'Quel est l\'effet typique de la hausse des taux d\'intérêt sur les entreprises?',
      ru: 'Каково типичное влияние растущих процентных ставок на компании?',
      de: 'Was ist die typische Auswirkung steigender Zinssätze auf Unternehmen?',
      pt: 'Qual é o efeito típico das taxas de juros crescentes nas empresas?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['Borçlanma maliyetlerini azaltır', 'DCF iskonto oranını düşürür', 'Borçlanma maliyetlerini artırır', 'Hisse senetlerini daha cazip hale getirir'],
      en: ['Reduces borrowing costs', 'Lowers DCF discount rate', 'Increases borrowing costs', 'Makes stocks more attractive'],
      es: ['Reduce los costos de endeudamiento', 'Baja la tasa de descuento DCF', 'Aumenta los costos de endeudamiento', 'Hace las acciones más atractivas'],
      fr: ['Réduit les coûts d\'emprunt', 'Abaisse le taux d\'actualisation DCF', 'Augmente les coûts d\'emprunt', 'Rend les actions plus attractives'],
      ru: ['Снижает стоимость заимствования', 'Снижает ставку дисконтирования DCF', 'Увеличивает стоимость заимствования', 'Делает акции более привлекательными'],
      de: ['Reduziert Kreditkosten', 'Senkt DCF-Diskontierungssatz', 'Erhöht Kreditkosten', 'Macht Aktien attraktiver'],
      pt: ['Reduz custos de empréstimo', 'Diminui taxa de desconto DCF', 'Aumenta custos de empréstimo', 'Torna ações mais atraentes']
    },
    correct: 2,
    explanation: {
      tr: 'Yükselen faiz oranları şirketlerin borçlanma maliyetlerini artırır, finansman giderlerini yükseltir ve DCF analizinde iskonto oranını artırarak değerlemeleri düşürür.',
      en: 'Rising interest rates increase companies\' borrowing costs, raise financing expenses, and increase the discount rate in DCF analysis, lowering valuations.',
      es: 'Las tasas de interés crecientes aumentan los costos de endeudamiento de las empresas, elevan los gastos de financiamiento y aumentan la tasa de descuento en el análisis DCF, reduciendo las valoraciones.',
      fr: 'La hausse des taux d\'intérêt augmente les coûts d\'emprunt des entreprises, élève les dépenses de financement et augmente le taux d\'actualisation dans l\'analyse DCF, abaissant les valorisations.',
      ru: 'Растущие процентные ставки увеличивают стоимость заимствования компаний, повышают расходы на финансирование и увеличивают ставку дисконтирования в DCF анализе, снижая оценки.',
      de: 'Steigende Zinssätze erhöhen die Kreditkosten der Unternehmen, steigern Finanzierungskosten und erhöhen die Diskontierungsrate in der DCF-Analyse, wodurch Bewertungen sinken.',
      pt: 'Taxas de juros crescentes aumentam os custos de empréstimo das empresas, elevam despesas de financiamento e aumentam a taxa de desconto na análise DCF, reduzindo avaliações.'
    }
  },
  {
    id: 4,
    question: {
      tr: 'Aşağıdakilerden hangisi sektör analizinde kullanılan bir faktördür?',
      en: 'Which of the following is a factor used in sector analysis?',
      es: '¿Cuál de los siguientes es un factor utilizado en el análisis sectorial?',
      fr: 'Lequel des suivants est un facteur utilisé dans l\'analyse sectorielle?',
      ru: 'Что из следующего является фактором, используемым в отраслевом анализе?',
      de: 'Welches der folgenden ist ein Faktor, der in der Branchenanalyse verwendet wird?',
      pt: 'Qual dos seguintes é um fator usado na análise setorial?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['RSI ve MACD', 'GDP büyümesi', 'Endüstri yaşam döngüsü', 'Likidasyon seviyeleri'],
      en: ['RSI and MACD', 'GDP growth', 'Industry life cycle', 'Liquidation levels'],
      es: ['RSI y MACD', 'Crecimiento del PIB', 'Ciclo de vida de la industria', 'Niveles de liquidación'],
      fr: ['RSI et MACD', 'Croissance du PIB', 'Cycle de vie de l\'industrie', 'Niveaux de liquidation'],
      ru: ['RSI и MACD', 'Рост ВВП', 'Жизненный цикл отрасли', 'Уровни ликвидации'],
      de: ['RSI und MACD', 'BIP-Wachstum', 'Branchenlebenszyklus', 'Liquidationsniveaus'],
      pt: ['RSI e MACD', 'Crescimento do PIB', 'Ciclo de vida da indústria', 'Níveis de liquidação']
    },
    correct: 2,
    explanation: {
      tr: 'Endüstri yaşam döngüsü (başlangıç, büyüme, olgunluk, düşüş) sektör analizinin temel bileşenlerinden biridir. RSI ve MACD teknik analiz araçlarıdır.',
      en: 'Industry life cycle (introduction, growth, maturity, decline) is one of the fundamental components of sector analysis. RSI and MACD are technical analysis tools.',
      es: 'El ciclo de vida de la industria (introducción, crecimiento, madurez, declive) es uno de los componentes fundamentales del análisis sectorial. RSI y MACD son herramientas de análisis técnico.',
      fr: 'Le cycle de vie de l\'industrie (introduction, croissance, maturité, déclin) est l\'un des composants fondamentaux de l\'analyse sectorielle. RSI et MACD sont des outils d\'analyse technique.',
      ru: 'Жизненный цикл отрасли (введение, рост, зрелость, спад) является одним из основных компонентов отраслевого анализа. RSI и MACD - это инструменты технического анализа.',
      de: 'Der Branchenlebenszyklus (Einführung, Wachstum, Reife, Rückgang) ist eine der Grundkomponenten der Branchenanalyse. RSI und MACD sind technische Analysewerkzeuge.',
      pt: 'O ciclo de vida da indústria (introdução, crescimento, maturidade, declínio) é um dos componentes fundamentais da análise setorial. RSI e MACD são ferramentas de análise técnica.'
    }
  },
  {
    id: 5,
    question: {
      tr: 'Nakit akışı tablosunun en kritik bölümü hangisidir?',
      en: 'Which is the most critical section of the cash flow statement?',
      es: '¿Cuál es la sección más crítica del estado de flujo de efectivo?',
      fr: 'Quelle est la section la plus critique du tableau des flux de trésorerie?',
      ru: 'Какая секция отчета о движении денежных средств является наиболее критической?',
      de: 'Welcher ist der kritischste Abschnitt der Kapitalflussrechnung?',
      pt: 'Qual é a seção mais crítica da demonstração de fluxo de caixa?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['Finansman Nakit Akışları', 'Yatırım Nakit Akışları', 'Operasyonel Nakit Akışları', 'Özkaynak Değişim Tablosu'],
      en: ['Financing Cash Flows', 'Investing Cash Flows', 'Operating Cash Flows', 'Statement of Equity Changes'],
      es: ['Flujos de Efectivo de Financiamiento', 'Flujos de Efectivo de Inversión', 'Flujos de Efectivo Operacionales', 'Estado de Cambios en el Patrimonio'],
      fr: ['Flux de Trésorerie de Financement', 'Flux de Trésorerie d\'Investissement', 'Flux de Trésorerie Opérationnels', 'État des Variations des Capitaux Propres'],
      ru: ['Денежные потоки от финансирования', 'Денежные потоки от инвестиций', 'Операционные денежные потоки', 'Отчет об изменен��ях в капитале'],
      de: ['Finanzierungs-Cashflows', 'Investitions-Cashflows', 'Operative Cashflows', 'Eigenkapitalveränderungsnachweis'],
      pt: ['Fluxos de Caixa de Financiamento', 'Fluxos de Caixa de Investimento', 'Fluxos de Caixa Operacionais', 'Demonstração de Mudanças no Patrimônio']
    },
    correct: 2,
    explanation: {
      tr: 'Operasyonel nakit akışları, şirketin ana faaliyet alanından nakit üretip üretmediğini gösterir ve en kritik bölümdür. Pozitif operasyonel nakit akışı sürdürülebilirlik için temeldir.',
      en: 'Operating cash flows show whether the company generates cash from its main business activities and is the most critical section. Positive operating cash flow is fundamental for sustainability.',
      es: 'Los flujos de efectivo operacionales muestran si la empresa genera efectivo de sus actividades comerciales principales y es la sección más crítica. El flujo de efectivo operacional positivo es fundamental para la sostenibilidad.',
      fr: 'Les flux de trésorerie opérationnels montrent si l\'entreprise génère de la trésorerie à partir de ses activités commerciales principales et constituent la section la plus critique. Un flux de trésorerie opérationnel positif est fondamental pour la durabilité.',
      ru: 'Операционные денежные потоки показывают, генерирует ли компания денежные средства от основной деятельности, и являются наиболее критической секцией. Положительный операционный денежный поток является основой устойчивости.',
      de: 'Operative Cashflows zeigen, ob das Unternehmen Bargeld aus seinen Hauptgeschäftstätigkeiten generiert und sind der kritischste Abschnitt. Positive operative Cashflows sind grundlegend für die Nachhaltigkeit.',
      pt: 'Os fluxos de caixa operacionais mostram se a empresa gera caixa de suas atividades comerciais principais e é a seção mais crítica. Fluxo de caixa operacional positivo é fundamental para sustentabilidade.'
    }
  },
  {
    id: 6,
    question: {
      tr: 'ROE oranı neyi ölçer?',
      en: 'What does the ROE ratio measure?',
      es: '¿Qué mide la relación ROE?',
      fr: 'Que mesure le ratio ROE?',
      ru: 'Что измеряет коэффициент ROE?',
      de: 'Was misst die ROE-Kennzahl?',
      pt: 'O que a relação ROE mede?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['Şirketin toplam borcunun özkaynaklara oranını', 'Şirketin varlıklarını ne kadar verimli kullandığını', 'Hissedarlar için yaratılan değeri', 'Şirketin kısa vadeli borç ödeme gücünü'],
      en: ['The ratio of company\'s total debt to equity', 'How efficiently the company uses its assets', 'Value created for shareholders', 'The company\'s short-term debt payment capacity'],
      es: ['La relación de la deuda total de la empresa con el patrimonio', 'Qué tan eficientemente la empresa usa sus activos', 'Valor creado para los accionistas', 'La capacidad de pago de deuda a corto plazo de la empresa'],
      fr: ['Le ratio de la dette totale de l\'entreprise sur les capitaux propres', 'L\'efficacité avec laquelle l\'entreprise utilise ses actifs', 'Valeur créée pour les actionnaires', 'La capacité de paiement de la dette à court terme de l\'entreprise'],
      ru: ['Отношение общего долга компании к собственному капиталу', 'Насколько эффективно компания использует свои активы', 'Стоимость, созданная для акционеров', 'Способность компании платить краткосрочные долги'],
      de: ['Das Verhältnis der Gesamtverschuldung des Unternehmens zum Eigenkapital', 'Wie effizient das Unternehmen seine Vermögenswerte nutzt', 'Wert, der für Aktionäre geschaffen wurde', 'Die kurzfristige Schuldenrückzahlungsfähigkeit des Unternehmens'],
      pt: ['A relação da dívida total da empresa com o patrimônio', 'Quão eficientemente a empresa usa seus ativos', 'Valor criado para acionistas', 'A capacidade de pagamento de dívida de curto prazo da empresa']
    },
    correct: 2,
    explanation: {
      tr: 'ROE (Return on Equity), hissedarların yatırdığı sermayeden ne kadar getiri elde edildiğini ölçer. Net Kâr / Özkaynak formülüyle hesaplanır ve hissedarlar için yaratılan değeri gösterir.',
      en: 'ROE (Return on Equity) measures how much return is generated from the capital invested by shareholders. It\'s calculated as Net Income / Equity and shows value created for shareholders.',
      es: 'ROE (Retorno sobre el Patrimonio) mide cuánto retorno se genera del capital invertido por los accionistas. Se calcula como Ingreso Neto / Patrimonio y muestra el valor creado para los accionistas.',
      fr: 'ROE (Retour sur Capitaux Propres) mesure combien de retour est généré à partir du capital investi par les actionnaires. Il est calculé comme Revenu Net / Capitaux Propres et montre la valeur créée pour les actionnaires.',
      ru: 'ROE (рентабельность собственного капитала) измеряет, какую доходность генерирует капитал, инвестированный акционерами. Рассчитывается как Чистая прибыль / Собственный капитал и показывает стоимость, созданную для акционеров.',
      de: 'ROE (Return on Equity) misst, wie viel Rendite aus dem von Aktionären investierten Kapital generiert wird. Es wird als Nettogewinn / Eigenkapital berechnet und zeigt den für Aktionäre geschaffenen Wert.',
      pt: 'ROE (Retorno sobre o Patrimônio) mede quanto retorno é gerado do capital investido pelos acionistas. É calculado como Lucro Líquido / Patrimônio e mostra valor criado para acionistas.'
    }
  },
  {
    id: 7,
    question: {
      tr: 'Cari Oran için kabul edilen minimum seviye nedir?',
      en: 'What is the accepted minimum level for Current Ratio?',
      es: '¿Cuál es el nivel mínimo aceptado para la Relación Corriente?',
      fr: 'Quel est le niveau minimum accepté pour le Ratio de Liquidité Générale?',
      ru: 'Каков принятый минимальный уровень для коэффициента текущей ликвидности?',
      de: 'Was ist das akzeptierte Mindestniveau für die Liquidität ersten Grades?',
      pt: 'Qual é o nível mínimo aceito para a Relação Corrente?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['0.5', '1.0', '1.5', '2.5'],
      en: ['0.5', '1.0', '1.5', '2.5'],
      es: ['0.5', '1.0', '1.5', '2.5'],
      fr: ['0.5', '1.0', '1.5', '2.5'],
      ru: ['0.5', '1.0', '1.5', '2.5'],
      de: ['0.5', '1.0', '1.5', '2.5'],
      pt: ['0.5', '1.0', '1.5', '2.5']
    },
    correct: 1,
    explanation: {
      tr: 'Cari Oran (Dönen Varlıklar / Kısa Vadeli Borçlar) için minimum kabul edilen seviye 1.0\'dır. Bu, şirketin kısa vadeli borçlarını karşılayabildiğini gösterir.',
      en: 'The minimum accepted level for Current Ratio (Current Assets / Current Liabilities) is 1.0. This indicates the company can meet its short-term obligations.',
      es: 'El nivel mínimo aceptado para la Relación Corriente (Activos Corrientes / Pasivos Corrientes) es 1.0. Esto indica que la empresa puede cumplir con sus obligaciones a corto plazo.',
      fr: 'Le niveau minimum accepté pour le Ratio de Liquidité Générale (Actifs Courants / Passifs Courants) est 1.0. Cela indique que l\'entreprise peut respecter ses obligations à court terme.',
      ru: 'Минимальный принятый уровень для коэффициента текущей ликвидности (Оборотные активы / Краткосрочные обязательства) составляет 1.0. Это указывает на то, что компания может выполнить свои краткосрочные обязательства.',
      de: 'Das akzeptierte Mindestniveau für die Liquidität ersten Grades (Umlaufvermögen / Kurzfristige Verbindlichkeiten) ist 1.0. Dies zeigt, dass das Unternehmen seine kurzfristigen Verpflichtungen erfüllen kann.',
      pt: 'O nível mínimo aceito para a Relação Corrente (Ativos Correntes / Passivos Correntes) é 1.0. Isso indica que a empresa pode cumprir suas obrigações de curto prazo.'
    }
  },
  {
    id: 8,
    question: {
      tr: 'Faiz Karşılama Oranı (Interest Coverage) hangi formülle hesaplanır?',
      en: 'How is the Interest Coverage Ratio calculated?',
      es: '¿Cómo se calcula la Relación de Cobertura de Intereses?',
      fr: 'Comment le Ratio de Couverture des Intérêts est-il calculé?',
      ru: 'Как рассчитывается коэффициент покрытия процентов?',
      de: 'Wie wird die Zinsdeckungsquote berechnet?',
      pt: 'Como é calculada a Relação de Cobertura de Juros?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['Net Kâr / Faiz Gideri', 'EBIT / Faiz Gideri', 'EBITDA / Net Borç', 'Borç / Özkaynak'],
      en: ['Net Profit / Interest Expense', 'EBIT / Interest Expense', 'EBITDA / Net Debt', 'Debt / Equity'],
      es: ['Utilidad Neta / Gasto de Intereses', 'EBIT / Gasto de Intereses', 'EBITDA / Deuda Neta', 'Deuda / Patrimonio'],
      fr: ['Bénéfice Net / Charges d\'Intérêts', 'EBIT / Charges d\'Intérêts', 'EBITDA / Dette Nette', 'Dette / Capitaux Propres'],
      ru: ['Чистая прибыль / Процентные расходы', 'EBIT / Процентные расходы', 'EBITDA / Чистый долг', 'Долг / Собственный капитал'],
      de: ['Nettogewinn / Zinsaufwand', 'EBIT / Zinsaufwand', 'EBITDA / Nettoverschuldung', 'Schulden / Eigenkapital'],
      pt: ['Lucro Líquido / Despesa de Juros', 'EBIT / Despesa de Juros', 'EBITDA / Dívida Líquida', 'Dívida / Patrimônio']
    },
    correct: 1,
    explanation: {
      tr: 'Faiz Karşılama Oranı, EBIT (Faiz ve Vergi Öncesi Kazanç) / Faiz Gideri formülüyle hesaplanır. Bu oran şirketin faiz ödemelerini karşılama gücünü ölçer.',
      en: 'Interest Coverage Ratio is calculated as EBIT (Earnings Before Interest and Taxes) / Interest Expense. This ratio measures the company\'s ability to meet interest payments.',
      es: 'La Relación de Cobertura de Intereses se calcula como EBIT (Ganancias Antes de Intereses e Impuestos) / Gasto de Intereses. Esta relación mide la capacidad de la empresa para cumplir con los pagos de intereses.',
      fr: 'Le Ratio de Couverture des Intérêts est calculé comme EBIT (Bénéfices Avant Intérêts et Impôts) / Charges d\'Intérêts. Ce ratio mesure la capacité de l\'entreprise à honorer les paiements d\'intérêts.',
      ru: 'Коэффициент покрытия процентов рассчитывается как EBIT (прибыль до вычета процентов и налогов) / Процентные расходы. Этот коэффициент измеряет способность компании выполнять процентные платежи.',
      de: 'Die Zinsdeckungsquote wird als EBIT (Gewinn vor Zinsen und Steuern) / Zinsaufwand berechnet. Diese Quote misst die Fähigkeit des Unternehmens, Zinszahlungen zu leisten.',
      pt: 'A Relação de Cobertura de Juros é calculada como EBIT (Lucros Antes de Juros e Impostos) / Despesa de Juros. Esta relação mede a capacidade da empresa de cumprir pagamentos de juros.'
    }
  },
  {
    id: 9,
    question: {
      tr: 'DCF analizinde "Terminal Değer" neden kritiktir?',
      en: 'Why is "Terminal Value" critical in DCF analysis?',
      es: '¿Por qué el "Valor Terminal" es crítico en el análisis DCF?',
      fr: 'Pourquoi la "Valeur Terminale" est-elle critique dans l\'analyse DCF?',
      ru: 'Почему "Терминальная стоимость" критична в DCF анализе?',
      de: 'Warum ist der "Endwert" in der DCF-Analyse kritisch?',
      pt: 'Por que o "Valor Terminal" é crítico na análise DCF?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['Şirketin borçlarını gösterir', 'Hisse başı kazanç tahminini yapar', 'Toplam değerin büyük kısmını oluşturur', 'Sadece kısa vadeli projeksiyonlar için geçerlidir'],
      en: ['Shows company debts', 'Makes earnings per share forecast', 'Constitutes a large part of total value', 'Only valid for short-term projections'],
      es: ['Muestra las deudas de la empresa', 'Hace pronóstico de ganancias por acción', 'Constituye una gran parte del valor total', 'Solo válido para proyecciones a corto plazo'],
      fr: ['Montre les dettes de l\'entreprise', 'Fait des prévisions de bénéfices par action', 'Constitue une grande partie de la valeur totale', 'Seulement valide pour les projections à court terme'],
      ru: ['Показывает долги компании', 'Делает прогноз прибыли на акцию', 'Составляет большую часть общей стоимости', 'Действительно только для краткосрочных прогнозов'],
      de: ['Zeigt Unternehmensschulden', 'Macht Gewinn-je-Aktie-Prognosen', 'Bildet einen großen Teil des Gesamtwerts', 'Nur gültig für kurzfristige Projektionen'],
      pt: ['Mostra dívidas da empresa', 'Faz previsão de lucro por ação', 'Constitui uma grande parte do valor total', 'Apenas válido para projeções de curto prazo']
    },
    correct: 2,
    explanation: {
      tr: 'Terminal Değer, DCF analizinde genellikle toplam değerin %70-80\'ini oluşturur. Şirketin projeksiyonlar sonrasındaki sürekli değeri için kritik öneme sahiptir.',
      en: 'Terminal Value typically constitutes 70-80% of total value in DCF analysis. It has critical importance for the company\'s perpetual value after projections.',
      es: 'El Valor Terminal típicamente constituye el 70-80% del valor total en el análisis DCF. Tiene importancia crítica para el valor perpetuo de la empresa después de las proyecciones.',
      fr: 'La Valeur Terminale constitue généralement 70-80% de la valeur totale dans l\'analyse DCF. Elle a une importance critique pour la valeur perpétuelle de l\'entreprise après les projections.',
      ru: 'Терминальная стоимость обычно составляет 70-80% общей стоимости в DCF анализе. Она имеет критическое значение для постоянной стоимости компании после прогнозов.',
      de: 'Der Endwert macht typischerweise 70-80% des Gesamtwerts in der DCF-Analyse aus. Er hat kritische Bedeutung für den ewigen Wert des Unternehmens nach den Projektionen.',
      pt: 'O Valor Terminal tipicamente constitui 70-80% do valor total na análise DCF. Tem importância crítica para o valor perpétuo da empresa após as projeções.'
    }
  },
  {
    id: 10,
    question: {
      tr: 'P/E oranı neyi ifade eder?',
      en: 'What does the P/E ratio represent?',
      es: '¿Qué representa la relación P/E?',
      fr: 'Que représente le ratio P/E?',
      ru: 'Что представляет коэффициент P/E?',
      de: 'Was stellt das KGV dar?',
      pt: 'O que a relação P/E representa?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['Şirketin defter değerini', 'Hisse fiyatının kazanca oranını', 'Borçların özkaynaklara oranını', 'Varlıkların kârlılığını'],
      en: ['Company\'s book value', 'Stock price to earnings ratio', 'Debt to equity ratio', 'Asset profitability'],
      es: ['Valor en libros de la empresa', 'Relación precio de acción a ganancias', 'Relación deuda a patrimonio', 'Rentabilidad de activos'],
      fr: ['Valeur comptable de l\'entreprise', 'Rapport prix de l\'action aux bénéfices', 'Rapport dette sur capitaux propres', 'Rentabilité des actifs'],
      ru: ['Балансовая стоимость компании', 'Отношение цены акции к прибыли', 'Отношение долга к собственному капиталу', 'Рентабельность активов'],
      de: ['Buchwert des Unternehmens', 'Verhältnis Aktienkurs zu Gewinn', 'Verhältnis Schulden zu Eigenkapital', 'Rentabilität der Vermögenswerte'],
      pt: ['Valor contábil da empresa', 'Relação preço da ação para lucros', 'Relação dívida para patrimônio', 'Rentabilidade de ativos']
    },
    correct: 1,
    explanation: {
      tr: 'P/E (Price/Earnings) oranı, hisse fiyatının hisse başı kazanca bölünmesiyle hesaplanır. Yatırımcıların bir TL kazanç için kaç TL ödediğini gösterir.',
      en: 'P/E (Price/Earnings) ratio is calculated by dividing stock price by earnings per share. It shows how much investors pay for one unit of earnings.',
      es: 'La relación P/E (Precio/Ganancias) se calcula dividiendo el precio de la acción por las ganancias por acción. Muestra cuánto pagan los inversores por una unidad de ganancias.',
      fr: 'Le ratio P/E (Prix/Bénéfices) est calculé en divisant le prix de l\'action par les bénéfices par action. Il montre combien les investisseurs paient pour une unité de bénéfices.',
      ru: 'Коэффициент P/E (цена/прибыль) рассчитывается путем деления цены акции на прибыль на акцию. Он показывает, сколько инвесторы платят за единицу прибыли.',
      de: 'Das KGV (Kurs-Gewinn-Verhältnis) wird berechnet, indem der Aktienkurs durch den Gewinn je Aktie geteilt wird. Es zeigt, wie viel Investoren für eine Gewinneinheit zahlen.',
      pt: 'A relação P/E (Preço/Lucros) é calculada dividindo o preço da ação pelo lucro por ação. Mostra quanto os investidores pagam por uma unidade de lucros.'
    }
  },
  {
    id: 11,
    question: {
      tr: 'Aşağıdakilerden hangisi kurumsal yönetim göstergesi değildir?',
      en: 'Which of the following is NOT a corporate governance indicator?',
      es: '¿Cuál de los siguientes NO es un indicador de gobierno corporativo?',
      fr: 'Lequel des suivants n\'est PAS un indicateur de gouvernance d\'entreprise?',
      ru: 'Что из следующего НЕ является показателем корпоративного управления?',
      de: 'Welches der folgenden ist KEIN Indikator für Corporate Governance?',
      pt: 'Qual dos seguintes NÃO é um indicador de governança corporativa?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['Yönetim kurulu bağımsızlığı', 'Şeffaflık raporları', 'Hissedar haklarının korunması', 'RSI ve MACD kullanımı'],
      en: ['Board independence', 'Transparency reports', 'Protection of shareholder rights', 'RSI and MACD usage'],
      es: ['Independencia del consejo', 'Informes de transparencia', 'Protección de derechos de accionistas', 'Uso de RSI y MACD'],
      fr: ['Indépendance du conseil', 'Rapports de transparence', 'Protection des droits des actionnaires', 'Utilisation de RSI et MACD'],
      ru: ['Независимость совета директоров', 'Отчеты о прозрачности', 'Защита прав акционеров', 'Использование RSI и MACD'],
      de: ['Vorstandsunabhängigkeit', 'Transparenzberichte', 'Schutz der Aktionärsrechte', 'Verwendung von RSI und MACD'],
      pt: ['Independência do conselho', 'Relatórios de transparência', 'Proteção dos direitos dos acionistas', 'Uso de RSI e MACD']
    },
    correct: 3,
    explanation: {
      tr: 'RSI ve MACD teknik analiz araçlarıdır, kurumsal yönetim göstergesi değildir. Kurumsal yönetim; şeffaflık, hesap verebilirlik ve hissedar hakları ile ilgilidir.',
      en: 'RSI and MACD are technical analysis tools, not corporate governance indicators. Corporate governance relates to transparency, accountability and shareholder rights.',
      es: 'RSI y MACD son herramientas de análisis técnico, no indicadores de gobierno corporativo. El gobierno corporativo se relaciona con transparencia, responsabilidad y derechos de accionistas.',
      fr: 'RSI et MACD sont des outils d\'analyse technique, pas des indicateurs de gouvernance d\'entreprise. La gouvernance d\'entreprise concerne la transparence, la responsabilité et les droits des actionnaires.',
      ru: 'RSI и MACD - это инструменты технического анализа, а не показатели корпоративного управления. Корпоративное управление связано с прозрачностью, подотчетностью и правами акционеров.',
      de: 'RSI und MACD sind technische Analysewerkzeuge, keine Corporate Governance-Indikatoren. Corporate Governance bezieht sich auf Transparenz, Rechenschaftspflicht und Aktionärsrechte.',
      pt: 'RSI e MACD são ferramentas de análise técnica, não indicadores de governança corporativa. Governança corporativa relaciona-se com transparência, responsabilidade e direitos dos acionistas.'
    }
  },
  {
    id: 12,
    question: {
      tr: 'Warren Buffett\'in "ekonomik hendek" (moat) kavramı neyi ifade eder?',
      en: 'What does Warren Buffett\'s "economic moat" concept refer to?',
      es: '¿A qué se refiere el concepto de "foso económico" de Warren Buffett?',
      fr: 'À quoi fait référence le concept de "fossé économique" de Warren Buffett?',
      ru: 'К чему относится концепция "экономического рва" Уоррена Баффета?',
      de: 'Worauf bezieht sich Warren Buffetts Konzept des "wirtschaftlichen Burggraben"?',
      pt: 'A que se refere o conceito de "fosso econômico" de Warren Buffett?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['Şirketin kısa vadeli nakit akışı', 'Şirketin rakiplerine karşı sürdürülebilir avantajı', 'Hisse fiyatındaki dalgalanmalar', 'Döviz kuru volatilitesi'],
      en: ['Company\'s short-term cash flow', 'Company\'s sustainable competitive advantage', 'Stock price fluctuations', 'Currency volatility'],
      es: ['Flujo de efectivo a corto plazo de la empresa', 'Ventaja competitiva sostenible de la empresa', 'Fluctuaciones del precio de las acciones', 'Volatilidad de la moneda'],
      fr: ['Flux de trésorerie à court terme de l\'entreprise', 'Avantage concurrentiel durable de l\'entreprise', 'Fluctuations du prix des actions', 'Volatilité des devises'],
      ru: ['Краткосрочный денежный поток компании', 'Устойчивое конкурентное преимущество компании', 'Колебания цены акций', 'Валютная волатильность'],
      de: ['Kurzfristiger Cashflow des Unternehmens', 'Nachhaltiger Wettbewerbsvorteil des Unternehmens', 'Aktienkursschwankungen', 'Währungsvolatilität'],
      pt: ['Fluxo de caixa de curto prazo da empresa', 'Vantagem competitiva sustentável da empresa', 'Flutuações do preço das ações', 'Volatilidade da moeda']
    },
    correct: 1,
    explanation: {
      tr: 'Ekonomik hendek, şirketin rakiplerine karşı sürdürülebilir rekabet avantajını ifade eder. Marka gücü, patent, ağ etkisi gibi faktörler hendek oluşturur.',
      en: 'Economic moat refers to a company\'s sustainable competitive advantage against competitors. Factors like brand power, patents, network effects create moats.',
      es: 'El foso económico se refiere a la ventaja competitiva sostenible de una empresa contra competidores. Factores como poder de marca, patentes, efectos de red crean fosos.',
      fr: 'Le fossé économique fait référence à l\'avantage concurrentiel durable d\'une entreprise contre les concurrents. Des facteurs comme le pouvoir de marque, les brevets, les effets de réseau créent des fossés.',
      ru: 'Экономический ров относится к устойчивому конкурентному преимуществу компании против конкурентов. Такие факторы, как сила бренда, патенты, сетевые эффекты создают рвы.',
      de: 'Der wirtschaftliche Burggraben bezieht sich auf den nachhaltigen Wettbewerbsvorteil eines Unternehmens gegenüber Konkurrenten. Faktoren wie Markenstärke, Patente, Netzwerkeffekte schaffen Burggräben.',
      pt: 'O fosso econômico refere-se à vantagem competitiva sustentável de uma empresa contra concorrentes. Fatores como poder da marca, patentes, efeitos de rede criam fossos.'
    }
  },
  {
    id: 13,
    question: {
      tr: 'Fed faiz artırdığında özellikle hangi hisse türü daha olumsuz etkilenir?',
      en: 'Which type of stock is particularly more negatively affected when the Fed raises interest rates?',
      es: '¿Qué tipo de acción se ve particularmente más afectada negativamente cuando la Fed sube las tasas de interés?',
      fr: 'Quel type d\'action est particulièrement plus négativement affecté lorsque la Fed augmente les taux d\'intérêt?',
      ru: 'Какой тип акций осо��енно негативно затрагивается, когда ФРС повышает процентные ставки?',
      de: 'Welcher Aktientyp ist besonders negativ betroffen, wenn die Fed die Zinssätze erhöht?',
      pt: 'Que tipo de ação é particularmente mais negativamente afetada quando o Fed aumenta as taxas de juros?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['Value stocks', 'Growth stocks', 'Defensive stocks', 'Dividend stocks'],
      en: ['Value stocks', 'Growth stocks', 'Defensive stocks', 'Dividend stocks'],
      es: ['Acciones de valor', 'Acciones de crecimiento', 'Acciones defensivas', 'Acciones de dividendos'],
      fr: ['Actions de valeur', 'Actions de croissance', 'Actions défensives', 'Actions à dividendes'],
      ru: ['Акции стоимости', 'Растущие акции', 'Защитные акции', 'Дивидендные акции'],
      de: ['Value-Aktien', 'Wachstumsaktien', 'Defensive Aktien', 'Dividendenaktien'],
      pt: ['Ações de valor', 'Ações de crescimento', 'Ações defensivas', 'Ações de dividendos']
    },
    correct: 1,
    explanation: {
      tr: 'Growth stocks (büyüme hisseleri) faiz artışından en olumsuz etkilenir çünkü gelecekteki nakit akışları daha fazla iskonto edilir ve borçlanma maliyetleri artar.',
      en: 'Growth stocks are most negatively affected by interest rate increases because future cash flows are discounted more heavily and borrowing costs increase.',
      es: 'Las acciones de crecimiento se ven más negativamente afectadas por los aumentos de tasas de interés porque los flujos de efectivo futuros se descuentan más fuertemente y los costos de endeudamiento aumentan.',
      fr: 'Les actions de croissance sont les plus négativement affectées par les hausses de taux d\'intérêt car les flux de trésorerie futurs sont plus fortement actualisés et les coûts d\'emprunt augmentent.',
      ru: 'Растущие акции наиболее негативно затрагиваются повышением процентных ставок, потому что будущие денежные потоки дисконтируются сильнее, а стоимость заимствования увеличивается.',
      de: 'Wachstumsaktien sind am negativsten von Zinssteigerungen betroffen, da zukünftige Cashflows stärker diskontiert werden und die Kreditkosten steigen.',
      pt: 'Ações de crescimento são mais negativamente afetadas por aumentos de taxa de juros porque fluxos de caixa futuros são mais pesadamente descontados e custos de empréstimo aumentam.'
    }
  },
  {
    id: 14,
    question: {
      tr: 'Aşağıdakilerden hangisi bir megatrend sektörüdür?',
      en: 'Which of the following is a megatrend sector?',
      es: '¿Cuál de los siguientes es un sector de megatendencia?',
      fr: 'Lequel des suivants est un secteur de mégatendance?',
      ru: 'Что из следующего является мегатрендовым сектором?',
      de: 'Welches der folgenden ist ein Megatrend-Sektor?',
      pt: 'Qual dos seguintes é um setor de megatendência?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['Kağıt Üretimi', 'Yenilenebilir Enerji', 'Tekstil', 'Geleneksel Madencilik'],
      en: ['Paper Manufacturing', 'Renewable Energy', 'Textile', 'Traditional Mining'],
      es: ['Fabricación de Papel', 'Energía Renovable', 'Textil', 'Minería Tradicional'],
      fr: ['Fabrication de Papier', 'Énergie Renouvelable', 'Textile', 'Exploitation Minière Traditionnelle'],
      ru: ['Производство бумаги', 'Возобновляемая энергия', 'Текстиль', 'Традиционная добыча'],
      de: ['Papierherstellung', 'Erneuerbare Energie', 'Textil', 'Traditioneller Bergbau'],
      pt: ['Fabricação de Papel', 'Energia Renovável', 'Têxtil', 'Mineração Tradicional']
    },
    correct: 1,
    explanation: {
      tr: 'Yenilenebilir enerji, küresel iklim değişikliği ve sürdürülebilirlik hedefleri nedeniyle önde gelen megatrend sektörlerinden biridir.',
      en: 'Renewable energy is one of the leading megatrend sectors due to global climate change and sustainability goals.',
      es: 'La energía renovable es uno de los sectores de megatendencia líderes debido al cambio climático global y los objetivos de sostenibilidad.',
      fr: 'L\'énergie renouvelable est l\'un des secteurs de mégatendance leaders en raison du changement climatique mondial et des objectifs de durabilité.',
      ru: 'Возобновляемая энергия является одним из ведущих мегатрендовых секторов из-за глобального изменения климата и целей устойчивости.',
      de: 'Erneuerbare Energie ist einer der führenden Megatrend-Sektoren aufgrund des globalen Klimawandels und der Nachhaltigkeitsziele.',
      pt: 'Energia renovável é um dos setores de megatendência líderes devido às mudanças climáticas globais e objetivos de sustentabilidade.'
    }
  },
  {
    id: 15,
    question: {
      tr: 'Borç/Özkaynak oranının 2.0 üzerinde olması genellikle neyi işaret eder?',
      en: 'What does a Debt/Equity ratio above 2.0 typically indicate?',
      es: '¿Qué indica típicamente una relación Deuda/Patrimonio por encima de 2.0?',
      fr: 'Qu\'indique généralement un ratio Dette/Capitaux Propres supérieur à 2.0?',
      ru: 'На что обычно указывает отношение долга к собственному капиталу выше 2.0?',
      de: 'Was zeigt ein Verschuldungsgrad über 2.0 typischerweise an?',
      pt: 'O que uma relação Dívida/Patrimônio acima de 2.0 tipicamente indica?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['Yüksek finansal risk', 'Güçlü likidite', 'Düşük kaldıraç', 'Güçlü kârlılık'],
      en: ['High financial risk', 'Strong liquidity', 'Low leverage', 'Strong profitability'],
      es: ['Alto riesgo financiero', 'Liquidez fuerte', 'Bajo apalancamiento', 'Rentabilidad fuerte'],
      fr: ['Risque financier élevé', 'Liquidité forte', 'Faible effet de levier', 'Rentabilité forte'],
      ru: ['Высокий финансовый риск', 'Сильная ликвидность', 'Низкий леверидж', 'Сильная прибыльность'],
      de: ['Hohes Finanzrisiko', 'Starke Liquidität', 'Geringe Hebelwirkung', 'Starke Rentabilität'],
      pt: ['Alto risco financeiro', 'Liquidez forte', 'Baixa alavancagem', 'Rentabilidade forte']
    },
    correct: 0,
    explanation: {
      tr: 'Borç/Özkaynak oranının 2.0 üzerinde olması, şirketin özkaynaklarının iki katından fazla borca sahip olduğunu ve yüksek finansal risk taşıdığını gösterir.',
      en: 'A Debt/Equity ratio above 2.0 indicates the company has more than twice its equity in debt and carries high financial risk.',
      es: 'Una relación Deuda/Patrimonio por encima de 2.0 indica que la empresa tiene más del doble de su patrimonio en deuda y conlleva alto riesgo financiero.',
      fr: 'Un ratio Dette/Capitaux Propres supérieur à 2.0 indique que l\'entreprise a plus du double de ses capitaux propres en dette et porte un risque financier élevé.',
      ru: 'Отношение долга к собственному капиталу выше 2.0 указывает на то, что у компании более чем в два раза больше долга, чем собственного капитала, и она несет высокий финансовый риск.',
      de: 'Ein Verschuldungsgrad über 2.0 zeigt an, dass das Unternehmen mehr als das Doppelte seines Eigenkapitals an Schulden hat und ein hohes Finanzrisiko trägt.',
      pt: 'Uma relação Dívida/Patrimônio acima de 2.0 indica que a empresa tem mais que o dobro de seu patrimônio em dívidas e carrega alto risco financeiro.'
    }
  },
  {
    id: 16,
    question: {
      tr: 'Gelir tablosu hangi dönemi kapsar?',
      en: 'What period does the income statement cover?',
      es: '¿Qué período cubre el estado de resultados?',
      fr: 'Quelle période couvre le compte de résultat?',
      ru: 'Какой период покрывает отчет о прибылях и убытках?',
      de: 'Welchen Zeitraum deckt die Gewinn- und Verlustrechnung ab?',
      pt: 'Que período a demonstração de resultados cobre?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['Belirli bir gün', 'Belirli bir çeyrek veya yıl', 'Tüm şirket ömrü', '10 yıllık bir süre'],
      en: ['A specific day', 'A specific quarter or year', 'Entire company lifetime', 'A 10-year period'],
      es: ['Un día específico', 'Un trimestre o año específico', 'Toda la vida de la empresa', 'Un período de 10 años'],
      fr: ['Un jour spécifique', 'Un trimestre ou une année spécifique', 'Toute la durée de vie de l\'entreprise', 'Une période de 10 ans'],
      ru: ['Конкретный день', 'Конкретный квартал или год', 'Весь срок жизни компании', '10-летний период'],
      de: ['Ein bestimmter Tag', 'Ein bestimmtes Quartal oder Jahr', 'Die gesamte Lebensdauer des Unternehmens', 'Ein 10-Jahres-Zeitraum'],
      pt: ['Um dia específico', 'Um trimestre ou ano específico', 'Toda a vida da empresa', 'Um período de 10 anos']
    },
    correct: 1,
    explanation: {
      tr: 'Gelir tablosu, belirli bir dönemdeki (çeyrek, yıl) gelir ve giderleri gösterir. Bilanço ise belirli bir tarihteki finansal durumu yansıtır.',
      en: 'Income statement shows revenues and expenses for a specific period (quarter, year). Balance sheet reflects financial position at a specific date.',
      es: 'El estado de resultados muestra ingresos y gastos para un período específico (trimestre, año). El balance general refleja la posición financiera en una fecha específica.',
      fr: 'Le compte de résultat montre les revenus et les dépenses pour une période spécifique (trimestre, année). Le bilan reflète la situation financière à une date spécifique.',
      ru: 'Отчет о прибылях и убытках показывает доходы и расходы за определенный период (квартал, год). Баланс отражает финансовое положение на конкретную дату.',
      de: 'Die Gewinn- und Verlustrechnung zeigt Erträge und Aufwendungen für einen bestimmten Zeitraum (Quartal, Jahr). Die Bilanz spiegelt die Finanzlage zu einem bestimmten Datum wider.',
      pt: 'A demonstração de resultados mostra receitas e despesas para um período específico (trimestre, ano). O balanço patrimonial reflete a posição financeira em uma data específica.'
    }
  },
  {
    id: 17,
    question: {
      tr: 'Bilanço hangi bilgiyi sunar?',
      en: 'What information does the balance sheet provide?',
      es: '¿Qué información proporciona el balance general?',
      fr: 'Quelles informations le bilan fournit-il?',
      ru: 'Какую информацию предоставляет баланс?',
      de: 'Welche Informationen liefert die Bilanz?',
      pt: 'Que informação o balanço patrimonial fornece?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['Şirketin belirli bir tarihteki finansal durumunu', 'Şirketin tüm kârlılık projeksiyonlarını', 'Şirketin nakit akış trendlerini', 'Şirketin rakip analizini'],
      en: ['Company\'s financial position at a specific date', 'Company\'s all profitability projections', 'Company\'s cash flow trends', 'Company\'s competitor analysis'],
      es: ['Posición financiera de la empresa en una fecha específica', 'Todas las proyecciones de rentabilidad de la empresa', 'Tendencias de flujo de efectivo de la empresa', 'Análisis de competidores de la empresa'],
      fr: ['Position financière de l\'entreprise à une date spécifique', 'Toutes les projections de rentabilité de l\'entreprise', 'Tendances des flux de trésorerie de l\'entreprise', 'Analyse des concurrents de l\'entreprise'],
      ru: ['Финансовое положение компании на конкретную дату', 'Все прогнозы прибыльности компании', 'Тенденции денежных потоков компании', 'Анализ конкурентов компании'],
      de: ['Finanzlage des Unternehmens zu einem bestimmten Datum', 'Alle Rentabilitätsprojektionen des Unternehmens', 'Cashflow-Trends des Unternehmens', 'Wettbewerbsanalyse des Unternehmens'],
      pt: ['Posição financeira da empresa em uma data específica', 'Todas as projeções de rentabilidade da empresa', 'Tendências de fluxo de caixa da empresa', 'Análise de concorrentes da empresa']
    },
    correct: 0,
    explanation: {
      tr: 'Bilanço, şirketin belirli bir tarihteki varlıkları, borçları ve özkaynaklarını gösterir. Bu, o andaki finansal durumun anlık görüntüsüdür.',
      en: 'Balance sheet shows company\'s assets, liabilities and equity at a specific date. It\'s a snapshot of financial position at that moment.',
      es: 'El balance general muestra los activos, pasivos y patrimonio de la empresa en una fecha específica. Es una instantánea de la posición financiera en ese momento.',
      fr: 'Le bilan montre les actifs, passifs et capitaux propres de l\'entreprise à une date spécifique. C\'est un instantané de la position financière à ce moment.',
      ru: 'Баланс показывает активы, обязательства и собственный капитал компании на конкретную дату. Это моментальный снимок финансового положения в этот момент.',
      de: 'Die Bilanz zeigt Vermögenswerte, Verbindlichkeiten und Eigenkapital des Unternehmens zu einem bestimmten Datum. Es ist eine Momentaufnahme der Finanzlage zu diesem Zeitpunkt.',
      pt: 'O balanço patrimonial mostra ativos, passivos e patrimônio da empresa em uma data específica. É um instantâneo da posição financeira naquele momento.'
    }
  },
  {
    id: 18,
    question: {
      tr: 'P/B oranının 1\'in altında olması genellikle neyi gösterir?',
      en: 'What does a P/B ratio below 1 typically indicate?',
      es: '¿Qué indica típicamente una relación P/B por debajo de 1?',
      fr: 'Qu\'indique généralement un ratio P/B inférieur à 1?',
      ru: 'На что обычно указывает отношение P/B ниже 1?',
      de: 'Was zeigt ein KBV unter 1 typischerweise an?',
      pt: 'O que uma relação P/B abaixo de 1 tipicamente indica?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['Şirketin aşırı pahalı olduğunu', 'Şirketin varlıklarına göre ucuz olabileceğini', 'Şirketin borçlarının arttığını', 'Şirketin kârlılığının çok yüksek olduğunu'],
      en: ['Company is overpriced', 'Company may be cheap relative to its assets', 'Company\'s debts are increasing', 'Company\'s profitability is very high'],
      es: ['La empresa está sobrevalorada', 'La empresa puede estar barata en relación a sus activos', 'Las deudas de la empresa están aumentando', 'La rentabilidad de la empresa es muy alta'],
      fr: ['L\'entreprise est surévaluée', 'L\'entreprise peut être bon marché par rapport à ses actifs', 'Les dettes de l\'entreprise augmentent', 'La rentabilité de l\'entreprise est très élevée'],
      ru: ['Компания переоценена', 'Компания может быть дешевой относительно своих активов', 'Долги компании увеличиваются', 'Прибыльность компании очень высока'],
      de: ['Das Unternehmen ist überbewertet', 'Das Unternehmen könnte günstig im Verhältnis zu seinen Vermögenswerten sein', 'Die Schulden des Unternehmens steigen', 'Die Rentabilität des Unternehmens ist sehr hoch'],
      pt: ['A empresa está supervalorizada', 'A empresa pode estar barata em relação aos seus ativos', 'As dívidas da empresa estão aumentando', 'A rentabilidade da empresa é muito alta']
    },
    correct: 1,
    explanation: {
      tr: 'P/B oranının 1\'in altında olması, hisse fiyatının defter değerinden düşük olduğunu gösterir. Bu, şirketin varlıklarına göre ucuz değerlendiğini işaret edebilir.',
      en: 'A P/B ratio below 1 indicates the stock price is below book value. This may signal the company is valued cheaply relative to its assets.',
      es: 'Una relación P/B por debajo de 1 indica que el precio de la acción está por debajo del valor en libros. Esto puede señalar que la empresa está valorada barata en relación a sus activos.',
      fr: 'Un ratio P/B inférieur à 1 indique que le prix de l\'action est inférieur à la valeur comptable. Cela peut signaler que l\'entreprise est valorisée à bon marché par rapport à ses actifs.',
      ru: 'Отношение P/B ниже 1 указывает на то, что цена акции ниже балансовой стоимости. Это может сигнализировать о том, что компания оценена дешево относительно своих активов.',
      de: 'Ein KBV unter 1 zeigt an, dass der Aktienkurs unter dem Buchwert liegt. Dies kann signalisieren, dass das Unternehmen günstig im Verhältnis zu seinen Vermögenswerten bewertet ist.',
      pt: 'Uma relação P/B abaixo de 1 indica que o preço da ação está abaixo do valor contábil. Isso pode sinalizar que a empresa está avaliada barata em relação aos seus ativos.'
    }
  },
  {
    id: 19,
    question: {
      tr: 'Döviz kuru yükseldiğinde ihracat yapan şirketler için tipik etki nedir?',
      en: 'What is the typical effect on export companies when currency rates rise?',
      es: '¿Cuál es el efecto típico en las empresas exportadoras cuando suben las tasas de cambio?',
      fr: 'Quel est l\'effet typique sur les entreprises exportatrices lorsque les taux de change augmentent?',
      ru: 'Каково типичное влияние на экспортные компании при росте валютных курсов?',
      de: 'Was ist die typische Auswirkung auf Exportunternehmen, wenn die Wechselkurse steigen?',
      pt: 'Qual é o efeito típico nas empresas exportadoras quando as taxas de câmbio sobem?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['Negatif, çünkü gelirleri düşer', 'Pozitif, çünkü gelirleri artar', 'Nötr, çünkü etkilenmez', 'Tamamen sektöre göre değişir'],
      en: ['Negative, because revenues decrease', 'Positive, because revenues increase', 'Neutral, because it\'s not affected', 'Completely depends on the sector'],
      es: ['Negativo, porque los ingresos disminuyen', 'Positivo, porque los ingresos aumentan', 'Neutral, porque no se ve afectado', 'Depende completamente del sector'],
      fr: ['Négatif, car les revenus diminuent', 'Positif, car les revenus augmentent', 'Neutre, car ce n\'est pas affecté', 'Dépend entièrement du secteur'],
      ru: ['Отрицательное, потому что доходы снижаются', 'Положительное, потому что доходы увеличиваются', 'Нейтральное, потому что не затрагивается', 'Полностью зависит от сектора'],
      de: ['Negativ, weil Einnahmen sinken', 'Positiv, weil Einnahmen steigen', 'Neutral, weil es nicht betroffen ist', 'Hängt völlig vom Sektor ab'],
      pt: ['Negativo, porque as receitas diminuem', 'Positivo, porque as receitas aumentam', 'Neutro, porque não é afetado', 'Depende completamente do setor']
    },
    correct: 1,
    explanation: {
      tr: 'Döviz kuru yükseldiğinde (TL değer kaybettiğinde) ihracat yapan şirketler döviz cinsinden kazançlarını TL\'ye çevirdiklerinde daha yüksek gelir elde ederler.',
      en: 'When currency rates rise (local currency depreciates), export companies earn higher revenues when converting their foreign currency earnings to local currency.',
      es: 'Cuando las tasas de cambio suben (la moneda local se deprecia), las empresas exportadoras obtienen mayores ingresos al convertir sus ganancias en moneda extranjera a moneda local.',
      fr: 'Lorsque les taux de change augmentent (la monnaie locale se déprécie), les entreprises exportatrices obtiennent des revenus plus élevés en convertissant leurs gains en devises étrangères en monnaie locale.',
      ru: 'Когда валютные курсы растут (местная валюта обесценивается), экспортные компании получают более высокие доходы при конвертации своих валютных доходов в местную валюту.',
      de: 'Wenn die Wechselkurse steigen (die Landeswährung abwertet), erzielen Exportunternehmen höhere Einnahmen bei der Umwandlung ihrer Fremdwährungsgewinne in die Landeswährung.',
      pt: 'Quando as taxas de câmbio sobem (moeda local deprecia), empresas exportadoras obtêm receitas maiores ao converter seus ganhos em moeda estrangeira para moeda local.'
    }
  },
  {
    id: 20,
    question: {
      tr: 'Temel analizde riskleri azaltmak için en sık kullanılan strateji hangisidir?',
      en: 'What is the most commonly used strategy to reduce risks in fundamental analysis?',
      es: '¿Cuál es la estrategia más comúnmente usada para reducir riesgos en análisis fundamental?',
      fr: 'Quelle est la stratégie la plus couramment utilisée pour réduire les risques dans l\'analyse fondamentale?',
      ru: 'Какая стратегия наиболее часто используется для снижения рисков в фундаментальном анализе?',
      de: 'Was ist die am häufigsten verwendete Strategie zur Risikominderung in der Fundamentalanalyse?',
      pt: 'Qual é a estratégia mais comumente usada para reduzir riscos na análise fundamental?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['Tüm parayı tek bir hisseye yatırmak', 'Yalnızca kısa vadeli işlemler yapmak', 'Portföy çeşitlendirmesi yapmak', 'Faiz oranlarını görmezden gelmek'],
      en: ['Investing all money in one stock', 'Only making short-term trades', 'Portfolio diversification', 'Ignoring interest rates'],
      es: ['Invertir todo el dinero en una acción', 'Solo hacer operaciones a corto plazo', 'Diversificación de cartera', 'Ignorar las tasas de interés'],
      fr: ['Investir tout l\'argent dans une action', 'Ne faire que des trades à court terme', 'Diversification de portefeuille', 'Ignorer les taux d\'intérêt'],
      ru: ['Инвестирование всех денег в одну акцию', 'Только краткосрочные сделки', 'Диверсификация портфеля', 'Игнорирование процентных ставок'],
      de: ['Alles Geld in eine Aktie investieren', 'Nur kurzfristige Trades machen', 'Portfolio-Diversifikation', 'Zinssätze ignorieren'],
      pt: ['Investir todo o dinheiro em uma ação', 'Apenas fazer negociações de curto prazo', 'Diversificação de portfólio', 'Ignorar taxas de juros']
    },
    correct: 2,
    explanation: {
      tr: 'Portföy çeşitlendirmesi, farklı sektörler, ülkeler ve varlık sınıflarına yatırım yaparak riski dağıtmak demektir. Bu, temel analizde risk azaltmanın en temel stratejisidir.',
      en: 'Portfolio diversification means spreading risk by investing in different sectors, countries and asset classes. This is the most fundamental risk reduction strategy in fundamental analysis.',
      es: 'La diversificación de cartera significa distribuir el riesgo invirtiendo en diferentes sectores, países y clases de activos. Esta es la estrategia más fundamental de reducción de riesgo en análisis fundamental.',
      fr: 'La diversification de portefeuille signifie répartir le risque en investissant dans différents secteurs, pays et classes d\'actifs. C\'est la stratégie de réduction de risque la plus fondamentale dans l\'analyse fondamentale.',
      ru: 'Диверсификация портфеля означает распределение риска путем инвестирования в различные секторы, страны и классы активов. Это наиболее фундаментальная стратегия снижения рисков в фундаментальном анализе.',
      de: 'Portfolio-Diversifikation bedeutet Risikostreuung durch Investitionen in verschiedene Sektoren, Länder und Anlageklassen. Dies ist die grundlegendste Risikominderungsstrategie in der Fundamentalanalyse.',
      pt: 'Diversificação de portfólio significa espalhar o risco investindo em diferentes setores, países e classes de ativos. Esta é a estratégia mais fundamental de redução de risco na análise fundamental.'
    }
  }
]