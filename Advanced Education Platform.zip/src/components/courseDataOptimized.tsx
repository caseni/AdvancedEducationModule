import { Language } from './useLanguage'

export interface CourseModule {
  title: { [lang in Language]: string }
  lessons: string[]
  duration: string
  topics: { [lang in Language]: string[] }
}

export interface Course {
  id: number
  category: string
  level: 'Beginner' | 'Intermediate' | 'Advanced'
  duration: string
  lessons: number
  rating: number
  enrolled: number
  progress: number
  hasQuiz: boolean
  contentTypes: string[]
  lastUpdated: string
  tags: string[]
  title: { [lang in Language]: string }
  description: { [lang in Language]: string }
  outcomes: { [lang in Language]: string[] }
  modules: CourseModule[]
  prerequisites: { [lang in Language]: string[] }
  skillsGained: { [lang in Language]: string[] }
}

export const courses: Course[] = [
  {
    id: 10,
    category: 'Analysis',
    level: 'Advanced',
    duration: '8',
    lessons: 16,
    rating: 4.9,
    enrolled: 856,
    progress: 0,
    hasQuiz: true,
    contentTypes: ['video', 'text', 'quiz', 'practice'],
    lastUpdated: '3',
    tags: ['ileri', 'teknik', 'analiz', 'SMC', 'grafik'],
    title: {
      tr: 'İleri Seviye Teknik Analiz',
      en: 'Advanced Technical Analysis',
      es: 'Análisis Técnico Avanzado',
      fr: 'Analyse Technique Avancée',
      ru: 'Продвинутый технический анализ'
    },
    description: {
      tr: 'SMC (Akıllı Para Kavramları), kurumsal davranış analizi, VWAP, Volume Profile ve ileri teknik analiz yöntemleri.',
      en: 'SMC (Smart Money Concepts), institutional behavior analysis, VWAP, Volume Profile and advanced technical analysis methods.',
      es: 'SMC (Smart Money Concepts), análisis comportamiento institucional, VWAP, Volume Profile y métodos análisis técnico avanzado.',
      fr: 'SMC (Smart Money Concepts), analyse comportement institutionnel, VWAP, Volume Profile et méthodes analyse technique avancée.',
      ru: 'SMC (Smart Money Concepts), анализ институционального поведения, VWAP, Volume Profile и продвинутые методы технического анализа.'
    },
    outcomes: {
      tr: [
        'SMC ile kurumsal davranışları anlayacaksınız',
        'VWAP ve Volume Profile kullanabileceksiniz',
        'Order Block ve likidite havuzlarını tespit edeceksiniz',
        'Konfluence teknikleri uygulayacaksınız'
      ],
      en: [
        'You will understand institutional behavior with SMC',
        'You will use VWAP and Volume Profile',
        'You will identify Order Blocks and liquidity pools',
        'You will apply confluence techniques'
      ],
      es: [
        'Entenderás comportamiento institucional con SMC',
        'Usarás VWAP y Volume Profile',
        'Identificarás Order Blocks y pools de liquidez',
        'Aplicarás técnicas de confluencia'
      ],
      fr: [
        'Vous comprendrez comportement institutionnel avec SMC',
        'Vous utiliserez VWAP et Volume Profile',
        'Vous identifierez Order Blocks et pools de liquidité',
        'Vous appliquerez techniques de confluence'
      ],
      ru: [
        'Вы поймете институциональное поведение с SMC',
        'Вы будете использовать VWAP и Volume Profile',
        'Вы определите Order Blocks и пулы ликвидности',
        'Вы применитe техники конфлюенса'
      ]
    },
    modules: [
      {
        title: {
          tr: 'SMC ve Kurumsal Analiz',
          en: 'SMC and Institutional Analysis',
          es: 'SMC y Análisis Institucional',
          fr: 'SMC et Analyse Institutionnelle',
          ru: 'SMC и институциональный анализ'
        },
        lessons: ['SMC Temelleri', 'Order Block', 'Likidite Havuzları', 'FVG'],
        duration: '4 saat',
        topics: {
          tr: ['Piyasa yapısı', 'Kurumsal davranış', 'Stop-hunt', 'Konfluence'],
          en: ['Market structure', 'Institutional behavior', 'Stop-hunt', 'Confluence'],
          es: ['Estructura mercado', 'Comportamiento institucional', 'Stop-hunt', 'Confluencia'],
          fr: ['Structure marché', 'Comportement institutionnel', 'Stop-hunt', 'Confluence'],
          ru: ['Рыночная структура', 'Институциональное поведение', 'Стоп-хант', 'Конфлюенс']
        }
      },
      {
        title: {
          tr: 'VWAP ve Volume Analizi',
          en: 'VWAP and Volume Analysis',
          es: 'VWAP y Análisis Volumen',
          fr: 'VWAP et Analyse Volume',
          ru: 'VWAP и анализ объема'
        },
        lessons: ['VWAP Kullanımı', 'Volume Profile', 'POC Analizi', 'Value Area'],
        duration: '4 saat',
        topics: {
          tr: ['Kurumsal değer', 'Hacim yoğunluğu', 'Destek-direnç', 'Volatilite'],
          en: ['Institutional value', 'Volume density', 'Support-resistance', 'Volatility'],
          es: ['Valor institucional', 'Densidad volumen', 'Soporte-resistencia', 'Volatilidad'],
          fr: ['Valeur institutionnelle', 'Densité volume', 'Support-résistance', 'Volatilité'],
          ru: ['Институциональная стоимость', 'Плотность объема', 'Поддержка-сопротивление', 'Волатильность']
        }
      }
    ],
    prerequisites: {
      tr: ['Temel teknik analiz'],
      en: ['Basic technical analysis'],
      es: ['Análisis técnico básico'],
      fr: ['Analyse technique de base'],
      ru: ['Базовый технический анализ']
    },
    skillsGained: {
      tr: ['SMC analizi', 'VWAP kullanımı', 'Volume Profile', 'Risk yönetimi'],
      en: ['SMC analysis', 'VWAP usage', 'Volume Profile', 'Risk management'],
      es: ['Análisis SMC', 'Uso VWAP', 'Volume Profile', 'Gestión riesgos'],
      fr: ['Analyse SMC', 'Utilisation VWAP', 'Volume Profile', 'Gestion risques'],
      ru: ['SMC анализ', 'Использование VWAP', 'Volume Profile', 'Управление рисками']
    }
  },
  {
    id: 1,
    category: 'Economics',
    level: 'Beginner',
    duration: '10',
    lessons: 20,
    rating: 4.8,
    enrolled: 1580,
    progress: 0,
    hasQuiz: true,
    contentTypes: ['video', 'text', 'quiz'],
    lastUpdated: '1',
    tags: ['temel', 'ekonomi', 'piyasa'],
    title: {
      tr: 'Temel Ekonomi',
      en: 'Basic Economics',
      es: 'Economía Básica',
      fr: 'Économie de Base',
      ru: 'Основы Экономики'
    },
    description: {
      tr: 'Mikroekonomi, makroekonomi, piyasa yapıları, GDP, enflasyon ve temel ekonomi kavramları.',
      en: 'Microeconomics, macroeconomics, market structures, GDP, inflation and basic economic concepts.',
      es: 'Microeconomía, macroeconomía, estructuras mercado, PIB, inflación y conceptos económicos básicos.',
      fr: 'Microéconomie, macroéconomie, structures marché, PIB, inflation et concepts économiques de base.',
      ru: 'Микроэкономика, макроэкономика, рыночные структуры, ВВП, инфляция и базовые экономические концепции.'
    },
    outcomes: {
      tr: [
        'Ekonominin temel ilkelerini anlayacaksınız',
        'Mikro ve makroekonomik süreçleri ayırt edeceksiniz',
        'Piyasa yapılarını karşılaştırabileceksiniz',
        'Ekonomik göstergeleri yorumlayacaksınız'
      ],
      en: [
        'You will understand basic principles of economics',
        'You will distinguish micro and macroeconomic processes',
        'You will compare market structures',
        'You will interpret economic indicators'
      ],
      es: [
        'Entenderás principios básicos de economía',
        'Distinguirás procesos micro y macroeconómicos',
        'Compararás estructuras de mercado',
        'Interpretarás indicadores económicos'
      ],
      fr: [
        'Vous comprendrez principes de base de l\'économie',
        'Vous distinguerez processus micro et macroéconomiques',
        'Vous comparerez structures de marché',
        'Vous interpréterez indicateurs économiques'
      ],
      ru: [
        'Вы поймете основные принципы экономики',
        'Вы различите микро и макроэкономические процессы',
        'Вы сравните рыночные структуры',
        'Вы интерпретируете экономические показатели'
      ]
    },
    modules: [
      {
        title: {
          tr: 'Mikroekonomi',
          en: 'Microeconomics',
          es: 'Microeconomía',
          fr: 'Microéconomie',
          ru: 'Микроэкономика'
        },
        lessons: ['Arz-Talep', 'Piyasa Yapıları', 'Tüketici Davranışı', 'Üretici Teorisi'],
        duration: '5 saat',
        topics: {
          tr: ['Fiyat mekanizması', 'Rekabet', 'Monopol', 'Oligopol'],
          en: ['Price mechanism', 'Competition', 'Monopoly', 'Oligopoly'],
          es: ['Mecanismo precio', 'Competencia', 'Monopolio', 'Oligopolio'],
          fr: ['Mécanisme prix', 'Concurrence', 'Monopole', 'Oligopole'],
          ru: ['Ценовой механизм', 'Конкуренция', 'Монополия', 'Олигополия']
        }
      },
      {
        title: {
          tr: 'Makroekonomi',
          en: 'Macroeconomics',
          es: 'Macroeconomía',
          fr: 'Macroéconomie',
          ru: 'Макроэкономика'
        },
        lessons: ['GDP', 'Enflasyon', 'İşsizlik', 'Para Politikası'],
        duration: '5 saat',
        topics: {
          tr: ['Büyüme', 'Fiyat istikrarı', 'İstihdam', 'Merkez bankası'],
          en: ['Growth', 'Price stability', 'Employment', 'Central bank'],
          es: ['Crecimiento', 'Estabilidad precios', 'Empleo', 'Banco central'],
          fr: ['Croissance', 'Stabilité prix', 'Emploi', 'Banque centrale'],
          ru: ['Рост', 'Ценовая стабильность', 'Занятость', 'Центральный банк']
        }
      }
    ],
    prerequisites: {
      tr: ['Temel matematik'],
      en: ['Basic mathematics'],
      es: ['Matemáticas básicas'],
      fr: ['Mathématiques de base'],
      ru: ['Базовая математика']
    },
    skillsGained: {
      tr: ['Ekonomik analiz', 'Piyasa analizi', 'Politika değerlendirme'],
      en: ['Economic analysis', 'Market analysis', 'Policy evaluation'],
      es: ['Análisis económico', 'Análisis mercado', 'Evaluación política'],
      fr: ['Analyse économique', 'Analyse marché', 'Évaluation politique'],
      ru: ['Экономический анализ', 'Рыночный анализ', 'Оценка политики']
    }
  }
]

export const getCoursesForLanguage = (language: Language) => {
  return courses.map(course => ({
    ...course,
    title: course.title[language],
    description: course.description[language],
    outcomes: course.outcomes[language]
  }))
}