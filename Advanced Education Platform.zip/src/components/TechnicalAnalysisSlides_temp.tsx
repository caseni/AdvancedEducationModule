import { LineChart, BarChart3, TrendingUp, Target, Lightbulb, Star, Users, Flag, Activity, Shield, Brain, Zap, Clock, Settings, TrendingDown } from 'lucide-react'
import chartAnalysisImage from 'figma:asset/62c51089983d0d87c1c3f7708323923f172aef9b.png'

export const technicalAnalysisSlides = [
  {
    title: { 
      tr: 'Teknik Analiz Nedir?', 
      en: 'What is Technical Analysis?', 
      es: '¿Qué es el Análisis Técnico?', 
      fr: 'Qu\'est-ce que l\'Analyse Technique?', 
      ru: 'Что такое технический анализ?' 
    },
    content: { 
      tr: [
        '• Geçmiş fiyat hareketleri ve hacim verilerini kullanarak gelecekteki fiyat yönünü tahmin etme sanatı',
        '• Temel prensipler: Fiyat her şeyi yansıtır, fiyat hareketleri tekrarlanır, trend analizi kritiktir',
        '• Kullanım alanları: Kısa vadeli trading, orta vadeli yatırım stratejileri, uzun vadeli trend analizi',
        '• Risk yönetimi ve giriş-çıkış noktalarının belirlenmesi için kullanılır'
      ],
      en: [
        '• Art of predicting future price direction using past price movements and volume data',
        '• Basic principles: Price reflects everything, price movements repeat, trend analysis is critical',
        '• Usage areas: Short-term trading, medium-term investment strategies, long-term trend analysis',
        '• Used for risk management and determining entry-exit points'
      ],
      es: [
        '• Arte de predecir la dirección futura del precio usando movimientos de precios pasados y datos de volumen',
        '• Principios básicos: El precio refleja todo, los movimientos de precios se repiten, el análisis de tendencias es crítico',
        '• Áreas de uso: Trading a corto plazo, estrategias de inversión a mediano plazo, análisis de tendencias a largo plazo',
        '• Usado para gestión de riesgos y determinar puntos de entrada-salida'
      ],
      fr: [
        '• Art de prédire la direction future des prix en utilisant les mouvements de prix passés et les données de volume',
        '• Principes de base: Le prix reflète tout, les mouvements de prix se répètent, l\'analyse des tendances est critique',
        '• Domaines d\'utilisation: Trading à court terme, stratégies d\'investissement à moyen terme, analyse des tendances à long terme',
        '• Utilisé pour la gestion des risques et la détermination des points d\'entrée-sortie'
      ],
      ru: [
        '• Искусство прогнозирования будущего направления цены с использованием прошлых ценовых движений и данных объема',
        '• Основные принципы: Цена отражает все, ценовые движения повторяются, анализ тренда критичен',
        '• Области применения: Краткосрочная торговля, среднесрочные инвестиционные стратегии, долгосрочный анализ тренда',
        '• Используется для управления рисками и определения точек входа-выхода'
      ]
    },
    example: { 
      tr: '📈 BIST100 geçen ay %8 yükseldi, şimdi 10.000 seviyesinde direnç ile karşılaştı. Teknik analistler bu kalıbı okuyarak sonraki hamleyi tahmin etmeye çalışır.',
      en: '📈 BIST100 rose 8% last month, now facing resistance at 10,000 level. Technical analysts try to predict the next move by reading this pattern.',
      es: '📈 BIST100 subió 8% el mes pasado, ahora enfrentando resistencia en el nivel 10,000. Los analistas técnicos intentan predecir el próximo movimiento leyendo este patrón.',
      fr: '📈 BIST100 a augmenté de 8% le mois dernier, faisant maintenant face à une résistance au niveau 10,000. Les analystes techniques essaient de prédire le prochain mouvement en lisant ce modèle.',
      ru: '📈 BIST100 вырос на 8% в прошлом месяце, сейчас сталкивается с сопротивлением на уровне 10,000. Технические аналитики пытаются предсказать следующий ход, читая этот паттерн.'
    },
    icon: <LineChart className="w-16 h-16 text-purple-500" />
  },
  {
    title: { 
      tr: 'Temel İlkeler ve Dow Teorisi', 
      en: 'Basic Principles and Dow Theory', 
      es: 'Principios Básicos y Teoría de Dow', 
      fr: 'Principes de Base et Théorie de Dow', 
      ru: 'Основные принципы и теория Доу' 
    },
    content: { 
      tr: [
        '• Piyasa her şeyi indirir: Fiyatlar tüm bilgileri otomatik olarak yansıtır',
        '• Üç tür trend: Birincil (1 yıl+), İkincil (3 hafta-3 ay), Minor (3 hafta-)',
        '• Birincil trendlerin üç fazı: Akkümülasyon, Public Participation, Distribüsyon',
        '• Volume ile doğrulama: Trend yönünde yüksek hacim olmalı'
      ],
      en: [
        '• Market discounts everything: Prices automatically reflect all information',
        '• Three types of trends: Primary (1+ year), Secondary (3 weeks-3 months), Minor (3 weeks-)',
        '• Three phases of primary trends: Accumulation, Public Participation, Distribution',
        '• Volume confirmation: High volume should be in trend direction'
      ],
      es: [
        '• El mercado descuenta todo: Los precios reflejan automáticamente toda la información',
        '• Tres tipos de tendencias: Primaria (1+ año), Secundaria (3 semanas-3 meses), Menor (3 semanas-)',
        '• Tres fases de tendencias primarias: Acumulación, Participación Pública, Distribución',
        '• Confirmación de volumen: Alto volumen debe estar en dirección de tendencia'
      ],
      fr: [
        '• Le marché escompte tout: Les prix reflètent automatiquement toutes les informations',
        '• Trois types de tendances: Primaire (1+ an), Secondaire (3 semaines-3 mois), Mineur (3 semaines-)',
        '• Trois phases des tendances primaires: Accumulation, Participation Publique, Distribution',
        '• Confirmation du volume: Un volume élevé doit être dans la direction de la tendance'
      ],
      ru: [
        '• Рынок учитывает все: Цены автоматически отражают всю информацию',
        '• Три типа трендов: Первичный (1+ год), Вторичный (3 недели-3 месяца), Незначительный (3 недели-)',
        '• Три фазы первичных трендов: Накопление, Общественное участие, Распределение',
        '• Подтверждение объемом: Высокий объем должен быть в направлении тренда'
      ]
    },
    example: { 
      tr: '📊 2024-2025 Bitcoin rallisinde: Akkümülasyon fazı (sessiz alım), Public fazı (medya ilgisi arttı), Distribüsyon fazı (büyük yatırımcılar satış yaptı).',
      en: '📊 In 2024-2025 Bitcoin rally: Accumulation phase (quiet buying), Public phase (media interest increased), Distribution phase (big investors sold).',
      es: '📊 En el rally de Bitcoin 2024-2025: Fase de acumulación (compra silenciosa), Fase pública (aumentó interés mediático), Fase de distribución (grandes inversores vendieron).',
      fr: '📊 Dans le rallye Bitcoin 2024-2025: Phase d\'accumulation (achat silencieux), Phase publique (intérêt médiatique accru), Phase de distribution (les gros investisseurs ont vendu).',
      ru: '📊 В ралли Bitcoin 2024-2025: Фаза накопления (тихая покупка), Публичная фаза (медийный интерес вырос), Фаза распределения (крупные инвесторы продавали).'
    },
    icon: <TrendingUp className="w-16 h-16 text-blue-500" />
  },
  {
    title: { 
      tr: 'Grafik Analizi ve 3D Visualization', 
      en: 'Chart Analysis and 3D Visualization', 
      es: 'Análisis de Gráficos y Visualización 3D', 
      fr: 'Analyse Graphique et Visualisation 3D', 
      ru: 'Графический анализ и 3D визуализация' 
    },
    content: { 
      tr: [
        '• Modern teknik analiz: 3D visualization ile piyasa derinliği görselleştirme',
        '• Multi-dimensional data analysis: Fiyat, hacim, zaman ve volatilite eş zamanlı analizi',
        '• Candlestick patterns: Doji, hammer, engulfing formasyonlarının 3D perspektifle tanımlanması',
        '• Volume profile integration: Hacim profili analizi ile fiyat-hacim korelasyonlarının görselleştirilmesi',
        '• Market depth visualization: Order book dynamiklerinin real-time 3D analizi'
      ],
      en: [
        '• Modern technical analysis: Market depth visualization with 3D visualization',
        '• Multi-dimensional data analysis: Simultaneous analysis of price, volume, time and volatility',
        '• Candlestick patterns: Identification of doji, hammer, engulfing formations with 3D perspective',
        '• Volume profile integration: Visualization of price-volume correlations with volume profile analysis',
        '• Market depth visualization: Real-time 3D analysis of order book dynamics'
      ],
      es: [
        '• Análisis técnico moderno: Visualización de profundidad del mercado con visualización 3D',
        '• Análisis de datos multidimensional: Análisis simultáneo de precio, volumen, tiempo y volatilidad',
        '• Patrones de velas: Identificación de formaciones doji, martillo, envolvente con perspectiva 3D',
        '• Integración de perfil de volumen: Visualización de correlaciones precio-volumen con análisis de perfil de volumen',
        '• Visualización de profundidad de mercado: Análisis 3D en tiempo real de dinámicas del libro de órdenes'
      ],
      fr: [
        '• Analyse technique moderne: Visualisation de la profondeur du marché avec visualisation 3D',
        '• Analyse de données multidimensionnelle: Analyse simultanée du prix, volume, temps et volatilité',
        '• Modèles de chandeliers: Identification des formations doji, marteau, engloutissant avec perspective 3D',
        '• Intégration du profil de volume: Visualisation des corrélations prix-volume avec analyse de profil de volume',
        '• Visualisation de la profondeur du marché: Analyse 3D en temps réel des dynamiques du carnet d\'ordres'
      ],
      ru: [
        '• Современный технический анализ: Визуализация глубины рынка с 3D визуализацией',
        '• Многомерный анализ данных: Одновременный анализ цены, объема, времени и волатильности',
        '• Паттерны свечей: Идентификация формаций доджи, молот, поглощение с 3D перспективой',
        '• Интеграция профиля объема: Визуализация корреляций цена-объем с анализом профиля объема',
        '• Визуализация глубины рынка: Анализ динамики книги ордеров в реальном времени 3D'
      ]
    },
    example: { 
      tr: '📊 3D grafik analizinde fiyat hareketleri ve hacim dağılımı birlikte görselleştirilir. Bu, geleneksel 2D grafiklerde görülemeyen piyasa dinamiklerini ortaya çıkarır ve daha doğru tahminler yapılmasını sağlar.',
      en: '📊 In 3D chart analysis, price movements and volume distribution are visualized together. This reveals market dynamics that cannot be seen in traditional 2D charts and enables more accurate predictions.',
      es: '📊 En el análisis de gráficos 3D, los movimientos de precios y la distribución de volumen se visualizan juntos. Esto revela dinámicas del mercado que no se pueden ver en gráficos 2D tradicionales y permite predicciones más precisas.',
      fr: '📊 Dans l\'analyse graphique 3D, les mouvements de prix et la distribution de volume sont visualisés ensemble. Cela révèle des dynamiques de marché qui ne peuvent être vues dans les graphiques 2D traditionnels et permet des prédictions plus précises.',
      ru: '📊 В 3D-анализе графиков движения цен и распределение объемов визуализируются вместе. Это выявляет динамику рынка, которую нельзя увидеть на традиционных 2D-графиках, и обеспечивает более точные прогнозы.'
    },
    icon: <TrendingDown className="w-16 h-16 text-cyan-400" />,
    image: chartAnalysisImage
  }
]