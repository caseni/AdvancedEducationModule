import { Brain, Heart, Users, Shield, AlertTriangle, Target, BookOpen, Activity, Clock, Lightbulb, Focus, TrendingUp, Zap, Eye, Anchor, Filter, Calendar, Battery, HeartHandshake, Sparkles } from 'lucide-react'

export const tradingPsychologySlides = [
  {
    title: { 
      tr: 'İşlem Psikolojisi Nedir?', 
      en: 'What is Trading Psychology?', 
      es: '¿Qué es la Psicología del Trading?', 
      fr: 'Qu\'est-ce que la Psychologie du Trading?', 
      ru: 'Что такое психология трейдинга?' 
    },
    content: { 
      tr: [
        '• İşlem psikolojisi, yatırım yaparken duygularımızı ve düşünce hatalarımızı kontrol edebilme becerisidir.',
        '• Başarı sadece grafik okumakla değil, sakin kalabilmekle gelir.',
        '• Deneyimli yatırımcılar bilir ki, kazancın %80\'i psikolojiye, sadece %20\'si teknik bilgiye bağlıdır.'
      ],
      en: [
        '• Trading psychology is the ability to control our emotions and thinking errors while investing.',
        '• Success comes not just from reading charts, but from staying calm.',
        '• Experienced investors know that 80% of profits depend on psychology, only 20% on technical knowledge.'
      ],
      es: [
        '• La psicología del trading es la habilidad de controlar nuestras emociones y errores de pensamiento al invertir.',
        '• El éxito no viene solo de leer gráficos, sino de mantener la calma.',
        '• Los inversores experimentados saben que el 80% de las ganancias depende de la psicología, solo el 20% del conocimiento técnico.'
      ],
      fr: [
        '• La psychologie du trading est la capacité de contrôler nos émotions et erreurs de pensée lors d\'investissements.',
        '• Le succès ne vient pas seulement de la lecture de graphiques, mais de rester calme.',
        '• Les investisseurs expérimentés savent que 80% des profits dépendent de la psychologie, seulement 20% des connaissances techniques.'
      ],
      ru: [
        '• Психология трейдинга - это способность контролировать наши эмоции и ошибки мышления при инвестировании.',
        '• Успех приходит не только от чтения графиков, но от сохранения спокойствия.',
        '• Опытные инвесторы знают, что 80% прибыли зависит от психологии, только 20% от технических знаний.'
      ]
    },
    example: { 
      tr: '🧠 2025\'te büyük düşüşte panik yapan yatırımcılar %30 zarar etti, sakin kalanlar fırsata çevirdi.',
      en: '🧠 In 2025 major decline, panicked investors lost 30%, those who stayed calm turned it into opportunity.',
      es: '🧠 En la gran caída de 2025, inversores en pánico perdieron 30%, quienes mantuvieron calma la convirtieron en oportunidad.',
      fr: '🧠 Dans la grande chute de 2025, investisseurs paniqués ont perdu 30%, ceux restés calmes l\'ont transformée en opportunité.',
      ru: '🧠 Во время большого падения 2025 года запаниковавшие инвесторы потеряли 30%, те кто сохранили спокойствие превратили это в возможность.'
    },
    icon: <Brain className="w-16 h-16 text-purple-500" />
  },
  {
    title: { 
      tr: 'Duyguların Yatırım Üzerindeki Etkisi', 
      en: 'Effects of Emotions on Investment', 
      es: 'Efectos de las Emociones en la Inversión', 
      fr: 'Effets des Émotions sur l\'Investissement', 
      ru: 'Влияние эмоций на инвестиции' 
    },
    content: { 
      tr: [
        '• Korku: Piyasa düşünce aceleyle satış yapmaya iter.',
        '• Açgözlülük: Aşırı risk almaya, balon fiyatlardan almaya sebep olur.',
        '• Kontrol: Duyguları tanıyıp işlem günlüğü tutmak, soğukkanlı kalmayı kolaylaştırır.',
        '• Sakin kalan yatırımcı, uzun vadede kazanan tarafta olur.'
      ],
      en: [
        '• Fear: Pushes to make hasty sales when market declines.',
        '• Greed: Causes taking excessive risks, buying at bubble prices.',
        '• Control: Recognizing emotions and keeping trading journal makes staying calm easier.',
        '• Investor who stays calm wins in the long term.'
      ],
      es: [
        '• Miedo: Empuja a hacer ventas apresuradas cuando el mercado declina.',
        '• Avaricia: Causa tomar riesgos excesivos, comprar a precios de burbuja.',
        '• Control: Reconocer emociones y llevar diario de trading facilita mantener la calma.',
        '• Inversor que mantiene calma gana a largo plazo.'
      ],
      fr: [
        '• Peur: Pousse à faire des ventes précipitées quand le marché décline.',
        '• Avidité: Cause prise de risques excessifs, achat à prix de bulle.',
        '• Contrôle: Reconnaître émotions et tenir journal de trading facilite garder calme.',
        '• Investisseur qui reste calme gagne à long terme.'
      ],
      ru: [
        '• Страх: Толкает к поспешным продажам при падении рынка.',
        '• Жадность: Вызывает принятие чрезмерных рисков, покупку по пузырьковым ценам.',
        '• Контроль: Распознавание эмоций и ведение торгового дневника облегчает сохранение спокойствия.',
        '• Инвестор, который остается спокойным, выигрывает в долгосрочной перспективе.'
      ]
    },
    example: { 
      tr: '❤️ Bitcoin rallisinde açgözlülük zirvede alım yaptırdı, düşüşte %40 kayıp oldu.',
      en: '❤️ Greed during Bitcoin rally caused buying at peak, 40% loss occurred during decline.',
      es: '❤️ Avaricia durante rally de Bitcoin causó compra en pico, ocurrió 40% de pérdida durante caída.',
      fr: '❤️ Avidité pendant rally Bitcoin a causé achat au pic, 40% de perte est survenue pendant chute.',
      ru: '❤️ Жадность во время ралли Bitcoin привела к покупке на пике, во время падения произошли 40% потери.'
    },
    icon: <Heart className="w-16 h-16 text-red-500" />
  },
  {
    title: { 
      tr: 'Sık Görülen Davranış Hataları', 
      en: 'Common Behavioral Mistakes', 
      es: 'Errores de Comportamiento Comunes', 
      fr: 'Erreurs de Comportement Communes', 
      ru: 'Распространенные поведенческие ошибки' 
    },
    content: { 
      tr: [
        '• Aşırı güven: "Ben yanılmam" diyerek fazla risk almak.',
        '• Sürü psikolojisi: Herkes alıyorsa almak, herkes satıyorsa satmak.',
        '• Kayıptan kaçma: Zarar eden yatırımı satamamak, daha büyük kayıplara yol açar.',
        '• Bu tuzakların farkında olmak, kayıpları azaltır.'
      ],
      en: [
        '• Overconfidence: Taking too much risk saying "I can\'t be wrong".',
        '• Herd mentality: Buying if everyone buys, selling if everyone sells.',
        '• Loss aversion: Unable to sell losing investment, leads to bigger losses.',
        '• Being aware of these traps reduces losses.'
      ],
      es: [
        '• Exceso de confianza: Tomar demasiado riesgo diciendo "No puedo estar equivocado".',
        '• Mentalidad de rebaño: Comprar si todos compran, vender si todos venden.',
        '• Aversión a pérdidas: Incapaz de vender inversión perdedora, lleva a pérdidas mayores.',
        '• Estar consciente de estas trampas reduce pérdidas.'
      ],
      fr: [
        '• Excès de confiance: Prendre trop de risque en disant "Je ne peux pas me tromper".',
        '• Mentalité de troupeau: Acheter si tout le monde achète, vendre si tout le monde vend.',
        '• Aversion aux pertes: Incapable de vendre investissement perdant, mène à plus grandes pertes.',
        '• Être conscient de ces pièges réduit les pertes.'
      ],
      ru: [
        '• Самоуверенность: Принятие слишком большого риска, говоря "Я не могу ошибаться".',
        '• Стадное мышление: Покупать если все покупают, продавать если все продают.',
        '• Неприятие потерь: Неспособность продать убыточную инвестицию, ведет к большим потерям.',
        '• Осознание этих ловушек снижает потери.'
      ]
    },
    example: { 
      tr: '🐑 Meme coin çılgınlığında sürü psikolojisi ile alanlar %60 kaybetti.',
      en: '🐑 Those who bought with herd mentality during meme coin craze lost 60%.',
      es: '🐑 Quienes compraron con mentalidad de rebaño durante locura de meme coins perdieron 60%.',
      fr: '🐑 Ceux qui ont acheté avec mentalité de troupeau pendant folie meme coin ont perdu 60%.',
      ru: '🐑 Те, кто покупал со стадным мышлением во время безумия мем-монет, потеряли 60%.'
    },
    icon: <Users className="w-16 h-16 text-blue-500" />
  },
  {
    title: { 
      tr: 'Kayıptan Kaçma', 
      en: 'Loss Aversion', 
      es: 'Aversión a Pérdidas', 
      fr: 'Aversion aux Pertes', 
      ru: 'Неприятие потерь' 
    },
    content: { 
      tr: [
        '• Kayıplar bize, aynı büyüklükteki kazançlardan daha ağır gelir.',
        '• Bu yüzden yatırımcılar çoğu zaman zarardaki hisselerini satmaz, ama kârlı olanı erkenden satar.',
        '• Çözüm: Önceden zarar-kâr limitleri koyup plana sadık kalmak.'
      ],
      en: [
        '• Losses feel heavier to us than gains of the same size.',
        '• Therefore investors often don\'t sell their losing stocks, but sell profitable ones early.',
        '• Solution: Set loss-profit limits beforehand and stick to the plan.'
      ],
      es: [
        '• Las pérdidas nos pesan más que las ganancias del mismo tamaño.',
        '• Por eso los inversores a menudo no venden sus acciones perdedoras, pero venden las rentables temprano.',
        '• Solución: Establecer límites de pérdida-ganancia de antemano y adherirse al plan.'
      ],
      fr: [
        '• Les pertes nous pèsent plus que les gains de même taille.',
        '• C\'est pourquoi les investisseurs ne vendent souvent pas leurs actions perdantes, mais vendent les rentables tôt.',
        '• Solution: Établir limites perte-profit à l\'avance et s\'en tenir au plan.'
      ],
      ru: [
        '• Потери ощущаются тяжелее, чем прибыли того же размера.',
        '• Поэтому инвесторы часто не продают свои убыточные акции, но продают прибыльные рано.',
        '• Решение: Заранее установить лимиты убытков-прибыли и придерживаться плана.'
      ]
    },
    example: { 
      tr: '⚖️ Zarar eden hisseyi "toparlanır" diye tutanlar daha büyük kayıp yaşadı.',
      en: '⚖️ Those who held losing stock saying "it will recover" experienced bigger losses.',
      es: '⚖️ Quienes mantuvieron acción perdedora diciendo "se recuperará" experimentaron pérdidas mayores.',
      fr: '⚖️ Ceux qui ont gardé action perdante en disant "elle se remettra" ont subi pertes plus importantes.',
      ru: '⚖️ Те, кто держал убыточную акцию, говоря "она восстановится", понесли большие потери.'
    },
    icon: <Shield className="w-16 h-16 text-orange-500" />
  },
  {
    title: { 
      tr: 'Aşırı Güvenin Bedeli', 
      en: 'The Cost of Overconfidence', 
      es: 'El Costo del Exceso de Confianza', 
      fr: 'Le Coût de l\'Excès de Confiance', 
      ru: 'Цена самоуверенности' 
    },
    content: { 
      tr: [
        '• "Ben biliyorum" hissi, yatırımcıyı en çok yanıltan duygudur.',
        '• Tek bir habere bakarak işlem yapmak, tüm parayı tek hisseye yatırmak tehlikelidir.',
        '• Çözüm: Verilere güvenmek, farklı görüşleri dinlemek, alçakgönüllü kalmak.'
      ],
      en: [
        '• "I know" feeling is the emotion that misleads investors the most.',
        '• Trading based on single news, investing all money in one stock is dangerous.',
        '• Solution: Trust data, listen to different opinions, stay humble.'
      ],
      es: [
        '• El sentimiento "yo sé" es la emoción que más engaña a los inversores.',
        '• Operar basado en una sola noticia, invertir todo el dinero en una acción es peligroso.',
        '• Solución: Confiar en datos, escuchar diferentes opiniones, mantenerse humilde.'
      ],
      fr: [
        '• Le sentiment "je sais" est l\'émotion qui trompe le plus les investisseurs.',
        '• Trader basé sur une seule nouvelle, investir tout l\'argent dans une action est dangereux.',
        '• Solution: Faire confiance aux données, écouter différentes opinions, rester humble.'
      ],
      ru: [
        '• Чувство "я знаю" - это эмоция, которая больше всего обманывает инвесторов.',
        '• Торговать на основе одной новости, инвестировать все деньги в одну акцию опасно.',
        '• Решение: Доверять данным, слушать разные мнения, оставаться скромным.'
      ]
    },
    example: { 
      tr: '🎯 "AI kesin yükselir" deyip tek sektöre yatırım yapanlar %35 zarar etti.',
      en: '🎯 Those who invested in single sector saying "AI will definitely rise" lost 35%.',
      es: '🎯 Quienes invirtieron en un sector diciendo "IA definitivamente subirá" perdieron 35%.',
      fr: '🎯 Ceux qui ont investi dans un seul secteur en disant "IA va certainement monter" ont perdu 35%.',
      ru: '🎯 Те, кто инвестировал в один сектор, говоря "ИИ точно вырастет", потеряли 35%.'
    },
    icon: <Target className="w-16 h-16 text-green-500" />
  },
  {
    title: { 
      tr: 'Sürü Psikolojisi ve FOMO', 
      en: 'Herd Psychology and FOMO', 
      es: 'Psicología de Rebaño y FOMO', 
      fr: 'Psychologie de Troupeau et FOMO', 
      ru: 'Стадная психология и FOMO' 
    },
    content: { 
      tr: [
        '• Kalabalığı takip etmek ya da fırsatı kaçırma korkusu (FOMO), pahalıdan almaya sebep olur.',
        '• Çözüm: Kendi stratejinize sadık kalmak, piyasa gürültüsünü filtrelemek.'
      ],
      en: [
        '• Following the crowd or fear of missing out (FOMO) causes buying expensive.',
        '• Solution: Stay loyal to your strategy, filter market noise.'
      ],
      es: [
        '• Seguir la multitud o miedo a perderse (FOMO) causa comprar caro.',
        '• Solución: Mantenerse leal a tu estrategia, filtrar ruido del mercado.'
      ],
      fr: [
        '• Suivre la foule ou peur de rater (FOMO) cause acheter cher.',
        '• Solution: Rester fidèle à votre stratégie, filtrer bruit du marché.'
      ],
      ru: [
        '• Следование за толпой или страх упустить (FOMO) приводит к дорогим покупкам.',
        '• Решение: Оставаться верным своей стратегии, фильтровать рыночный шум.'
      ]
    },
    example: { 
      tr: '😱 NFT çılgınlığında FOMO ile alanlar %80 değer kaybı yaşadı.',
      en: '😱 Those who bought with FOMO during NFT craze experienced 80% value loss.',
      es: '😱 Quienes compraron con FOMO durante locura NFT experimentaron 80% de pérdida de valor.',
      fr: '😱 Ceux qui ont acheté avec FOMO pendant folie NFT ont subi 80% de perte de valeur.',
      ru: '😱 Те, кто покупал с FOMO во время безумия NFT, понесли 80% потерь стоимости.'
    },
    icon: <AlertTriangle className="w-16 h-16 text-yellow-500" />
  },
  {
    title: { 
      tr: 'Çapalama (İlk Bilgiye Takılma)', 
      en: 'Anchoring (Getting Stuck on First Information)', 
      es: 'Anclaje (Quedarse Atascado en Primera Información)', 
      fr: 'Ancrage (Rester Bloqué sur Première Information)', 
      ru: 'Привязка (застревание на первой информации)' 
    },
    content: { 
      tr: [
        '• Bir hisseyi geçmiş fiyatına bakarak "ucuz" sanmak yaygın bir hatadır.',
        '• Çözüm: Güncel verilere bakmak, şirketin gerçek değerini değerlendirmek.'
      ],
      en: [
        '• Thinking a stock is "cheap" by looking at its past price is a common mistake.',
        '• Solution: Look at current data, evaluate company\'s real value.'
      ],
      es: [
        '• Pensar que una acción es "barata" mirando su precio pasado es un error común.',
        '• Solución: Mirar datos actuales, evaluar valor real de la empresa.'
      ],
      fr: [
        '• Penser qu\'une action est "bon marché" en regardant son prix passé est une erreur courante.',
        '• Solution: Regarder données actuelles, évaluer valeur réelle de l\'entreprise.'
      ],
      ru: [
        '• Думать, что акция "дешевая", глядя на её прошлую цену - распространенная ошибка.',
        '• Решение: Смотреть на текущие данные, оценивать реальную стоимость компании.'
      ]
    },
    example: { 
      tr: '⚓ "100 TL\'den 50 TL\'ye düştü, ucuz" diye alan, 20 TL\'ye kadar gördü.',
      en: '⚓ Those who bought saying "dropped from 100 TL to 50 TL, cheap" saw it go to 20 TL.',
      es: '⚓ Quienes compraron diciendo "cayó de 100 TL a 50 TL, barato" lo vieron llegar a 20 TL.',
      fr: '⚓ Ceux qui ont acheté en disant "tombé de 100 TL à 50 TL, bon marché" l\'ont vu aller à 20 TL.',
      ru: '⚓ Те, кто покупал, говоря "упало со 100 лир до 50 лир, дешево", увидели падение до 20 лир.'
    },
    icon: <Anchor className="w-16 h-16 text-cyan-500" />
  },
  {
    title: { 
      tr: 'Onay Arama (Sadece İstediğini Görme)', 
      en: 'Confirmation Bias (Only Seeing What You Want)', 
      es: 'Sesgo de Confirmación (Solo Ver Lo Que Quieres)', 
      fr: 'Biais de Confirmation (Voir Seulement Ce Que Vous Voulez)', 
      ru: 'Предвзятость подтверждения (видеть только то, что хочешь)' 
    },
    content: { 
      tr: [
        '• İnsanlar genellikle kendi fikrine uygun haberleri dinler, tersini görmezden gelir.',
        '• Çözüm: Karşıt görüşlere de bakmak, farklı kaynaklardan bilgi almak.'
      ],
      en: [
        '• People usually listen to news that fits their opinion, ignore the opposite.',
        '• Solution: Look at opposing views too, get information from different sources.'
      ],
      es: [
        '• La gente usualmente escucha noticias que encajan con su opinión, ignora lo opuesto.',
        '• Solución: Mirar también puntos de vista opuestos, obtener información de fuentes diferentes.'
      ],
      fr: [
        '• Les gens écoutent habituellement nouvelles qui correspondent à leur opinion, ignorent l\'opposé.',
        '• Solution: Regarder aussi points de vue opposés, obtenir information de sources différentes.'
      ],
      ru: [
        '• Люди обычно слушают новости, которые соответствуют их мнению, игнорируют противоположное.',
        '• Решение: Смотреть также на противоположные точки зрения, получать информацию из разных источников.'
      ]
    },
    example: { 
      tr: '🔍 Sadece olumlu kripto haberlerini okuyup, olumsuzları görmezden gelenler zarar etti.',
      en: '🔍 Those who only read positive crypto news and ignored negative ones lost money.',
      es: '🔍 Quienes solo leyeron noticias cripto positivas e ignoraron las negativas perdieron dinero.',
      fr: '🔍 Ceux qui ont seulement lu nouvelles crypto positives et ignoré négatives ont perdu argent.',
      ru: '🔍 Те, кто читал только положительные крипто-новости и игнорировал отрицательные, потеряли деньги.'
    },
    icon: <Filter className="w-16 h-16 text-indigo-500" />
  },
  {
    title: { 
      tr: 'Disiplinli Kalmak', 
      en: 'Staying Disciplined', 
      es: 'Mantenerse Disciplinado', 
      fr: 'Rester Discipliné', 
      ru: 'Оставаться дисциплинированным' 
    },
    content: { 
      tr: [
        '• Başarının sırrı, plana sadık kalmaktır.',
        '• İşlem günlüğü tutun.',
        '• Hedef ve limit belirleyin.',
        '• Rutinler oluşturun.',
        '• Disiplin, duygulara teslim olmayı engeller.'
      ],
      en: [
        '• The secret of success is staying loyal to the plan.',
        '• Keep a trading journal.',
        '• Set targets and limits.',
        '• Create routines.',
        '• Discipline prevents surrendering to emotions.'
      ],
      es: [
        '• El secreto del éxito es mantenerse leal al plan.',
        '• Llevar un diario de trading.',
        '• Establecer objetivos y límites.',
        '• Crear rutinas.',
        '• La disciplina previene rendirse a las emociones.'
      ],
      fr: [
        '• Le secret du succès est rester fidèle au plan.',
        '• Tenir un journal de trading.',
        '• Établir objectifs et limites.',
        '• Créer routines.',
        '• La discipline empêche de se rendre aux émotions.'
      ],
      ru: [
        '• Секрет успеха - оставаться верным плану.',
        '• Ведите торговый дневник.',
        '• Устанавливайте цели и лимиты.',
        '• Создавайте рутины.',
        '• Дисциплина предотвращает капитуляцию перед эмоциями.'
      ]
    },
    example: { 
      tr: '📖 Disiplinli yatırımcılar her gün aynı saatte analiz yapar, duygusal karar vermez.',
      en: '📖 Disciplined investors analyze at the same time every day, don\'t make emotional decisions.',
      es: '📖 Inversores disciplinados analizan a la misma hora cada día, no toman decisiones emocionales.',
      fr: '📖 Investisseurs disciplinés analysent à la même heure chaque jour, ne prennent pas décisions émotionnelles.',
      ru: '📖 Дисциплинированные инвесторы анализируют в одно и то же время каждый день, не принимают эмоциональных решений.'
    },
    icon: <BookOpen className="w-16 h-16 text-green-600" />
  },
  {
    title: { 
      tr: 'Strateji ve Psikoloji', 
      en: 'Strategy and Psychology', 
      es: 'Estrategia y Psicología', 
      fr: 'Stratégie et Psychologie', 
      ru: 'Стратегия и психология' 
    },
    content: { 
      tr: [
        '• Net bir strateji (zarar durdurma, kâr alma hedefi) duyguları kontrol eder.',
        '• Panik satışlarını önler, sabırlı kalmanızı sağlar.'
      ],
      en: [
        '• Clear strategy (stop loss, profit target) controls emotions.',
        '• Prevents panic selling, helps you stay patient.'
      ],
      es: [
        '• Estrategia clara (stop loss, objetivo de ganancia) controla emociones.',
        '• Previene venta de pánico, te ayuda a mantenerte paciente.'
      ],
      fr: [
        '• Stratégie claire (stop loss, objectif de profit) contrôle émotions.',
        '• Prévient vente de panique, vous aide à rester patient.'
      ],
      ru: [
        '• Четкая стратегия (стоп-лосс, цель прибыли) контролирует эмоции.',
        '• Предотвращает панические продажи, помогает оставаться терпеливым.'
      ]
    },
    example: { 
      tr: '📋 "%10 zarar edersem sat, %20 kâr edersem sat" kuralı ile duyguları devre dışı bırakın.',
      en: '📋 With rule "sell if 10% loss, sell if 20% profit" disable emotions.',
      es: '📋 Con regla "vender si 10% pérdida, vender si 20% ganancia" desactivar emociones.',
      fr: '📋 Avec règle "vendre si 10% perte, vendre si 20% profit" désactiver émotions.',
      ru: '📋 С правилом "продать при 10% убытке, продать при 20% прибыли" отключить эмоции.'
    },
    icon: <Activity className="w-16 h-16 text-blue-600" />
  },
  {
    title: { 
      tr: 'Stop-Loss Kullanımı', 
      en: 'Using Stop-Loss', 
      es: 'Uso de Stop-Loss', 
      fr: 'Utilisation du Stop-Loss', 
      ru: 'Использование стоп-лосса' 
    },
    content: { 
      tr: [
        '• Stop-loss, "şu fiyata inerse otomatik sat" kuralıdır.',
        '• Kayıpları sınırlar, duygusal kararları engeller.',
        '• Risk yönetimi için en temel araçtır.'
      ],
      en: [
        '• Stop-loss is "automatically sell if it drops to this price" rule.',
        '• Limits losses, prevents emotional decisions.',
        '• Most basic tool for risk management.'
      ],
      es: [
        '• Stop-loss es regla "vender automáticamente si baja a este precio".',
        '• Limita pérdidas, previene decisiones emocionales.',
        '• Herramienta más básica para gestión de riesgo.'
      ],
      fr: [
        '• Stop-loss est règle "vendre automatiquement si ça baisse à ce prix".',
        '• Limite pertes, prévient décisions émotionnelles.',
        '• Outil le plus basique pour gestion de risque.'
      ],
      ru: [
        '• Стоп-лосс - это правило "автоматически продать, если упадет до этой цены".',
        '• Ограничивает потери, предотвращает эмоциональные решения.',
        '• Самый базовый инструмент для управления рисками.'
      ]
    },
    example: { 
      tr: '🛑 100 TL\'den aldığınız hisseye 90 TL stop-loss koyarak maksimum %10 zarar garantilersiniz.',
      en: '🛑 By putting 90 TL stop-loss on stock bought at 100 TL, you guarantee maximum 10% loss.',
      es: '🛑 Poniendo stop-loss de 90 TL en acción comprada a 100 TL, garantizas máximo 10% de pérdida.',
      fr: '🛑 En mettant stop-loss de 90 TL sur action achetée à 100 TL, vous garantissez maximum 10% de perte.',
      ru: '🛑 Поставив стоп-лосс 90 лир на акцию, купленную за 100 лир, вы гарантируете максимум 10% потерь.'
    },
    icon: <Shield className="w-16 h-16 text-red-600" />
  },
  {
    title: { 
      tr: 'İşlem Günlüğü Tutmak', 
      en: 'Keeping a Trading Journal', 
      es: 'Llevar un Diario de Trading', 
      fr: 'Tenir un Journal de Trading', 
      ru: 'Ведение торгового дневника' 
    },
    content: { 
      tr: [
        '• Her işlemin nedenini ve sonucunu yazmak, hataları görmeyi sağlar.',
        '• Geçmişteki duygusal kararlar böylece daha kolay fark edilir.'
      ],
      en: [
        '• Writing reason and result of each trade helps see mistakes.',
        '• Past emotional decisions are thus more easily noticed.'
      ],
      es: [
        '• Escribir razón y resultado de cada operación ayuda a ver errores.',
        '• Decisiones emocionales pasadas son así más fácilmente notadas.'
      ],
      fr: [
        '• Écrire raison et résultat de chaque trade aide à voir erreurs.',
        '• Décisions émotionnelles passées sont ainsi plus facilement remarquées.'
      ],
      ru: [
        '• Записывание причины и результата каждой сделки помогает увидеть ошибки.',
        '• Прошлые эмоциональные решения таким образом легче замечаются.'
      ]
    },
    example: { 
      tr: '📝 "FOMO ile aldım, %15 zarar ettim" yazan yatırımcı aynı hatayı tekrarlamaz.',
      en: '📝 Investor who writes "bought with FOMO, lost 15%" won\'t repeat same mistake.',
      es: '📝 Inversor que escribe "compré con FOMO, perdí 15%" no repetirá mismo error.',
      fr: '📝 Investisseur qui écrit "acheté avec FOMO, perdu 15%" ne répétera pas même erreur.',
      ru: '📝 Инвестор, который пишет "купил с FOMO, потерял 15%", не повторит ту же ошибку.'
    },
    icon: <BookOpen className="w-16 h-16 text-purple-600" />
  },
  {
    title: { 
      tr: 'Stres Yönetimi', 
      en: 'Stress Management', 
      es: 'Gestión del Estrés', 
      fr: 'Gestion du Stress', 
      ru: 'Управление стрессом' 
    },
    content: { 
      tr: [
        '• Stresli bir zihin hataya açıktır.',
        '• Nefes egzersizleri yapın.',
        '• Gerektiğinde mola verin.',
        '• Stresliyken işlem yapmayın.',
        '• Sakin zihin, net karar verir.'
      ],
      en: [
        '• Stressed mind is prone to errors.',
        '• Do breathing exercises.',
        '• Take breaks when necessary.',
        '• Don\'t trade when stressed.',
        '• Calm mind makes clear decisions.'
      ],
      es: [
        '• Mente estresada es propensa a errores.',
        '• Hacer ejercicios de respiración.',
        '• Tomar descansos cuando sea necesario.',
        '• No operar cuando estresado.',
        '• Mente calmada toma decisiones claras.'
      ],
      fr: [
        '• Esprit stressé est sujet aux erreurs.',
        '• Faire exercices de respiration.',
        '• Prendre pauses quand nécessaire.',
        '• Ne pas trader quand stressé.',
        '• Esprit calme prend décisions claires.'
      ],
      ru: [
        '• Напряженный ум склонен к ошибкам.',
        '• Делайте дыхательные упражнения.',
        '• Делайте перерывы при необходимости.',
        '• Не торгуйте в стрессе.',
        '• Спокойный ум принимает четкие решения.'
      ]
    },
    example: { 
      tr: '🧘 Büyük kayıp sonrası 1 hafta ara veren yatırımcı, daha iyi kararlar almaya başladı.',
      en: '🧘 Investor who took 1 week break after big loss started making better decisions.',
      es: '🧘 Inversor que tomó 1 semana de descanso después de gran pérdida empezó a tomar mejores decisiones.',
      fr: '🧘 Investisseur qui a pris 1 semaine de pause après grande perte a commencé à prendre meilleures décisions.',
      ru: '🧘 Инвестор, который взял недельный перерыв после большой потери, начал принимать лучшие решения.'
    },
    icon: <Focus className="w-16 h-16 text-green-500" />
  },
  {
    title: { 
      tr: 'Uzun Vadeli vs Kısa Vadeli Yatırım', 
      en: 'Long-term vs Short-term Investment', 
      es: 'Inversión a Largo vs Corto Plazo', 
      fr: 'Investissement Long vs Court Terme', 
      ru: 'Долгосрочные против краткосрочных инвестиций' 
    },
    content: { 
      tr: [
        '• Uzun vadeli: Daha az stresli, sabır ister.',
        '• Kısa vadeli: Daha heyecanlı, ama daha riskli.',
        '• Seçim kişisel risk toleransına göre yapılmalı.'
      ],
      en: [
        '• Long-term: Less stressful, requires patience.',
        '• Short-term: More exciting, but riskier.',
        '• Choice should be made according to personal risk tolerance.'
      ],
      es: [
        '• Largo plazo: Menos estresante, requiere paciencia.',
        '• Corto plazo: Más emocionante, pero más riesgoso.',
        '• Elección debe hacerse según tolerancia personal al riesgo.'
      ],
      fr: [
        '• Long terme: Moins stressant, nécessite patience.',
        '• Court terme: Plus excitant, mais plus risqué.',
        '• Choix doit être fait selon tolérance personnelle au risque.'
      ],
      ru: [
        '• Долгосрочно: Менее стрессово, требует терпения.',
        '• Краткосрочно: Более захватывающе, но рискованнее.',
        '• Выбор должен делаться согласно личной толерантности к риску.'
      ]
    },
    example: { 
      tr: '📅 10 yıl Apple hissesi tutanlar %500 kazandı, günlük alım-satım yapanlar çoğu zaman zarar etti.',
      en: '📅 Those who held Apple stock for 10 years gained 500%, daily traders mostly lost.',
      es: '📅 Quienes mantuvieron acciones de Apple por 10 años ganaron 500%, traders diarios mayormente perdieron.',
      fr: '📅 Ceux qui ont gardé actions Apple pendant 10 ans ont gagné 500%, traders quotidiens ont surtout perdu.',
      ru: '📅 Те, кто держал акции Apple 10 лет, получили 500%, дневные трейдеры в основном потеряли.'
    },
    icon: <Clock className="w-16 h-16 text-blue-500" />
  },
  {
    title: { 
      tr: 'Risk Toleransı', 
      en: 'Risk Tolerance', 
      es: 'Tolerancia al Riesgo', 
      fr: 'Tolérance au Risque', 
      ru: 'Толерантность к риску' 
    },
    content: { 
      tr: [
        '• Herkesin dayanabileceği zarar farklıdır.',
        '• Bazı yatırımcı %10 kayba dayanamazken, bazıları sakin kalabilir.',
        '• Kendi risk seviyenizi bilmek, doğru stratejiyi seçmenizi sağlar.'
      ],
      en: [
        '• Everyone\'s tolerable loss is different.',
        '• Some investors can\'t stand 10% loss, others can stay calm.',
        '• Knowing your risk level helps choose right strategy.'
      ],
      es: [
        '• La pérdida tolerable de cada uno es diferente.',
        '• Algunos inversores no pueden soportar 10% de pérdida, otros pueden mantener calma.',
        '• Conocer tu nivel de riesgo ayuda a elegir estrategia correcta.'
      ],
      fr: [
        '• La perte tolérable de chacun est différente.',
        '• Certains investisseurs ne peuvent supporter 10% de perte, d\'autres peuvent rester calmes.',
        '• Connaître votre niveau de risque aide à choisir bonne stratégie.'
      ],
      ru: [
        '• Переносимые потери у каждого разные.',
        '• Некоторые инвесторы не могут вынести 10% потерь, другие могут оставаться спокойными.',
        '• Знание своего уровня риска помогает выбрать правильную стратегию.'
      ]
    },
    example: { 
      tr: '⚡ Genç yatırımcı %20 kayba dayanabilirken, emekliye yakın kişi %5 bile zor.',
      en: '⚡ Young investor can tolerate 20% loss, person near retirement finds even 5% difficult.',
      es: '⚡ Inversor joven puede tolerar 20% de pérdida, persona cerca de jubilación encuentra incluso 5% difícil.',
      fr: '⚡ Jeune investisseur peut tolérer 20% de perte, personne proche retraite trouve même 5% difficile.',
      ru: '⚡ Молодой инвестор может переносить 20% потерь, человек близкий к пенсии находит даже 5% трудными.'
    },
    icon: <Battery className="w-16 h-16 text-yellow-600" />
  },
  {
    title: { 
      tr: 'Duygusal Tuzaklardan Kaçınmak', 
      en: 'Avoiding Emotional Traps', 
      es: 'Evitar Trampas Emocionales', 
      fr: 'Éviter les Pièges Émotionnels', 
      ru: 'Избегание эмоциональных ловушек' 
    },
    content: { 
      tr: [
        '• İntikam işlemi: Zarar sonrası aceleyle yeniden işlem yapmak.',
        '• Aşırı işlem: Gereksiz yere sürekli al-sat yapmak.',
        '• Çözüm: İşlem limitleri belirlemek, kontrol listesi kullanmak.'
      ],
      en: [
        '• Revenge trading: Hastily making new trades after loss.',
        '• Overtrading: Constantly buying-selling unnecessarily.',
        '• Solution: Set trading limits, use checklist.'
      ],
      es: [
        '• Trading de venganza: Hacer nuevas operaciones apresuradamente después de pérdida.',
        '• Sobreoperación: Constantemente comprar-vender innecesariamente.',
        '• Solución: Establecer límites de trading, usar lista de verificación.'
      ],
      fr: [
        '• Trading de vengeance: Faire nouvelles opérations précipitamment après perte.',
        '• Sur-trading: Constamment acheter-vendre inutilement.',
        '• Solution: Établir limites de trading, utiliser checklist.'
      ],
      ru: [
        '• Мстительная торговля: Поспешное совершение новых сделок после потери.',
        '• Чрезмерная торговля: Постоянная ненужная купля-продажа.',
        '• Решение: Установить торговые лимиты, использовать чек-лист.'
      ]
    },
    example: { 
      tr: '🎯 Günde maksimum 3 işlem kuralı koyan trader, aşırı işlemden kurtuldu.',
      en: '🎯 Trader who set maximum 3 trades per day rule got rid of overtrading.',
      es: '🎯 Trader que estableció regla de máximo 3 operaciones por día se libró del sobretrading.',
      fr: '🎯 Trader qui a établi règle de maximum 3 opérations par jour s\'est débarrassé du sur-trading.',
      ru: '🎯 Трейдер, который установил правило максимум 3 сделки в день, избавился от чрезмерной торговли.'
    },
    icon: <Target className="w-16 h-16 text-red-500" />
  },
  {
    title: { 
      tr: 'Psikolojik Dayanıklılık', 
      en: 'Psychological Resilience', 
      es: 'Resistencia Psicológica', 
      fr: 'Résilience Psychologique', 
      ru: 'Психологическая устойчивость' 
    },
    content: { 
      tr: [
        '• Büyük düşüşlerde panik yapmamak, uzun vadede fark yaratır.',
        '• Geçmiş hatalardan öğrenmek, küçük başarıları kutlamak, dayanıklılığı artırır.'
      ],
      en: [
        '• Not panicking during big declines makes difference in long term.',
        '• Learning from past mistakes, celebrating small successes increases resilience.'
      ],
      es: [
        '• No entrar en pánico durante grandes caídas hace diferencia a largo plazo.',
        '• Aprender de errores pasados, celebrar pequeños éxitos aumenta resistencia.'
      ],
      fr: [
        '• Ne pas paniquer pendant grandes chutes fait différence à long terme.',
        '• Apprendre des erreurs passées, célébrer petits succès augmente résilience.'
      ],
      ru: [
        '• Неспособность паниковать во время больших падений имеет значение в долгосрочной перспективе.',
        '• Изучение прошлых ошибок, празднование небольших успехов повышает устойчивость.'
      ]
    },
    example: { 
      tr: '💪 2020 pandemi krizinde sakin kalan yatırımcılar 2021\'de büyük kazanç sağladı.',
      en: '💪 Investors who stayed calm during 2020 pandemic crisis made big gains in 2021.',
      es: '💪 Inversores que mantuvieron calma durante crisis pandémica 2020 obtuvieron grandes ganancias en 2021.',
      fr: '💪 Investisseurs qui sont restés calmes pendant crise pandémique 2020 ont fait gros gains en 2021.',
      ru: '💪 Инвесторы, которые сохранили спокойствие во время пандемического кризиса 2020 года, получили большие прибыли в 2021 году.'
    },
    icon: <TrendingUp className="w-16 h-16 text-green-600" />
  },
  {
    title: { 
      tr: 'Mindfulness (Farkındalık)', 
      en: 'Mindfulness', 
      es: 'Atención Plena', 
      fr: 'Pleine Conscience', 
      ru: 'Осознанность' 
    },
    content: { 
      tr: [
        '• İşlem yapmadan önce birkaç dakika nefes egzersizi yapmak, sakin kalmayı sağlar.',
        '• Bilinçli farkındalık, kararların kalitesini yükseltir.'
      ],
      en: [
        '• Doing breathing exercises for few minutes before trading helps stay calm.',
        '• Conscious awareness improves decision quality.'
      ],
      es: [
        '• Hacer ejercicios de respiración por pocos minutos antes de operar ayuda a mantener calma.',
        '• Conciencia consciente mejora calidad de decisiones.'
      ],
      fr: [
        '• Faire exercices de respiration pendant quelques minutes avant trading aide à rester calme.',
        '• Conscience consciente améliore qualité des décisions.'
      ],
      ru: [
        '• Выполнение дыхательных упражнений в течение нескольких минут перед торговлей помогает сохранять спокойствие.',
        '• Сознательная осознанность улучшает качество решений.'
      ]
    },
    example: { 
      tr: '🧘 Her sabah 5 dakika meditasyon yapan trader, günlük stresini %50 azalttı.',
      en: '🧘 Trader who meditates 5 minutes every morning reduced daily stress by 50%.',
      es: '🧘 Trader que medita 5 minutos cada mañana redujo estrés diario en 50%.',
      fr: '🧘 Trader qui médite 5 minutes chaque matin a réduit stress quotidien de 50%.',
      ru: '🧘 Трейдер, который медитирует 5 минут каждое утро, снизил ежедневный стресс на 50%.'
    },
    icon: <Eye className="w-16 h-16 text-indigo-600" />
  },
  {
    title: { 
      tr: 'Hatalardan Ders Çıkarmak', 
      en: 'Learning from Mistakes', 
      es: 'Aprender de los Errores', 
      fr: 'Apprendre des Erreurs', 
      ru: 'Учиться на ошибках' 
    },
    content: { 
      tr: [
        '• Hatalar kaçınılmazdır. Önemli olan, aynı hatayı tekrarlamamaktır.',
        '• Düzenli olarak işlemleri gözden geçirmek, gelişimin anahtarıdır.'
      ],
      en: [
        '• Mistakes are inevitable. Important thing is not repeating the same mistake.',
        '• Regularly reviewing trades is key to improvement.'
      ],
      es: [
        '• Los errores son inevitables. Lo importante es no repetir el mismo error.',
        '• Revisar regularmente las operaciones es clave para la mejora.'
      ],
      fr: [
        '• Les erreurs sont inévitables. Important est ne pas répéter même erreur.',
        '• Réviser régulièrement les opérations est clé pour amélioration.'
      ],
      ru: [
        '• Ошибки неизбежны. Важно не повторять ту же ошибку.',
        '• Регулярный пересмотр сделок - ключ к улучшению.'
      ]
    },
    example: { 
      tr: '📚 Aylık analiz yapan yatırımcı, hata oranını yılda %60 azalttı.',
      en: '📚 Investor doing monthly analysis reduced error rate by 60% per year.',
      es: '📚 Inversor haciendo análisis mensual redujo tasa de error en 60% por año.',
      fr: '📚 Investisseur faisant analyse mensuelle a réduit taux d\'erreur de 60% par an.',
      ru: '📚 Инвестор, проводящий ежемесячный анализ, снизил уровень ошибок на 60% в год.'
    },
    icon: <Lightbulb className="w-16 h-16 text-yellow-500" />
  },
  {
    title: { 
      tr: 'Geleceğin İşlem Psikolojisi', 
      en: 'Future of Trading Psychology', 
      es: 'Futuro de la Psicología del Trading', 
      fr: 'Avenir de la Psychologie du Trading', 
      ru: 'Будущее психологии трейдинга' 
    },
    content: { 
      tr: [
        '• Yakında yapay zeka, yatırımcıların duygularını analiz edip uyarılar verecek.',
        '• Ama unutmayın: Teknoloji destek olur, asıl başarı insanın kendi disiplininde saklıdır.'
      ],
      en: [
        '• Soon AI will analyze investors\' emotions and give warnings.',
        '• But remember: Technology supports, real success lies in human\'s own discipline.'
      ],
      es: [
        '• Pronto la IA analizará emociones de inversores y dará advertencias.',
        '• Pero recuerda: La tecnología apoya, el éxito real radica en la propia disciplina humana.'
      ],
      fr: [
        '• Bientôt l\'IA analysera émotions des investisseurs et donnera avertissements.',
        '• Mais souvenez-vous: La technologie soutient, le vrai succès réside dans propre discipline humaine.'
      ],
      ru: [
        '• Скоро ИИ будет анализировать эмоции инвесторов и давать предупреждения.',
        '• Но помните: Технологии поддерживают, настоящий успех заключается в собственной человеческой дисциплине.'
      ]
    },
    example: { 
      tr: '🤖 2030\'da AI asistan: "Stresli görünüyorsun, bugün işlem yapma" diyecek.',
      en: '🤖 In 2030, AI assistant will say: "You look stressed, don\'t trade today".',
      es: '🤖 En 2030, asistente IA dirá: "Te ves estresado, no operes hoy".',
      fr: '🤖 En 2030, assistant IA dira: "Tu as l\'air stressé, ne trade pas aujourd\'hui".',
      ru: '🤖 В 2030 году ИИ-помощник скажет: "Ты выглядишь напряженным, сегодня не торгуй".'
    },
    icon: <Sparkles className="w-16 h-16 text-purple-600" />
  }
]

// Trading Psychology Quiz
export const tradingPsychologyQuiz = [
  {
    question: {
      tr: 'İşlem psikolojisinin başarıdaki payı yaklaşık olarak nedir?',
      en: 'What is the approximate share of trading psychology in success?',
      es: '¿Cuál es la participación aproximada de la psicología del trading en el éxito?',
      fr: 'Quelle est la part approximative de la psychologie du trading dans le succès?',
      ru: 'Какова приблизительная доля торговой психологии в успехе?'
    },
    options: {
      tr: ['%100 psikoloji', '%80 psikoloji, %20 teknik bilgi', '%50 psikoloji, %50 teknik bilgi', '%20 psikoloji, %80 teknik bilgi'],
      en: ['100% psychology', '80% psychology, 20% technical knowledge', '50% psychology, 50% technical knowledge', '20% psychology, 80% technical knowledge'],
      es: ['100% psicología', '80% psicología, 20% conocimiento técnico', '50% psicología, 50% conocimiento técnico', '20% psicología, 80% conocimiento técnico'],
      fr: ['100% psychologie', '80% psychologie, 20% connaissances techniques', '50% psychologie, 50% connaissances techniques', '20% psychologie, 80% connaissances techniques'],
      ru: ['100% психология', '80% психология, 20% технические знания', '50% психология, 50% технические знания', '20% психология, 80% технические знания']
    },
    correct: 1
  },
  {
    question: {
      tr: 'Korku duygusu yatırımcıyı genellikle ne yapmaya iter?',
      en: 'What does fear emotion usually push investors to do?',
      es: '¿Qué suele empujar a hacer la emoción del miedo a los inversores?',
      fr: 'Que pousse généralement l\'émotion de peur les investisseurs à faire?',
      ru: 'К чему обычно подталкивает эмоция страха инвесторов?'
    },
    options: {
      tr: ['Daha fazla hisse almak', 'Düşüşte satış yapmaya', 'Portföy çeşitlendirmesi yapmaya', 'Strateji geliştirmeye'],
      en: ['Buy more stocks', 'Sell during declines', 'Diversify portfolio', 'Develop strategy'],
      es: ['Comprar más acciones', 'Vender durante caídas', 'Diversificar cartera', 'Desarrollar estrategia'],
      fr: ['Acheter plus d\'actions', 'Vendre pendant les baisses', 'Diversifier portefeuille', 'Développer stratégie'],
      ru: ['Покупать больше акций', 'Продавать во время спадов', 'Диверсифицировать портфель', 'Разрабатывать стратегию']
    },
    correct: 1
  },
  {
    question: {
      tr: 'Aşırı güven önyargısı, yatırımcının riskleri küçümsemesine ve fazla risk almasına yol açabilir.',
      en: 'Overconfidence bias can lead investors to underestimate risks and take excessive risks.',
      es: 'El sesgo de exceso de confianza puede llevar a los inversores a subestimar riesgos y tomar riesgos excesivos.',
      fr: 'Le biais de surconfiance peut amener les investisseurs à sous-estimer les risques et prendre des risques excessifs.',
      ru: 'Предвзятость самоуверенности может привести к тому, что инвесторы недооценивают риски и принимают чрезмерные риски.'
    },
    type: 'true_false',
    correct: true,
    explanation: {
      tr: 'Aşırı güven önyargısı, yatırımcıların kendi yeteneklerini abarttıkları ve risk-getiri dengesini yanlış değerlendirdikleri durumdur.',
      en: 'Overconfidence bias occurs when investors overestimate their abilities and misjudge the risk-return balance.',
      es: 'El sesgo de exceso de confianza ocurre cuando los inversores sobreestiman sus habilidades y juzgan mal el equilibrio riesgo-retorno.',
      fr: 'Le biais de surconfiance se produit quand les investisseurs surestiment leurs capacités et jugent mal l\'équilibre risque-rendement.',
      ru: 'Предвзятость самоуверенности возникает, когда инвесторы переоценивают свои способности и неправильно оценивают баланс риска и доходности.'
    }
  },
  {
    question: {
      tr: 'Sürü psikolojisi ve FOMO yatırımcıları genellikle hangi durumda etkiler?',
      en: 'In which situation do herd psychology and FOMO usually affect investors?',
      es: '¿En qué situación suelen afectar la psicología de rebaño y FOMO a los inversores?',
      fr: 'Dans quelle situation la psychologie de troupeau et FOMO affectent-ils généralement les investisseurs?',
      ru: 'В какой ситуации психология толпы и FOMO обычно влияют на инвесторов?'
    },
    options: {
      tr: ['Fiyatların düşüşünde panik satış', 'Piyasa rallisinde pahalı alım', 'Uzun vadeli yatırım yaparken', 'Temel analiz yaparken'],
      en: ['Panic selling during price declines', 'Expensive buying during market rally', 'When making long-term investments', 'When doing fundamental analysis'],
      es: ['Venta pánico durante caídas precios', 'Compra cara durante rally mercado', 'Al hacer inversiones largo plazo', 'Al hacer análisis fundamental'],
      fr: ['Vente panique pendant baisses prix', 'Achat cher pendant rallye marché', 'En faisant investissements long terme', 'En faisant analyse fondamentale'],
      ru: ['Панические продажи во время падения цен', 'Дорогие покупки во время ралли рынка', 'При долгосрочных инвестициях', 'При фундаментальном анализе']
    },
    correct: 1
  },
  {
    question: {
      tr: 'Çapalama (anchoring) önyargısı yatırımcıyı nasıl etkiler?',
      en: 'How does anchoring bias affect investors?',
      es: '¿Cómo afecta el sesgo de anclaje a los inversores?',
      fr: 'Comment le biais d\'ancrage affecte-t-il les investisseurs?',
      ru: 'Как предвзятость привязки влияет на инвесторов?'
    },
    options: {
      tr: ['Objektif karar almalarını sağlar', 'İlk aldıkları bilgiye takılıp ona göre karar verirler', 'Risk toleranslarını artırır', 'Portföy çeşitlendirmesini teşvik eder'],
      en: ['Helps them make objective decisions', 'They stick to initial information and make decisions based on it', 'Increases their risk tolerance', 'Encourages portfolio diversification'],
      es: ['Les ayuda a tomar decisiones objetivas', 'Se aferran a información inicial y toman decisiones basadas en ello', 'Aumenta su tolerancia al riesgo', 'Fomenta diversificación de cartera'],
      fr: ['Les aide à prendre décisions objectives', 'Ils s\'accrochent à information initiale et prennent décisions basées sur cela', 'Augmente leur tolérance au risque', 'Encourage diversification portefeuille'],
      ru: ['Помогает принимать объективные решения', 'Они привязываются к первоначальной информации и принимают решения на ее основе', 'Повышает толерантность к риску', 'Способствует диверсификации портфеля']
    },
    correct: 1
  },
  {
    question: {
      tr: 'Onaylama (confirmation) önyargısı hangi davranışı tetikler?',
      en: 'Which behavior does confirmation bias trigger?',
      es: '¿Qué comportamiento desencadena el sesgo de confirmación?',
      fr: 'Quel comportement déclenche le biais de confirmation?',
      ru: 'Какое поведение вызывает предвзятость подтверждения?'
    },
    options: {
      tr: ['Tüm bilgileri objektif değerlendirme', 'Sadece kendi görüşünü destekleyen bilgilere inanma', 'Riskleri küçümseme', 'Panik satış'],
      en: ['Objectively evaluating all information', 'Believing only information that supports own view', 'Underestimating risks', 'Panic selling'],
      es: ['Evaluar objetivamente toda información', 'Creer solo información que apoya propia vista', 'Subestimar riesgos', 'Venta pánico'],
      fr: ['Évaluer objectivement toute information', 'Croire seulement information qui soutient sa propre vue', 'Sous-estimer risques', 'Vente panique'],
      ru: ['Объективная оценка всей информации', 'Вера только в информацию, поддерживающую собственную точку зрения', 'Недооценка рисков', 'Паническая продажа']
    },
    correct: 1
  },
  {
    question: {
      tr: 'Stop-loss kullanımının temel amacı nedir?',
      en: 'What is the main purpose of using stop-loss?',
      es: '¿Cuál es el propósito principal de usar stop-loss?',
      fr: 'Quel est l\'objectif principal d\'utiliser stop-loss?',
      ru: 'Какова основная цель использования стоп-лосс?'
    },
    options: {
      tr: ['Kârı maksimize etmek', 'Zararları sınırlamak ve duygusal kararları engellemek', 'Piyasa trendini tahmin etmek', 'Portföyü çeşitlendirmek'],
      en: ['Maximize profit', 'Limit losses and prevent emotional decisions', 'Predict market trend', 'Diversify portfolio'],
      es: ['Maximizar ganancia', 'Limitar pérdidas y prevenir decisiones emocionales', 'Predecir tendencia mercado', 'Diversificar cartera'],
      fr: ['Maximiser profit', 'Limiter pertes et prévenir décisions émotionnelles', 'Prédire tendance marché', 'Diversifier portefeuille'],
      ru: ['Максимизировать прибыль', 'Ограничить потери и предотвратить эмоциональные решения', 'Прогнозировать рыночный тренд', 'Диверсифицировать портфель']
    },
    correct: 1
  },
  {
    question: {
      tr: 'İşlem günlüğü tutmanın en önemli faydası nedir?',
      en: 'What is the most important benefit of keeping a trading journal?',
      es: '¿Cuál es el beneficio más importante de mantener un diario de trading?',
      fr: 'Quel est l\'avantage le plus important de tenir un journal de trading?',
      ru: 'Каково самое важное преимущество ведения торгового дневника?'
    },
    options: {
      tr: ['Vergi beyannamesi için kayıt tutmak', 'Hataları analiz edip duygusal tetikleyicileri fark etmek', 'Günlük kâr-zarar hesabı yapmak', 'Sadece işlem miktarlarını takip etmek'],
      en: ['Keeping records for tax returns', 'Analyzing mistakes and recognizing emotional triggers', 'Daily profit-loss calculation', 'Only tracking transaction amounts'],
      es: ['Mantener registros para declaraciones de impuestos', 'Analizar errores y reconocer disparadores emocionales', 'Cálculo diario de ganancias-pérdidas', 'Solo rastrear montos de transacciones'],
      fr: ['Garder dossiers pour déclarations fiscales', 'Analyser erreurs et reconnaître déclencheurs émotionnels', 'Calcul quotidien profits-pertes', 'Seulement suivre montants transactions'],
      ru: ['Ведение записей для налоговых деклараций', 'Анализ ошибок и распознавание эмоциональных триггеров', 'Ежедневный расчет прибылей-убытков', 'Только отслеживание сумм транзакций']
    },
    correct: 1
  },
  {
    question: {
      tr: 'Risk toleransı yüksek bir yatırımcı genellikle daha sakin ve rasyonel kararlar verir.',
      en: 'An investor with high risk tolerance usually makes calmer and more rational decisions.',
      es: 'Un inversor con alta tolerancia al riesgo generalmente toma decisiones más calmadas y racionales.',
      fr: 'Un investisseur avec haute tolérance au risque prend généralement des décisions plus calmes et rationnelles.',
      ru: 'Инвестор с высокой толерантностью к риску обычно принимает более спокойные и рациональные решения.'
    },
    type: 'true_false',
    correct: true,
    explanation: {
      tr: 'Yüksek risk toleransı olan yatırımcılar piyasa dalgalanmalarından daha az etkilendikleri için duygusal stres yaşamaz ve daha rasyonel davranırlar.',
      en: 'Investors with high risk tolerance are less affected by market fluctuations, so they experience less emotional stress and behave more rationally.',
      es: 'Los inversores con alta tolerancia al riesgo se ven menos afectados por fluctuaciones del mercado, experimentan menos estrés emocional y se comportan más racionalmente.',
      fr: 'Les investisseurs avec haute tolérance au risque sont moins affectés par fluctuations du marché, subissent moins de stress émotionnel et se comportent plus rationnellement.',
      ru: 'Инвесторы с высокой толерантностью к риску меньше подвержены рыночным колебаниям, поэтому испытывают меньше эмоционального стресса и ведут себя более рационально.'
    }
  },
  {
    question: {
      tr: 'Duygusal tuzaklardan kaçınmak için hangi yöntemler önerilir?',
      en: 'Which methods are recommended to avoid emotional traps?',
      es: '¿Qué métodos se recomiendan para evitar trampas emocionales?',
      fr: 'Quelles méthodes sont recommandées pour éviter les pièges émotionnels?',
      ru: 'Какие методы рекомендуются для избежания эмоциональных ловушек?'
    },
    options: {
      tr: ['İntikam ticareti yapmak', 'Kurallı strateji ve işlem limiti koymak', 'Duygusal kararlara odaklanmak', 'Sadece haberleri takip etmek'],
      en: ['Revenge trading', 'Setting rule-based strategy and trading limits', 'Focusing on emotional decisions', 'Only following news'],
      es: ['Trading de venganza', 'Establecer estrategia basada en reglas y límites de trading', 'Enfocarse en decisiones emocionales', 'Solo seguir noticias'],
      fr: ['Trading de vengeance', 'Établir stratégie basée sur règles et limites de trading', 'Se concentrer sur décisions émotionnelles', 'Seulement suivre actualités'],
      ru: ['Мстительная торговля', 'Установление стратегии на основе правил и торговых лимитов', 'Сосредоточение на эмоциональных решениях', 'Только следование новостям']
    },
    correct: 1
  },
  {
    question: {
      tr: 'Psikolojik dayanıklılığı artırmak için hangi teknikler kullanılabilir?',
      en: 'Which techniques can be used to increase psychological resilience?',
      es: '¿Qué técnicas se pueden usar para aumentar la resistencia psicológica?',
      fr: 'Quelles techniques peuvent être utilisées pour augmenter la résilience psychologique?',
      ru: 'Какие техники можно использовать для повышения психологической устойчивости?'
    },
    options: {
      tr: ['Geçmiş hatalardan ders almak ve küçük kazançları kutlamak', 'Duygusal kararlara odaklanmak', 'Yalnızca kısa vadeli işlemler yapmak', 'Haberleri takip ederek panik yapmak'],
      en: ['Learning from past mistakes and celebrating small wins', 'Focusing on emotional decisions', 'Only making short-term trades', 'Following news and panicking'],
      es: ['Aprender de errores pasados y celebrar pequeñas victorias', 'Enfocarse en decisiones emocionales', 'Solo hacer operaciones corto plazo', 'Seguir noticias y entrar en pánico'],
      fr: ['Apprendre des erreurs passées et célébrer petites victoires', 'Se concentrer sur décisions émotionnelles', 'Faire seulement transactions court terme', 'Suivre actualités et paniquer'],
      ru: ['Учиться на прошлых ошибках и отмечать маленькие победы', 'Сосредоточение на эмоциональных решениях', 'Делать только краткосрочные сделки', 'Следить за новостями и паниковать']
    },
    correct: 0
  },
  {
    question: {
      tr: 'Mindfulness ve nefes egzersizleri işlem performansını iyileştirmeye yardımcı olabilir.',
      en: 'Mindfulness and breathing exercises can help improve trading performance.',
      es: 'Mindfulness y ejercicios de respiración pueden ayudar a mejorar el rendimiento del trading.',
      fr: 'La pleine conscience et exercices de respiration peuvent aider à améliorer la performance du trading.',
      ru: 'Осознанность и дыхательные упражнения могут помочь улучшить торговую производительность.'
    },
    type: 'true_false',
    correct: true,
    explanation: {
      tr: 'Mindfulness ve nefes egzersizleri stresi azaltır, odaklanmayı artırır ve duygusal kontrolü geliştirir, bu da daha iyi işlem kararları almaya yardımcı olur.',
      en: 'Mindfulness and breathing exercises reduce stress, improve focus and enhance emotional control, helping make better trading decisions.',
      es: 'Mindfulness y ejercicios respiración reducen estrés, mejoran enfoque y mejoran control emocional, ayudando a tomar mejores decisiones de trading.',
      fr: 'La pleine conscience et exercices respiration réduisent stress, améliorent concentration et renforcent contrôle émotionnel, aidant à prendre meilleures décisions trading.',
      ru: 'Осознанность и дыхательные упражнения снижают стресс, улучшают концентрацию и усиливают эмоциональный контроль, помогая принимать лучшие торговые решения.'
    }
  },
  {
    question: {
      tr: 'Kayıp kaçınma davranışı yatırımcıyı genellikle hangi şekilde etkiler?',
      en: 'How does loss aversion behavior usually affect investors?',
      es: '¿Cómo afecta generalmente el comportamiento de aversión a pérdidas a los inversores?',
      fr: 'Comment le comportement d\'aversion aux pertes affecte-t-il généralement les investisseurs?',
      ru: 'Как поведение избегания потерь обычно влияет на инвесторов?'
    },
    options: {
      tr: ['Kâr elde eden pozisyonları erken satmak', 'Zarar eden pozisyonları erken kapatmak', 'Portföyü çeşitlendirmek', 'Teknik analiz yapmak'],
      en: ['Selling profitable positions early', 'Closing losing positions early', 'Diversifying portfolio', 'Doing technical analysis'],
      es: ['Vender posiciones rentables temprano', 'Cerrar posiciones perdedoras temprano', 'Diversificar cartera', 'Hacer análisis técnico'],
      fr: ['Vendre positions rentables tôt', 'Fermer positions perdantes tôt', 'Diversifier portefeuille', 'Faire analyse technique'],
      ru: ['Продавать прибыльные позиции рано', 'Закрывать убыточные позиции рано', 'Диверсифицировать портфель', 'Проводить технический анализ']
    },
    correct: 0
  },
  {
    question: {
      tr: 'Uzun vadeli ve kısa vadeli yatırım zihniyeti arasındaki temel fark nedir?',
      en: 'What is the fundamental difference between long-term and short-term investment mindset?',
      es: '¿Cuál es la diferencia fundamental entre mentalidad de inversión a largo y corto plazo?',
      fr: 'Quelle est la différence fondamentale entre mentalité d\'investissement long et court terme?',
      ru: 'В чем принципиальная разница между долгосрочным и краткосрочным инвестиционным мышлением?'
    },
    options: {
      tr: ['Uzun vadeli daha az kârlı, kısa vadeli daha kârlı', 'Uzun vadeli sabır gerektirir, kısa vadeli yüksek stres ve hızlı karar', 'İkisi arasında fark yok', 'Uzun vadeli riskli, kısa vadeli güvenli'],
      en: ['Long-term less profitable, short-term more profitable', 'Long-term requires patience, short-term involves high stress and quick decisions', 'No difference between them', 'Long-term risky, short-term safe'],
      es: ['Largo plazo menos rentable, corto plazo más rentable', 'Largo plazo requiere paciencia, corto plazo involucra alto estrés y decisiones rápidas', 'No hay diferencia entre ellos', 'Largo plazo arriesgado, corto plazo seguro'],
      fr: ['Long terme moins rentable, court terme plus rentable', 'Long terme nécessite patience, court terme implique stress élevé et décisions rapides', 'Pas de différence entre eux', 'Long terme risqué, court terme sûr'],
      ru: ['Долгосрочные менее прибыльны, краткосрочные более прибыльны', 'Долгосрочные требуют терпения, краткосрочные связаны с высоким стрессом и быстрыми решениями', 'Между ними нет разницы', 'Долгосрочные рискованны, краткосрочные безопасны']
    },
    correct: 1
  },
  {
    question: {
      tr: 'İşlem psikolojisinin geleceğinde hangi trend öne çıkmaktadır?',
      en: 'Which trend stands out in the future of trading psychology?',
      es: '¿Qué tendencia se destaca en el futuro de la psicología del trading?',
      fr: 'Quelle tendance se démarque dans l\'avenir de la psychologie du trading?',
      ru: 'Какая тенденция выделяется в будущем торговой психологии?'
    },
    options: {
      tr: ['Yalnızca temel analiz', 'AI destekli duygu analizi ve davranışsal finans entegrasyonu', 'Sadece kısa vadeli işlemler', 'Teknik analiz yerine tahmin oyunları'],
      en: ['Only fundamental analysis', 'AI-supported emotion analysis and behavioral finance integration', 'Only short-term trades', 'Prediction games instead of technical analysis'],
      es: ['Solo análisis fundamental', 'Análisis emocional con soporte de IA e integración finanzas conductuales', 'Solo operaciones corto plazo', 'Juegos predicción en lugar análisis técnico'],
      fr: ['Seulement analyse fondamentale', 'Analyse émotions soutenue par IA et intégration finance comportementale', 'Seulement transactions court terme', 'Jeux prédiction au lieu analyse technique'],
      ru: ['Только фундаментальный анализ', 'Анализ эмоций с поддержкой ИИ и интеграция поведенческих финансов', 'Только краткосрочные сделки', 'Игры предсказаний вместо технического анализа']
    },
    correct: 1
  }
]