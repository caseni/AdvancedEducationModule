import { Globe, BookOpen, TrendingUp, Shield, Zap, Calculator, Award, Users, AlertTriangle, DollarSign, Activity, Target, Layers, Eye, Brain, Settings, Clock, PieChart, BarChart3, LineChart } from 'lucide-react'

export const DerivativesMarketsSlides = [
  {
    title: { 
      tr: 'Türev Piyasalar Nedir?', 
      en: 'What are Derivatives Markets?', 
      es: '¿Qué son los Mercados de Derivados?', 
      fr: 'Que sont les Marchés de Dérivés?', 
      ru: 'Что такое рынки деривативов?' 
    },
    content: { 
      tr: [
        '• Türev piyasalar, değerini başka bir varlıktan alan sözleşmelerin işlem gördüğü yerlerdir.',
        '• Bu varlık hisse senedi, döviz, altın, petrol veya faiz oranı olabilir.',
        '• **Amaç:** Fiyat değişimlerinden korunmak ya da kazanç fırsatı yakalamak.',
        '• Örnek: Bir çiftçi hasat edeceği buğdayın fiyatı düşmesin diye şimdiden sözleşme yapabilir.'
      ],
      en: [
        '• Derivatives markets are places where contracts that derive their value from other assets are traded.',
        '• This asset can be stocks, currency, gold, oil or interest rates.',
        '• **Purpose:** Protect from price changes or catch profit opportunities.',
        '• Example: A farmer can make a contract now so the price of wheat to be harvested doesn\'t fall.'
      ],
      es: [
        '• Los mercados de derivados son lugares donde se negocian contratos que derivan su valor de otros activos.',
        '• Este activo puede ser acciones, divisa, oro, petróleo o tasas de interés.',
        '• **Propósito:** Protegerse de cambios de precio o capturar oportunidades de ganancia.',
        '• Ejemplo: Un agricultor puede hacer un contrato ahora para que el precio del trigo a cosechar no baje.'
      ],
      fr: [
        '• Les marchés de dérivés sont des endroits où sont négociés des contrats qui tirent leur valeur d\'autres actifs.',
        '• Cet actif peut être des actions, devise, or, pétrole ou taux d\'intérêt.',
        '• **Objectif:** Se protéger des changements de prix ou saisir des opportunités de profit.',
        '• Exemple: Un agriculteur peut faire un contrat maintenant pour que le prix du blé à récolter ne baisse pas.'
      ],
      ru: [
        '• Рынки деривативов - это места, где торгуются контракты, получающие свою стоимость от других активов.',
        '• Этот актив может быть акциями, валютой, золотом, нефтью или процентными ставками.',
        '• **Цель:** З��щита от изменения цен или получение возможностей прибыли.',
        '• Пример: Фермер может заключить контракт сейчас, чтобы цена пшеницы к урожаю не упала.'
      ]
    },
    example: { 
      tr: '🌾 Çiftçi buğday hasadından önce fiyatı sabitleyerek riskini azaltır.',
      en: '🌾 Farmer reduces risk by fixing price before wheat harvest.',
      es: '🌾 Agricultor reduce riesgo fijando precio antes de cosecha de trigo.',
      fr: '🌾 Agriculteur réduit risque en fixant prix avant récolte de blé.',
      ru: '🌾 Фермер снижает риск, фиксируя цену до сбора пшеницы.'
    },
    icon: <Globe className="w-16 h-16 text-blue-500" />
  },
  {
    title: { 
      tr: 'Neden Önemlidir?', 
      en: 'Why Important?', 
      es: '¿Por qué es Importante?', 
      fr: 'Pourquoi Important?', 
      ru: 'Почему важно?' 
    },
    content: { 
      tr: [
        '• Fiyat dalgalanmalarına karşı güvenlik sağlar.',
        '• Şirketler için maliyetleri sabit tutar.',
        '• Yatırımcılara daha fazla fırsat sunar.',
        '• Piyasada fiyatların adil oluşmasına katkı verir.',
        '• **Günümüz:** 2025\'te türev piyasaların toplam büyüklüğü 640 trilyon USD – dünya ekonomisinin 7 katı!'
      ],
      en: [
        '• Provides security against price fluctuations.',
        '• Keeps costs stable for companies.',
        '• Offers more opportunities to investors.',
        '• Contributes to fair price formation in markets.',
        '• **Today:** In 2025, total size of derivatives markets is 640 trillion USD – 7 times the world economy!'
      ],
      es: [
        '• Proporciona seguridad contra fluctuaciones de precio.',
        '• Mantiene costos estables para empresas.',
        '• Ofrece más oportunidades a inversores.',
        '• Contribuye a formación justa de precios en mercados.',
        '• **Hoy:** En 2025, tamaño total de mercados de derivados es 640 billones USD – ¡7 veces la economía mundial!'
      ],
      fr: [
        '• Fournit sécurité contre fluctuations de prix.',
        '• Maintient coûts stables pour entreprises.',
        '• Offre plus d\'opportunités aux investisseurs.',
        '• Contribue à formation équitable des prix sur marchés.',
        '• **Aujourd\'hui:** En 2025, taille totale des marchés de dérivés est 640 billions USD – 7 fois l\'économie mondiale!'
      ],
      ru: [
        '• Обеспечивает безопасность против ценовых колебаний.',
        '• Поддерживает стабильность затрат для компаний.',
        '• Предлагает больше возможностей инвесторам.',
        '• Способствует справедливому ценообразованию на рынках.',
        '• **Сегодня:** В 2025 году общий размер рынков деривативов составляет 640 трлн USD – в 7 раз больше мировой экономики!'
      ]
    },
    example: { 
      tr: '💰 640 trilyon USD - dünya ekonomisinin 7 katı büyüklükte piyasa.',
      en: '💰 640 trillion USD - market 7 times the size of world economy.',
      es: '💰 640 billones USD - mercado 7 veces el tamaño de la economía mundial.',
      fr: '💰 640 billions USD - marché 7 fois la taille de l\'économie mondiale.',
      ru: '💰 640 трлн USD - рынок в 7 раз больше мировой экономики.'
    },
    icon: <TrendingUp className="w-16 h-16 text-green-500" />
  },
  {
    title: { 
      tr: 'Piyasa Türleri', 
      en: 'Market Types', 
      es: 'Tipos de Mercado', 
      fr: 'Types de Marchés', 
      ru: 'Типы рынков' 
    },
    content: { 
      tr: [
        '• **Borsada İşlem Gören Türevler** (Futures, Opsiyonlar): Standart kurallara sahiptir, herkesin ulaşabileceği şeffaf piyasadır.',
        '• **Tezgah Üstü (OTC):** İki taraf arasında özel olarak yapılır. Daha esnek ama risklidir.',
        '• Örnek: Bir banka ile şirket arasında yapılan özel döviz anlaşması OTC\'dir.'
      ],
      en: [
        '• **Exchange-Traded Derivatives** (Futures, Options): Have standard rules, transparent market accessible to everyone.',
        '• **Over-the-Counter (OTC):** Made privately between two parties. More flexible but riskier.',
        '• Example: Special currency agreement between a bank and company is OTC.'
      ],
      es: [
        '• **Derivados Negociados en Bolsa** (Futuros, Opciones): Tienen reglas estándar, mercado transparente accesible a todos.',
        '• **Over-the-Counter (OTC):** Hecho privadamente entre dos partes. Más flexible pero más riesgoso.',
        '• Ejemplo: Acuerdo especial de divisa entre banco y empresa es OTC.'
      ],
      fr: [
        '• **Dérivés Négociés en Bourse** (Futures, Options): Ont règles standard, marché transparent accessible à tous.',
        '• **Over-the-Counter (OTC):** Fait privément entre deux parties. Plus flexible mais plus risqué.',
        '• Exemple: Accord spécial de devise entre banque et entreprise est OTC.'
      ],
      ru: [
        '• **Биржевые Деривативы** (Фьючерсы, Опционы): Имеют стандартные правила, прозрачный рынок, доступный всем.',
        '• **Внебиржевые (OTC):** Заключаются в частном порядке между двумя сторонами. Более гибкие, но рискованные.',
        '• Пример: Специальное валютное соглашение между банком и компанией - это OTC.'
      ]
    },
    example: { 
      tr: '🏢 Banka ile şirket arasındaki özel döviz anlaşması OTC örneğidir.',
      en: '🏢 Special currency agreement between bank and company is OTC example.',
      es: '🏢 Acuerdo especial de divisa entre banco y empresa es ejemplo OTC.',
      fr: '🏢 Accord spécial de devise entre banque et entreprise est exemple OTC.',
      ru: '🏢 Специальное валютное соглашение между банком и компанией - пример OTC.'
    },
    icon: <Layers className="w-16 h-16 text-purple-500" />
  },
  {
    title: { 
      tr: 'Forward Sözleşmeleri', 
      en: 'Forward Contracts', 
      es: 'Contratos Forward', 
      fr: 'Contrats Forward', 
      ru: 'Форвардные контракты' 
    },
    content: { 
      tr: [
        '• Taraflar gelecekte belli bir tarihte, belli bir fiyattan alım-satım yapmayı kabul eder.',
        '• Özel anlaşmadır, borsada değil OTC\'de yapılır.',
        '• **Risk:** Taraflardan biri sözleşmeyi yerine getirmezse zarar olabilir.',
        '• Örnek: Bir ihracatçı, 3 ay sonra alacağı 1 milyon USD\'yi şimdiden TL\'ye çevirmek için forward yapar.'
      ],
      en: [
        '• Parties agree to buy-sell at a specific price on a specific future date.',
        '• It\'s a private agreement, made in OTC not on exchange.',
        '• **Risk:** There can be loss if one party doesn\'t fulfill the contract.',
        '• Example: An exporter makes forward to convert 1 million USD to be received in 3 months to TL now.'
      ],
      es: [
        '• Las partes acuerdan comprar-vender a precio específico en fecha futura específica.',
        '• Es acuerdo privado, hecho en OTC no en bolsa.',
        '• **Riesgo:** Puede haber pérdida si una parte no cumple el contrato.',
        '• Ejemplo: Un exportador hace forward para convertir 1 millón USD a recibir en 3 meses a TL ahora.'
      ],
      fr: [
        '• Les parties acceptent d\'acheter-vendre à prix spécifique à date future spécifique.',
        '• C\'est accord privé, fait en OTC pas en bourse.',
        '• **Risque:** Il peut y avoir perte si une partie n\'accomplit pas le contrat.',
        '• Exemple: Un exportateur fait forward pour convertir 1 million USD à recevoir dans 3 mois en TL maintenant.'
      ],
      ru: [
        '• Стороны соглашаются покупать-продавать по определенной цене в определенную будущую дату.',
        '• Это частное соглашение, заключаемое внебиржево, а не на бирже.',
        '• **Риск:** Может быть потеря, если одна сторона не выполнит контракт.',
        '• Пример: Экспортер делает форвард для конвертации 1 млн USD, которые получит через 3 месяца, в лиры сейчас.'
      ]
    },
    example: { 
      tr: '💵 İhracatçı 3 ay sonraki 1 milyon USD\'sini şimdiden TL\'ye çevirir.',
      en: '💵 Exporter converts 1 million USD to be received in 3 months to TL now.',
      es: '💵 Exportador convierte 1 millón USD a recibir en 3 meses a TL ahora.',
      fr: '💵 Exportateur convertit 1 million USD à recevoir dans 3 mois en TL maintenant.',
      ru: '💵 Экспортер конвертирует 1 млн USD, которые получит через 3 месяца, в лиры сейчас.'
    },
    icon: <Calculator className="w-16 h-16 text-orange-500" />
  },
  {
    title: { 
      tr: 'Futures Sözleşmeleri', 
      en: 'Futures Contracts', 
      es: 'Contratos Futuros', 
      fr: 'Contrats Futures', 
      ru: 'Фьючерсные контракты' 
    },
    content: { 
      tr: [
        '• Forward\'ın borsada işlem gören, standart hâlidir.',
        '• Günlük hesaplaşma yapılır, risk daha azdır.',
        '• Daha çok yatırımcıya açıktır, kolayca alınıp satılabilir.',
        '• Örnek: Bir havayolu şirketi, yakıt fiyatları artmasın diye petrol futures sözleşmesi alır.'
      ],
      en: [
        '• It\'s the exchange-traded, standard version of forward.',
        '• Daily settlement is made, risk is lower.',
        '• Open to more investors, can be easily bought and sold.',
        '• Example: An airline company buys oil futures contract so fuel prices don\'t increase.'
      ],
      es: [
        '• Es la versión estándar negociada en bolsa del forward.',
        '• Se hace liquidación diaria, riesgo es menor.',
        '• Abierto a más inversores, puede comprarse y venderse fácilmente.',
        '• Ejemplo: Una aerolínea compra contrato futures de petróleo para que precios de combustible no aumenten.'
      ],
      fr: [
        '• C\'est la version standard négociée en bourse du forward.',
        '• Règlement quotidien est fait, risque est moindre.',
        '• Ouvert à plus d\'investisseurs, peut être acheté et vendu facilement.',
        '• Exemple: Une compagnie aérienne achète contrat futures pétrole pour que prix carburant n\'augmentent pas.'
      ],
      ru: [
        '• Это биржевая, стандартная версия форварда.',
        '• Проводится ежедневные расчеты, риск ниже.',
        '• Открыт для большего числа инвесторов, легко покупается и продается.',
        '• Пример: Авиакомпания покупает нефтяной фьючерсный контракт, чтобы цены на топливо не выросли.'
      ]
    },
    example: { 
      tr: '✈️ Havayolu şirketi yakıt fiyatlarını sabitlemek için petrol futures alır.',
      en: '✈️ Airline company buys oil futures to fix fuel prices.',
      es: '✈️ Aerolínea compra futuros de petróleo para fijar precios de combustible.',
      fr: '✈️ Compagnie aérienne achète futures pétrole pour fixer prix carburant.',
      ru: '✈️ Авиакомпания покупает нефтяные фьючерсы для фиксации цен на топливо.'
    },
    icon: <Zap className="w-16 h-16 text-yellow-500" />
  },
  {
    title: { 
      tr: 'Forward vs Futures Karşılaştırma', 
      en: 'Forward vs Futures Comparison', 
      es: 'Comparación Forward vs Futuros', 
      fr: 'Comparaison Forward vs Futures', 
      ru: 'Сравнение форвардов и фьючерсов' 
    },
    content: { 
      tr: [
        '• **Özellik karşılaştırması:**',
        '',
        '**Standart mı?**',
        '• Forward (OTC): Hayır',
        '• Futures (Borsa): Evet',
        '',
        '**Risk**',
        '• Forward (OTC): Yüksek', 
        '• Futures (Borsa): Daha düşük',
        '',
        '**Esneklik**',
        '• Forward (OTC): Çok esnek',
        '• Futures (Borsa): Sınırlı',
        '',
        '**Likidite**',
        '• Forward (OTC): Az',
        '• Futures (Borsa): Yüksek'
      ],
      en: [
        '• **Feature comparison:**',
        '',
        '**Is it Standard?**',
        '• Forward (OTC): No',
        '• Futures (Exchange): Yes',
        '',
        '**Risk**',
        '• Forward (OTC): High',
        '• Futures (Exchange): Lower',
        '',
        '**Flexibility**',
        '• Forward (OTC): Very flexible',
        '• Futures (Exchange): Limited',
        '',
        '**Liquidity**',
        '• Forward (OTC): Low',
        '• Futures (Exchange): High'
      ],
      es: [
        '• **Comparación de características:**',
        '',
        '**¿Es Estándar?**',
        '• Forward (OTC): No',
        '• Futuros (Bolsa): Sí',
        '',
        '**Riesgo**',
        '• Forward (OTC): Alto',
        '• Futuros (Bolsa): Menor',
        '',
        '**Flexibilidad**',
        '• Forward (OTC): Muy flexible',
        '• Futuros (Bolsa): Limitada',
        '',
        '**Liquidez**',
        '• Forward (OTC): Baja',
        '• Futuros (Bolsa): Alta'
      ],
      fr: [
        '• **Comparaison des caractéristiques:**',
        '',
        '**Est-ce Standard?**',
        '• Forward (OTC): Non',
        '• Futures (Bourse): Oui',
        '',
        '**Risque**',
        '• Forward (OTC): Élevé',
        '• Futures (Bourse): Plus bas',
        '',
        '**Flexibilité**',
        '• Forward (OTC): Très flexible',
        '• Futures (Bourse): Limitée',
        '',
        '**Liquidité**',
        '• Forward (OTC): Faible',
        '• Futures (Bourse): Élevée'
      ],
      ru: [
        '• **Сравнение характеристик:**',
        '',
        '**Стандартный?**',
        '• Форвард (OTC): Нет',
        '• Фьючерсы (Биржа): Да',
        '',
        '**Риск**',
        '• Форвард (OTC): Высокий',
        '• Фьючерсы (Биржа): Ниже',
        '',
        '**Гибкость**',
        '• Форвард (OTC): Очень гибкий',
        '• Фьючерсы (Биржа): Ограниченная',
        '',
        '**Ликвидность**',
        '• Форвард (OTC): Низкая',
        '• Фьючерсы (Биржа): Высокая'
      ]
    },
    example: { 
      tr: '⚖️ Büyük şirket özel forward, küçük yatırımcı standart futures tercih eder.',
      en: '⚖️ Large company prefers custom forward, small investor prefers standard futures.',
      es: '⚖️ Gran empresa prefiere forward personalizado, pequeño inversor prefiere futuros estándar.',
      fr: '⚖️ Grande entreprise préfère forward personnalisé, petit investisseur préfère futures standard.',
      ru: '⚖️ Крупная компания предпочитает индивидуальный форвард, мелкий инвестор предпочитает стандартные фьючерсы.'
    },
    icon: <Award className="w-16 h-16 text-blue-600" />
  },
  {
    title: { 
      tr: 'Opsiyon Nedir?', 
      en: 'What is an Option?', 
      es: '¿Qué es una Opción?', 
      fr: 'Qu\'est-ce qu\'une Option?', 
      ru: 'Что такое опцион?' 
    },
    content: { 
      tr: [
        '• Opsiyon, size bir hak verir, zorunluluk vermez.',
        '• **Call Opsiyon:** Belirli fiyattan alma hakkı',
        '• **Put Opsiyon:** Belirli fiyattan satma hakkı',
        '• **Avantaj:** Yatırımcı riskini sınırlandırır.',
        '• Örnek: Hisse senedinin fiyatı artarsa, call opsiyon alan yatırımcı kar eder.'
      ],
      en: [
        '• Option gives you a right, doesn\'t give obligation.',
        '• **Call Option:** Right to buy at specific price',
        '• **Put Option:** Right to sell at specific price',
        '• **Advantage:** Investor limits their risk.',
        '• Example: If stock price rises, investor who bought call option profits.'
      ],
      es: [
        '• Opción te da un derecho, no da obligación.',
        '• **Opción Call:** Derecho a comprar a precio específico',
        '• **Opción Put:** Derecho a vender a precio específico',
        '• **Ventaja:** Inversor limita su riesgo.',
        '• Ejemplo: Si precio de acción sube, inversor que compró opción call obtiene ganancia.'
      ],
      fr: [
        '• Option vous donne un droit, ne donne pas d\'obligation.',
        '• **Option Call:** Droit d\'acheter à prix spécifique',
        '• **Option Put:** Droit de vendre à prix spécifique',
        '• **Avantage:** Investisseur limite son risque.',
        '• Exemple: Si prix action monte, investisseur qui a acheté option call profite.'
      ],
      ru: [
        '• Опцион дает вам право, не дает обязательств.',
        '• **Колл Опцион:** Право купить по определенной цене',
        '• **Пут Опцион:** Право продать по определенной цене',
        '• **Преимущество:** Инвестор ограничивает свой риск.',
        '• Пример: Если цена акции растет, инвестор, купивший колл-опцион, получает прибыль.'
      ]
    },
    example: { 
      tr: '📈 Hisse 100 TL\'ken 110 TL call alan yatırımcı, hisse 120 TL olunca kar eder.',
      en: '📈 Investor who bought 110 TL call when stock was 100 TL profits when stock becomes 120 TL.',
      es: '📈 Inversor que compró call de 110 TL cuando acción era 100 TL obtiene ganancia cuando acción llega a 120 TL.',
      fr: '📈 Investisseur qui a acheté call 110 TL quand action était 100 TL profite quand action devient 120 TL.',
      ru: '📈 Инвестор, купивший колл 110 лир при цене акции 100 лир, получает прибыль, когда акция становится 120 лир.'
    },
    icon: <Users className="w-16 h-16 text-green-600" />
  },
  {
    title: { 
      tr: 'Opsiyonların Kullanımı', 
      en: 'Option Usage', 
      es: 'Uso de Opciones', 
      fr: 'Utilisation d\'Options', 
      ru: 'Использование опционов' 
    },
    content: { 
      tr: [
        '• Şirketler kendini fiyat dalgalanmalarına karşı korur.',
        '• Yatırımcılar sınırlı riskle büyük kazanç hedefler.',
        '• Borsalarda milyonlarca opsiyon sözleşmesi işlem görür.',
        '• **Gerçek Hayat:** Tesla opsiyonları 2025\'te çok işlem gördü, hissede sert yükseliş yaşandı.'
      ],
      en: [
        '• Companies protect themselves against price fluctuations.',
        '• Investors target big gains with limited risk.',
        '• Millions of option contracts are traded on exchanges.',
        '• **Real Life:** Tesla options were heavily traded in 2025, stock experienced sharp rise.'
      ],
      es: [
        '• Empresas se protegen contra fluctuaciones de precio.',
        '• Inversores apuntan a grandes ganancias con riesgo limitado.',
        '• Millones de contratos de opciones se negocian en bolsas.',
        '• **Vida Real:** Opciones de Tesla fueron muy negociadas en 2025, acción experimentó fuerte alza.'
      ],
      fr: [
        '• Entreprises se protègent contre fluctuations de prix.',
        '• Investisseurs visent gros gains avec risque limité.',
        '• Millions de contrats d\'options sont négociés sur bourses.',
        '• **Vraie Vie:** Options Tesla ont été beaucoup négociées en 2025, action a connu forte hausse.'
      ],
      ru: [
        '• Компании защищают себя от ценовых колебаний.',
        '• Инвесторы нацеливаются на большие прибыли с ограниченным риском.',
        '• Миллионы опционных контрактов торгуются на биржах.',
        '• **Реальная Жизнь:** Опционы Tesla активно торговались в 2025 году, акция испытала резкий рост.'
      ]
    },
    example: { 
      tr: '🚗 Tesla opsiyonları 2025\'te çok popüler oldu, hisse sert yükseldi.',
      en: '🚗 Tesla options became very popular in 2025, stock rose sharply.',
      es: '🚗 Opciones de Tesla se volvieron muy populares en 2025, acción subió fuertemente.',
      fr: '🚗 Options Tesla sont devenues très populaires en 2025, action a monté fortement.',
      ru: '🚗 Опционы Tesla стали очень популярными в 2025 году, акция резко выросла.'
    },
    icon: <Target className="w-16 h-16 text-blue-500" />
  },
  {
    title: { 
      tr: 'Greeks (Risk Ölçümleri)', 
      en: 'Greeks (Risk Measurements)', 
      es: 'Griegas (Medidas de Riesgo)', 
      fr: 'Grecques (Mesures de Risque)', 
      ru: 'Греки (Измерения риска)' 
    },
    content: { 
      tr: [
        '• Opsiyonların nasıl davrandığını ölçmek için matematiksel göstergeler kullanılır:',
        '• **Delta:** Fiyat değiştiğinde opsiyonun değeri nasıl etkilenir?',
        '• **Theta:** Zaman geçtikçe opsiyonun değeri nasıl azalır?',
        '• **Vega:** Piyasa oynaklığı artarsa opsiyonun değeri nasıl değişir?',
        '• (Başlangıç için Delta & Theta bilmek yeterli.)'
      ],
      en: [
        '• Mathematical indicators are used to measure how options behave:',
        '• **Delta:** How is option value affected when price changes?',
        '• **Theta:** How does option value decrease as time passes?',
        '• **Vega:** How does option value change if market volatility increases?',
        '• (Knowing Delta & Theta is enough for beginners.)'
      ],
      es: [
        '• Se usan indicadores matemáticos para medir cómo se comportan las opciones:',
        '• **Delta:** ¿Cómo se afecta valor de opción cuando precio cambia?',
        '• **Theta:** ¿Cómo disminuye valor de opción al pasar tiempo?',
        '• **Vega:** ¿Cómo cambia valor de opción si volatilidad del mercado aumenta?',
        '• (Conocer Delta & Theta es suficiente para principiantes.)'
      ],
      fr: [
        '• Des indicateurs mathématiques sont utilisés pour mesurer comment les options se comportent:',
        '• **Delta:** Comment valeur option est affectée quand prix change?',
        '• **Theta:** Comment valeur option diminue au passage du temps?',
        '• **Vega:** Comment valeur option change si volatilité marché augmente?',
        '• (Connaître Delta & Theta suffit pour débutants.)'
      ],
      ru: [
        '• Математические индикаторы используются для измерения поведения опционов:',
        '• **Дельта:** Как влияет на стоимость опциона изменение цены?',
        '• **Тета:** Как уменьшается стоимость опциона с течением времени?',
        '• **Вега:** Как изменяется стоимость опциона при росте рыночной волатильности?',
        '• (Знание Дельта и Тета достаточно для начинающих.)'
      ]
    },
    example: { 
      tr: '📊 Delta 0.5 olan opsiyon, hisse 2 TL artarsa yaklaşık 1 TL değer kazanır.',
      en: '📊 Option with delta 0.5 gains approximately 1 TL value if stock rises 2 TL.',
      es: '📊 Opción con delta 0.5 gana aproximadamente 1 TL de valor si acción sube 2 TL.',
      fr: '📊 Option avec delta 0,5 gagne environ 1 TL de valeur si action monte de 2 TL.',
      ru: '📊 Опцион с дельтой 0,5 получает примерно 1 лиру стоимости, если акция поднимается на 2 лиры.'
    },
    icon: <Calculator className="w-16 h-16 text-red-500" />
  },
  {
    title: { 
      tr: 'Basit Opsiyon Stratejileri', 
      en: 'Simple Option Strategies', 
      es: 'Estrategias Simples de Opciones', 
      fr: 'Stratégies Simples d\'Options', 
      ru: 'Простые опционные стратегии' 
    },
    content: { 
      tr: [
        '• **Protective Put:** Hisseyi tutarken, düşüşe karşı put opsiyon almak.',
        '• **Covered Call:** Elinizde hisse varken, ek gelir için call opsiyon satmak.',
        '• **Straddle:** Fiyat çok oynarsa kazanmak için hem call hem put almak.',
        '• Örnek: Elinde 1000 hisse olan yatırımcı, fiyat düşerse zarar etmemek için put opsiyon alır.'
      ],
      en: [
        '• **Protective Put:** Buying put option against decline while holding stock.',
        '• **Covered Call:** Selling call option for extra income while having stock.',
        '• **Straddle:** Buying both call and put to profit if price moves a lot.',
        '• Example: Investor with 1000 shares buys put option to avoid loss if price falls.'
      ],
      es: [
        '• **Protective Put:** Comprar opción put contra caída mientras se tiene acción.',
        '• **Covered Call:** Vender opción call para ingreso extra mientras se tiene acción.',
        '• **Straddle:** Comprar tanto call como put para obtener ganancia si precio se mueve mucho.',
        '• Ejemplo: Inversor con 1000 acciones compra opción put para evitar pérdida si precio baja.'
      ],
      fr: [
        '• **Protective Put:** Acheter option put contre baisse tout en détenant action.',
        '• **Covered Call:** Vendre option call pour revenu supplémentaire tout en ayant action.',
        '• **Straddle:** Acheter à la fois call et put pour profiter si prix bouge beaucoup.',
        '• Exemple: Investisseur avec 1000 actions achète option put pour éviter perte si prix baisse.'
      ],
      ru: [
        '• **Защитный Пут:** Покупка пут-опциона против падения при владении акцией.',
        '• **Покрытый Колл:** Продажа колл-опциона для дополнитель��ого дохода при наличии акции.',
        '• **Стрэддл:** Покупка и колла, и пута для прибыли при сильном движении цены.',
        '• Пример: Инвестор с 1000 акций покупает пут-опцион, чтобы избежать потерь при падении цены.'
      ]
    },
    example: { 
      tr: '🛡️ 1000 hissesi olan yatırımcı düşüşe karşı put opsiyon alarak kendini korur.',
      en: '🛡️ Investor with 1000 shares protects himself by buying put option against decline.',
      es: '🛡️ Inversor con 1000 acciones se protege comprando opción put contra caída.',
      fr: '🛡️ Investisseur avec 1000 actions se protège en achetant option put contre baisse.',
      ru: '🛡️ Инвестор с 1000 акций защищает себя, покупая пут-опцион против падения.'
    },
    icon: <Shield className="w-16 h-16 text-purple-600" />
  },
  {
    title: { 
      tr: 'Gerçek Hayattan Örnekler', 
      en: 'Real Life Examples', 
      es: 'Ejemplos de la Vida Real', 
      fr: 'Exemples de la Vraie Vie', 
      ru: 'Примеры из реальной жизни' 
    },
    content: { 
      tr: [
        '• Havayolu şirketleri yakıt fiyatlarına karşı hedge yapar.',
        '• İhracatç��lar döviz kurlarına karşı forward kullanır.',
        '• Yatırımcılar spekülasyon için opsiyon stratejileri uygular.'
      ],
      en: [
        '• Airlines hedge against fuel prices.',
        '• Exporters use forward against exchange rates.',
        '• Investors apply option strategies for speculation.'
      ],
      es: [
        '• Aerolíneas hacen cobertura contra precios de combustible.',
        '• Exportadores usan forward contra tipos de cambio.',
        '• Inversores aplican estrategias de opciones para especulación.'
      ],
      fr: [
        '• Compagnies aériennes font couverture contre prix carburant.',
        '• Exportateurs utilisent forward contre taux de change.',
        '• Investisseurs appliquent stratégies options pour spéculation.'
      ],
      ru: [
        '• Авиакомпании хеджируют против цен на топливо.',
        '• Экспортеры используют форварды против обменных курсов.',
        '• Инвесторы применяют опционные стратегии для спекуляций.'
      ]
    },
    example: { 
      tr: '🌍 Türk Hava Yolları yakıt maliyetlerini sabitlemek için futures kullanır.',
      en: '🌍 Turkish Airlines uses futures to fix fuel costs.',
      es: '🌍 Turkish Airlines usa futuros para fijar costos de combustible.',
      fr: '🌍 Turkish Airlines utilise futures pour fixer coûts carburant.',
      ru: '🌍 Turkish Airlines использует фьючерсы для фиксации затрат на топливо.'
    },
    icon: <Activity className="w-16 h-16 text-indigo-500" />
  },
  {
    title: { 
      tr: 'Sonuç ve Özet', 
      en: 'Conclusion and Summary', 
      es: 'Conclusión y Resumen', 
      fr: 'Conclusion et Résumé', 
      ru: 'Заключение и резюме' 
    },
    content: { 
      tr: [
        '• Türev piyasalar, modern finansın kalbidir.',
        '• Riskten korunma ve yatırım için vazgeçilmezdir.',
        '• **Temel ürünler:** Forward, Futures ve Opsiyon.',
        '• Basit stratejiler öğrenildikten sonra daha ileri seviyelere geçilebilir.'
      ],
      en: [
        '• Derivatives markets are the heart of modern finance.',
        '• Indispensable for risk protection and investment.',
        '• **Basic products:** Forward, Futures and Options.',
        '• After learning simple strategies, can move to more advanced levels.'
      ],
      es: [
        '• Los mercados de derivados son el corazón de las finanzas modernas.',
        '• Indispensables para protección de riesgo e inversión.',
        '• **Productos básicos:** Forward, Futuros y Opciones.',
        '• Después de aprender estrategias simples, se puede pasar a niveles más avanzados.'
      ],
      fr: [
        '• Les marchés de dérivés sont le cœur de la finance moderne.',
        '• Indispensables pour protection des risques et investissement.',
        '• **Produits de base:** Forward, Futures et Options.',
        '• Après avoir appris stratégies simples, peut passer à niveaux plus avancés.'
      ],
      ru: [
        '• Рынки деривативов - сердце современных финансов.',
        '• Незаменимы для защиты от рисков и инвестиций.',
        '• **Основные продукты:** Форварды, Фьючерсы и Опционы.',
        '• После изучения простых стратегий можно переходить к более продвинутым уровням.'
      ]
    },
    example: { 
      tr: '🎯 Bu bilgilerle türev piyasalarda bilinçli kararlar alabilirsiniz.',
      en: '🎯 With this knowledge, you can make informed decisions in derivatives markets.',
      es: '🎯 Con este conocimiento, puedes tomar decisiones informadas en mercados de derivados.',
      fr: '🎯 Avec cette connaissance, vous pouvez prendre décisions éclairées sur marchés de dérivés.',
      ru: '🎯 С этими знаниями вы можете принимать обоснованные решения на рынках деривативов.'
    },
    icon: <Award className="w-16 h-16 text-gold-500" />
  }
]