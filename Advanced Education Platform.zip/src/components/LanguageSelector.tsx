import React, { useState } from 'react'
import { useLanguage, Language } from './useLanguage'
import { Button } from './ui/button'
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover'
import { Check, Globe } from 'lucide-react'

const languages = [
  { code: 'tr', name: 'Türkçe', flag: '🇹🇷' },
  { code: 'en', name: 'English', flag: '🇺🇸' },
  { code: 'es', name: 'Español', flag: '🇪🇸' },
  { code: 'fr', name: 'Français', flag: '🇫🇷' },
  { code: 'ru', name: 'Русский', flag: '🇷🇺' },
  { code: 'de', name: 'Deutsch', flag: '🇩🇪' },
  { code: 'pt', name: 'Português', flag: '🇵🇹' }
]

export function LanguageSelector() {
  const { language, setLanguage } = useLanguage()
  const [isOpen, setIsOpen] = useState(false)
  
  const currentLang = languages.find(lang => lang.code === language) || languages[0]
  
  const handleLanguageChange = (langCode: string) => {
    console.log(`Switching to language: ${langCode}`)
    setLanguage(langCode as Language)
    setIsOpen(false)
  }

  return (
    <Popover open={isOpen} onOpenChange={setIsOpen}>
      <PopoverTrigger asChild>
        <Button 
          variant="outline" 
          size="sm" 
          className="flex items-center space-x-2 min-w-[120px] justify-start bg-background/50 backdrop-blur-sm border-border/50 hover:bg-background/80"
          onClick={() => setIsOpen(!isOpen)}
        >
          <Globe className="w-4 h-4" />
          <span className="text-lg">{currentLang.flag}</span>
          <span className="text-sm font-medium">{currentLang.name}</span>
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-48 p-2" align="end">
        <div className="space-y-1">
          {languages.map((lang) => (
            <button
              key={lang.code}
              onClick={() => handleLanguageChange(lang.code)}
              className={`
                w-full flex items-center justify-between px-3 py-2 rounded-md text-sm transition-colors
                ${language === lang.code 
                  ? 'bg-primary text-primary-foreground' 
                  : 'hover:bg-muted text-foreground'
                }
              `}
            >
              <div className="flex items-center space-x-2">
                <span className="text-lg">{lang.flag}</span>
                <span className="font-medium">{lang.name}</span>
              </div>
              {language === lang.code && (
                <Check className="w-4 h-4" />
              )}
            </button>
          ))}
        </div>
        <div className="mt-3 pt-2 border-t border-border">
          <p className="text-xs text-muted-foreground text-center">
            Seçiminiz kaydedilir
          </p>
        </div>
      </PopoverContent>
    </Popover>
  )
}