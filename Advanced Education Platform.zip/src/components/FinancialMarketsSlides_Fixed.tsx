import React from 'react'
import { 
  BarChart3, TrendingUp, Coins, Building2, Shield, Globe, Zap, Pickaxe, 
  Bitcoin, Building, PieChart, Users, Target, Briefcase, Brain, Scale, 
  Gavel, Network, AlertTriangle, Sparkles, Lightbulb, DollarSign,
  LineChart, Banknote, CreditCard, Landmark, TrendingDown, Eye,
  Activity, Settings, Gauge, Wallet
} from 'lucide-react'
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover'
import { Button } from './ui/button'

// Terim tanımları - Tooltip için
const termDefinitions = {
  tr: {
    'likidite': 'Bir varlığın kolay ve hızlı şekilde nakde çevrilebilme özelliği.',
    'ilk-halka-arz': 'Bir şirketin ilk kez halka açılarak hisse satması ve halka açık hale gelmesi.',
    'ikincil-piyasa': 'Halihazırda var olan hisselerin yatırımcılar arasında el değiştirdiği pazar.',
    'repo': 'Kısa vadeli, teminatlı borçlanma işlemi.',
    'temettü': 'Hisse sahiplerine şirket kârından yapılan paydaş ödemesi.',
    'opsiyon-hakları': 'Bir finansal sözleşmenin sahibine alma veya satma hakkı vermesi.',
    'etf': 'Bir sepet varlığı takip eden ve hisse gibi alınıp satılabilen fon.',
    'defi': 'Blokzincir üzerinde çalışan, merkezi bir aracı olmadan finansal hizmet sunan uygulamalar.',
    'volatilite': 'Bir varlığın fiyatının ne kadar hızlı ve geniş hareket ettiğinin ölçüsü.',
    'finansal-bulasma': 'Bir piyasadaki veya ülkedeki şokların diğer piyasalara yayılma riski.',
    'cbdc': 'Ülke merkez bankası tarafından çıkarılabilecek dijital para biçimi.',
    'beta': 'Bir hisse senedinin piyasa hareketlerine ne kadar duyarlı olduğunun ölçüsü.',
    'var': 'Belirli bir süre ve güven aralığında oluşabilecek maksimum kayıp miktarı.',
    'sec': 'Amerikan Sermaye Piyasası Kurulu - finansal piyasaları düzenleyen kurum.',
    'spk': 'Türkiye Sermaye Piyasası Kurulu - finansal piyasaları düzenleyen kurum.',
    'niceliksel-genişleme': 'Merkez bankasının tahvil alarak piyasaya para sürmesi işlemi.',
    'vix': 'Piyasa korku endeksi - gelecekteki volatilite beklentisini ölçen gösterge.',
    'kaldıraç': 'Ödünç alınan parayla yatırım yapmak - kazancı ve kaybı büyütür.',
    'akıllı-kontratlar': 'Blokzincir üzerinde otomatik çalışan programlanmış sözleşmeler.',
    'nyse': 'New York Menkul Kıymetler Borsası - dünyanın en büyük borsası.',
    'bist': 'Borsa İstanbul - Türkiye\'nin ana borsası.',
    'lse': 'Londra Menkul Kıymetler Borsası - Avrupa\'nın büyük borsalarından biri.',
    'dürtme-teknikleri': 'İnsanları daha iyi finansal kararlar almaya yönlendiren yumuşak müdahale yöntemleri.',
    'esg': 'Çevresel, Sosyal ve Yönetişim kriterlerine göre değerlendirilen sürdürülebilir yatırım yaklaşımı.'
  },
  en: {
    'liquidity': 'The ability of an asset to be easily and quickly converted to cash.',
    'ipo': 'Initial Public Offering - when a company goes public for the first time.',
    'secondary-market': 'Market where existing securities are traded among investors.',
    'repo': 'Short-term, collateralized borrowing transaction.',
    'dividend': 'Payment made to shareholders from company profits.',
    'option-rights': 'Rights that give the holder the ability to buy or sell an asset.',
    'etf': 'Exchange-traded fund that tracks a basket of assets.',
    'defi': 'Decentralized finance applications running on blockchain.',
    'volatility': 'Measure of how quickly and widely an asset\'s price moves.',
    'financial-contagion': 'Risk of shocks in one market spreading to other markets.',
    'cbdc': 'Central Bank Digital Currency issued by a country\'s central bank.',
    'beta': 'Measure of how sensitive a stock is to market movements.',
    'var': 'Value at Risk - maximum potential loss over a specific period.',
    'sec': 'Securities and Exchange Commission - US financial market regulator.',
    'spk': 'Capital Markets Board of Turkey - Turkish financial market regulator.',
    'quantitative-easing': 'Central bank policy of buying bonds to inject money into the market.',
    'vix': 'Volatility Index - measures market fear and expected volatility.',
    'leverage': 'Using borrowed money to invest - amplifies both gains and losses.',
    'smart-contracts': 'Self-executing contracts with terms written into blockchain code.',
    'nyse': 'New York Stock Exchange - world\'s largest stock exchange.',
    'bist': 'Borsa Istanbul - Turkey\'s main stock exchange.',
    'lse': 'London Stock Exchange - one of Europe\'s major exchanges.',
    'nudge-techniques': 'Soft intervention methods to guide people toward better financial decisions.',
    'esg': 'Environmental, Social, and Governance criteria for sustainable investing.'
  }
}

// Tooltip bileşeni
const TermTooltip = ({ term, children, language = 'tr' }: { 
  term: string
  children: React.ReactNode
  language?: string 
}) => {
  const definition = termDefinitions[language as keyof typeof termDefinitions]?.[term]
  
  if (!definition) return <>{children}</>
  
  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button 
          variant="ghost" 
          size="sm" 
          className="h-auto p-0 text-inherit hover:bg-transparent inline-flex items-center gap-1"
        >
          <span className="text-base font-medium">{children}</span>
          <span className="inline-flex items-center justify-center w-3 h-3 text-xs text-white bg-blue-500 hover:bg-blue-600 rounded-full cursor-help transition-colors duration-200 flex-shrink-0">
            ?
          </span>
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80 p-3 text-sm" side="top">
        <div className="font-medium text-primary mb-1 capitalize">{term.replace('-', ' ')}</div>
        <div className="text-muted-foreground">{definition}</div>
      </PopoverContent>
    </Popover>
  )
}

export const financialMarketsSlides = [
  {
    title: { 
      tr: 'Finansal Piyasalar Nedir?', 
      en: 'What are Financial Markets?', 
      es: '¿Qué son los Mercados Financieros?', 
      fr: 'Que sont les Marchés Financiers?', 
      ru: 'Что такое финансовые рынки?' 
    },
    content: { 
      tr: [
        '• Finansal piyasalar, para ve yatırım araçlarının alınıp satıldığı organize platformlardır (borsa, banka, döviz bürosu gibi)',
        '• Para biriktiren kişilerle sermayeye ihtiyacı olan şirketleri bir araya getirir - tasarrufları ekonomiye kazandırır',
        '• Temel işlevleri: Paranın ihtiyacı olana yönlendirilmesi, gerçek fiyat oluşturma, risklerin dağıtılması ve kolayca alım-satım imkanı',
        '• Bireysel yatırımcılara servet biriktirme şansı verir, şirketlere büyüme sermayesi sağlar',
        '• Sağlıklı çalışan piyasalar ülke ekonomisinin büyümesini hızlandırır ve yenilikleri destekler'
      ],
      en: [
        '• Financial markets are organized platforms where money and investment instruments are traded',
        '• They bring together savers and those in need of capital - channeling savings to the economy',
        '• Core functions: Capital allocation, price discovery, risk distribution and easy trading',
        '• Provides wealth accumulation opportunities for individuals, growth capital for companies',
        '• Well-functioning markets accelerate economic growth and support innovation'
      ]
    },
    contentWithTooltips: {
      tr: (
        <div className="space-y-3">
          <div>• Finansal piyasalar, para ve yatırım araçlarının alınıp satıldığı organize platformlardır (borsa, banka, döviz bürosu gibi)</div>
          <div>• Para biriktiren kişilerle sermayeye ihtiyacı olan şirketleri bir araya getirir - tasarrufları ekonomiye kazandırır</div>
          <div>• Temel işlevleri: Paranın ihtiyacı olana yönlendirilmesi, gerçek fiyat oluşturma, risklerin dağıtılması ve kolayca alım-satım imkanı (<TermTooltip term="likidite">likidite</TermTooltip>)</div>
          <div>• Bireysel yatırımcılara servet biriktirme şansı verir, şirketlere büyüme sermayesi sağlar</div>
          <div>• Sağlıklı çalışan piyasalar ülke ekonomisinin büyümesini hızlandırır ve yenilikleri destekler</div>
        </div>
      ),
      en: (
        <div className="space-y-3">
          <div>• Financial markets are organized platforms where money and investment instruments are traded</div>
          <div>• They bring together savers and those in need of capital - channeling savings to the economy</div>
          <div>• Core functions: Capital allocation, price discovery, risk distribution and easy trading (<TermTooltip term="liquidity" language="en">liquidity</TermTooltip>)</div>
          <div>• Provides wealth accumulation opportunities for individuals, growth capital for companies</div>
          <div>• Well-functioning markets accelerate economic growth and support innovation</div>
        </div>
      )
    },
    example: { 
      tr: '💼 2025\'te global finansal piyasalar, yüksek volatilite nedeniyle yatırımcılara %10 ortalama getiri sağladı; ancak ticaret gerilimleri riskleri artırdı.',
      en: '💼 In 2025, global financial markets provided 10% average return to investors due to high volatility; however trade tensions increased risks.',
      es: '💼 En 2025, los mercados financieros globales proporcionaron 10% de retorno promedio a inversionistas debido a alta volatilidad; sin embargo tensiones comerciales aumentaron riesgos.',
      fr: '💼 En 2025, les marchés financiers mondiaux ont fourni 10% de rendement moyen aux investisseurs en raison de la forte volatilité ; cependant les tensions commerciales ont augmenté les risques.',
      ru: '💼 В 2025 году глобальные финансовые рынки обеспечили 10% средней доходности инвесторам из-за высокой волатильности; однако торговая напряженность увеличила риски.'
    },
    icon: <BarChart3 className="w-16 h-16 text-blue-500" />
  }
]

// Quiz soruları
export const financialMarketsQuiz = [
  {
    question: {
      tr: 'Finansal piyasaların temel işlevi nedir?',
      en: 'What is the primary function of financial markets?'
    },
    answers: {
      tr: [
        'Sadece hisse senedi alım-satımı',
        'Para biriktiren ve sermayeye ihtiyaç duyanları buluşturmak',
        'Sadece devlet borçlanması',
        'Sadece döviz ticareti'
      ],
      en: [
        'Only stock trading',
        'Bringing together savers and those needing capital',
        'Only government borrowing', 
        'Only currency trading'
      ]
    },
    correct: 1
  }
]