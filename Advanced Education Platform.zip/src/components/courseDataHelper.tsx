import { Language } from './useLanguage'
import { Course, courses } from './courseData'

// Function to ensure unique course data for language processing
export function getCoursesForLanguage(language: Language): Course[] {
  // Create a map to ensure no duplicate IDs
  const uniqueCourses = new Map<number, Course>()
  
  // Process each course and ensure it's unique by ID
  courses.forEach(course => {
    if (!uniqueCourses.has(course.id)) {
      // Keep the original course structure intact
      uniqueCourses.set(course.id, course)
    }
  })
  
  // Return array of unique courses
  return Array.from(uniqueCourses.values())
}