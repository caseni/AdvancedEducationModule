import React from 'react'
import { 
  BarChart3, TrendingUp, Coins, Building2, Shield, Globe, Zap, Pickaxe, 
  Bitcoin, Building, PieChart, Users, Target, Briefcase, Brain, Scale, 
  Gavel, Network, AlertTriangle, Sparkles, Lightbulb, DollarSign,
  LineChart, Banknote, CreditCard, Landmark, TrendingDown, Eye,
  Activity, Settings, Gauge, Wallet
} from 'lucide-react'
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover'
import { Button } from './ui/button'

// Terim tanımları - Tooltip için
const termDefinitions = {
  tr: {
    'likidite': 'Bir varlığın kolay ve hızlı şekilde nakde çevrilebilme özelliği.',
    'ilk-halka-arz': 'Bir şirketin ilk kez halka açılarak hisse satması ve halka açık hale gelmesi.',
    'ikincil-piyasa': 'Halihazırda var olan hisselerin yatırımcılar arasında el değiştirdiği pazar.',
    'repo': 'Kısa vadeli, teminatlı borçlanma işlemi.',
    'temettü': 'Hisse sahiplerine şirket kârından yapılan paydaş ödemesi.',
    'opsiyon-hakları': 'Bir finansal sözleşmenin sahibine alma veya satma hakkı vermesi.',
    'etf': 'Bir sepet varlığı takip eden ve hisse gibi alınıp satılabilen fon.',
    'defi': 'Blokzincir üzerinde çalışan, merkezi bir aracı olmadan finansal hizmet sunan uygulamalar.',
    'volatilite': 'Bir varlığın fiyatının ne kadar hızlı ve geniş hareket ettiğinin ölçüsü.',
    'finansal-bulasma': 'Bir piyasadaki veya ülkedeki şokların diğer piyasalara yayılma riski.',
    'cbdc': 'Ülke merkez bankası tarafından çıkarılabilecek dijital para biçimi.',
    'beta': 'Bir hisse senedinin piyasa hareketlerine ne kadar duyarlı olduğunun ölçüsü.',
    'var': 'Belirli bir süre ve güven aralığında oluşabilecek maksimum kayıp miktarı.',
    'sec': 'Amerikan Sermaye Piyasası Kurulu - finansal piyasaları düzenleyen kurum.',
    'spk': 'Türkiye Sermaye Piyasası Kurulu - finansal piyasaları düzenleyen kurum.',
    'niceliksel-genişleme': 'Merkez bankasının tahvil alarak piyasaya para sürmesi işlemi.',
    'vix': 'Piyasa korku endeksi - gelecekteki volatilite beklentisini ölçen gösterge.',
    'kaldıraç': 'Ödünç alınan parayla yatırım yapmak - kazancı ve kaybı büyütür.',
    'akıllı-kontratlar': 'Blokzincir üzerinde otomatik çalışan programlanmış sözleşmeler.',
    'nyse': 'New York Menkul Kıymetler Borsası - dünyanın en büyük borsası.',
    'bist': 'Borsa İstanbul - Türkiye\'nin ana borsası.',
    'lse': 'Londra Menkul Kıymetler Borsası - Avrupanın büyük borsalarından biri.',
    'dürtme-teknikleri': 'İnsanları daha iyi finansal kararlar almaya yönlendiren yumuşak müdahale yöntemleri.',
    'esg': 'Sürdürülebilir yatırım yaklaşımı.',
    'dxy': 'ABD Dolar Endeksi - doların diğer başlıca para birimlerine karşı değerini ölçen endeks.'
  },
  en: {
    'liquidity': 'The ability of an asset to be easily and quickly converted to cash.',
    'ipo': 'Initial Public Offering - when a company goes public for the first time.',
    'secondary-market': 'Market where existing securities are traded among investors.',
    'repo': 'Short-term, collateralized borrowing transaction.',
    'dividend': 'Payment made to shareholders from company profits.',
    'option-rights': 'Rights that give the holder the ability to buy or sell an asset.',
    'etf': 'Exchange-traded fund that tracks a basket of assets.',
    'defi': 'Decentralized finance applications running on blockchain.',
    'volatility': 'Measure of how quickly and widely an asset\'s price moves.',
    'financial-contagion': 'Risk of shocks in one market spreading to other markets.',
    'cbdc': 'Central Bank Digital Currency issued by a country\'s central bank.',
    'beta': 'Measure of how sensitive a stock is to market movements.',
    'var': 'Value at Risk - maximum potential loss over a specific period.',
    'sec': 'Securities and Exchange Commission - US financial market regulator.',
    'spk': 'Capital Markets Board of Turkey - Turkish financial market regulator.',
    'quantitative-easing': 'Central bank policy of buying bonds to inject money into the market.',
    'vix': 'Volatility Index - measures market fear and expected volatility.',
    'leverage': 'Using borrowed money to invest - amplifies both gains and losses.',
    'smart-contracts': 'Self-executing contracts with terms written into blockchain code.',
    'nyse': 'New York Stock Exchange - world\'s largest stock exchange.',
    'bist': 'Borsa Istanbul - Turkey\'s main stock exchange.',
    'lse': 'London Stock Exchange - one of Europe\'s major exchanges.',
    'nudge-techniques': 'Soft intervention methods to guide people toward better financial decisions.',
    'esg': 'Environmental, Social, and Governance criteria for sustainable investing.',
    'dxy': 'US Dollar Index - measures the value of the dollar against major currencies.'
  },
  es: {
    'liquidez': 'La capacidad de un activo de ser fácil y rápidamente convertido a efectivo.',
    'oferta-publica-inicial': 'Cuando una empresa sale pública por primera vez.',
    'mercado-secundario': 'Mercado donde valores existentes se comercian entre inversores.',
    'repo': 'Transacción de préstamo a corto plazo con garantía.',
    'dividendo': 'Pago hecho a accionistas de las ganancias de la empresa.',
    'derechos-opcion': 'Derechos que dan al tenedor la capacidad de comprar o vender un activo.',
    'etf': 'Fondo cotizado que rastrea una cesta de activos.',
    'defi': 'Aplicaciones de finanzas descentralizadas ejecutándose en blockchain.',
    'volatilidad': 'Medida de qué tan rápido y ampliamente se mueve el precio de un activo.',
    'contagio-financiero': 'Riesgo de choques en un mercado extendiéndose a otros mercados.',
    'cbdc': 'Moneda Digital del Banco Central emitida por el banco central de un país.',
    'beta': 'Medida de qué tan sensible es una acción a los movimientos del mercado.',
    'var': 'Valor en Riesgo - pérdida potencial máxima en un período específico.',
    'sec': 'Comisión de Valores - regulador del mercado financiero de EE.UU.',
    'spk': 'Junta de Mercados de Capital de Turquía - regulador del mercado financiero turco.',
    'expansion-cuantitativa': 'Política del banco central de comprar bonos para inyectar dinero al mercado.',
    'vix': 'Índice de Volatilidad - mide el miedo del mercado y la volatilidad esperada.',
    'apalancamiento': 'Usar dinero prestado para invertir - amplifica tanto ganancias como pérdidas.',
    'contratos-inteligentes': 'Contratos autoejecutables con términos escritos en código blockchain.',
    'nyse': 'Bolsa de Valores de Nueva York - la bolsa más grande del mundo.',
    'bist': 'Borsa Istanbul - la bolsa principal de Turquía.',
    'lse': 'Bolsa de Valores de Londres - una de las principales bolsas de Europa.',
    'tecnicas-empujon': 'Métodos de intervención suave para guiar a las personas hacia mejores decisiones financieras.',
    'esg': 'Criterios Ambientales, Sociales y de Gobernanza para inversión sostenible.',
    'dxy': 'Índice del Dólar Estadounidense - mide el valor del dólar contra las principales monedas.'
  },
  fr: {
    'liquidite': 'La capacité d\'un actif à être facilement et rapidement converti en espèces.',
    'introduction-bourse': 'Quand une entreprise devient publique pour la première fois.',
    'marche-secondaire': 'Marché où les valeurs existantes sont échangées entre investisseurs.',
    'repo': 'Transaction d\'emprunt à court terme avec garantie.',
    'dividende': 'Paiement fait aux actionnaires des profits de l\'entreprise.',
    'droits-option': 'Droits qui donnent au détenteur la capacité d\'acheter ou vendre un actif.',
    'etf': 'Fonds négocié en bourse qui suit un panier d\'actifs.',
    'defi': 'Applications de finance décentralisée fonctionnant sur blockchain.',
    'volatilite': 'Mesure de la rapidité et de l\'ampleur du mouvement du prix d\'un actif.',
    'contagion-financiere': 'Risque de chocs dans un marché se propageant à d\'autres marchés.',
    'cbdc': 'Monnaie Numérique de Banque Centrale émise par la banque centrale d\'un pays.',
    'beta': 'Mesure de la sensibilité d\'une action aux mouvements du marché.',
    'var': 'Valeur à Risque - perte potentielle maximale sur une période spécifique.',
    'sec': 'Commission des Valeurs - régulateur du marché financier américain.',
    'spk': 'Conseil des Marchés de Capitaux de Turquie - régulateur du marché financier turc.',
    'assouplissement-quantitatif': 'Politique de la banque centrale d\'acheter des obligations pour injecter de l\'argent sur le marché.',
    'vix': 'Indice de Volatilité - mesure la peur du marché et la volatilité attendue.',
    'effet-levier': 'Utiliser de l\'argent emprunté pour investir - amplifie les gains et les pertes.',
    'contrats-intelligents': 'Contrats auto-exécutants avec termes écrits dans le code blockchain.',
    'nyse': 'Bourse de New York - la plus grande bourse du monde.',
    'bist': 'Borsa Istanbul - la bourse principale de la Turquie.',
    'lse': 'Bourse de Londres - une des principales bourses d\'Europe.',
    'techniques-incitation': 'Méthodes d\'intervention douce pour guider les gens vers de meilleures décisions financières.',
    'esg': 'Critères Environnementaux, Sociaux et de Gouvernance pour l\'investissement durable.',
    'dxy': 'Indice du Dollar Américain - mesure la valeur du dollar contre les principales devises.'
  },
  ru: {
    'ликвидность': 'Способность актива быть легко и быстро конвертированным в наличные.',
    'первичное-размещение': 'Когда компания впервые становится публичной.',
    'вторичный-рынок': 'Рынок, где существующие ценные бумаги торгуются между инвесторами.',
    'репо': 'Краткосрочная обеспеченная заемная транзакция.',
    'дивиденд': 'Выплата акционерам из прибыли компании.',
    'права-опционов': 'Права, дающие держателю возможность купить или продать актив.',
    'etf': 'Биржевой фонд, отслеживающий корзину активов.',
    'defi': 'Децентрализованные финансовые приложения, работающие на блокчейне.',
    'волатильность': 'Мера того, как быстро и широко движется цена актива.',
    'финансовое-заражение': 'Риск распространения шоков с одного рынка на другие рынки.',
    'cbdc': 'Цифровая валюта центрального банка, выпущенная центральным банком страны.',
    'бета': 'Мера чувствительности акции к движениям рынка.',
    'var': 'Стоимость под риском - максимальная потенциальная потеря за определенный период.',
    'sec': 'Комиссия по ценным бумагам - регулятор финансового рынка США.',
    'spk': 'Совет рынков капитала Турции - регулятор турецкого финансового рынка.',
    'количественное-смягчение': 'Политика центрального банка покупки облигаций для вливания денег на рынок.',
    'vix': 'Индекс волатильности - измеряет страх рынка и ожидаемую волатильность.',
    'кредитное-плечо': 'Использование заемных денег для инвестиций - усиливает как прибыли, так и убытки.',
    'умные-контракты': 'Самоисполняющиеся контракты с условиями, записанными в коде блокчейна.',
    'nyse': 'Нью-Йоркская фондовая биржа - крупнейшая биржа в мире.',
    'bist': 'Борса Стамбул - главная биржа Турции.',
    'lse': 'Лондонская фондовая биржа - одна из крупнейших бирж Европы.',
    'техники-подталкивания': 'Мягкие методы вмешательства для направления людей к лучшим финансовым решениям.',
    'esg': 'Экологические, социальные и управленческие критерии для устойчивого инвестирования.',
    'dxy': 'Индекс доллара США - измеряет стоимость доллара против основных валют.'
  }
}

// Tooltip bileşeni
const TermTooltip = ({ term, children, language = 'tr' }: { 
  term: string
  children: React.ReactNode
  language?: string 
}) => {
  const definition = termDefinitions[language as keyof typeof termDefinitions]?.[term]
  
  if (!definition) return <>{children}</>
  
  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button 
          variant="ghost" 
          size="sm" 
          className="h-auto p-0 text-inherit hover:bg-transparent inline-flex items-center gap-1"
        >
          <span className="text-base font-medium">{children}</span>
          <span className="inline-flex items-center justify-center w-3 h-3 text-xs text-white bg-blue-500 hover:bg-blue-600 rounded-full cursor-help transition-colors duration-200 flex-shrink-0">
            ?
          </span>
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80 p-3 text-sm" side="top">
        <div className="font-medium text-primary mb-1 capitalize">{term.replace('-', ' ')}</div>
        <div className="text-muted-foreground">{definition}</div>
      </PopoverContent>
    </Popover>
  )
}

export const financialMarketsSlides = [
  {
    title: { 
      tr: 'Finansal Piyasalar Nedir?', 
      en: 'What are Financial Markets?', 
      es: '¿Qué son los Mercados Financieros?', 
      fr: 'Que sont les Marchés Financiers?', 
      ru: 'Что такое финансовые рынки?' 
    },
    content: { 
      tr: [
        '• Finansal piyasalar, para ve yatırım araçlarının alınıp satıldığı organize platformlardır (borsa, banka, döviz bürosu gibi)',
        '• Para biriktiren kişilerle sermayeye ihtiyacı olan şirketleri bir araya getirir - tasarrufları ekonomiye kazandırır',
        '• Temel işlevleri: Paranın ihtiyacı olana yönlendirilmesi, gerçek fiyat oluşturma, risklerin dağıtılması ve kolayca alım-satım imkanı',
        '• Bireysel yatırımcılara servet biriktirme şansı verir, şirketlere büyüme sermayesi sağlar',
        '• Sağlıklı çalışan piyasalar ülke ekonomisinin büyümesini hızlandırır ve yenilikleri destekler'
      ],
      en: [
        '• Financial markets are organized platforms where money and investment instruments are traded',
        '• They bring together savers and those in need of capital - channeling savings to the economy',
        '• Core functions: Capital allocation, price discovery, risk distribution and easy trading',
        '• Provides wealth accumulation opportunities for individuals, growth capital for companies',
        '• Well-functioning markets accelerate economic growth and support innovation'
      ],
      es: [
        '• Los mercados financieros son plataformas organizadas donde se comercian dinero e instrumentos de inversión',
        '• Conectan ahorradores con empresas que necesitan capital - canalizan ahorros hacia la economía',
        '• Funciones principales: Asignación de capital, descubrimiento de precios, distribución de riesgos y trading fácil',
        '• Proporciona oportunidades de acumulación de riqueza para individuos, capital de crecimiento para empresas',
        '• Mercados que funcionan bien aceleran el crecimiento económico y apoyan la innovación'
      ],
      fr: [
        '• Les marchés financiers sont des plateformes organisées où argent et instruments d\'investissement sont échangés',
        '• Ils réunissent épargnants et entreprises ayant besoin de capital - canalisent épargnes vers économie',
        '• Fonctions principales: Allocation de capital, découverte des prix, distribution des risques et trading facile',
        '• Fournit opportunités d\'accumulation de richesse pour individus, capital de croissance pour entreprises',
        '• Marchés bien fonctionnels accélèrent croissance économique et soutiennent innovation'
      ],
      ru: [
        '• Финансовые рынки - это организованные платформы, где торгуются деньги и инвестиционные инструменты',
        '• Они соединяют вкладчиков с компаниями, нуждающимися в капитале - направляют сбережения в экономику',
        '• Основные функции: Распределение капитала, ценообразование, распределение рисков и легкая торговля',
        '• Предоставляет возможности накопления богатства для частных лиц, капитал роста для компаний',
        '• Хорошо функционирующие рынки ускоряют экономический рост и поддерживают инновации'
      ]
    },
    contentWithTooltips: {
      tr: (
        <div className="space-y-3">
          <div>• Finansal piyasalar, para ve yatırım araçlarının alınıp satıldığı organize platformlardır (borsa, banka, döviz bürosu gibi)</div>
          <div>• Para biriktiren kişilerle sermayeye ihtiyacı olan şirketleri bir araya getirir - tasarrufları ekonomiye kazandırır</div>
          <div>• Temel işlevleri: Paranın ihtiyacı olana yönlendirilmesi, gerçek fiyat oluşturma, risklerin dağıtılması ve kolayca alım-satım imkanı (<TermTooltip term="likidite">likidite</TermTooltip>)</div>
          <div>• Bireysel yatırımcılara servet biriktirme şansı verir, şirketlere büyüme sermayesi sağlar</div>
          <div>• Sağlıklı çalışan piyasalar ülke ekonomisinin büyümesini hızlandırır ve yenilikleri destekler</div>
        </div>
      ),
      en: (
        <div className="space-y-3">
          <div>• Financial markets are organized platforms where money and investment instruments are traded</div>
          <div>• They bring together savers and those in need of capital - channeling savings to the economy</div>
          <div>• Core functions: Capital allocation, price discovery, risk distribution and easy trading (<TermTooltip term="liquidity" language="en">liquidity</TermTooltip>)</div>
          <div>• Provides wealth accumulation opportunities for individuals, growth capital for companies</div>
          <div>• Well-functioning markets accelerate economic growth and support innovation</div>
        </div>
      ),
      es: (
        <div className="space-y-3">
          <div>• Los mercados financieros son plataformas organizadas donde se comercian dinero e instrumentos de inversión</div>
          <div>• Conectan ahorradores con empresas que necesitan capital - canalizan ahorros hacia la economía</div>
          <div>• Funciones principales: Asignación de capital, descubrimiento de precios, distribución de riesgos y trading fácil (<TermTooltip term="liquidez" language="es">liquidez</TermTooltip>)</div>
          <div>• Proporciona oportunidades de acumulación de riqueza para individuos, capital de crecimiento para empresas</div>
          <div>• Mercados que funcionan bien aceleran el crecimiento económico y apoyan la innovación</div>
        </div>
      ),
      fr: (
        <div className="space-y-3">
          <div>• Les marchés financiers sont des plateformes organisées où argent et instruments d'investissement sont échangés</div>
          <div>• Ils réunissent épargnants et entreprises ayant besoin de capital - canalisent épargnes vers économie</div>
          <div>• Fonctions principales: Allocation de capital, découverte des prix, distribution des risques et trading facile (<TermTooltip term="liquidite" language="fr">liquidité</TermTooltip>)</div>
          <div>• Fournit opportunités d'accumulation de richesse pour individus, capital de croissance pour entreprises</div>
          <div>• Marchés bien fonctionnels accélèrent croissance économique et soutiennent innovation</div>
        </div>
      ),
      ru: (
        <div className="space-y-3">
          <div>• Финансовые рынки - это организованные платформы, где торгуются деньги и инвестиционные инструменты</div>
          <div>• Они соединяют вкладчиков с компаниями, нуждающимися в капитале - направляют сбережения в экономику</div>
          <div>• Основные функции: Распределение капитала, ценообразование, распределение рисков и легкая торговля (<TermTooltip term="ликвидность" language="ru">ликвидность</TermTooltip>)</div>
          <div>• Предоставляет возможности накопления богатства для частных лиц, капитал роста для компаний</div>
          <div>• Хорошо функционирующие рынки ускоряют экономический рост и поддерживают инновации</div>
        </div>
      )
    },
    example: { 
      tr: '💼 2025\'te global finansal piyasalar, yüksek volatilite nedeniyle yatırımcılara %10 ortalama getiri sağladı; ancak ticaret gerilimleri riskleri artırdı.',
      en: '💼 In 2025, global financial markets provided 10% average return to investors due to high volatility; however trade tensions increased risks.',
      es: '💼 En 2025, los mercados financieros globales proporcionaron 10% de retorno promedio a inversionistas debido a alta volatilidad; sin embargo tensiones comerciales aumentaron riesgos.',
      fr: '💼 En 2025, les marchés financiers mondiaux ont fourni 10% de rendement moyen aux investisseurs en raison de la forte volatilité ; cependant les tensions commerciales ont augmenté les risques.',
      ru: '💼 В 2025 году глобальные финансовые рынки обеспечили 10% средней доходности инвесторам из-за высокой волатильности; однако торговая напряженность увеличила риски.'
    },
    icon: <BarChart3 className="w-16 h-16 text-blue-500" />
  },
  {
    title: { 
      tr: 'Finansal Piyasa Türleri', 
      en: 'Types of Financial Markets', 
      es: 'Tipos de Mercados Financieros', 
      fr: 'Types de Marchés Financiers', 
      ru: 'Типы финансовых рынков' 
    },
    content: { 
      tr: [
        '• Para Piyasası: Kısa vadeli (1 yıl altı) borçlanma araçları - çok güvenli ama düşük kazanç (devlet bonosu, banka mevduatı)',
        '• Sermaye Piyasası: Uzun vadeli yatırımlar - hisse senetleri (şirket ortaklığı) ve tahviller (borç verme belgesi)',
        '• Birincil Piyasa: Şirketlerin ilk kez halka açıldığı yer (IPO = İlk Halka Arz); taze para toplama alanı',
        '• İkincil Piyasa: Halihazırda var olan hisselerin el değiştirdiği yer (Borsa İstanbul gibi); günlük alım-satım merkezi',
        '• Her piyasa türü farklı risk seviyesi ve kazanç beklentisi sunar - yaşınıza ve hedeflerinize göre seçim yapın'
      ],
      en: [
        '• Money Market: Short-term (under 1 year) debt instruments - very safe but low return (government bills, bank deposits)',
        '• Capital Market: Long-term investments - stocks (company ownership) and bonds (debt certificates)',
        '• Primary Market: Where companies go public for the first time (IPO = Initial Public Offering); fresh capital raising',
        '• Secondary Market: Where existing stocks change hands (like Istanbul Stock Exchange); daily trading center',
        '• Each market type offers different risk levels and return expectations - choose according to your age and goals'
      ],
      es: [
        '• Mercado Monetario: Instrumentos de deuda a corto plazo (menos de 1 año) - muy seguros pero bajo retorno',
        '• Mercado de Capitales: Inversiones a largo plazo - acciones (propiedad de empresa) y bonos (certificados de deuda)',
        '• Mercado Primario: Donde empresas salen públicas por primera vez (IPO); recaudación de capital fresco',
        '• Mercado Secundario: Donde acciones existentes cambian de manos; centro de trading diario',
        '• Cada tipo de mercado ofrece diferentes niveles de riesgo y expectativas de retorno'
      ],
      fr: [
        '• Marché Monétaire: Instruments de dette à court terme (moins d\'1 an) - très sûrs mais faible rendement',
        '• Marché des Capitaux: Investissements à long terme - actions (propriété d\'entreprise) et obligations (certificats de dette)',
        '• Marché Primaire: Où entreprises deviennent publiques pour la première fois (IPO); levée de capital frais',
        '• Marché Secondaire: Où actions existantes changent de mains; centre de trading quotidien',
        '• Chaque type de marché offre différents niveaux de risque et attentes de rendement'
      ],
      ru: [
        '• Денежный рынок: Краткосрочные (менее 1 года) долговые инструменты - очень безопасные но низкая доходность',
        '• Рынок капиталов: Долгосрочные инвестиции - акции (собственность компании) и облигации (долговые сертификаты)',
        '• Первичный рынок: Где компании становятся публичными впервые (IPO); привлечение свежего капитала',
        '• Вторичный рынок: Где существующие акции переходят из рук в руки; центр ежедневной торговли',
        '• Каждый тип рынка предлагает разные уровни риска и ожидания доходности'
      ]
    },
    contentWithTooltips: {
      tr: (
        <div className="space-y-3">
          <div>• Para Piyasası: Kısa vadeli (1 yıl altı) borçlanma araçları - çok güvenli ama düşük kazanç (devlet bonosu, banka mevduatı)</div>
          <div>• Sermaye Piyasası: Uzun vadeli yatırımlar - hisse senetleri (şirket ortaklığı) ve tahviller (borç verme belgesi)</div>
          <div>• Birincil Piyasa: Şirketlerin ilk kez halka açıldığı yer (<TermTooltip term="ilk-halka-arz">İlk Halka Arz</TermTooltip>); taze para toplama alanı</div>
          <div>• <TermTooltip term="ikincil-piyasa">İkincil Piyasa</TermTooltip>: Halihazırda var olan hisselerin el değiştirdiği yer (Borsa İstanbul gibi); günlük alım-satım merkezi</div>
          <div>• Her piyasa türü farklı risk seviyesi ve kazanç beklentisi sunar - yaşınıza ve hedeflerinize göre seçim yapın</div>
        </div>
      ),
      en: (
        <div className="space-y-3">
          <div>• Money Market: Short-term (under 1 year) debt instruments - very safe but low return (government bills, bank deposits)</div>
          <div>• Capital Market: Long-term investments - stocks (company ownership) and bonds (debt certificates)</div>
          <div>• Primary Market: Where companies go public for the first time (<TermTooltip term="ipo" language="en">IPO</TermTooltip>); fresh capital raising</div>
          <div>• <TermTooltip term="secondary-market" language="en">Secondary Market</TermTooltip>: Where existing stocks change hands (like Istanbul Stock Exchange); daily trading center</div>
          <div>• Each market type offers different risk levels and return expectations - choose according to your age and goals</div>
        </div>
      ),
      es: (
        <div className="space-y-3">
          <div>• Mercado Monetario: Instrumentos de deuda a corto plazo (menos de 1 año) - muy seguros pero bajo retorno</div>
          <div>• Mercado de Capitales: Inversiones a largo plazo - acciones (propiedad de empresa) y bonos (certificados de deuda)</div>
          <div>• Mercado Primario: Donde empresas salen públicas por primera vez (<TermTooltip term="oferta-publica-inicial" language="es">IPO</TermTooltip>); recaudación de capital fresco</div>
          <div>• <TermTooltip term="mercado-secundario" language="es">Mercado Secundario</TermTooltip>: Donde acciones existentes cambian de manos; centro de trading diario</div>
          <div>• Cada tipo de mercado ofrece diferentes niveles de riesgo y expectativas de retorno</div>
        </div>
      ),
      fr: (
        <div className="space-y-3">
          <div>• Marché Monétaire: Instruments de dette à court terme (moins d'1 an) - très sûrs mais faible rendement</div>
          <div>• Marché des Capitaux: Investissements à long terme - actions (propriété d'entreprise) et obligations (certificats de dette)</div>
          <div>• Marché Primaire: Où entreprises deviennent publiques pour la première fois (<TermTooltip term="introduction-bourse" language="fr">IPO</TermTooltip>); levée de capital frais</div>
          <div>• <TermTooltip term="marche-secondaire" language="fr">Marché Secondaire</TermTooltip>: Où actions existantes changent de mains; centre de trading quotidien</div>
          <div>• Chaque type de marché offre différents niveaux de risque et attentes de rendement</div>
        </div>
      ),
      ru: (
        <div className="space-y-3">
          <div>• Денежный рынок: Краткосрочные (менее 1 года) долговые инструменты - очень безопасные но низкая доходность</div>
          <div>• Рынок капиталов: Долгосрочные инвестиции - акции (собственность компании) и облигации (долговые сертификаты)</div>
          <div>• Первичный рынок: Где компании становятся публичными впервые (<TermTooltip term="первичное-размещение" language="ru">IPO</TermTooltip>); привлечение свежего капитала</div>
          <div>• <TermTooltip term="вторичный-рынок" language="ru">Вторичный рынок</TermTooltip>: Где существующие акции переходят из рук в руки; центр ежедневной торговли</div>
          <div>• Каждый тип рынка предлагает разные уровни риска и ожидания доходности</div>
        </div>
      )
    },
    example: { 
      tr: '📊 2025\'te sermaye piyasaları, M&A ve IPO aktivitelerinde %20 artış gördü; özel kredi talebi yükseldi.',
      en: '📊 In 2025, capital markets saw 20% increase in M&A and IPO activities; private credit demand rose.',
      es: '📊 En 2025, mercados de capitales vieron 20% aumento en actividades M&A e IPO; demanda de crédito privado subió.',
      fr: '📊 En 2025, marchés des capitaux ont vu 20% d\'augmentation des activités M&A et IPO; demande de crédit privé a augmenté.',
      ru: '📊 В 2025 году рынки капитала увидели 20% рост активности M&A и IPO; спрос на частный кредит вырос.'
    },
    icon: <TrendingUp className="w-16 h-16 text-green-500" />
  },
  {
    title: { 
      tr: 'Para Piyasası Araçları', 
      en: 'Money Market Instruments', 
      es: 'Instrumentos del Mercado Monetario', 
      fr: 'Instruments du Marché Monétaire', 
      ru: 'Инструменты денежного рынка' 
    },
    content: { 
      tr: [
        '• Başlıca araçlar: Ticari senetler (şirket borç kağıtları), repo (teminatlı borç verme), vadeli mevduat sertifikaları',
        '• Şirketlerin kısa süreli nakit ihtiyaçlarını karşılar - maaş ödemesi, hammadde alımı gibi günlük giderler için',
        '• Özellikler: Çok kolay nakde çevrilebilir, güvenli ama düşük kazanç (yılda %3-6 arası)',
        '• Merkez bankası faizleri düştüğünde para piyasası kazançları da düşer - enflasyon riski oluşabilir',
        '• TCMB, Fed gibi merkez bankaları faiz oranlarını değiştirerek bu piyasaları yönlendirir'
      ],
      en: [
        '• Main instruments: Commercial papers (corporate debt), repos (collateralized lending), time deposit certificates',
        '• Covers companies\' short-term cash needs - for daily expenses like salary payments, raw material purchases',
        '• Features: Highly liquid, safe but low returns (3-6% annually)',
        '• When central bank rates fall, money market returns also decrease - inflation risk may arise',
        '• Central banks like CBRT, Fed guide these markets by changing interest rates'
      ],
      es: [
        '• Instrumentos principales: Papeles comerciales (deuda corporativa), repos (préstamos garantizados), certificados de depósito a plazo',
        '• Cubre necesidades de efectivo a corto plazo de empresas - para gastos diarios como pagos de salarios, compra de materias primas',
        '• Características: Altamente líquidos, seguros pero bajos retornos (3-6% anual)',
        '• Cuando tasas del banco central caen, retornos del mercado monetario también bajan - riesgo de inflación puede surgir',
        '• Bancos centrales guían estos mercados cambiando tasas de interés'
      ],
      fr: [
        '• Instruments principaux: Papiers commerciaux (dette d\'entreprise), repos (prêts garantis), certificats de dépôt à terme',
        '• Couvre besoins de trésorerie à court terme des entreprises - pour dépenses quotidiennes comme paiements salaires, achats matières premières',
        '• Caractéristiques: Très liquides, sûrs mais faibles rendements (3-6% annuel)',
        '• Quand taux banque centrale baissent, rendements marché monétaire baissent aussi - risque inflation peut surgir',
        '• Banques centrales guident ces marchés en changeant taux d\'intérêt'
      ],
      ru: [
        '• Основные инструменты: Коммерческие бумаги (корпоративный долг), репо (обеспеченное кредитование), срочные депозитные сертификаты',
        '• Покрывает краткосрочные потребности компаний в наличности - для ежедневных расходов как зарплаты, закупка сырья',
        '• Особенности: Высоколиквидные, безопасные но низкая доходность (3-6% годовых)',
        '• Когда ставки центрального банка падают, доходность денежного рынка также снижается - может возникнуть инфляционный риск',
        '• Центральные банки направляют эти рынки, изменяя процентные ставки'
      ]
    },
    contentWithTooltips: {
      tr: (
        <div className="space-y-3">
          <div>• Başlıca araçlar: Ticari senetler (şirket borç kağıtları), <TermTooltip term="repo">repo</TermTooltip> (teminatlı borç verme), vadeli mevduat sertifikaları</div>
          <div>• Şirketlerin kısa süreli nakit ihtiyaçlarını karşılar - maaş ödemesi, hammadde alımı gibi günlük giderler için</div>
          <div>• Özellikler: Çok kolay nakde çevrilebilir, güvenli ama düşük kazanç (yılda %3-6 arası)</div>
          <div>• Merkez bankası faizleri düştüğünde para piyasası kazançları da düşer - enflasyon riski oluşabilir</div>
          <div>• TCMB, Fed gibi merkez bankaları faiz oranlarını değiştirerek bu piyasaları yönlendirir</div>
        </div>
      ),
      en: (
        <div className="space-y-3">
          <div>• Main instruments: Commercial papers (corporate debt), <TermTooltip term="repo" language="en">repos</TermTooltip> (collateralized lending), time deposit certificates</div>
          <div>• Covers companies' short-term cash needs - for daily expenses like salary payments, raw material purchases</div>
          <div>• Features: Highly liquid, safe but low returns (3-6% annually)</div>
          <div>• When central bank rates fall, money market returns also decrease - inflation risk may arise</div>
          <div>• Central banks like CBRT, Fed guide these markets by changing interest rates</div>
        </div>
      ),
      es: (
        <div className="space-y-3">
          <div>• Instrumentos principales: Papeles comerciales (deuda corporativa), <TermTooltip term="repo" language="es">repos</TermTooltip> (préstamos garantizados), certificados de depósito a plazo</div>
          <div>• Cubre necesidades de efectivo a corto plazo de empresas - para gastos diarios como pagos de salarios, compra de materias primas</div>
          <div>• Características: Altamente líquidos, seguros pero bajos retornos (3-6% anual)</div>
          <div>• Cuando tasas del banco central caen, retornos del mercado monetario también bajan - riesgo de inflación puede surgir</div>
          <div>• Bancos centrales guían estos mercados cambiando tasas de interés</div>
        </div>
      ),
      fr: (
        <div className="space-y-3">
          <div>• Instruments principaux: Papiers commerciaux (dette d'entreprise), <TermTooltip term="repo" language="fr">repos</TermTooltip> (prêts garantis), certificats de dépôt à terme</div>
          <div>• Couvre besoins de trésorerie à court terme des entreprises - pour dépenses quotidiennes comme paiements salaires, achats matières premières</div>
          <div>• Caractéristiques: Très liquides, sûrs mais faibles rendements (3-6% annuel)</div>
          <div>• Quand taux banque centrale baissent, rendements marché monétaire baissent aussi - risque inflation peut surgir</div>
          <div>• Banques centrales guident ces marchés en changeant taux d'intérêt</div>
        </div>
      ),
      ru: (
        <div className="space-y-3">
          <div>• Основные инструменты: Коммерческие бумаги (корпоративный долг), <TermTooltip term="репо" language="ru">репо</TermTooltip> (обеспеченное кредитование), срочные депозитные сертификаты</div>
          <div>• Покрывает краткосрочные потребности компаний в наличности - для ежедневных расходов как зарплаты, закупка сырья</div>
          <div>• Особенности: Высоколиквидные, безопасные но низкая доходность (3-6% годовых)</div>
          <div>• Когда ставки центрального банка падают, доходность денежного рынка также снижается - может возникнуть инфляционный риск</div>
          <div>• Центральные банки направляют эти рынки, изменяя процентные ставки</div>
        </div>
      )
    },
    example: { 
      tr: '💰 2025\'te para piyasası faizleri %4-5 aralığında kaldı; Fed kesintileri likiditeyi artırdı.',
      en: '💰 In 2025, money market rates remained in 4-5% range; Fed cuts increased liquidity.',
      es: '💰 En 2025, tasas del mercado monetario se mantuvieron en rango 4-5%; cortes Fed aumentaron liquidez.',
      fr: '💰 En 2025, taux marché monétaire sont restés dans la fourchette 4-5%; coupes Fed ont augmenté liquidité.',
      ru: '💰 В 2025 году ставки денежного рынка остались в диапазоне 4-5%; снижения ФРС увеличили ликвидность.'
    },
    icon: <Coins className="w-16 h-16 text-yellow-500" />
  },
  {
    title: { 
      tr: 'Sermaye Piyasası ve Hisse Senetleri', 
      en: 'Capital Market and Stocks', 
      es: 'Mercado de Capitales y Acciones', 
      fr: 'Marché des Capitaux et Actions', 
      ru: 'Рынок капитала и акции' 
    },
    content: { 
      tr: [
        '• Hisse Senetleri: Bir şirkette ortak olmanızı sağlayan belge; oy hakkı ve kar paylaşımı hakkı verir',
        '• İki kazanç yolu: Temettü (şirketin dağıttığı kar payı) ve hisse fiyat artışı (alış-satış farkı)',
        '• BIST, NYSE gibi borsalarda işlem görür; fiyatlar alıcı-satıcı dengesine göre sürekli değişir',
        '• Uzun vadede (5+ yıl) yüksek kazanç şansı ama kısa vadede çok dalgalı - değer kaybı riski yüksek',
        '• Başarılı yatırım için şirket araştırması, sabır ve uzun vadeli bakış açısı şart'
      ],
      en: [
        '• Stocks: Documents that make you a partner in a company; provides voting rights and profit sharing',
        '• Two income sources: Dividends (company profit distribution) and stock price appreciation (buy-sell difference)',
        '• Traded on exchanges like BIST, NYSE; prices constantly change based on buyer-seller balance',
        '• High return potential in long term (5+ years) but very volatile short term - high risk of value loss',
        '• Successful investment requires company research, patience and long-term perspective'
      ],
      es: [
        '• Acciones: Documentos que te hacen socio de una empresa; proporciona derechos de voto y participación en ganancias',
        '• Dos fuentes de ingresos: Dividendos (distribución de ganancias de empresa) y apreciación del precio de acciones',
        '• Comerciadas en bolsas como BIST, NYSE; precios cambian constantemente basado en balance comprador-vendedor',
        '• Alto potencial de retorno a largo plazo (5+ años) pero muy volátil a corto plazo - alto riesgo de pérdida de valor',
        '• Inversión exitosa requiere investigación de empresa, paciencia y perspectiva a largo plazo'
      ],
      fr: [
        '• Actions: Documents qui vous rendent associé dans une entreprise; fournit droits de vote et partage des bénéfices',
        '• Deux sources de revenus: Dividendes (distribution des bénéfices d\'entreprise) et appréciation du prix des actions',
        '• Négociées sur bourses comme BIST, NYSE; prix changent constamment basé sur équilibre acheteur-vendeur',
        '• Fort potentiel de rendement à long terme (5+ ans) mais très volatil à court terme - risque élevé de perte de valeur',
        '• Investissement réussi nécessite recherche d\'entreprise, patience et perspective à long terme'
      ],
      ru: [
        '• Акции: Документы, которые делают вас партнером в компании; предоставляет права голоса и участие в прибылях',
        '• Два источника дохода: Дивиденды (распределение прибыли компании) и рост цены акций',
        '• Торгуются на биржах как BIST, NYSE; цены постоянно меняются на основе баланса покупатель-продавец',
        '• Высокий потенциал доходности в долгосрочной перспективе (5+ лет) но очень волатильны краткосрочно - высокий риск потери стоимости',
        '• Успешная инвестиция требует исследования компании, терпения и долгосрочной перспективы'
      ]
    },
    contentWithTooltips: {
      tr: (
        <div className="space-y-3">
          <div>• Hisse Senetleri: Bir şirkette ortak olmanızı sağlayan belge; oy hakkı ve kar paylaşımı hakkı verir</div>
          <div>• İki kazanç yolu: <TermTooltip term="temettü">Temettü</TermTooltip> (şirketin dağıttığı kar payı) ve hisse fiyat artışı (alış-satış farkı)</div>
          <div>• <TermTooltip term="bist">BIST</TermTooltip>, <TermTooltip term="nyse">NYSE</TermTooltip> gibi borsalarda işlem görür; fiyatlar alıcı-satıcı dengesine göre sürekli değişir</div>
          <div>• Uzun vadede (5+ yıl) yüksek kazanç şansı ama kısa vadede çok dalgalı - değer kaybı riski yüksek</div>
          <div>• Başarılı yatırım için şirket araştırması, sabır ve uzun vadeli bakış açısı şart</div>
        </div>
      ),
      en: (
        <div className="space-y-3">
          <div>• Stocks: Documents that make you a partner in a company; provides voting rights and profit sharing</div>
          <div>• Two income sources: <TermTooltip term="dividend" language="en">Dividends</TermTooltip> (company profit distribution) and stock price appreciation (buy-sell difference)</div>
          <div>• Traded on exchanges like <TermTooltip term="bist" language="en">BIST</TermTooltip>, <TermTooltip term="nyse" language="en">NYSE</TermTooltip>; prices constantly change based on buyer-seller balance</div>
          <div>• High return potential in long term (5+ years) but very volatile short term - high risk of value loss</div>
          <div>• Successful investment requires company research, patience and long-term perspective</div>
        </div>
      ),
      es: (
        <div className="space-y-3">
          <div>• Acciones: Documentos que te hacen socio de una empresa; proporciona derechos de voto y participación en ganancias</div>
          <div>• Dos fuentes de ingresos: <TermTooltip term="dividendo" language="es">Dividendos</TermTooltip> (distribución de ganancias de empresa) y apreciación del precio de acciones</div>
          <div>• Comerciadas en bolsas como <TermTooltip term="bist" language="es">BIST</TermTooltip>, <TermTooltip term="nyse" language="es">NYSE</TermTooltip>; precios cambian constantemente basado en balance comprador-vendedor</div>
          <div>• Alto potencial de retorno a largo plazo (5+ años) pero muy volátil a corto plazo - alto riesgo de pérdida de valor</div>
          <div>• Inversión exitosa requiere investigación de empresa, paciencia y perspectiva a largo plazo</div>
        </div>
      ),
      fr: (
        <div className="space-y-3">
          <div>• Actions: Documents qui vous rendent associé dans une entreprise; fournit droits de vote et partage des bénéfices</div>
          <div>• Deux sources de revenus: <TermTooltip term="dividende" language="fr">Dividendes</TermTooltip> (distribution des bénéfices d'entreprise) et appréciation du prix des actions</div>
          <div>• Négociées sur bourses comme <TermTooltip term="bist" language="fr">BIST</TermTooltip>, <TermTooltip term="nyse" language="fr">NYSE</TermTooltip>; prix changent constamment basé sur équilibre acheteur-vendeur</div>
          <div>• Fort potentiel de rendement à long terme (5+ ans) mais très volatil à court terme - risque élevé de perte de valeur</div>
          <div>• Investissement réussi nécessite recherche d'entreprise, patience et perspective à long terme</div>
        </div>
      ),
      ru: (
        <div className="space-y-3">
          <div>• Акции: Документы, которые делают вас партнером в компании; предоставляет права голоса и участие в прибылях</div>
          <div>• Два источника дохода: <TermTooltip term="дивиденд" language="ru">Дивиденды</TermTooltip> (распределение прибыли компании) и рост цены акций</div>
          <div>• Торгуются на биржах как <TermTooltip term="bist" language="ru">BIST</TermTooltip>, <TermTooltip term="nyse" language="ru">NYSE</TermTooltip>; цены постоянно меняются на основе баланса покупатель-продавец</div>
          <div>• Высокий потенциал доходности в долгосрочной перспективе (5+ лет) но очень волатильны краткосрочно - высокий риск потери стоимости</div>
          <div>• Успешная инвестиция требует исследования компании, терпения и долгосрочной перспективы</div>
        </div>
      )
    },
    example: { 
      tr: '📈 2025\'te S&P 500 %10.2 YTD yükseldi; rekor kapanışlar yaptı.',
      en: '📈 In 2025, S&P 500 rose 10.2% YTD; made record closes.',
      es: '📈 En 2025, S&P 500 subió 10.2% YTD; hizo cierres récord.',
      fr: '📈 En 2025, S&P 500 a monté 10.2% YTD; a fait des clôtures record.',
      ru: '📈 В 2025 году S&P 500 вырос на 10.2% YTD; сделал рекордные закрытия.'
    },
    icon: <Building2 className="w-16 h-16 text-blue-600" />
  },
  {
    title: { 
      tr: 'Tahvil Piyasası', 
      en: 'Bond Market', 
      es: 'Mercado de Bonos', 
      fr: 'Marché Obligataire', 
      ru: 'Рынок облигаций' 
    },
    content: { 
      tr: [
        '• Tahviller: Devlet veya şirketlere borç verdiğinizi gösteren senet; vade sonunda paranızı faizle geri alırsınız',
        '• Düzenli faiz (kupon) ödemeleri yapar; ABD devlet tahvilleri dünyanın en güvenli yatırımı sayılır',
        '• Ana türleri: Devlet tahvilleri (çok güvenli ama az kazanç), şirket tahvilleri (riskli ama kazancı yüksek)',
        '• Vade uzarsa faiz değişikliklerinden daha çok etkilenir; uzun vadeli tahviller daha riskli',
        '• Önemli kural: Piyasa faizleri yükselince mevcut tahvillerin değeri düşer (ters ilişki)'
      ],
      en: [
        '• Bonds: Certificate showing you lent money to government or companies; get your money back with interest at maturity',
        '• Makes regular interest (coupon) payments; US government bonds considered world\'s safest investment',
        '• Main types: Government bonds (very safe but low return), corporate bonds (risky but higher return)',
        '• Longer maturity means more affected by interest rate changes; long-term bonds are riskier',
        '• Important rule: When market rates rise, existing bond values fall (inverse relationship)'
      ],
      es: [
        '• Bonos: Certificado que muestra que prestaste dinero a gobierno o empresas; recupera tu dinero con interés al vencimiento',
        '• Hace pagos regulares de interés (cupón); bonos del gobierno estadounidense considerados inversión más segura del mundo',
        '• Tipos principales: Bonos gubernamentales (muy seguros pero bajo retorno), bonos corporativos (riesgosos pero mayor retorno)',
        '• Mayor vencimiento significa más afectado por cambios de tasas de interés; bonos a largo plazo son más riesgosos',
        '• Regla importante: Cuando tasas de mercado suben, valores de bonos existentes bajan (relación inversa)'
      ],
      fr: [
        '• Obligations: Certificat montrant que vous avez prêté de l\'argent au gouvernement ou entreprises; récupérez argent avec intérêt à échéance',
        '• Fait paiements réguliers d\'intérêt (coupon); obligations gouvernement américain considérées investissement le plus sûr au monde',
        '• Types principaux: Obligations gouvernementales (très sûres mais faible rendement), obligations d\'entreprise (risquées mais rendement plus élevé)',
        '• Échéance plus longue signifie plus affecté par changements taux d\'intérêt; obligations long terme plus risquées',
        '• Règle importante: Quand taux marché montent, valeurs obligations existantes baissent (relation inverse)'
      ],
      ru: [
        '• Облигации: Сертификат показывающий что вы одолжили деньги правительству или компаниям; получите деньги обратно с процентами при погашении',
        '• Делает регулярные выплаты процентов (купон); облигации правительства США считаются самой безопасной инвестицией в мире',
        '• Основные типы: Государственные облигации (очень безопасные но низкая доходность), корпоративные облигации (рискованные но более высокая доходность)',
        '• Более длительный срок погашения означает больше влияния изменений процентных ставок; долгосрочные облигации более рискованны',
        '• Важное правило: Когда рыночные ставки растут, стоимость существующих облигаций падает (обратная зависимость)'
      ]
    },
    contentWithTooltips: {
      tr: (
        <div className="space-y-3">
          <div>• Tahviller: Devlet veya şirketlere borç verdiğinizi gösteren senet; vade sonunda paranızı faizle geri alırsınız</div>
          <div>• Düzenli faiz (kupon) ödemeleri yapar; ABD devlet tahvilleri dünyanın en güvenli yatırımı sayılır</div>
          <div>• Ana türleri: Devlet tahvilleri (çok güvenli ama az kazanç), şirket tahvilleri (riskli ama kazancı yüksek)</div>
          <div>• Vade uzarsa faiz değişikliklerinden daha çok etkilenir; uzun vadeli tahviller daha riskli</div>
          <div>• Önemli kural: Piyasa faizleri yükselince mevcut tahvillerin değeri düşer (ters ilişki)</div>
        </div>
      ),
      en: (
        <div className="space-y-3">
          <div>• Bonds: Certificate showing you lent money to government or companies; get your money back with interest at maturity</div>
          <div>• Makes regular interest (coupon) payments; US government bonds considered world's safest investment</div>
          <div>• Main types: Government bonds (very safe but low return), corporate bonds (risky but higher return)</div>
          <div>• Longer maturity means more affected by interest rate changes; long-term bonds are riskier</div>
          <div>• Important rule: When market rates rise, existing bond values fall (inverse relationship)</div>
        </div>
      ),
      es: (
        <div className="space-y-3">
          <div>• Bonos: Certificado que muestra que prestaste dinero a gobierno o empresas; recupera tu dinero con interés al vencimiento</div>
          <div>• Hace pagos regulares de interés (cupón); bonos del gobierno estadounidense considerados inversión más segura del mundo</div>
          <div>• Tipos principales: Bonos gubernamentales (muy seguros pero bajo retorno), bonos corporativos (riesgosos pero mayor retorno)</div>
          <div>• Mayor vencimiento significa más afectado por cambios de tasas de interés; bonos a largo plazo son más riesgosos</div>
          <div>• Regla importante: Cuando tasas de mercado suben, valores de bonos existentes bajan (relación inversa)</div>
        </div>
      ),
      fr: (
        <div className="space-y-3">
          <div>• Obligations: Certificat montrant que vous avez prêté de l'argent au gouvernement ou entreprises; récupérez argent avec intérêt à échéance</div>
          <div>• Fait paiements réguliers d'intérêt (coupon); obligations gouvernement américain considérées investissement le plus sûr au monde</div>
          <div>• Types principaux: Obligations gouvernementales (très sûres mais faible rendement), obligations d'entreprise (risquées mais rendement plus élevé)</div>
          <div>• Échéance plus longue signifie plus affecté par changements taux d'intérêt; obligations long terme plus risquées</div>
          <div>• Règle importante: Quand taux marché montent, valeurs obligations existantes baissent (relation inverse)</div>
        </div>
      ),
      ru: (
        <div className="space-y-3">
          <div>• Облигации: Сертификат показывающий что вы одолжили деньги правительству или компаниям; получите деньги обратно с процентами при погашении</div>
          <div>• Делает регулярные выплаты процентов (купон); облигации правительства США считаются самой безопасной инвестицией в мире</div>
          <div>• Основные типы: Государственные облигации (очень безопасные но низкая доходность), корпоративные облигации (рискованные но более высокая доходность)</div>
          <div>• Более длительный срок погашения означает больше влияния изменений процентных ставок; долгосрочные облигации более рискованны</div>
          <div>• Важное правило: Когда рыночные ставки растут, стоимость существующих облигаций падает (обратная зависимость)</div>
        </div>
      )
    },
    example: { 
      tr: '📋 2025\'te ABD tahvil getirileri %4-5 aralığında kaldı; enflasyonla stabilleşti.',
      en: '📋 In 2025, US bond yields remained in 4-5% range; stabilized with inflation.',
      es: '📋 En 2025, rendimientos de bonos estadounidenses se mantuvieron en rango 4-5%; se estabilizaron con inflación.',
      fr: '📋 En 2025, rendements obligations américaines sont restés dans fourchette 4-5%; stabilisés avec inflation.',
      ru: '📋 В 2025 году доходность облигаций США остались в диапазоне 4-5%; стабилизировались с инфляцией.'
    },
    icon: <Shield className="w-16 h-16 text-green-600" />
  },
  {
    title: { 
      tr: 'Döviz Piyasası (Forex)', 
      en: 'Foreign Exchange Market (Forex)', 
      es: 'Mercado de Divisas (Forex)', 
      fr: 'Marché des Changes (Forex)', 
      ru: 'Валютный рынок (Forex)' 
    },
    content: { 
      tr: [
        '• Forex: Para birimlerinin alım-satımı; günde 7 trilyon dolarlık işlemle dünyanın en büyük piyasası',
        '• Önemli pariteler: EUR/USD (Euro-Dolar), USD/TRY (Dolar-Lira); ülke ekonomilerinin karşılaştırılması',
        '• Kur değişkenlerini etkileyen faktörler: Faiz farkları, enflasyon, siyasi olaylar, ekonomik haberler',
        '• İşlem türleri: Spot (anında), vadeli (ileri tarihli), swap (değişim) sözleşmeleri',
        '• Kaldıraç kullanımı: Az parayla çok büyük işlem yapabilirsiniz ama kayıp riskiniz de o kadar büyük'
      ],
      en: [
        '• Forex: Trading of currencies; world\'s largest market with $7 trillion daily volume',
        '• Important pairs: EUR/USD (Euro-Dollar), USD/TRY (Dollar-Lira); comparison of country economies',
        '• Factors affecting exchange rates: Interest rate differentials, inflation, political events, economic news',
        '• Transaction types: Spot (immediate), forward (future dated), swap contracts',
        '• Leverage usage: Can trade large amounts with small capital but loss risk is equally large'
      ],
      es: [
        '• Forex: Trading de monedas; mercado más grande del mundo con volumen diario de $7 trillones',
        '• Pares importantes: EUR/USD (Euro-Dólar), USD/TRY (Dólar-Lira); comparación de economías de países',
        '• Factores que afectan tipos de cambio: Diferenciales de tasas de interés, inflación, eventos políticos, noticias económicas',
        '• Tipos de transacciones: Spot (inmediato), forward (fecha futura), contratos swap',
        '• Uso de apalancamiento: Puede operar grandes cantidades con pequeño capital pero riesgo de pérdida es igualmente grande'
      ],
      fr: [
        '• Forex: Trading de devises; plus grand marché mondial avec volume quotidien de $7 trillions',
        '• Paires importantes: EUR/USD (Euro-Dollar), USD/TRY (Dollar-Lire); comparaison économies pays',
        '• Facteurs affectant taux de change: Différentiels taux d\'intérêt, inflation, événements politiques, nouvelles économiques',
        '• Types de transactions: Spot (immédiat), forward (date future), contrats swap',
        '• Usage effet de levier: Peut trader grandes quantités avec petit capital mais risque de perte également grand'
      ],
      ru: [
        '• Forex: Торговля валютами; крупнейший рынок мира с ежедневным объемом $7 триллионов',
        '• Важные пары: EUR/USD (Евро-Доллар), USD/TRY (Доллар-Лира); сравнение экономик стран',
        '• Факторы влияющие на обменные курсы: Разница процентных ставок, инфляция, политические события, экономические новости',
        '• Типы транзакций: Спот (немедленный), форвард (будущая дата), своп контракты',
        '• Использование кредитного плеча: Можете торговать большими суммами с малым капиталом но риск потерь равно велик'
      ]
    },
    contentWithTooltips: {
      tr: (
        <div className="space-y-3">
          <div>• Forex: Para birimlerinin alım-satımı; günde 7 trilyon dolarlık işlemle dünyanın en büyük piyasası</div>
          <div>• Önemli pariteler: EUR/USD (Euro-Dolar), USD/TRY (Dolar-Lira); ülke ekonomilerinin karşılaştırılması</div>
          <div>• Kur değişkenlerini etkileyen faktörler: Faiz farkları, enflasyon, siyasi olaylar, ekonomik haberler</div>
          <div>• İşlem türleri: Spot (anında), vadeli (ileri tarihli), swap (değişim) sözleşmeleri</div>
          <div>• <TermTooltip term="kaldıraç">Kaldıraç</TermTooltip> kullanımı: Az parayla çok büyük işlem yapabilirsiniz ama kayıp riskiniz de o kadar büyük</div>
        </div>
      ),
      en: (
        <div className="space-y-3">
          <div>• Forex: Trading of currencies; world's largest market with $7 trillion daily volume</div>
          <div>• Important pairs: EUR/USD (Euro-Dollar), USD/TRY (Dollar-Lira); comparison of country economies</div>
          <div>• Factors affecting exchange rates: Interest rate differentials, inflation, political events, economic news</div>
          <div>• Transaction types: Spot (immediate), forward (future dated), swap contracts</div>
          <div>• <TermTooltip term="leverage" language="en">Leverage</TermTooltip> usage: Can trade large amounts with small capital but loss risk is equally large</div>
        </div>
      ),
      es: (
        <div className="space-y-3">
          <div>• Forex: Trading de monedas; mercado más grande del mundo con volumen diario de $7 trillones</div>
          <div>• Pares importantes: EUR/USD (Euro-Dólar), USD/TRY (Dólar-Lira); comparación de economías de países</div>
          <div>• Factores que afectan tipos de cambio: Diferenciales de tasas de interés, inflación, eventos políticos, noticias económicas</div>
          <div>• Tipos de transacciones: Spot (inmediato), forward (fecha futura), contratos swap</div>
          <div>• Uso de <TermTooltip term="apalancamiento" language="es">apalancamiento</TermTooltip>: Puede operar grandes cantidades con pequeño capital pero riesgo de pérdida es igualmente grande</div>
        </div>
      ),
      fr: (
        <div className="space-y-3">
          <div>• Forex: Trading de devises; plus grand marché mondial avec volume quotidien de $7 trillions</div>
          <div>• Paires importantes: EUR/USD (Euro-Dollar), USD/TRY (Dollar-Lire); comparaison économies pays</div>
          <div>• Facteurs affectant taux de change: Différentiels taux d'intérêt, inflation, événements politiques, nouvelles économiques</div>
          <div>• Types de transactions: Spot (immédiat), forward (date future), contrats swap</div>
          <div>• Usage <TermTooltip term="effet-levier" language="fr">effet de levier</TermTooltip>: Peut trader grandes quantités avec petit capital mais risque de perte également grand</div>
        </div>
      ),
      ru: (
        <div className="space-y-3">
          <div>• Forex: Торговля валютами; крупнейший рынок мира с ежедневным объемом $7 триллионов</div>
          <div>• Важные пары: EUR/USD (Евро-Доллар), USD/TRY (Доллар-Лира); сравнение экономик стран</div>
          <div>• Факторы влияющие на обменные курсы: Разница процентных ставок, инфляция, политические события, экономические новости</div>
          <div>• Типы транзакций: Спот (немедленный), форвард (будущая дата), своп контракты</div>
          <div>• Использование <TermTooltip term="кредитное-плечо" language="ru">кредитного плеча</TermTooltip>: Можете торговать большими суммами с малым капиталом но риск потерь равно велик</div>
        </div>
      )
    },
    example: { 
      tr: '💱 2025\'te USD güçlü kaldı; carry trade AUD/USD\'de etkili oldu.',
      en: '💱 In 2025, USD remained strong; carry trade was effective in AUD/USD.',
      es: '💱 En 2025, USD se mantuvo fuerte; carry trade fue efectivo en AUD/USD.',
      fr: '💱 En 2025, USD est resté fort; carry trade était efficace dans AUD/USD.',
      ru: '💱 В 2025 году USD остался сильным; керри-трейд был эффективен в AUD/USD.'
    },
    icon: <Globe className="w-16 h-16 text-purple-500" />
  },
  {
    title: { 
      tr: 'Türev Piyasalar', 
      en: 'Derivatives Markets', 
      es: 'Mercados de Derivados', 
      fr: 'Marchés Dérivés', 
      ru: 'Рынки деривативов' 
    },
    content: { 
      tr: [
        '• Türev Ürünler: Değeri başka bir varlığa (hisse, altın, döviz) bağlı olan sözleşmeler - vadeli işlemler, opsiyonlar',
        '• İki ana amaç: Mevcut yatırımları koruma (güvence) veya fiyat değişimlerinden kazanç sağlama (spekülasyon)',
        '• Vadeli İşlemler: Gelecekte belirli fiyattan alma/satma zorunluluğu - çiftçi buğdayını önceden satar',
        '• Opsiyon Sözleşmeleri: Alma (call) veya satma (put) hakkı ama zorunluluk yok - sigorta gibi',
        '• Çok riskli: Kaldıraçlı yapıda olduğundan büyük kazanç şansı ama sınırsız kayıp riski - sadece uzmanlar için'
      ],
      en: [
        '• Derivatives: Contracts whose value depends on another asset (stocks, gold, currency) - futures, options',
        '• Two main purposes: Protecting existing investments (hedging) or profiting from price changes (speculation)',
        '• Futures: Obligation to buy/sell at specific price in future - farmer pre-sells wheat',
        '• Option Contracts: Right to buy (call) or sell (put) but no obligation - like insurance',
        '• Very risky: Leveraged structure offers big profit potential but unlimited loss risk - for experts only'
      ],
      es: [
        '• Derivados: Contratos cuyo valor depende de otro activo (acciones, oro, moneda) - futuros, opciones',
        '• Dos propósitos principales: Proteger inversiones existentes (cobertura) o ganar con cambios de precios (especulación)',
        '• Futuros: Obligación de comprar/vender a precio específico en futuro - granjero pre-vende trigo',
        '• Contratos de Opción: Derecho a comprar (call) o vender (put) pero sin obligación - como seguro',
        '• Muy riesgoso: Estructura apalancada ofrece gran potencial de ganancia pero riesgo de pérdida ilimitado - solo para expertos'
      ],
      fr: [
        '• Dérivés: Contrats dont valeur dépend d\'autre actif (actions, or, devise) - futures, options',
        '• Deux objectifs principaux: Protéger investissements existants (couverture) ou profiter changements prix (spéculation)',
        '• Futures: Obligation acheter/vendre à prix spécifique dans futur - fermier pré-vend blé',
        '• Contrats d\'Option: Droit acheter (call) ou vendre (put) mais pas obligation - comme assurance',
        '• Très risqué: Structure à effet de levier offre grand potentiel profit mais risque perte illimité - pour experts seulement'
      ],
      ru: [
        '• Деривативы: Контракты чья стоимость зависит от другого актива (акции, золото, валюта) - фьючерсы, опционы',
        '• Две основные цели: Защита существующих инвестиций (хеджирование) или получение прибыли от изменений цен (спекуляция)',
        '• Фьючерсы: Обязательство купить/продать по определенной цене в будущем - фермер предварительно продает пшеницу',
        '• Опционные контракты: Право купить (колл) или продать (пут) но без обязательства - как страховка',
        '• Очень рискованно: Структура с кредитным плечом предлагает большой потенциал прибыли но неограниченный риск потерь - только для экспертов'
      ]
    },
    contentWithTooltips: {
      tr: (
        <div className="space-y-3">
          <div>• Türev Ürünler: Değeri başka bir varlığa (hisse, altın, döviz) bağlı olan sözleşmeler - vadeli işlemler, opsiyonlar</div>
          <div>• İki ana amaç: Mevcut yatırımları koruma (güvence) veya fiyat değişimlerinden kazanç sağlama (spekülasyon)</div>
          <div>• Vadeli İşlemler: Gelecekte belirli fiyattan alma/satma zorunluluğu - çiftçi buğdayını önceden satar</div>
          <div>• <TermTooltip term="opsiyon-hakları">Opsiyon Sözleşmeleri</TermTooltip>: Alma (call) veya satma (put) hakkı ama zorunluluk yok - sigorta gibi</div>
          <div>• Çok riskli: Kaldıraçlı yapıda olduğundan büyük kazanç şansı ama sınırsız kayıp riski - sadece uzmanlar için</div>
        </div>
      ),
      en: (
        <div className="space-y-3">
          <div>• Derivatives: Contracts whose value depends on another asset (stocks, gold, currency) - futures, options</div>
          <div>• Two main purposes: Protecting existing investments (hedging) or profiting from price changes (speculation)</div>
          <div>• Futures: Obligation to buy/sell at specific price in future - farmer pre-sells wheat</div>
          <div>• <TermTooltip term="option-rights" language="en">Option Contracts</TermTooltip>: Right to buy (call) or sell (put) but no obligation - like insurance</div>
          <div>• Very risky: Leveraged structure offers big profit potential but unlimited loss risk - for experts only</div>
        </div>
      ),
      es: (
        <div className="space-y-3">
          <div>• Derivados: Contratos cuyo valor depende de otro activo (acciones, oro, moneda) - futuros, opciones</div>
          <div>• Dos propósitos principales: Proteger inversiones existentes (cobertura) o ganar con cambios de precios (especulación)</div>
          <div>• Futuros: Obligación de comprar/vender a precio específico en futuro - granjero pre-vende trigo</div>
          <div>• <TermTooltip term="derechos-opcion" language="es">Contratos de Opción</TermTooltip>: Derecho a comprar (call) o vender (put) pero sin obligación - como seguro</div>
          <div>• Muy riesgoso: Estructura apalancada ofrece gran potencial de ganancia pero riesgo de pérdida ilimitado - solo para expertos</div>
        </div>
      ),
      fr: (
        <div className="space-y-3">
          <div>• Dérivés: Contrats dont valeur dépend d'autre actif (actions, or, devise) - futures, options</div>
          <div>• Deux objectifs principaux: Protéger investissements existants (couverture) ou profiter changements prix (spéculation)</div>
          <div>• Futures: Obligation acheter/vendre à prix spécifique dans futur - fermier pré-vend blé</div>
          <div>• <TermTooltip term="droits-option" language="fr">Contrats d'Option</TermTooltip>: Droit acheter (call) ou vendre (put) mais pas obligation - comme assurance</div>
          <div>• Très risqué: Structure à effet de levier offre grand potentiel profit mais risque perte illimité - pour experts seulement</div>
        </div>
      ),
      ru: (
        <div className="space-y-3">
          <div>• Деривативы: Контракты чья стоимость зависит от другого актива (акции, золото, валюта) - фьючерсы, опционы</div>
          <div>• Две основные цели: Защита существующих инвестиций (хеджирование) или получение прибыли от изменений цен (спекуляция)</div>
          <div>• Фьючерсы: Обязательство купить/продать по определенной цене в будущем - фермер предварительно продает пшеницу</div>
          <div>• <TermTooltip term="права-опционов" language="ru">Опционные контракты</TermTooltip>: Право купить (колл) или продать (пут) но без обязательства - как страховка</div>
          <div>• Очень рискованно: Структура с кредитным плечом предлагает большой потенциал прибыли но неограниченный риск потерь - только для экспертов</div>
        </div>
      )
    },
    example: { 
      tr: '⚡ 2025\'te türev hacimleri, volatiliteyle %15 arttı; enerji sözleşmeleri öne çıktı.',
      en: '⚡ In 2025, derivatives volumes increased 15% with volatility; energy contracts stood out.',
      es: '⚡ En 2025, volúmenes de derivados aumentaron 15% con volatilidad; contratos de energía destacaron.',
      fr: '⚡ En 2025, volumes dérivés ont augmenté 15% avec volatilité; contrats énergie se sont démarqués.',
      ru: '⚡ В 2025 году объемы деривативов выросли на 15% с волатильностью; контракты на энергию выделились.'
    },
    icon: <Zap className="w-16 h-16 text-orange-500" />
  },
  {
    title: { 
      tr: 'Emtia Piyasaları', 
      en: 'Commodity Markets', 
      es: 'Mercados de Materias Primas', 
      fr: 'Marchés des Matières Premières', 
      ru: 'Товарные рынки' 
    },
    content: { 
      tr: [
        '• Emtia Piyasaları: Ham madde ve tarım ürünlerinin ticareti (altın, petrol, buğday, kahve, bakır)',
        '• İşlem şekilleri: Spot (anında teslim) veya vadeli (gelecek teslimat); altın enflasyona karşı korunma aracı',
        '• Fiyat belirleyicileri: Dünya arz-talep durumu, hava koşulları, hasat sonuçları, savaşlar, dolar kuru',
        '• Emtia fiyatları çok dalgalı; ekonomik duruma ve mevsimlere çok bağımlı (yazın doğalgaz ucuz, kışın pahalı)',
        '• ETF\'lerle fiziki mal almadan emtialara yatırım yapabilirsiniz; portföy dengeleme için faydalı'
      ],
      en: [
        '• Commodity Markets: Trading of raw materials and agricultural products (gold, oil, wheat, coffee, copper)',
        '• Trading methods: Spot (immediate delivery) or futures (future delivery); gold is inflation hedge',
        '• Price determinants: Global supply-demand situation, weather conditions, harvest results, wars, dollar exchange rate',
        '• Commodity prices very volatile; highly dependent on economic conditions and seasons (natural gas cheap in summer, expensive in winter)',
        '• Can invest in commodities through ETFs without buying physical goods; useful for portfolio balancing'
      ],
      es: [
        '• Mercados de Materias Primas: Trading de materias primas y productos agrícolas (oro, petróleo, trigo, café, cobre)',
        '• Métodos de trading: Spot (entrega inmediata) o futuros (entrega futura); oro es cobertura contra inflación',
        '• Determinantes de precios: Situación oferta-demanda global, condiciones climáticas, resultados de cosecha, guerras, tipo de cambio del dólar',
        '• Precios de materias primas muy volátiles; altamente dependientes de condiciones económicas y estaciones (gas natural barato en verano, caro en invierno)',
        '• Puede invertir en materias primas a través de ETFs sin comprar bienes físicos; útil para balanceo de portafolio'
      ],
      fr: [
        '• Marchés des Matières Premières: Trading matières premières et produits agricoles (or, pétrole, blé, café, cuivre)',
        '• Méthodes trading: Spot (livraison immédiate) ou futures (livraison future); or est couverture contre inflation',
        '• Déterminants prix: Situation offre-demande mondiale, conditions météo, résultats récolte, guerres, taux change dollar',
        '• Prix matières premières très volatils; hautement dépendants conditions économiques et saisons (gaz naturel bon marché été, cher hiver)',
        '• Peut investir matières premières via ETFs sans acheter biens physiques; utile pour équilibrage portefeuille'
      ],
      ru: [
        '• Товарные рынки: Торговля сырьем и сельскохозяйственными продуктами (золото, нефть, пшеница, кофе, медь)',
        '• Методы торговли: Спот (немедленная поставка) или фьючерсы (будущая поставка); золото это защита от инфляции',
        '• Определители цен: Глобальная ситуация спрос-предложение, погодные условия, результаты урожая, войны, курс доллара',
        '• Цены на товары очень волатильны; сильно зависят от экономических условий и сезонов (природный газ дешев летом, дорог зимой)',
        '• Можете инвестировать в товары через ETF без покупки физических товаров; полезно для балансировки портфеля'
      ]
    },
    contentWithTooltips: {
      tr: (
        <div className="space-y-3">
          <div>• Emtia Piyasaları: Ham madde ve tarım ürünlerinin ticareti (altın, petrol, buğday, kahve, bakır)</div>
          <div>• İşlem şekilleri: Spot (anında teslim) veya vadeli (gelecek teslimat); altın enflasyona karşı korunma aracı</div>
          <div>• Fiyat belirleyicileri: Dünya arz-talep durumu, hava koşulları, hasat sonuçları, savaşlar, dolar kuru</div>
          <div>• Emtia fiyatları çok dalgalı; ekonomik duruma ve mevsimlere çok bağımlı (yazın doğalgaz ucuz, kışın pahalı)</div>
          <div>• <TermTooltip term="etf">ETF</TermTooltip>'lerle fiziki mal almadan emtialara yatırım yapabilirsiniz; portföy dengeleme için faydalı</div>
        </div>
      ),
      en: (
        <div className="space-y-3">
          <div>• Commodity Markets: Trading of raw materials and agricultural products (gold, oil, wheat, coffee, copper)</div>
          <div>• Trading methods: Spot (immediate delivery) or futures (future delivery); gold is inflation hedge</div>
          <div>• Price determinants: Global supply-demand situation, weather conditions, harvest results, wars, dollar exchange rate</div>
          <div>• Commodity prices very volatile; highly dependent on economic conditions and seasons (natural gas cheap in summer, expensive in winter)</div>
          <div>• Can invest in commodities through <TermTooltip term="etf" language="en">ETFs</TermTooltip> without buying physical goods; useful for portfolio balancing</div>
        </div>
      ),
      es: (
        <div className="space-y-3">
          <div>• Mercados de Materias Primas: Trading de materias primas y productos agrícolas (oro, petróleo, trigo, café, cobre)</div>
          <div>• Métodos de trading: Spot (entrega inmediata) o futuros (entrega futura); oro es cobertura contra inflación</div>
          <div>• Determinantes de precios: Situación oferta-demanda global, condiciones climáticas, resultados de cosecha, guerras, tipo de cambio del dólar</div>
          <div>• Precios de materias primas muy volátiles; altamente dependientes de condiciones económicas y estaciones (gas natural barato en verano, caro en invierno)</div>
          <div>• Puede invertir en materias primas a través de <TermTooltip term="etf" language="es">ETFs</TermTooltip> sin comprar bienes físicos; útil para balanceo de portafolio</div>
        </div>
      ),
      fr: (
        <div className="space-y-3">
          <div>• Marchés des Matières Premières: Trading matières premières et produits agricoles (or, pétrole, blé, café, cuivre)</div>
          <div>• Méthodes trading: Spot (livraison immédiate) ou futures (livraison future); or est couverture contre inflation</div>
          <div>• Déterminants prix: Situation offre-demande mondiale, conditions météo, résultats récolte, guerres, taux change dollar</div>
          <div>• Prix matières premières très volatils; hautement dépendants conditions économiques et saisons (gaz naturel bon marché été, cher hiver)</div>
          <div>• Peut investir matières premières via <TermTooltip term="etf" language="fr">ETFs</TermTooltip> sans acheter biens physiques; utile pour équilibrage portefeuille</div>
        </div>
      ),
      ru: (
        <div className="space-y-3">
          <div>• Товарные рынки: Торговля сырьем и сельскохозяйственными продуктами (золото, нефть, пшеница, кофе, медь)</div>
          <div>• Методы торговли: Спот (немедленная поставка) или фьючерсы (будущая поставка); золото это защита от инфляции</div>
          <div>• Определители цен: Глобальная ситуация спрос-предложение, погодные условия, результаты урожая, войны, курс доллара</div>
          <div>• Цены на товары очень волатильны; сильно зависят от экономических условий и сезонов (природный газ дешев летом, дорог зимой)</div>
          <div>• Можете инвестировать в товары через <TermTooltip term="etf" language="ru">ETF</TermTooltip> без покупки физических товаров; полезно для балансировки портфеля</div>
        </div>
      )
    },
    example: { 
      tr: '🛢️ 2025\'te enerji fiyatları %3.9 düştü; petrol arzı dengelendi.',
      en: '🛢️ In 2025, energy prices fell 3.9%; oil supply balanced.',
      es: '🛢️ En 2025, precios de energía cayeron 3.9%; suministro de petróleo se equilibró.',
      fr: '🛢️ En 2025, prix énergie ont chuté 3.9%; approvisionnement pétrole s\'est équilibré.',
      ru: '🛢️ В 2025 году цены на энергию упали на 3.9%; предложение нефти сбалансировалось.'
    },
    icon: <Pickaxe className="w-16 h-16 text-amber-600" />
  },
  {
    title: { 
      tr: 'Kripto Para Piyasaları', 
      en: 'Cryptocurrency Markets', 
      es: 'Mercados de Criptomonedas', 
      fr: 'Marchés des Cryptomonnaies', 
      ru: 'Рынки криптовалют' 
    },
    content: { 
      tr: [
        '• Kripto Para Piyasaları: Dijital paralar (Bitcoin, Ethereum, diğer coinler) - blokzincir teknolojisiyle çalışır',
        '• Bitcoin "dijital altın" olarak değer saklama aracı, Ethereum akıllı kontratlar ve DeFi uygulamaları için platform görevi görür',
        '• Ayırt edici özellikler: Çok yüksek dalgalanma, 7/24 ticaret, bankalardan bağımsız sistem',
        '• Bitcoin ve Ethereum ETF\'leriyle geleneksel yatırımcılar da kolayca erişebiliyor',
        '• Büyük riskler: Yasal belirsizlik, hacking tehlikesi, manipülasyon - sadece kaybedebileceğiniz parayla girin'
      ],
      en: [
        '• Cryptocurrency Markets: Digital currencies (Bitcoin, Ethereum, other coins) - operates with blockchain technology',
        '• Bitcoin serves as "digital gold" store of value, Ethereum as platform for smart contracts and DeFi applications',
        '• Distinctive features: Very high volatility, 24/7 trading, banking-independent system',
        '• Traditional investors can easily access through Bitcoin and Ethereum ETFs',
        '• Major risks: Legal uncertainty, hacking danger, manipulation - only enter with money you can afford to lose'
      ],
      es: [
        '• Mercados de Criptomonedas: Monedas digitales (Bitcoin, Ethereum, otras monedas) - opera con tecnología blockchain',
        '• Bitcoin sirve como "oro digital" reserva de valor, Ethereum como plataforma para contratos inteligentes y aplicaciones DeFi',
        '• Características distintivas: Muy alta volatilidad, trading 24/7, sistema independiente de bancos',
        '• Inversores tradicionales pueden acceder fácilmente a través de ETFs de Bitcoin y Ethereum',
        '• Riesgos principales: Incertidumbre legal, peligro de hacking, manipulación - solo entre con dinero que pueda permitirse perder'
      ],
      fr: [
        '• Marchés Cryptomonnaies: Monnaies numériques (Bitcoin, Ethereum, autres pièces) - fonctionne avec technologie blockchain',
        '• Bitcoin sert comme "or numérique" réserve valeur, Ethereum comme plateforme contrats intelligents et applications DeFi',
        '• Caractéristiques distinctives: Très haute volatilité, trading 24/7, système indépendant banques',
        '• Investisseurs traditionnels peuvent accéder facilement via ETFs Bitcoin et Ethereum',
        '• Risques majeurs: Incertitude légale, danger piratage, manipulation - entrez seulement avec argent que vous pouvez vous permettre perdre'
      ],
      ru: [
        '• Рынки криптовалют: Цифровые валюты (Bitcoin, Ethereum, другие монеты) - работают на блокчейн технологии',
        '• Bitcoin служит как "цифровое золото" средство сохранения стоимости, Ethereum как платформа для умных контрактов и DeFi приложений',
        '• Отличительные особенности: Очень высокая волатильность, торговля 24/7, независимая от банков система',
        '• Традиционные инвесторы могут легко получить доступ через Bitcoin и Ethereum ETF',
        '• Основные риски: Правовая неопределенность, опасность взлома, манипуляции - входите только с деньгами которые можете позволить себе потерять'
      ]
    },
    contentWithTooltips: {
      tr: (
        <div className="space-y-3">
          <div>• Kripto Para Piyasaları: Dijital paralar (Bitcoin, Ethereum, diğer coinler) - blokzincir teknolojisiyle çalışır</div>
          <div>• Bitcoin "dijital altın" olarak değer saklama aracı, Ethereum <TermTooltip term="akıllı-kontratlar">akıllı kontratlar</TermTooltip> ve <TermTooltip term="defi">DeFi</TermTooltip> uygulamaları için platform görevi görür</div>
          <div>• Ayırt edici özellikler: Çok yüksek dalgalanma, 7/24 ticaret, bankalardan bağımsız sistem</div>
          <div>• Bitcoin ve Ethereum ETF'leriyle geleneksel yatırımcılar da kolayca erişebiliyor</div>
          <div>• Büyük riskler: Yasal belirsizlik, hacking tehlikesi, manipülasyon - sadece kaybedebileceğiniz parayla girin</div>
        </div>
      ),
      en: (
        <div className="space-y-3">
          <div>• Cryptocurrency Markets: Digital currencies (Bitcoin, Ethereum, other coins) - operates with blockchain technology</div>
          <div>• Bitcoin serves as "digital gold" store of value, Ethereum as platform for <TermTooltip term="smart-contracts" language="en">smart contracts</TermTooltip> and <TermTooltip term="defi" language="en">DeFi</TermTooltip> applications</div>
          <div>• Distinctive features: Very high volatility, 24/7 trading, banking-independent system</div>
          <div>• Traditional investors can easily access through Bitcoin and Ethereum ETFs</div>
          <div>• Major risks: Legal uncertainty, hacking danger, manipulation - only enter with money you can afford to lose</div>
        </div>
      ),
      es: (
        <div className="space-y-3">
          <div>• Mercados de Criptomonedas: Monedas digitales (Bitcoin, Ethereum, otras monedas) - opera con tecnología blockchain</div>
          <div>• Bitcoin sirve como "oro digital" reserva de valor, Ethereum como plataforma para <TermTooltip term="contratos-inteligentes" language="es">contratos inteligentes</TermTooltip> y aplicaciones <TermTooltip term="defi" language="es">DeFi</TermTooltip></div>
          <div>• Características distintivas: Muy alta volatilidad, trading 24/7, sistema independiente de bancos</div>
          <div>• Inversores tradicionales pueden acceder fácilmente a través de ETFs de Bitcoin y Ethereum</div>
          <div>• Riesgos principales: Incertidumbre legal, peligro de hacking, manipulación - solo entre con dinero que pueda permitirse perder</div>
        </div>
      ),
      fr: (
        <div className="space-y-3">
          <div>• Marchés Cryptomonnaies: Monnaies numériques (Bitcoin, Ethereum, autres pièces) - fonctionne avec technologie blockchain</div>
          <div>• Bitcoin sert comme "or numérique" réserve valeur, Ethereum comme plateforme <TermTooltip term="contrats-intelligents" language="fr">contrats intelligents</TermTooltip> et applications <TermTooltip term="defi" language="fr">DeFi</TermTooltip></div>
          <div>• Caractéristiques distinctives: Très haute volatilité, trading 24/7, système indépendant banques</div>
          <div>• Investisseurs traditionnels peuvent accéder facilement via ETFs Bitcoin et Ethereum</div>
          <div>• Risques majeurs: Incertitude légale, danger piratage, manipulation - entrez seulement avec argent que vous pouvez vous permettre perdre</div>
        </div>
      ),
      ru: (
        <div className="space-y-3">
          <div>• Рынки криптовалют: Цифровые валюты (Bitcoin, Ethereum, другие монеты) - работают на блокчейн технологии</div>
          <div>• Bitcoin служит как "цифровое золото" средство сохранения стоимости, Ethereum как платформа для <TermTooltip term="умные-контракты" language="ru">умных контрактов</TermTooltip> и <TermTooltip term="defi" language="ru">DeFi</TermTooltip> приложений</div>
          <div>• Отличительные особенности: Очень высокая волатильность, торговля 24/7, независимая от банков система</div>
          <div>• Традиционные инвесторы могут легко получить доступ через Bitcoin и Ethereum ETF</div>
          <div>• Основные риски: Правовая неопределенность, опасность взлома, манипуляции - входите только с деньгами которые можете позволить себе потерять</div>
        </div>
      )
    },
    example: { 
      tr: '₿ 2025\'te Bitcoin $122K ATH\'ye ulaştı; ETF talebi boğa piyasasını tetikledi.',
      en: '₿ In 2025, Bitcoin reached $122K ATH; ETF demand triggered bull market.',
      es: '₿ En 2025, Bitcoin alcanzó $122K ATH; demanda de ETF disparó mercado alcista.',
      fr: '₿ En 2025, Bitcoin a atteint $122K ATH; demande ETF a déclenché marché haussier.',
      ru: '₿ В 2025 году Bitcoin достиг $122K ATH; спрос на ETF запустил бычий рынок.'
    },
    icon: <Bitcoin className="w-16 h-16 text-orange-400" />
  },
  {
    title: { 
      tr: 'Borsalar ve İşleyişi', 
      en: 'Exchanges and Their Operation', 
      es: 'Bolsas y su Funcionamiento', 
      fr: 'Bourses et leur Fonctionnement', 
      ru: 'Биржи и их работа' 
    },
    content: { 
      tr: [
        '• Borsalar: NYSE (New York), BIST (İstanbul), LSE (Londra) gibi organize edilmiş ticaret platformları; alıcı-satıcıları bir araya getirir',
        '• Elektronik emir eşleştirme sistemleri sayesinde milisaniyeler içinde en iyi fiyatlarda işlem gerçekleştirir',
        '• Modern işleyiş: Tamamen elektronik alım-satım, algoritmik ticaret desteği, sürekli likidite sağlama',
        '• Kritik rolleri: Piyasa şeffaflığı, adil fiyat oluşumu, yatırımcı koruma kuralları ve düzenli denetim',
        '• Güvenilir altyapı ve düzenleme ile hem bireysel hem kurumsal yatırımcıların güvenini kazanır ve sürdürür'
      ],
      en: [
        '• Exchanges: Organized trading platforms like NYSE (New York), BIST (Istanbul), LSE (London); bring together buyers and sellers',
        '• Electronic order matching systems execute trades at best prices within milliseconds',
        '• Modern operation: Fully electronic trading, algorithmic trading support, continuous liquidity provision',
        '• Critical roles: Market transparency, fair price formation, investor protection rules and regular oversight',
        '• Gains and maintains trust of both individual and institutional investors through reliable infrastructure and regulation'
      ],
      es: [
        '• Bolsas: Plataformas de trading organizadas como NYSE (Nueva York), BIST (Estambul), LSE (Londres); reúnen compradores y vendedores',
        '• Sistemas electrónicos de emparejamiento de órdenes ejecutan operaciones a mejores precios en milisegundos',
        '• Operación moderna: Trading completamente electrónico, soporte de trading algorítmico, provisión continua de liquidez',
        '• Roles críticos: Transparencia del mercado, formación justa de precios, reglas de protección al inversor y supervisión regular',
        '• Gana y mantiene confianza de inversores individuales e institucionales mediante infraestructura confiable y regulación'
      ],
      fr: [
        '• Bourses: Plateformes trading organisées comme NYSE (New York), BIST (Istanbul), LSE (Londres); réunissent acheteurs et vendeurs',
        '• Systèmes électroniques appariement ordres exécutent trades aux meilleurs prix en millisecondes',
        '• Fonctionnement moderne: Trading entièrement électronique, support trading algorithmique, provision liquidité continue',
        '• Rôles critiques: Transparence marché, formation prix équitable, règles protection investisseur et surveillance régulière',
        '• Gagne et maintient confiance investisseurs individuels et institutionnels via infrastructure fiable et régulation'
      ],
      ru: [
        '• Биржи: Организованные торговые платформы как NYSE (Нью-Йорк), BIST (Стамбул), LSE (Лондон); соединяют покупателей и продавцов',
        '• Электронные системы соп��ставления ордеров исполняют сделки по лучшим ценам за миллисекунды',
        '• Современная работа: Полностью электронная торговля, поддержка алгоритмической торговли, непрерывное обеспечение ликвидности',
        '• Критические роли: Прозрачность рынка, справедливое ценообразование, правила защиты инвесторов и регулярный надзор',
        '• Завоевывает и поддерживает доверие частных и институциональных инвесторов через надежную инфраструктуру и регулирование'
      ]
    },
    contentWithTooltips: {
      tr: (
        <div className="space-y-3">
          <div>• Borsalar: <TermTooltip term="nyse">NYSE</TermTooltip>, <TermTooltip term="bist">BIST</TermTooltip>, <TermTooltip term="lse">LSE</TermTooltip> gibi organize edilmiş ticaret platformları; alıcı-satıcıları bir araya getirir</div>
          <div>• Elektronik emir eşleştirme sistemleri sayesinde milisaniyeler içinde en iyi fiyatlarda işlem gerçekleştirir</div>
          <div>• Modern işleyiş: Tamamen elektronik alım-satım, algoritmik ticaret desteği, sürekli likidite sağlama</div>
          <div>• Kritik rolleri: Piyasa şeffaflığı, adil fiyat oluşumu, yatırımcı koruma kuralları ve düzenli denetim</div>
          <div>• Güvenilir altyapı ve düzenleme ile hem bireysel hem kurumsal yatırımcıların güvenini kazanır ve sürdürür</div>
        </div>
      ),
      en: (
        <div className="space-y-3">
          <div>• Exchanges: Organized trading platforms like <TermTooltip term="nyse" language="en">NYSE</TermTooltip>, <TermTooltip term="bist" language="en">BIST</TermTooltip>, <TermTooltip term="lse" language="en">LSE</TermTooltip>; bring together buyers and sellers</div>
          <div>• Electronic order matching systems execute trades at best prices within milliseconds</div>
          <div>• Modern operation: Fully electronic trading, algorithmic trading support, continuous liquidity provision</div>
          <div>• Critical roles: Market transparency, fair price formation, investor protection rules and regular oversight</div>
          <div>• Gains and maintains trust of both individual and institutional investors through reliable infrastructure and regulation</div>
        </div>
      ),
      es: (
        <div className="space-y-3">
          <div>• Bolsas: Plataformas de trading organizadas como <TermTooltip term="nyse" language="es">NYSE</TermTooltip>, <TermTooltip term="bist" language="es">BIST</TermTooltip>, <TermTooltip term="lse" language="es">LSE</TermTooltip>; reúnen compradores y vendedores</div>
          <div>• Sistemas electrónicos de emparejamiento de órdenes ejecutan operaciones a mejores precios en milisegundos</div>
          <div>• Operación moderna: Trading completamente electrónico, soporte de trading algorítmico, provisión continua de liquidez</div>
          <div>• Roles críticos: Transparencia del mercado, formación justa de precios, reglas de protección al inversor y supervisión regular</div>
          <div>• Gana y mantiene confianza de inversores individuales e institucionales mediante infraestructura confiable y regulación</div>
        </div>
      ),
      fr: (
        <div className="space-y-3">
          <div>• Bourses: Plateformes trading organisées comme <TermTooltip term="nyse" language="fr">NYSE</TermTooltip>, <TermTooltip term="bist" language="fr">BIST</TermTooltip>, <TermTooltip term="lse" language="fr">LSE</TermTooltip>; réunissent acheteurs et vendeurs</div>
          <div>• Systèmes électroniques appariement ordres exécutent trades aux meilleurs prix en millisecondes</div>
          <div>• Fonctionnement moderne: Trading entièrement électronique, support trading algorithmique, provision liquidité continue</div>
          <div>• Rôles critiques: Transparence marché, formation prix équitable, règles protection investisseur et surveillance régulière</div>
          <div>• Gagne et maintient confiance investisseurs individuels et institutionnels via infrastructure fiable et régulation</div>
        </div>
      ),
      ru: (
        <div className="space-y-3">
          <div>• Биржи: Организованные торговые платформы как <TermTooltip term="nyse" language="ru">NYSE</TermTooltip>, <TermTooltip term="bist" language="ru">BIST</TermTooltip>, <TermTooltip term="lse" language="ru">LSE</TermTooltip>; соединяют покупателей и продавцов</div>
          <div>• Электронные системы сопоставления ордеров исполняют сделки по лучшим ценам за миллисекунды</div>
          <div>• Современная работа: Полностью электронная торговля, поддержка алгоритмической торговли, непрерывное обеспечение ликвидности</div>
          <div>• Критические роли: Прозрачность рынка, справедливое ценообразование, правила защиты инвесторов и регулярный надзор</div>
          <div>• Завоевывает и поддерживает доверие частных и институциональных инвесторов через надежную инфраструктуру и регулирование</div>
        </div>
      )
    },
    example: { 
      tr: '🏛️ 2025\'te borsalar, teknoloji entegrasyonuyla hacmi %10 artırdı; AI ticaret öne çıktı.',
      en: '🏛️ In 2025, exchanges increased volume 10% through technology integration; AI trading stood out.',
      es: '🏛️ En 2025, bolsas aumentaron volumen 10% mediante integración tecnológica; trading AI destacó.',
      fr: '🏛️ En 2025, bourses ont augmenté volume 10% via intégration technologique; trading IA s\'est démarqué.',
      ru: '🏛️ В 2025 году биржи увеличили объем на 10% через интеграцию технологий; ИИ-трейдинг выделился.'
    },
    icon: <Building className="w-16 h-16 text-gray-600" />
  },
  {
    title: { 
      tr: 'Piyasa Endeksleri', 
      en: 'Market Indices', 
      es: 'Índices de Mercado', 
      fr: 'Indices de Marché', 
      ru: 'Рыночные индексы' 
    },
    content: { 
      tr: [
        '• **Piyasa Endeksleri:** Belirli kriterlere göre seçilen hisse gruplarının performansını ölçen sepetler (S&P 500, BIST 100, FTSE 100)',
        '• **S&P 500:** ABD\'nin en büyük 500 şirketini içerir ve Amerikan ekonomisinin genel sağlığını en iyi yansıtan gösterge',
        '• **Ana kullanım alanları:** Yatırım performansı için benchmark, portföy yöneticilerinin başarı ölçütü, endeks fonlarının referansı',
        '• **Hesaplama yöntemi:** Şirketlerin piyasa değerine göre ağırlıklı ortalama; büyük şirketlerin etkisi daha fazladır',
        '• **DXY (Dolar Endeksi):** ABD dolarının diğer başlıca para birimlerine karşı gücünü ölçen önemli gösterge',
        '• Sağlıklı endeks için sektörel çeşitlilik kritik önem taşır; teknoloji ağırlığının aşırı yükselmesi risk oluşturabilir'
      ],
      en: [
        '• **Market Indices:** Baskets measuring performance of stock groups selected by specific criteria (S&P 500, BIST 100, FTSE 100)',
        '• **S&P 500:** Contains America\'s largest 500 companies and best reflects overall health of American economy',
        '• **Main uses:** Benchmark for investment performance, success measure for portfolio managers, reference for index funds',
        '• **Calculation method:** Weighted average based on companies\' market values; larger companies have more impact',
        '• **DXY (Dollar Index):** Important indicator measuring US dollar strength against other major currencies',
        '• Sectoral diversification is critical for healthy index; excessive technology weighting can create risks'
      ],
      es: [
        '• ��ndices de Mercado: Cestas midiendo rendimiento de grupos de acciones seleccionados por criterios específicos (S&P 500, BIST 100, FTSE 100)',
        '• **S&P 500:** Contiene las 500 empresas más grandes de América y mejor refleja salud general de economía americana',
        '• **Usos principales:** Benchmark para rendimiento de inversión, medida de éxito para gestores de portafolio, referencia para fondos índice',
        '• **Método de cálculo:** Promedio ponderado basado en valores de mercado de empresas; empresas más grandes tienen más impacto',
        '• **DXY (Índice Dólar):** Indicador importante que mide fuerza del dólar estadounidense contra otras monedas principales',
        '• Diversificación sectorial es crítica para índice saludable; peso excesivo de tecnología puede crear riesgos'
      ],
      fr: [
        '• **Indices de Marché:** Paniers mesurant performance groupes actions sélectionnés par critères spécifiques (S&P 500, BIST 100, FTSE 100)',
        '• **S&P 500:** Contient 500 plus grandes entreprises américaines et reflète mieux santé générale économie américaine',
        '• **Usages principaux:** Benchmark pour performance investissement, mesure succès gestionnaires portefeuille, référence fonds indiciels',
        '• **Méthode calcul:** Moyenne pondérée basée sur valeurs marché entreprises; grandes entreprises ont plus impact',
        '• **DXY (Indice Dollar):** Indicateur important mesurant force dollar américain contre autres devises principales',
        '• Diversification sectorielle critique pour indice sain; poids technologie excessif peut créer risques'
      ],
      ru: [
        '• **Рыночные индексы:** Корзины измеряющие результативность групп акций выбранных по определенным критериям (S&P 500, BIST 100, FTSE 100)',
        '• **S&P 500:** Содержит 500 крупнейших американских компаний и лучше всего отражает общее здоровье американской экономики',
        '• **Основные применения:** Бенчмарк для инвестиционной результативности, мера успеха портфельных менеджеров, ориентир для индексных фондов',
        '• **Метод расчета:** Взвешенное среднее основанное на рыночных стоимостях компаний; крупные компании имеют больше влияния',
        '• **DXY (Индекс доллара):** Важный индикатор измеряющий силу американского доллара против других основных валют',
        '• Секторальная диверсификация критична для здорового индекса; чрезмерный вес технологий может создать риски'
      ]
    },
    contentWithTooltips: {
      tr: (
        <div className="space-y-3">
          <div>• <strong>Piyasa Endeksleri:</strong> Belirli kriterlere göre seçilen hisse gruplarının performansını ölçen sepetler (S&P 500, BIST 100, FTSE 100)</div>
          <div>• <strong>S&P 500:</strong> ABD'nin en büyük 500 şirketini içerir ve Amerikan ekonomisinin genel sağlığını en iyi yansıtan gösterge</div>
          <div>• <strong>Ana kullanım alanları:</strong> Yatırım performansı için benchmark, portföy yöneticilerinin başarı ölçütü, endeks fonlarının referansı</div>
          <div>• <strong>Hesaplama yöntemi:</strong> Şirketlerin piyasa değerine göre ağırlıklı ortalama; büyük şirketlerin etkisi daha fazladır</div>
          <div>• <strong><TermTooltip term="dxy">DXY (Dolar Endeksi)</TermTooltip>:</strong> ABD dolarının diğer başlıca para birimlerine karşı gücünü ölçen önemli gösterge</div>
          <div>• Sağlıklı endeks için sektörel çeşitlilik kritik önem taşır; teknoloji ağırlığının aşırı yükselmesi risk oluşturabilir</div>
        </div>
      ),
      en: (
        <div className="space-y-3">
          <div>• <strong>Market Indices:</strong> Baskets measuring performance of stock groups selected by specific criteria (S&P 500, BIST 100, FTSE 100)</div>
          <div>• <strong>S&P 500:</strong> Contains America's largest 500 companies and best reflects overall health of American economy</div>
          <div>• <strong>Main uses:</strong> Benchmark for investment performance, success measure for portfolio managers, reference for index funds</div>
          <div>• <strong>Calculation method:</strong> Weighted average based on companies' market values; larger companies have more impact</div>
          <div>• <strong><TermTooltip term="dxy" language="en">DXY (Dollar Index)</TermTooltip>:</strong> Important indicator measuring US dollar strength against other major currencies</div>
          <div>• Sectoral diversification is critical for healthy index; excessive technology weighting can create risks</div>
        </div>
      ),
      es: (
        <div className="space-y-3">
          <div>• <strong>Índices de Mercado:</strong> Cestas midiendo rendimiento de grupos de acciones seleccionados por criterios específicos (S&P 500, BIST 100, FTSE 100)</div>
          <div>• <strong>S&P 500:</strong> Contiene las 500 empresas más grandes de América y mejor refleja salud general de economía americana</div>
          <div>• <strong>Usos principales:</strong> Benchmark para rendimiento de inversión, medida de éxito para gestores de portafolio, referencia para fondos índice</div>
          <div>• <strong>Método de cálculo:</strong> Promedio ponderado basado en valores de mercado de empresas; empresas más grandes tienen más impacto</div>
          <div>• <strong><TermTooltip term="dxy" language="es">DXY (Índice Dólar)</TermTooltip>:</strong> Indicador importante que mide fuerza del dólar estadounidense contra otras monedas principales</div>
          <div>• Diversificación sectorial es crítica para índice saludable; peso excesivo de tecnología puede crear riesgos</div>
        </div>
      ),
      fr: (
        <div className="space-y-3">
          <div>• <strong>Indices de Marché:</strong> Paniers mesurant performance groupes actions sélectionnés par critères spécifiques (S&P 500, BIST 100, FTSE 100)</div>
          <div>• <strong>S&P 500:</strong> Contient 500 plus grandes entreprises américaines et reflète mieux santé générale économie américaine</div>
          <div>• <strong>Usages principaux:</strong> Benchmark pour performance investissement, mesure succès gestionnaires portefeuille, référence fonds indiciels</div>
          <div>• <strong>Méthode calcul:</strong> Moyenne pondérée basée sur valeurs marché entreprises; grandes entreprises ont plus impact</div>
          <div>• <strong><TermTooltip term="dxy" language="fr">DXY (Indice Dollar)</TermTooltip>:</strong> Indicateur important mesurant force dollar américain contre autres devises principales</div>
          <div>• Diversification sectorielle critique pour indice sain; poids technologie excessif peut créer risques</div>
        </div>
      ),
      ru: (
        <div className="space-y-3">
          <div>• <strong>Рыночные индексы:</strong> Корзины измеряющие результативность групп акций выбранных по определенным критериям (S&P 500, BIST 100, FTSE 100)</div>
          <div>• <strong>S&P 500:</strong> Содержит 500 крупнейших американских компаний и лучше всего отражает общее здоровье американской экономики</div>
          <div>• <strong>Основные применения:</strong> Бенчмарк для инвестиционной результативности, мера успеха портфельных менеджеров, ориентир для индексных фондов</div>
          <div>• <strong>Метод расчета:</strong> Взвешенное среднее основанное на рыночных стоимостях компаний; крупные компании имеют больше влияния</div>
          <div>• <strong><TermTooltip term="dxy" language="ru">DXY (Индекс доллара)</TermTooltip>:</strong> Важный индикатор измеряющий силу американского доллара против других основных валют</div>
          <div>• Секторальная диверсификация критична для здорового индекса; чрезмерный вес технологий может создать риски</div>
        </div>
      )
    },
    example: { 
      tr: '📊 2025\'te S&P 500 rekor kapattı; Fed kesintileri verileri destekledi.',
      en: '📊 In 2025, S&P 500 closed at record highs; Fed cuts supported data.',
      es: '📊 En 2025, S&P 500 cerró en máximos récord; cortes Fed apoyaron datos.',
      fr: '📊 En 2025, S&P 500 a clôturé à des records; coupes Fed ont soutenu données.',
      ru: '📊 В 2025 году S&P 500 закрылся на рекордных максимумах; снижения ФРС поддержали данные.'
    },
    icon: <PieChart className="w-16 h-16 text-indigo-500" />
  },
  {
    title: { 
      tr: 'Piyasa Katılımcıları', 
      en: 'Market Participants', 
      es: 'Participantes del Mercado', 
      fr: 'Participants du Marché', 
      ru: 'Участники рынка' 
    },
    content: { 
      tr: [
        '• Ana katılımcılar: Bireysel yatırımcılar (retail), kurumsal yatırımcılar (fonlar, bankalar), aracı kurumlar (brokerler, yatırım bankaları)',
        '• Her grup farklı hedef ve risk iştahıyla hareket eder - hedge fonlar yüksek risk alarak alfa getiri peşinde koşar',
        '• Kritik rolleri: Piyasaya likidite sağlama, adil fiyat keşfi sürecine katkı, riskin tabana yayılması',
        '• Modern etkileşim: Yüksek frekanslı algoritmik ticaret işlem hızını mikrosaniyelere indirdi, AI destekli kararlar yaygınlaştı',
        '• Bu katılımcıların toplu davranışları piyasa trendlerini, volatiliteyi ve genel finansal istikrarı doğrudan şekillendirir'
      ],
      en: [
        '• Main participants: Individual investors (retail), institutional investors (funds, banks), intermediary institutions (brokers, investment banks)',
        '• Each group acts with different goals and risk appetite - hedge funds pursue alpha returns by taking high risks',
        '• Critical roles: Providing market liquidity, contributing to fair price discovery process, spreading risk broadly',
        '• Modern interaction: High-frequency algorithmic trading reduced transaction speed to microseconds, AI-supported decisions became widespread',
        '• Collective behavior of these participants directly shapes market trends, volatility and overall financial stability'
      ],
      es: [
        '• Participantes principales: Inversores individuales (retail), inversores institucionales (fondos, bancos), instituciones intermediarias (brokers, bancos de inversión)',
        '• Cada grupo actúa con diferentes objetivos y apetito de riesgo - fondos hedge persiguen retornos alfa tomando altos riesgos',
        '• Roles críticos: Proveer liquidez al mercado, contribuir al proceso de descubrimiento justo de precios, extender riesgo ampliamente',
        '• Interacción moderna: Trading algorítmico de alta frecuencia redujo velocidad de transacción a microsegundos, decisiones con soporte IA se generalizaron',
        '• Comportamiento colectivo de estos participantes da forma directamente a tendencias de mercado, volatilidad y estabilidad financiera general'
      ],
      fr: [
        '• Participants principaux: Investisseurs individuels (retail), investisseurs institutionnels (fonds, banques), institutions intermédiaires (brokers, banques d\'investissement)',
        '• Chaque groupe agit avec objectifs différents et appétit risque - fonds hedge poursuivent rendements alpha en prenant risques élevés',
        '• Rôles critiques: Fournir liquidité marché, contribuer processus découverte prix équitable, étendre risque largement',
        '• Interaction moderne: Trading algorithmique haute fréquence a réduit vitesse transaction à microsecondes, décisions soutenues IA se sont généralisées',
        '• Comportement collectif ces participants façonne directement tendances marché, volatilité et stabilité financière générale'
      ],
      ru: [
        '• Основные участники: Частные инвесторы (розничные), институциональные инвесторы (фонды, банки), посреднические учреждения (брокеры, инвестиционные банки)',
        '• Каждая группа действует с разными целями и аппетитом к риску - хедж-фонды преследуют альфа-доходность принимая высокие риски',
        '• Критические роли: Обеспечение рыночной ликвидности, содействие справедливому процессу ценообразования, широкое распространение риска',
        '• Современное взаимодействие: Высокочастотный алгоритмический трейдинг сократил скорость транзакций до микросекунд, решения с поддержкой ИИ стали широко распространены',
        '• Коллективное ��оведение этих участников напрямую формирует рыночные тренды, волатильность и общую финансовую стабильность'
      ]
    },
    contentWithTooltips: {
      tr: (
        <div className="space-y-3">
          <div>• Ana katılımcılar: Bireysel yatırımcılar (retail), kurumsal yatırımcılar (fonlar, bankalar), aracı kurumlar (brokerler, yatırım bankaları)</div>
          <div>• Her grup farklı hedef ve risk iştahıyla hareket eder - hedge fonlar yüksek risk alarak alfa getiri peşinde koşar</div>
          <div>• Kritik rolleri: Piyasaya <TermTooltip term="likidite">likidite</TermTooltip> sağlama, adil fiyat keşfi sürecine katkı, riskin tabana yayılması</div>
          <div>• Modern etkileşim: Yüksek frekanslı algoritmik ticaret işlem hızını mikrosaniyelere indirdi, AI destekli kararlar yaygınlaştı</div>
          <div>• Bu katılımcıların toplu davranışları piyasa trendlerini, volatiliteyi ve genel finansal istikrarı doğrudan şekillendirir</div>
        </div>
      ),
      en: (
        <div className="space-y-3">
          <div>• Main participants: Individual investors (retail), institutional investors (funds, banks), intermediary institutions (brokers, investment banks)</div>
          <div>• Each group acts with different goals and risk appetite - hedge funds pursue alpha returns by taking high risks</div>
          <div>• Critical roles: Providing market <TermTooltip term="liquidity" language="en">liquidity</TermTooltip>, contributing to fair price discovery process, spreading risk broadly</div>
          <div>• Modern interaction: High-frequency algorithmic trading reduced transaction speed to microseconds, AI-supported decisions became widespread</div>
          <div>• Collective behavior of these participants directly shapes market trends, volatility and overall financial stability</div>
        </div>
      ),
      es: (
        <div className="space-y-3">
          <div>• Participantes principales: Inversores individuales (retail), inversores institucionales (fondos, bancos), instituciones intermediarias (brokers, bancos de inversión)</div>
          <div>• Cada grupo actúa con diferentes objetivos y apetito de riesgo - fondos hedge persiguen retornos alfa tomando altos riesgos</div>
          <div>• Roles críticos: Proveer <TermTooltip term="liquidez" language="es">liquidez</TermTooltip> al mercado, contribuir al proceso de descubrimiento justo de precios, extender riesgo ampliamente</div>
          <div>• Interacción moderna: Trading algorítmico de alta frecuencia redujo velocidad de transacción a microsegundos, decisiones con soporte IA se generalizaron</div>
          <div>• Comportamiento colectivo de estos participantes da forma directamente a tendencias de mercado, volatilidad y estabilidad financiera general</div>
        </div>
      ),
      fr: (
        <div className="space-y-3">
          <div>• Participants principaux: Investisseurs individuels (retail), investisseurs institutionnels (fonds, banques), institutions intermédiaires (brokers, banques d'investissement)</div>
          <div>• Chaque groupe agit avec objectifs différents et appétit risque - fonds hedge poursuivent rendements alpha en prenant risques élevés</div>
          <div>• Rôles critiques: Fournir <TermTooltip term="liquidite" language="fr">liquidité</TermTooltip> marché, contribuer processus découverte prix équitable, étendre risque largement</div>
          <div>• Interaction moderne: Trading algorithmique haute fréquence a réduit vitesse transaction à microsecondes, décisions soutenues IA se sont généralisées</div>
          <div>• Comportement collectif ces participants façonne directement tendances marché, volatilité et stabilité financière générale</div>
        </div>
      ),
      ru: (
        <div className="space-y-3">
          <div>• Основные участники: Частные инвесторы (розничные), институциональные инвесторы (фонды, банки), посреднические учреждения (брокеры, инвестиционные банки)</div>
          <div>• Каждая группа действует с разными целями и аппетитом к риску - хедж-фонды преследуют альфа-доходность принимая высокие риски</div>
          <div>• Критические роли: Обеспечение рыночной <TermTooltip term="ликвидность" language="ru">ликвидности</TermTooltip>, содействие справедливому процессу ценообразования, широкое распространение риска</div>
          <div>• Современное взаимодействие: Высокочастотный алгоритмический трейдинг сократил скорость транзакций до микросекунд, решения с поддержкой ИИ стали широко распространены</div>
          <div>• Коллективное поведение этих участников напрямую формирует рыночные тренды, волатильность и общую финансовую стабильность</div>
        </div>
      )
    },
    example: { 
      tr: '👥 2025\'te kurumlar, özel kredi yatırımlarını %30 artırdı; M&A canlandı.',
      en: '👥 In 2025, institutions increased private credit investments 30%; M&A revitalized.',
      es: '👥 En 2025, instituciones aumentaron inversiones de crédito privado 30%; M&A se revitalizó.',
      fr: '👥 En 2025, institutions ont augmenté investissements crédit privé 30%; M&A s\'est revitalisé.',
      ru: '👥 В 2025 году институты увеличили инвестиции в частный кредит на 30%; M&A оживились.'
    },
    icon: <Users className="w-16 h-16 text-cyan-500" />
  },
  {
    title: { 
      tr: 'Risk ve Getiri Dengesi', 
      en: 'Risk and Return Balance', 
      es: 'Balance de Riesgo y Retorno', 
      fr: 'Équilibre Risque et Rendement', 
      ru: 'Баланс риска и доходности' 
    },
    content: { 
      tr: [
        '• Temel Kural: Yüksek kazanç isteyen yüksek risk alır - ama aynı şekilde büyük kayıp riski de vardır',
        '• Risk sıralaması: Devlet tahvilleri (güvenli %3-5), hisse senetleri (orta %8-12), kripto paralar (riskli %200 veya -%80)',
        '• Risk ölçüm araçları: Volatilite (fiyat dalgalanması), Beta (piyasayla benzerlik), VaR (potansiyel kayıp)',
        '• Risk kontrolü: Farklı yatırımlar yapın, zamanlamaya dikkat edin, çok büyük bahis oynamayın',
        '• Başarı için: Kendi risk kapasitene uygun, dengeli bir portföy oluştur ve sabırla sürdür'
      ],
      en: [
        '• Basic Rule: Those seeking high returns must take high risks - but there is also large loss risk',
        '• Risk ranking: Government bonds (safe 3-5%), stocks (medium 8-12%), cryptocurrencies (risky +200% or -80%)',
        '• Risk measurement tools: Volatility (price fluctuation), Beta (similarity to market), VaR (potential loss)',
        '• Risk control: Diversify investments, pay attention to timing, don\'t make very large bets',
        '• For success: Create a balanced portfolio suitable for your risk capacity and maintain it patiently'
      ],
      es: [
        '• Regla Básica: Quienes buscan altos retornos deben tomar altos riesgos - pero también hay gran riesgo de pérdida',
        '• Ranking de riesgo: Bonos gubernamentales (seguros 3-5%), acciones (medio 8-12%), criptomonedas (riesgosas +200% o -80%)',
        '• Herramientas medición riesgo: Volatilidad (fluctuación precios), Beta (similitud al mercado), VaR (pérdida potencial)',
        '• Control de riesgo: Diversificar inversiones, prestar atención al timing, no hacer apuestas muy grandes',
        '• Para éxito: Crear portafolio equilibrado adecuado para tu capacidad de riesgo y mantenerlo pacientemente'
      ],
      fr: [
        '• Règle de Base: Ceux qui cherchent hauts rendements doivent prendre hauts risques - mais il y a aussi grand risque perte',
        '• Classement risque: Obligations gouvernementales (sûres 3-5%), actions (moyen 8-12%), cryptomonnaies (risquées +200% ou -80%)',
        '• Outils mesure risque: Volatilité (fluctuation prix), Beta (similarité marché), VaR (perte potentielle)',
        '• Contrôle risque: Diversifier investissements, attention au timing, ne pas faire très gros paris',
        '• Pour succès: Créer portefeuille équilibré adapté à votre capacité risque et maintenir patiemment'
      ],
      ru: [
        '• Основное правило: Те кто ищет высокую доходность должны принимать высокие риски - но есть также большой риск потерь',
        '• Рейтинг риска: Государственные облигации (безопасные 3-5%), акции (средние 8-12%), криптовалюты (рискованные +200% или -80%)',
        '• Инструменты измерения риска: Волатильность (колебания цен), Бета (схожесть с рынком), VaR (потенциальные потери)',
        '• Контроль риска: Диверсифицировать инвестиции, обращать внимание на тайминг, не делать очень крупные ставки',
        '• Для успеха: Создать сбалансированный портфель подходящий для вашей рисковой способности и терпеливо поддерживать'
      ]
    },
    contentWithTooltips: {
      tr: (
        <div className="space-y-3">
          <div>• Temel Kural: Yüksek kazanç isteyen yüksek risk alır - ama aynı şekilde büyük kayıp riski de vardır</div>
          <div>• Risk sıralaması: Devlet tahvilleri (güvenli %3-5), hisse senetleri (orta %8-12), kripto paralar (riskli %200 veya -%80)</div>
          <div>• Risk ölçüm araçları: <TermTooltip term="volatilite">Volatilite</TermTooltip> (fiyat dalgalanması), <TermTooltip term="beta">Beta</TermTooltip> (piyasayla benzerlik), <TermTooltip term="var">VaR</TermTooltip> (potansiyel kayıp)</div>
          <div>• Risk kontrolü: Farklı yatırımlar yapın, zamanlamaya dikkat edin, çok büyük bahis oynamayın</div>
          <div>• Başarı için: Kendi risk kapasitene uygun, dengeli bir portföy oluştur ve sabırla sürdür</div>
        </div>
      ),
      en: (
        <div className="space-y-3">
          <div>• Basic Rule: Those seeking high returns must take high risks - but there is also large loss risk</div>
          <div>• Risk ranking: Government bonds (safe 3-5%), stocks (medium 8-12%), cryptocurrencies (risky +200% or -80%)</div>
          <div>• Risk measurement tools: <TermTooltip term="volatility" language="en">Volatility</TermTooltip> (price fluctuation), <TermTooltip term="beta" language="en">Beta</TermTooltip> (similarity to market), <TermTooltip term="var" language="en">VaR</TermTooltip> (potential loss)</div>
          <div>• Risk control: Diversify investments, pay attention to timing, don't make very large bets</div>
          <div>• For success: Create a balanced portfolio suitable for your risk capacity and maintain it patiently</div>
        </div>
      ),
      es: (
        <div className="space-y-3">
          <div>• Regla Básica: Quienes buscan altos retornos deben tomar altos riesgos - pero también hay gran riesgo de pérdida</div>
          <div>• Ranking de riesgo: Bonos gubernamentales (seguros 3-5%), acciones (medio 8-12%), criptomonedas (riesgosas +200% o -80%)</div>
          <div>• Herramientas medición riesgo: <TermTooltip term="volatilidad" language="es">Volatilidad</TermTooltip> (fluctuación precios), <TermTooltip term="beta" language="es">Beta</TermTooltip> (similitud al mercado), <TermTooltip term="var" language="es">VaR</TermTooltip> (pérdida potencial)</div>
          <div>• Control de riesgo: Diversificar inversiones, prestar atención al timing, no hacer apuestas muy grandes</div>
          <div>• Para éxito: Crear portafolio equilibrado adecuado para tu capacidad de riesgo y mantenerlo pacientemente</div>
        </div>
      ),
      fr: (
        <div className="space-y-3">
          <div>• Règle de Base: Ceux qui cherchent hauts rendements doivent prendre hauts risques - mais il y a aussi grand risque perte</div>
          <div>• Classement risque: Obligations gouvernementales (sûres 3-5%), actions (moyen 8-12%), cryptomonnaies (risquées +200% ou -80%)</div>
          <div>• Outils mesure risque: <TermTooltip term="volatilite" language="fr">Volatilité</TermTooltip> (fluctuation prix), <TermTooltip term="beta" language="fr">Beta</TermTooltip> (similarité marché), <TermTooltip term="var" language="fr">VaR</TermTooltip> (perte potentielle)</div>
          <div>• Contrôle risque: Diversifier investissements, attention au timing, ne pas faire très gros paris</div>
          <div>• Pour succès: Créer portefeuille équilibré adapté à votre capacité risque et maintenir patiemment</div>
        </div>
      ),
      ru: (
        <div className="space-y-3">
          <div>• Основное правило: Те кто ищет высокую доходность должны принимать высокие риски - но есть также большой риск потерь</div>
          <div>• Рейтинг риска: Государственные облигации (безопасные 3-5%), акции (средние 8-12%), криптовалюты (рискованные +200% или -80%)</div>
          <div>• Инструменты измерения риска: <TermTooltip term="волатильность" language="ru">Волатильность</TermTooltip> (колебания цен), <TermTooltip term="бета" language="ru">Бета</TermTooltip> (схожесть с рынком), <TermTooltip term="var" language="ru">VaR</TermTooltip> (потенциальные потери)</div>
          <div>• Контроль риска: Диверсифицировать инвестиции, обращать внимание на тайминг, не делать очень крупные ставки</div>
          <div>• Для успеха: Создать сбалансированный портфель подходящий для вашей рисковой способности и терпеливо поддерживать</div>
        </div>
      )
    },
    example: { 
      tr: '⚖️ 2025\'te hisse getirileri %12\'yi aştı; ancak volatilite arttı.',
      en: '⚖️ In 2025, stock returns exceeded 12%; however volatility increased.',
      es: '⚖️ En 2025, retornos de acciones superaron 12%; sin embargo volatilidad aumentó.',
      fr: '⚖️ En 2025, rendements actions ont dépassé 12%; cependant volatilité a augmenté.',
      ru: '⚖️ В 2025 году доходность акций превысила 12%; однако волатильность увеличилась.'
    },
    icon: <Scale className="w-16 h-16 text-purple-600" />
  },
  {
    title: { 
      tr: 'Portföy Yönetimi', 
      en: 'Portfolio Management', 
      es: 'Gestión de Portafolio', 
      fr: 'Gestion de Portefeuille', 
      ru: 'Управление портфелем' 
    },
    content: { 
      tr: [
        '• Portföy Yönetimi: Paranızı farklı yatırım araçlarına bölerek hem riski azaltıp hem kazancı artırmaya çalışma sanatı',
        '• Klasik dağılım: %60 hisse (büyüme için), %40 tahvil (güvenlik için) - yaşınız arttıkça hisse oranını azaltın',
        '• Yönetim şekilleri: Aktif (sürekli alım-satım), pasif (al-bekle tarzı) - pasif genelde daha karlı çıkar',
        '• Düzenli dengeleme şart: 3-6 ayda bir oranları kontrol edin, sapanları düzeltin',
        '• ETF\'ler ve endeks fonları hem ucuz hem kolay yönetim imkanı sunar - yeni başlayanlar için ideal'
      ],
      en: [
        '• Portfolio Management: The art of dividing your money among different investment instruments to reduce risk while increasing returns',
        '• Classic allocation: 60% stocks (for growth), 40% bonds (for security) - reduce stock ratio as you age',
        '• Management styles: Active (continuous trading), passive (buy-and-hold style) - passive usually more profitable',
        '• Regular rebalancing essential: Check ratios every 3-6 months, correct deviations',
        '• ETFs and index funds offer both cheap and easy management - ideal for beginners'
      ],
      es: [
        '• Gestión de Portafolio: El arte de dividir tu dinero entre diferentes instrumentos de inversión para reducir riesgo mientras aumentas retornos',
        '• Asignación clásica: 60% acciones (para crecimiento), 40% bonos (para seguridad) - reduce ratio de acciones con la edad',
        '• Estilos de gestión: Activo (trading continuo), pasivo (estilo comprar y mantener) - pasivo usualmente más rentable',
        '• Rebalanceo regular esencial: Verificar ratios cada 3-6 meses, corregir desviaciones',
        '• ETFs y fondos índice ofrecen gestión barata y fácil - ideal para principiantes'
      ],
      fr: [
        '• Gestion Portefeuille: Art de diviser argent entre différents instruments investissement pour réduire risque tout augmentant rendements',
        '• Allocation classique: 60% actions (pour croissance), 40% obligations (pour sécurité) - réduire ratio actions avec âge',
        '• Styles gestion: Actif (trading continu), passif (style acheter-conserver) - passif généralement plus rentable',
        '• Rééquilibrage régulier essentiel: Vérifier ratios tous 3-6 mois, corriger déviations',
        '• ETFs et fonds indiciels offrent gestion bon marché et facile - idéal pour débutants'
      ],
      ru: [
        '• Управление портфелем: Искусство разделения денег между разными инвестиционными инструментами для снижения риска при увеличении доходности',
        '• Классическое распределение: 60% акции (для роста), 40% облигации (для безопасности) - уменьшайте долю акций с возрастом',
        '• Стили управления: Активный (непрерывная торговля), пассивный (стиль покупай-держи) - пассивный обычно более прибыльный',
        '• Регулярная перебалансировка обязательна: Проверяйте соотношения каждые 3-6 месяцев, исправляйте отклонения',
        '• ETF и индексные фонды предлагают дешевое и легкое управление - идеально для новичков'
      ]
    },
    contentWithTooltips: {
      tr: (
        <div className="space-y-3">
          <div>• Portföy Yönetimi: Paranızı farklı yatırım araçlarına bölerek hem riski azaltıp hem kazancı artırmaya çalışma sanatı</div>
          <div>• Klasik dağılım: %60 hisse (büyüme için), %40 tahvil (güvenlik için) - yaşınız arttıkça hisse oranını azaltın</div>
          <div>• Yönetim şekilleri: Aktif (sürekli alım-satım), pasif (al-bekle tarzı) - pasif genelde daha karlı çıkar</div>
          <div>• Düzenli dengeleme şart: 3-6 ayda bir oranları kontrol edin, sapanları düzeltin</div>
          <div>• <TermTooltip term="etf">ETF</TermTooltip>'ler ve endeks fonları hem ucuz hem kolay yönetim imkanı sunar - yeni başlayanlar için ideal</div>
        </div>
      ),
      en: (
        <div className="space-y-3">
          <div>• Portfolio Management: The art of dividing your money among different investment instruments to reduce risk while increasing returns</div>
          <div>• Classic allocation: 60% stocks (for growth), 40% bonds (for security) - reduce stock ratio as you age</div>
          <div>• Management styles: Active (continuous trading), passive (buy-and-hold style) - passive usually more profitable</div>
          <div>• Regular rebalancing essential: Check ratios every 3-6 months, correct deviations</div>
          <div>• <TermTooltip term="etf" language="en">ETFs</TermTooltip> and index funds offer both cheap and easy management - ideal for beginners</div>
        </div>
      ),
      es: (
        <div className="space-y-3">
          <div>• Gestión de Portafolio: El arte de dividir tu dinero entre diferentes instrumentos de inversión para reducir riesgo mientras aumentas retornos</div>
          <div>• Asignación clásica: 60% acciones (para crecimiento), 40% bonos (para seguridad) - reduce ratio de acciones con la edad</div>
          <div>• Estilos de gestión: Activo (trading continuo), pasivo (estilo comprar y mantener) - pasivo usualmente más rentable</div>
          <div>• Rebalanceo regular esencial: Verificar ratios cada 3-6 meses, corregir desviaciones</div>
          <div>• <TermTooltip term="etf" language="es">ETFs</TermTooltip> y fondos índice ofrecen gestión barata y fácil - ideal para principiantes</div>
        </div>
      ),
      fr: (
        <div className="space-y-3">
          <div>• Gestion Portefeuille: Art de diviser argent entre différents instruments investissement pour réduire risque tout augmentant rendements</div>
          <div>• Allocation classique: 60% actions (pour croissance), 40% obligations (pour sécurité) - réduire ratio actions avec âge</div>
          <div>• Styles gestion: Actif (trading continu), passif (style acheter-conserver) - passif généralement plus rentable</div>
          <div>• Rééquilibrage régulier essentiel: Vérifier ratios tous 3-6 mois, corriger déviations</div>
          <div>• <TermTooltip term="etf" language="fr">ETFs</TermTooltip> et fonds indiciels offrent gestion bon marché et facile - idéal pour débutants</div>
        </div>
      ),
      ru: (
        <div className="space-y-3">
          <div>• Управление портфелем: Искусство разделения денег между разными инвестиционными инструментами для снижения риска при увеличении доходности</div>
          <div>• Классическое распределение: 60% акции (для роста), 40% облигации (для безопасности) - уменьшайте долю акций с возрастом</div>
          <div>• Стили управления: Активный (непрерывная торговля), пассивный (стиль покупай-держи) - пассивный обычно более прибыльный</div>
          <div>• Регулярная перебалансировка обязательна: Проверяйте соотношения каждые 3-6 месяцев, исправляйте отклонения</div>
          <div>• <TermTooltip term="etf" language="ru">ETF</TermTooltip> и индексные фонды предлагают дешевое и легкое управление - идеально для новичков</div>
        </div>
      )
    },
    example: { 
      tr: '💼 2025\'te multi-asset portföyler, altın ve emtia ekleyerek %8 getiri sağladı.',
      en: '💼 In 2025, multi-asset portfolios achieved 8% return by adding gold and commodities.',
      es: '💼 En 2025, portafolios multi-activos lograron 8% retorno agregando oro y materias primas.',
      fr: '💼 En 2025, portefeuilles multi-actifs ont atteint 8% rendement en ajoutant or et matières premières.',
      ru: '💼 В 2025 году мульти-активные портфели достигли 8% доходности добавив золото и товары.'
    },
    icon: <Briefcase className="w-16 h-16 text-teal-600" />
  },
  {
    title: { 
      tr: 'Piyasa Verimliliği Hipotezi', 
      en: 'Efficient Market Hypothesis', 
      es: 'Hipótesis del Mercado Eficiente', 
      fr: 'Hypothèse du Marché Efficace', 
      ru: 'Гипотеза эффективного рынка' 
    },
    content: { 
      tr: [
        '• Etkin Piyasa Hipotezi: Tüm mevcut bilgiler anında fiyatlara yansır; hisse fiyatları rastgele yürüyüş sergiler',
        '• Yeni bilgi (haberler, ekonomik veriler) anında fiyatlarda değişiklik yaratır; geç kalanlar arbitraj fırsatından yararlanamaz',
        '• Üç verimlilik formu: Zayıf (geçmiş fiyatlar), Yarı-güçlü (kamuya açık bilgiler), Güçlü (içeriden bilgiler dahil tüm bilgi)',
        '• Gerçek dünya eleştirileri: Değer anomalisi, momentum etkisi, takvim anomalileri gibi piyasa verimsizlikler fırsat yaratır',
        '• Sonuç: Piyasalar genelde etkin ama kısa dönem verimsizlikler ve duygusal tepkiler arbitraj imkanları sunar'
      ],
      en: [
        '• Efficient Market Hypothesis: All available information is instantly reflected in prices; stock prices show random walk',
        '• New information (news, economic data) instantly creates price changes; latecomers cannot benefit from arbitrage opportunities',
        '• Three efficiency forms: Weak (past prices), Semi-strong (public information), Strong (all information including insider)',
        '• Real-world criticisms: Value anomalies, momentum effects, calendar anomalies create market inefficiencies that offer opportunities',
        '• Conclusion: Markets are generally efficient but short-term inefficiencies and emotional reactions offer arbitrage opportunities'
      ],
      es: [
        '• Hipótesis Mercado Eficiente: Toda información disponible se refleja instantáneamente en precios; precios de acciones muestran camino aleatorio',
        '• Nueva información (noticias, datos económicos) crea cambios de precios instantáneamente; rezagados no pueden beneficiarse de oportunidades de arbitraje',
        '• Tres formas de eficiencia: Débil (precios pasados), Semi-fuerte (información pública), Fuerte (toda información incluyendo insider)',
        '• Críticas mundo real: Anomalías de valor, efectos momentum, anomalías calendario crean ineficiencias de mercado que ofrecen oportunidades',
        '• Conclusión: Mercados son generalmente eficientes pero ineficiencias corto plazo y reacciones emocionales ofrecen oportunidades arbitraje'
      ],
      fr: [
        '• Hypothèse Marché Efficace: Toute information disponible se reflète instantanément dans prix; prix actions montrent marche aléatoire',
        '• Nouvelle information (nouvelles, données économiques) crée changements prix instantanément; retardataires ne peuvent bénéficier opportunités arbitrage',
        '• Trois formes efficacité: Faible (prix passés), Semi-forte (information publique), Forte (toute information incluant insider)',
        '• Critiques monde réel: Anomalies valeur, effets momentum, anomalies calendrier créent inefficacités marché qui offrent opportunités',
        '• Conclusion: Marchés sont généralement efficaces mais inefficacités court terme et réactions émotionnelles offrent opportunités arbitrage'
      ],
      ru: [
        '• Гипотеза эффективного рынка: Вся доступная информация мгновенно отражается в ценах; цены акций показывают случайное блуждание',
        '• Новая информация (новости, экономические данные) мгновенно создает изменения цен; опоздавшие не могут извлечь выгоду из арбитражных возможностей',
        '• Три формы эффективности: Слабая (прошлые цены), Полусильная (публичная информация), Сильная (вся информация включая инсайдерскую)',
        '• Критика реального мира: Ценовые аномалии, эффекты моментума, календарные аномалии создают рыночные неэффективности предлагающие возможности',
        '• Заключение: Рынки в целом эффективны но краткосрочные неэффективности и эмоциональные реакции предлагают арбитражные возможности'
      ]
    },
    contentWithTooltips: {
      tr: (
        <div className="space-y-3">
          <div>• Etkin Piyasa Hipotezi: Tüm mevcut bilgiler anında fiyatlara yansır; hisse fiyatları rastgele yürüyüş sergiler</div>
          <div>• Yeni bilgi (haberler, ekonomik veriler) anında fiyatlarda değişiklik yaratır; geç kalanlar arbitraj fırsatından yararlanamaz</div>
          <div>• Üç verimlilik formu: Zayıf (geçmiş fiyatlar), Yarı-güçlü (kamuya açık bilgiler), Güçlü (içeriden bilgiler dahil tüm bilgi)</div>
          <div>• Gerçek dünya eleştirileri: Değer anomalisi, momentum etkisi, takvim anomalileri gibi piyasa verimsizlikler fırsat yaratır</div>
          <div>• Sonuç: Piyasalar genelde etkin ama kısa dönem verimsizlikler ve duygusal tepkiler arbitraj imkanları sunar</div>
        </div>
      ),
      en: (
        <div className="space-y-3">
          <div>• Efficient Market Hypothesis: All available information is instantly reflected in prices; stock prices show random walk</div>
          <div>• New information (news, economic data) instantly creates price changes; latecomers cannot benefit from arbitrage opportunities</div>
          <div>• Three efficiency forms: Weak (past prices), Semi-strong (public information), Strong (all information including insider)</div>
          <div>• Real-world criticisms: Value anomalies, momentum effects, calendar anomalies create market inefficiencies that offer opportunities</div>
          <div>• Conclusion: Markets are generally efficient but short-term inefficiencies and emotional reactions offer arbitrage opportunities</div>
        </div>
      ),
      es: (
        <div className="space-y-3">
          <div>• Hipótesis Mercado Eficiente: Toda información disponible se refleja instantáneamente en precios; precios de acciones muestran camino aleatorio</div>
          <div>• Nueva información (noticias, datos económicos) crea cambios de precios instantáneamente; rezagados no pueden beneficiarse de oportunidades de arbitraje</div>
          <div>• Tres formas de eficiencia: Débil (precios pasados), Semi-fuerte (información pública), Fuerte (toda información incluyendo insider)</div>
          <div>• Críticas mundo real: Anomalías de valor, efectos momentum, anomalías calendario crean ineficiencias de mercado que ofrecen oportunidades</div>
          <div>• Conclusión: Mercados son generalmente eficientes pero ineficiencias corto plazo y reacciones emocionales ofrecen oportunidades arbitraje</div>
        </div>
      ),
      fr: (
        <div className="space-y-3">
          <div>• Hypothèse Marché Efficace: Toute information disponible se reflète instantanément dans prix; prix actions montrent marche aléatoire</div>
          <div>• Nouvelle information (nouvelles, données économiques) crée changements prix instantanément; retardataires ne peuvent bénéficier opportunités arbitrage</div>
          <div>• Trois formes efficacité: Faible (prix passés), Semi-forte (information publique), Forte (toute information incluant insider)</div>
          <div>• Critiques monde réel: Anomalies valeur, effets momentum, anomalies calendrier créent inefficacités marché qui offrent opportunités</div>
          <div>• Conclusion: Marchés sont généralement efficaces mais inefficacités court terme et réactions émotionnelles offrent opportunités arbitrage</div>
        </div>
      ),
      ru: (
        <div className="space-y-3">
          <div>• Гипотеза эффективного рынка: Вся доступная информация мгновенно отражается в ценах; цены акций показывают случайное блуждание</div>
          <div>• Новая информация (новости, экономические данные) мгновенно создает изменения цен; опоздавшие не могут извлечь выгоду из арбитражных возможностей</div>
          <div>• Три формы эффективности: Слабая (прошлые цены), Полусильная (публичная информация), Сильная (вся информация включая инсайдерскую)</div>
          <div>• Критика реального мира: Ценовые аномалии, эффекты моментума, календарные аномалии создают рыночные неэффективности предлагающие возможности</div>
          <div>• Заключение: Рынки в целом эффективны но краткосрочные неэффективности и эмоциональные реакции предлагают арбитражные возможности</div>
        </div>
      )
    },
    example: { 
      tr: '📈 2025\'te piyasalar, Fed verileriyle hızlı tepki verdi; verimlilik test edildi.',
      en: '📈 In 2025, markets reacted quickly to Fed data; efficiency was tested.',
      es: '📈 En 2025, mercados reaccionaron rápidamente a datos Fed; eficiencia fue probada.',
      fr: '📈 En 2025, marchés ont réagi rapidement aux données Fed; efficacité a été testée.',
      ru: '📈 В 2025 году рынки быстро отреагировали на данные ФРС; эффективность была проверена.'
    },
    icon: <Target className="w-16 h-16 text-green-700" />
  },
  {
    title: { 
      tr: 'Davranışsal Finans', 
      en: 'Behavioral Finance', 
      es: 'Finanzas Conductuales', 
      fr: 'Finance Comportementale', 
      ru: 'Поведенческие финансы' 
    },
    content: { 
      tr: [
        '• Davranışsal Finans: İnsan psikolojisi ve duygularının finansal kararları nasıl etkilediğini inceler; aşırı güven büyük kayıplara yol açar',
        '• Panik satış ve FOMO (kaçırma korkusu) alımları piyasa dalgalanmalarını derinleştirir ve balonlar yaratır',
        '• Yaygın bilişsel önyargılar: Kayıptan kaçınma, sürü psikolojisi, onaylama yanlılığı, aşırı iyimserlik',
        '• Pratik uygulamalar: Nudge teknikleri, otomatik tasarruf planları ve disiplinli yatırım kuralları rasyonelliği artırır',
        '• Sonuç: Psikolojik faktörleri anlayıp kontrol altına alan yatırımcılar daha başarılı uzun vadeli sonuçlar elde eder'
      ],
      en: [
        '• Behavioral Finance: Studies how human psychology and emotions affect financial decisions; overconfidence leads to large losses',
        '• Panic selling and FOMO (fear of missing out) buying deepens market fluctuations and creates bubbles',
        '• Common cognitive biases: Loss aversion, herd mentality, confirmation bias, excessive optimism',
        '• Practical applications: Nudge techniques, automatic savings plans and disciplined investment rules increase rationality',
        '• Conclusion: Investors who understand and control psychological factors achieve more successful long-term results'
      ],
      es: [
        '• Finanzas Conductuales: Estudia cómo psicología humana y emociones afectan decisiones financieras; exceso de confianza lleva a grandes pérdidas',
        '• Venta pánico y compra FOMO (miedo perderse) profundiza fluctuaciones mercado y crea burbujas',
        '• Sesgos cognitivos comunes: Aversión pérdida, mentalidad rebaño, sesgo confirmación, optimismo excesivo',
        '• Aplicaciones prácticas: Técnicas empujón, planes ahorro automático y reglas inversión disciplinadas aumentan racionalidad',
        '• Conclusión: Inversores que entienden y controlan factores psicológicos logran resultados largo plazo más exitosos'
      ],
      fr: [
        '• Finance Comportementale: Étudie comment psychologie humaine et émotions affectent décisions financières; excès confiance mène à grandes pertes',
        '• Vente panique et achat FOMO (peur rater) approfondit fluctuations marché et crée bulles',
        '• Biais cognitifs communs: Aversion perte, mentalité troupeau, biais confirmation, optimisme excessif',
        '• Applications pratiques: Techniques incitation, plans épargne automatiques et règles investissement disciplinées augmentent rationalité',
        '• Conclusion: Investisseurs qui comprennent et contrôlent facteurs psychologiques obtiennent résultats long terme plus réussis'
      ],
      ru: [
        '• Поведенческие финансы: Изучают как человеческая психология и эмоции влияют на финансовые решения; самоуверенность приводит к большим потерям',
        '• Паническая продажа и покупки FOMO (страх упустить) углубляют рыночные колебания и создают пузыри',
        '• Распространенные когнитивные предрассудки: Неприятие потерь, стадное мышление, предвзятость подтверждения, чрезмерный оптимизм',
        '• Практические применения: Техники подталкивания, автоматические планы сбережений и дисциплинированные правила инвестирования увеличивают рациональность',
        '• Заключение: Инвесторы которые понимают и контролируют психологические факторы достигают более успешных долгосрочных результатов'
      ]
    },
    contentWithTooltips: {
      tr: (
        <div className="space-y-3">
          <div>• Davranışsal Finans: İnsan psikolojisi ve duygularının finansal kararları nasıl etkilediğini inceler; aşırı güven büyük kayıplara yol açar</div>
          <div>• Panik satış ve FOMO (kaçırma korkusu) alımları piyasa dalgalanmalarını derinleştirir ve balonlar yaratır</div>
          <div>• Yaygın bilişsel önyargılar: Kayıptan kaçınma, sürü psikolojisi, onaylama yanlılığı, aşırı iyimserlik</div>
          <div>• Pratik uygulamalar: <TermTooltip term="dürtme-teknikleri">Nudge teknikleri</TermTooltip>, otomatik tasarruf planları ve disiplinli yatırım kuralları rasyonelliği artırır</div>
          <div>• Sonuç: Psikolojik faktörleri anlayıp kontrol altına alan yatırımcılar daha başarılı uzun vadeli sonuçlar elde eder</div>
        </div>
      ),
      en: (
        <div className="space-y-3">
          <div>• Behavioral Finance: Studies how human psychology and emotions affect financial decisions; overconfidence leads to large losses</div>
          <div>• Panic selling and FOMO (fear of missing out) buying deepens market fluctuations and creates bubbles</div>
          <div>• Common cognitive biases: Loss aversion, herd mentality, confirmation bias, excessive optimism</div>
          <div>• Practical applications: <TermTooltip term="nudge-techniques" language="en">Nudge techniques</TermTooltip>, automatic savings plans and disciplined investment rules increase rationality</div>
          <div>• Conclusion: Investors who understand and control psychological factors achieve more successful long-term results</div>
        </div>
      ),
      es: (
        <div className="space-y-3">
          <div>• Finanzas Conductuales: Estudia cómo psicología humana y emociones afectan decisiones financieras; exceso de confianza lleva a grandes pérdidas</div>
          <div>• Venta pánico y compra FOMO (miedo perderse) profundiza fluctuaciones mercado y crea burbujas</div>
          <div>• Sesgos cognitivos comunes: Aversión pérdida, mentalidad rebaño, sesgo confirmación, optimismo excesivo</div>
          <div>• Aplicaciones prácticas: <TermTooltip term="tecnicas-empujon" language="es">Técnicas empujón</TermTooltip>, planes ahorro automático y reglas inversión disciplinadas aumentan racionalidad</div>
          <div>• Conclusión: Inversores que entienden y controlan factores psicológicos logran resultados largo plazo más exitosos</div>
        </div>
      ),
      fr: (
        <div className="space-y-3">
          <div>• Finance Comportementale: Étudie comment psychologie humaine et émotions affectent décisions financières; excès confiance mène à grandes pertes</div>
          <div>• Vente panique et achat FOMO (peur rater) approfondit fluctuations marché et crée bulles</div>
          <div>• Biais cognitifs communs: Aversion perte, mentalité troupeau, biais confirmation, optimisme excessif</div>
          <div>• Applications pratiques: <TermTooltip term="techniques-incitation" language="fr">Techniques incitation</TermTooltip>, plans épargne automatiques et règles investissement disciplinées augmentent rationalité</div>
          <div>• Conclusion: Investisseurs qui comprennent et contrôlent facteurs psychologiques obtiennent résultats long terme plus réussis</div>
        </div>
      ),
      ru: (
        <div className="space-y-3">
          <div>• Поведенческие финансы: Изучают как человеческая психология и эмоции влияют на финансовые решения; самоуверенность приводит к большим потерям</div>
          <div>• Паническая продажа и покупки FOMO (страх упустить) углубляют рыночные колебания и создают пузыри</div>
          <div>• Распространенные когнитивные предрассудки: Неприятие потерь, стадное мышление, предвзятость подтверждения, чрезмерный оптимизм</div>
          <div>• Практические применения: <TermTooltip term="техники-подталкивания" language="ru">Техники подталкивания</TermTooltip>, автоматические планы сбережений и дисциплинированные правила инвестирования увеличивают рациональность</div>
          <div>• Заключение: Инвесторы которые понимают и контролируют психологические факторы достигают более успешных долгосрочных результатов</div>
        </div>
      )
    },
    example: { 
      tr: '🧠 2025\'te davranışsal faktörler, kripto boğa koşusunu tetikledi; FOMO etkisi.',
      en: '🧠 In 2025, behavioral factors triggered crypto bull run; FOMO effect.',
      es: '🧠 En 2025, factores conductuales dispararon bull run cripto; efecto FOMO.',
      fr: '🧠 En 2025, facteurs comportementaux ont déclenché bull run crypto; effet FOMO.',
      ru: '🧠 В 2025 году поведенческие факторы запустили криптобычий рынок; эффект FOMO.'
    },
    icon: <Brain className="w-16 h-16 text-pink-500" />
  },
  {
    title: { 
      tr: 'Piyasa Düzenlemeleri', 
      en: 'Market Regulations', 
      es: 'Regulaciones del Mercado', 
      fr: 'Régulations du Marché', 
      ru: 'Рыночные регулирования' 
    },
    content: { 
      tr: [
        '• Finansal Düzenlemeler: SEC (ABD), SPK (Türkiye) gibi kurumlar piyasa şeffaflığını sağlar; insider trading ve manipülasyonu yasaklar',
        '• Temel amaçları: Bireysel yatırımcı koruması, sistemik risklerin önlenmesi, piyasa bütünlüğünün sağlanması',
        '• Basel III kuralları: Bankaların sermaye yeterliliği, likidite oranları ve risk yönetimi standartlarını güçlendirir',
        '• Düzenleme etkileri: Uyum maliyetleri yüksek olsa da yatırımcı güvenini artırır ve uzun vadeli stabilite sağlar',
        '• Sonuç: Etkili regülasyon finansal krizleri önler, piyasa istikrarını destekler ve ekonomik büyümeyi kolaylaştırır'
      ],
      en: [
        '• Financial Regulations: Institutions like SEC (US), SPK (Turkey) ensure market transparency; prohibit insider trading and manipulation',
        '• Basic objectives: Individual investor protection, preventing systemic risks, ensuring market integrity',
        '• Basel III rules: Strengthen banks\' capital adequacy, liquidity ratios and risk management standards',
        '• Regulation effects: Though compliance costs are high, increases investor confidence and provides long-term stability',
        '• Conclusion: Effective regulation prevents financial crises, supports market stability and facilitates economic growth'
      ],
      es: [
        '• Regulaciones Financieras: Instituciones como SEC (EE.UU.), SPK (Turquía) aseguran transparencia del mercado; prohíben trading insider y manipulación',
        '• Objetivos básicos: Protección inversor individual, prevención riesgos sistémicos, aseguramiento integridad mercado',
        '• Reglas Basel III: Fortalecen adecuación capital bancos, ratios liquidez y estándares gestión riesgo',
        '• Efectos regulación: Aunque costos cumplimiento son altos, aumenta confianza inversor y proporciona estabilidad largo plazo',
        '• Conclusión: Regulación efectiva previene crisis financieras, apoya estabilidad mercado y facilita crecimiento económico'
      ],
      fr: [
        '• Régulations Financières: Institutions comme SEC (États-Unis), SPK (Turquie) assurent transparence marché; interdisent trading initié et manipulation',
        '• Objectifs de base: Protection investisseur individuel, prévention risques systémiques, assurance intégrité marché',
        '• Règles Basel III: Renforcent adéquation capital banques, ratios liquidité et standards gestion risque',
        '• Effets régulation: Bien que coûts conformité soient élevés, augmente confiance investisseur et fournit stabilité long terme',
        '• Conclusion: Régulation efficace prévient crises financières, soutient stabilité marché et facilite croissance économique'
      ],
      ru: [
        '• Финансовые регулирования: Институты как SEC (США), SPK (Турция) обеспечивают прозрачность рынка; запрещают инсайдерскую торговлю и манипуляции',
        '• Основные цели: Защита частных инвесторов, предотвращение системных рисков, обеспечение целостности рынка',
        '• Правила Basel III: Укрепляют достаточность капитала банков, коэффициенты ликвидности и стандарты управления рисками',
        '• Эффекты регулирования: Хотя затраты на соответствие высоки, увеличивает доверие инвесторов и обеспечивает долгосрочную стабильность',
        '• Заключение: Эффективное регулирование предотвращает финансовые кризисы, поддерживает стабильность рынка и способствует экономическому росту'
      ]
    },
    contentWithTooltips: {
      tr: (
        <div className="space-y-3">
          <div>• Finansal Düzenlemeler: <TermTooltip term="sec">SEC</TermTooltip> (ABD), <TermTooltip term="spk">SPK</TermTooltip> (Türkiye) gibi kurumlar piyasa şeffaflığını sağlar; insider trading ve manipülasyonu yasaklar</div>
          <div>• Temel amaçları: Bireysel yatırımcı koruması, sistemik risklerin önlenmesi, piyasa bütünlüğünün sağlanması</div>
          <div>• Basel III kuralları: Bankaların sermaye yeterliliği, likidite oranları ve risk yönetimi standartlarını güçlendirir</div>
          <div>• Düzenleme etkileri: Uyum maliyetleri yüksek olsa da yatırımcı güvenini artırır ve uzun vadeli stabilite sağlar</div>
          <div>• Sonuç: Etkili regülasyon finansal krizleri önler, piyasa istikrarını destekler ve ekonomik büyümeyi kolaylaştırır</div>
        </div>
      ),
      en: (
        <div className="space-y-3">
          <div>• Financial Regulations: Institutions like <TermTooltip term="sec" language="en">SEC</TermTooltip> (US), <TermTooltip term="spk" language="en">SPK</TermTooltip> (Turkey) ensure market transparency; prohibit insider trading and manipulation</div>
          <div>• Basic objectives: Individual investor protection, preventing systemic risks, ensuring market integrity</div>
          <div>• Basel III rules: Strengthen banks' capital adequacy, liquidity ratios and risk management standards</div>
          <div>• Regulation effects: Though compliance costs are high, increases investor confidence and provides long-term stability</div>
          <div>• Conclusion: Effective regulation prevents financial crises, supports market stability and facilitates economic growth</div>
        </div>
      ),
      es: (
        <div className="space-y-3">
          <div>• Regulaciones Financieras: Instituciones como <TermTooltip term="sec" language="es">SEC</TermTooltip> (EE.UU.), <TermTooltip term="spk" language="es">SPK</TermTooltip> (Turquía) aseguran transparencia del mercado; prohíben trading insider y manipulación</div>
          <div>• Objetivos básicos: Protección inversor individual, prevención riesgos sistémicos, aseguramiento integridad mercado</div>
          <div>• Reglas Basel III: Fortalecen adecuación capital bancos, ratios liquidez y estándares gestión riesgo</div>
          <div>• Efectos regulación: Aunque costos cumplimiento son altos, aumenta confianza inversor y proporciona estabilidad largo plazo</div>
          <div>• Conclusión: Regulación efectiva previene crisis financieras, apoya estabilidad mercado y facilita crecimiento económico</div>
        </div>
      ),
      fr: (
        <div className="space-y-3">
          <div>• Régulations Financières: Institutions comme <TermTooltip term="sec" language="fr">SEC</TermTooltip> (États-Unis), <TermTooltip term="spk" language="fr">SPK</TermTooltip> (Turquie) assurent transparence marché; interdisent trading initié et manipulation</div>
          <div>• Objectifs de base: Protection investisseur individuel, prévention risques systémiques, assurance intégrité marché</div>
          <div>• Règles Basel III: Renforcent adéquation capital banques, ratios liquidité et standards gestion risque</div>
          <div>• Effets régulation: Bien que coûts conformité soient élevés, augmente confiance investisseur et fournit stabilité long terme</div>
          <div>• Conclusion: Régulation efficace prévient crises financières, soutient stabilité marché et facilite croissance économique</div>
        </div>
      ),
      ru: (
        <div className="space-y-3">
          <div>• Финансовые регулирования: Институты как <TermTooltip term="sec" language="ru">SEC</TermTooltip> (США), <TermTooltip term="spk" language="ru">SPK</TermTooltip> (Турция) обеспечивают прозрачность рынка; запрещают инсайдерскую торговлю и манипуляции</div>
          <div>• Основные цели: Защита частных инвесторов, предотвращение системных рисков, обеспечение целостности рынка</div>
          <div>• Правила Basel III: Укрепляют достаточность капитала банков, коэффициенты ликвидности и стандарты управления рисками</div>
          <div>• Эффекты регулирования: Хотя затраты на соответствие высоки, увеличивает доверие инвесторов и обеспечивает долгосрочную стабильность</div>
          <div>• Заключение: Эффективное регулирование предотвращает финансовые кризисы, поддерживает стабильность рынка и способствует экономическому росту</div>
        </div>
      )
    },
    example: { 
      tr: '⚖️ 2025\'te düzenlemeler, fintech entegrasyonunu hızlandırdı; compliance trendi.',
      en: '⚖️ In 2025, regulations accelerated fintech integration; compliance trend.',
      es: '⚖️ En 2025, regulaciones aceleraron integración fintech; tendencia cumplimiento.',
      fr: '⚖️ En 2025, régulations ont accéléré intégration fintech; tendance conformité.',
      ru: '⚖️ В 2025 году регулирования ускорили интеграцию финтех; тренд соответствия.'
    },
    icon: <Gavel className="w-16 h-16 text-red-600" />
  },
  {
    title: { 
      tr: 'Global Piyasalar ve Entegrasyon', 
      en: 'Global Markets and Integration', 
      es: 'Mercados Globales e Integración', 
      fr: 'Marchés Mondiaux et Intégration', 
      ru: 'Глобальные рынки и интеграция' 
    },
    content: { 
      tr: [
        '• Küresel Entegrasyon: Modern finansal piyasalar tamamen birbirine bağlı; ABD borsasındaki düşüş saatler içinde Asya ve Avrupa\'yı etkiler',
        '• Ticaret savaşları, gümrük tarifeleri ve jeopolitik gerginlikler küresel döviz kurlarında yüksek volatilite yaratır',
        '• Entegrasyonun avantajları: Uluslararası çeşitlendirme, arbitraj fırsatları; riskleri: Finansal bulaşma (contagion) etkisi',
        '• Modern trendler: ESG (çevresel, sosyal, yönetişim) odaklı yatırımlar artıyor; sürdürülebilir finans ön plana çıkıyor',
        '• Gelecek: Başarılı küresel portföy yönetimi için merkez bankalarının koordinasyonu ve risk paylaşımı kritik önem taşır'
      ],
      en: [
        '• Global Integration: Modern financial markets are completely interconnected; decline in US stock market affects Asia and Europe within hours',
        '• Trade wars, customs tariffs and geopolitical tensions create high volatility in global exchange rates',
        '• Integration advantages: International diversification, arbitrage opportunities; risks: Financial contagion effect',
        '• Modern trends: ESG (environmental, social, governance) focused investments increasing; sustainable finance coming to forefront',
        '• Future: Central bank coordination and risk sharing critical for successful global portfolio management'
      ],
      es: [
        '• Integración Global: Mercados financieros modernos están completamente interconectados; declive en mercado bursátil estadounidense afecta Asia y Europa en horas',
        '• Guerras comerciales, aranceles aduaneros y tensiones geopolíticas crean alta volatilidad en tipos de cambio globales',
        '• Ventajas integración: Diversificación internacional, oportunidades arbitraje; riesgos: Efecto contagio financiero',
        '• Tendencias modernas: Inversiones enfocadas ESG (ambiental, social, gobernanza) aumentando; finanzas sostenibles llegando al frente',
        '• Futuro: Coordinación banco central y compartir riesgo crítico para gestión exitosa portafolio global'
      ],
      fr: [
        '• Intégration Mondiale: Marchés financiers modernes sont complètement interconnectés; déclin marché boursier américain affecte Asie et Europe en heures',
        '• Guerres commerciales, tarifs douaniers et tensions géopolitiques créent haute volatilité taux change mondiaux',
        '• Avantages intégration: Diversification internationale, opportunités arbitrage; risques: Effet contagion financière',
        '• Tendances modernes: Investissements axés ESG (environnemental, social, gouvernance) augmentent; finance durable arrive au premier plan',
        '• Avenir: Coordination banque centrale et partage risque critiques pour gestion réussie portefeuille mondial'
      ],
      ru: [
        '• Глобальная интеграция: Современные финансовые рынки полностью взаимосвязаны; снижение американского фондового рынка влияет на Азию и Европу в течение часов',
        '• Торговые войны, таможенные тарифы и геополитическая напряженность создают высокую волатильность глобальных обменных курсов',
        '• Преимущества интеграции: Международная диверсификация, арбитражные возможности; риски: Эффект финансового заражения',
        '• Современные тренды: ESG (экологические, социальные, управленческие) ориентированные инвестиции растут; устойчивые финансы выходят на передний план',
        '• Будущее: Координация центральных банков и разделение рисков критично для успешного управления глобальным портфелем'
      ]
    },
    contentWithTooltips: {
      tr: (
        <div className="space-y-3">
          <div>• Küresel Entegrasyon: Modern finansal piyasalar tamamen birbirine bağlı; ABD borsasındaki düşüş saatler içinde Asya ve Avrupa'yı etkiler</div>
          <div>• Ticaret savaşları, gümrük tarifeleri ve jeopolitik gerginlikler küresel döviz kurlarında yüksek volatilite yaratır</div>
          <div>• Entegrasyonun avantajları: Uluslararası çeşitlendirme, arbitraj fırsatları; riskleri: <TermTooltip term="finansal-bulasma">Finansal bulaşma</TermTooltip> (contagion) etkisi</div>
          <div>• Modern trendler: <TermTooltip term="esg">ESG</TermTooltip> (çevresel, sosyal, yönetişim) odaklı yatırımlar artıyor; sürdürülebilir finans ön plana çıkıyor</div>
          <div>• Gelecek: Başarılı küresel portföy yönetimi için merkez bankalarının koordinasyonu ve risk paylaşımı kritik önem taşır</div>
        </div>
      ),
      en: (
        <div className="space-y-3">
          <div>• Global Integration: Modern financial markets are completely interconnected; decline in US stock market affects Asia and Europe within hours</div>
          <div>• Trade wars, customs tariffs and geopolitical tensions create high volatility in global exchange rates</div>
          <div>• Integration advantages: International diversification, arbitrage opportunities; risks: <TermTooltip term="financial-contagion" language="en">Financial contagion</TermTooltip> effect</div>
          <div>• Modern trends: <TermTooltip term="esg" language="en">ESG</TermTooltip> (environmental, social, governance) focused investments increasing; sustainable finance coming to forefront</div>
          <div>• Future: Central bank coordination and risk sharing critical for successful global portfolio management</div>
        </div>
      ),
      es: (
        <div className="space-y-3">
          <div>• Integración Global: Mercados financieros modernos están completamente interconectados; declive en mercado bursátil estadounidense afecta Asia y Europa en horas</div>
          <div>• Guerras comerciales, aranceles aduaneros y tensiones geopolíticas crean alta volatilidad en tipos de cambio globales</div>
          <div>• Ventajas integración: Diversificación internacional, oportunidades arbitraje; riesgos: <TermTooltip term="contagio-financiero" language="es">Contagio financiero</TermTooltip> efecto</div>
          <div>• Tendencias modernas: <TermTooltip term="esg" language="es">ESG</TermTooltip> (ambiental, social, gobernanza) inversiones enfocadas aumentando; finanzas sostenibles llegando al frente</div>
          <div>• Futuro: Coordinación banco central y compartir riesgo crítico para gestión exitosa portafolio global</div>
        </div>
      ),
      fr: (
        <div className="space-y-3">
          <div>• Intégration Mondiale: Marchés financiers modernes sont complètement interconnectés; déclin marché boursier américain affecte Asie et Europe en heures</div>
          <div>• Guerres commerciales, tarifs douaniers et tensions géopolitiques créent haute volatilité taux change mondiaux</div>
          <div>• Avantages intégration: Diversification internationale, opportunités arbitrage; risques: <TermTooltip term="contagion-financiere" language="fr">Contagion financière</TermTooltip> effet</div>
          <div>• Tendances modernes: <TermTooltip term="esg" language="fr">ESG</TermTooltip> (environnemental, social, gouvernance) investissements axés augmentent; finance durable arrive au premier plan</div>
          <div>• Avenir: Coordination banque centrale et partage risque critiques pour gestion réussie portefeuille mondial</div>
        </div>
      ),
      ru: (
        <div className="space-y-3">
          <div>• Глобальная интеграция: Современные финансовые рынки полностью взаимосвязаны; снижение американского фондового рынка влияет на Азию и Европу в течение часов</div>
          <div>• Торговые войны, таможенные тарифы и геополитическая напряженность создают высокую волатильность глобальных обменных курсов</div>
          <div>• Преимущества интеграции: Международная диверсификация, арбитражные возможности; риски: <TermTooltip term="финансовое-заражение" language="ru">Финансовое заражение</TermTooltip> эффект</div>
          <div>• Современные тренды: <TermTooltip term="esg" language="ru">ESG</TermTooltip> (экологические, социальные, управленческие) ориентированные инвестиции растут; устойчивые финансы выходят на передний план</div>
          <div>• Будущее: Координация центральных банков и разделение рисков критично для успешного управления глобальным портфелем</div>
        </div>
      )
    },
    example: { 
      tr: '🌐 2025\'te global piyasalar, ticaret gerilimleriyle %0.7 yavaşladı; Çin-ABD etkisi.',
      en: '🌐 In 2025, global markets slowed 0.7% with trade tensions; China-US effect.',
      es: '🌐 En 2025, mercados globales se desaceleraron 0.7% con tensiones comerciales; efecto China-EE.UU.',
      fr: '🌐 En 2025, marchés mondiaux ont ralenti 0.7% avec tensions commerciales; effet Chine-États-Unis.',
      ru: '🌐 В 2025 году глобальные рынки замедлились на 0.7% из-за торговой напряженности; эффект Китай-США.'
    },
    icon: <Network className="w-16 h-16 text-blue-700" />
  },
  {
    title: { 
      tr: 'Finansal Krizler ve Dersler', 
      en: 'Financial Crises and Lessons', 
      es: 'Crisis Financieras y Lecciones', 
      fr: 'Crises Financières et Leçons', 
      ru: 'Финансовые кризисы и уроки' 
    },
    content: { 
      tr: [
        '• Finansal Kriz Nedenleri: Varlık balonları (konut, teknoloji), aşırı borç birikimi, sistemik risk; 2008 subprime krizi örneği',
        '• Yüksek kaldıraç kullanımı küçük şokları büyük kayıplara dönüştürür; "çok büyük batmayacak" sorunu yaratır',
        '• Kriz müdahaleleri: Merkez bankası likidite desteği, niceliksel genişleme (QE), banka kurtarma paketleri',
        '• Önemli dersler: Güçlü finansal düzenlemeler, risk yönetimi, sistemik izleme kritik önem taşır',
        '• Erken uyarı: Kredi genişlemesi, varlık fiyat-gelir oranları, VIX endeksi gibi göstergeler izlenmeli'
      ],
      en: [
        '• Financial Crisis Causes: Asset bubbles (housing, technology), excessive debt accumulation, systemic risk; 2008 subprime crisis example',
        '• High leverage usage transforms small shocks into large losses; creates "too big to fail" problem',
        '• Crisis interventions: Central bank liquidity support, quantitative easing (QE), bank bailout packages',
        '• Important lessons: Strong financial regulations, risk management, systemic monitoring are critical',
        '• Early warning: Indicators like credit expansion, asset price-income ratios, VIX index should be monitored'
      ],
      es: [
        '• Causas Crisis Financiera: Burbujas de activos (vivienda, tecnología), acumulación excesiva deuda, riesgo sistémico; ejemplo crisis subprime 2008',
        '• Uso alto apalancamiento transforma pequeños choques en grandes pérdidas; crea problema "demasiado grande para fallar"',
        '• Intervenciones crisis: Apoyo liquidez banco central, flexibilización cuantitativa (QE), paquetes rescate bancario',
        '• Lecciones importantes: Regulaciones financieras fuertes, gestión riesgo, monitoreo sistémico son críticos',
        '• Alerta temprana: Indicadores como expansión crédito, ratios precio-ingreso activos, índice VIX deben monitorearse'
      ],
      fr: [
        '• Causes Crise Financière: Bulles actifs (logement, technologie), accumulation excessive dette, risque systémique; exemple crise subprime 2008',
        '• Usage fort effet levier transforme petits chocs en grandes pertes; crée problème "trop gros pour échouer"',
        '• Interventions crise: Soutien liquidité banque centrale, assouplissement quantitatif (QE), paquets sauvetage bancaire',
        '• Leçons importantes: Régulations financières fortes, gestion risque, surveillance systémique sont critiques',
        '• Alerte précoce: Indicateurs comme expansion crédit, ratios prix-revenu actifs, indice VIX doivent être surveillés'
      ],
      ru: [
        '• Причины финансового кризиса: Пузыри активов (жилье, технологии), чрезмерное накопление долгов, системный риск; пример субпрайм кризиса 2008',
        '• Высокое использование кредитного плеча превращает небольшие шоки в большие потери; создает проблему "слишком большой чтобы обанкротиться"',
        '• Антикризисные вмешательства: Поддержка ликвидности центрального банка, количественное смягчение (QE), пакеты спасения банков',
        '• Важные уроки: Сильные финансовые регулирования, управление рисками, системный мониторинг критичны',
        '• Раннее предупреждение: Индикаторы как расширение кредита, соотношения цена-доход активов, индекс VIX должны отслеживаться'
      ]
    },
    contentWithTooltips: {
      tr: (
        <div className="space-y-3">
          <div>• Finansal Kriz Nedenleri: Varlık balonları (konut, teknoloji), aşırı borç birikimi, sistemik risk; 2008 subprime krizi örneği</div>
          <div>• Yüksek <TermTooltip term="kaldıraç">kaldıraç</TermTooltip> kullanımı küçük şokları büyük kayıplara dönüştürür; "çok büyük batmayacak" sorunu yaratır</div>
          <div>• Kriz müdahaleleri: Merkez bankası likidite desteği, <TermTooltip term="niceliksel-genişleme">niceliksel genişleme</TermTooltip> (QE), banka kurtarma paketleri</div>
          <div>• Önemli dersler: Güçlü finansal düzenlemeler, risk yönetimi, sistemik izleme kritik önem taşır</div>
          <div>• Erken uyarı: Kredi genişlemesi, varlık fiyat-gelir oranları, <TermTooltip term="vix">VIX</TermTooltip> endeksi gibi göstergeler izlenmeli</div>
        </div>
      ),
      en: (
        <div className="space-y-3">
          <div>• Financial Crisis Causes: Asset bubbles (housing, technology), excessive debt accumulation, systemic risk; 2008 subprime crisis example</div>
          <div>• High <TermTooltip term="leverage" language="en">leverage</TermTooltip> usage transforms small shocks into large losses; creates "too big to fail" problem</div>
          <div>• Crisis interventions: Central bank liquidity support, <TermTooltip term="quantitative-easing" language="en">quantitative easing</TermTooltip> (QE), bank bailout packages</div>
          <div>• Important lessons: Strong financial regulations, risk management, systemic monitoring are critical</div>
          <div>• Early warning: Indicators like credit expansion, asset price-income ratios, <TermTooltip term="vix" language="en">VIX</TermTooltip> index should be monitored</div>
        </div>
      ),
      es: (
        <div className="space-y-3">
          <div>• Causas Crisis Financiera: Burbujas de activos (vivienda, tecnología), acumulación excesiva deuda, riesgo sistémico; ejemplo crisis subprime 2008</div>
          <div>• Uso alto <TermTooltip term="apalancamiento" language="es">apalancamiento</TermTooltip> transforma pequeños choques en grandes pérdidas; crea problema "demasiado grande para fallar"</div>
          <div>• Intervenciones crisis: Apoyo liquidez banco central, <TermTooltip term="expansion-cuantitativa" language="es">flexibilización cuantitativa</TermTooltip> (QE), paquetes rescate bancario</div>
          <div>• Lecciones importantes: Regulaciones financieras fuertes, gestión riesgo, monitoreo sistémico son críticos</div>
          <div>• Alerta temprana: Indicadores como expansión crédito, ratios precio-ingreso activos, índice <TermTooltip term="vix" language="es">VIX</TermTooltip> deben monitorearse</div>
        </div>
      ),
      fr: (
        <div className="space-y-3">
          <div>• Causes Crise Financière: Bulles actifs (logement, technologie), accumulation excessive dette, risque systémique; exemple crise subprime 2008</div>
          <div>• Usage fort <TermTooltip term="effet-levier" language="fr">effet levier</TermTooltip> transforme petits chocs en grandes pertes; crée problème "trop gros pour échouer"</div>
          <div>• Interventions crise: Soutien liquidité banque centrale, <TermTooltip term="assouplissement-quantitatif" language="fr">assouplissement quantitatif</TermTooltip> (QE), paquets sauvetage bancaire</div>
          <div>• Leçons importantes: Régulations financières fortes, gestion risque, surveillance systémique sont critiques</div>
          <div>• Alerte précoce: Indicateurs comme expansion crédit, ratios prix-revenu actifs, indice <TermTooltip term="vix" language="fr">VIX</TermTooltip> doivent être surveillés</div>
        </div>
      ),
      ru: (
        <div className="space-y-3">
          <div>• Причины финансового кризиса: Пузыри активов (жилье, технологии), чрезмерное накопление долгов, системный риск; пример субпрайм кризиса 2008</div>
          <div>• Высокое использование <TermTooltip term="кредитное-плечо" language="ru">кредитного плеча</TermTooltip> превращает небольшие шоки в большие потери; создает проблему "слишком большой чтобы обанкротиться"</div>
          <div>• Антикризисные вмешательства: Поддержка ликвидности центрального банка, <TermTooltip term="количественное-смягчение" language="ru">количественное смягчение</TermTooltip> (QE), пакеты спасения банков</div>
          <div>• Важные уроки: Сильные финансовые регулирования, управление рисками, системный мониторинг критичны</div>
          <div>• Раннее предупреждение: Индикаторы как расширение кредита, соотношения цена-доход активов, индекс <TermTooltip term="vix" language="ru">VIX</TermTooltip> должны отслеживаться</div>
        </div>
      )
    },
    example: { 
      tr: '⚠️ 2025\'te hisse çöküşü, tarife politikalarıyla başladı; volatilite global yayıldı.',
      en: '⚠️ In 2025, stock crash started with tariff policies; volatility spread globally.',
      es: '⚠️ En 2025, crash bursátil comenzó con políticas arancelarias; volatilidad se extendió globalmente.',
      fr: '⚠️ En 2025, crash boursier a commencé avec politiques tarifaires; volatilité s\'est étendue mondialement.',
      ru: '⚠️ В 2025 году биржевой крах начался с тарифной политики; волатильность распространилась глобально.'
    },
    icon: <AlertTriangle className="w-16 h-16 text-red-500" />
  },
  {
    title: { 
      tr: 'Finansal Piyasaların Geleceği', 
      en: 'Future of Financial Markets', 
      es: 'Futuro de los Mercados Financieros', 
      fr: 'Avenir des Marchés Financiers', 
      ru: 'Будущее финансовых рынков' 
    },
    content: { 
      tr: [
        '• Gelecek Trendleri: AI destekli ticaret algoritmaları, blockchain tabanlı finans (DeFi), sürdürülebilir (ESG) yatırımlar ön plana çıkıyor',
        '• Dijital dönüşüm: CBDC\'ler (merkez bankası dijital paraları), dijital cüzdanlar, anlık ödemeler geleneksel bankacılığı yeniden şekillendiriyor',
        '• Başlıca zorluklar: Siber güvenlik tehditleri, düzenleyici belirsizlik, teknolojik bölünme riskleri',
        '• Büyük fırsatlar: Gerçek varlık tokenizasyonu, DeFi protokolleri, AI destekli risk yönetimi, küresel finansal erişimin demokratikleşmesi',
        '• Geleceğe hazırlık: Teknolojik gelişmeleri takip edin, sürekli öğrenin, portföyünüzü çeşitlendirin ve değişime uyum sağlayın'
      ],
      en: [
        '• Future Trends: AI-powered trading algorithms, blockchain-based finance (DeFi), sustainable (ESG) investments coming to forefront',
        '• Digital transformation: CBDCs (central bank digital currencies), digital wallets, instant payments reshaping traditional banking',
        '• Major challenges: Cybersecurity threats, regulatory uncertainty, technological fragmentation risks',
        '• Great opportunities: Real asset tokenization, DeFi protocols, AI-powered risk management, democratization of global financial access',
        '• Future preparation: Follow technological developments, continuously learn, diversify your portfolio and adapt to change'
      ],
      es: [
        '• Tendencias Futuras: Algoritmos de trading potenciados por IA, finanzas basadas en blockchain (DeFi), inversiones sostenibles (ESG) llegando al frente',
        '• Transformación digital: CBDCs (monedas digitales banco central), carteras digitales, pagos instantáneos remodelando banca tradicional',
        '• Desafíos principales: Amenazas ciberseguridad, incertidumbre regulatoria, riesgos fragmentación tecnológica',
        '• Grandes oportunidades: Tokenización activos reales, protocolos DeFi, gestión riesgo potenciada por IA, democratización acceso financiero global',
        '• Preparación futuro: Sigue desarrollos tecnológicos, aprende continuamente, diversifica tu portafolio y adáptate al cambio'
      ],
      fr: [
        '• Tendances Futures: Algorithmes trading alimentés IA, finance basée blockchain (DeFi), investissements durables (ESG) arrivant au premier plan',
        '• Transformation numérique: CBDCs (monnaies numériques banque centrale), portefeuilles numériques, paiements instantanés remodelant banque traditionnelle',
        '• Défis majeurs: Menaces cybersécurité, incertitude réglementaire, risques fragmentation technologique',
        '• Grandes opportunités: Tokenisation actifs réels, protocoles DeFi, gestion risque alimentée IA, démocratisation accès financier mondial',
        '• Préparation avenir: Suivez développements technologiques, apprenez continuellement, diversifiez votre portefeuille et adaptez-vous au changement'
      ],
      ru: [
        '• Будущие тренды: ИИ-алгоритмы торговли, блокчейн-финансы (DeFi), устойчивые (ESG) инвестиции выходят на передний план',
        '• Цифровая трансформация: CBDC (цифровые валюты центральных банков), цифровые кошельки, мгновенные платежи преобразуют традиционный банкинг',
        '• Основные вызовы: Угрозы кибербезопасности, регулятивная неопределенность, риски технологической фрагментации',
        '• Большие возможности: Токенизация реальных активов, DeFi протоколы, ИИ-управление рисками, демократизация глобального финансового доступа',
        '• Подготовка к будущему: Следите за технологическими разработками, непрерывно учитесь, диверсифицируйте портфель и адаптируйтесь к изменениям'
      ]
    },
    contentWithTooltips: {
      tr: (
        <div className="space-y-3">
          <div>• Gelecek Trendleri: AI destekli ticaret algoritmaları, blockchain tabanlı finans (<TermTooltip term="defi">DeFi</TermTooltip>), sürdürülebilir (<TermTooltip term="esg">ESG</TermTooltip>) yatırımlar ön plana çıkıyor</div>
          <div>• Dijital dönüşüm: <TermTooltip term="cbdc">CBDC</TermTooltip>'ler (merkez bankası dijital paraları), dijital cüzdanlar, anlık ödemeler geleneksel bankacılığı yeniden şekillendiriyor</div>
          <div>• Başlıca zorluklar: Siber güvenlik tehditleri, düzenleyici belirsizlik, teknolojik bölünme riskleri</div>
          <div>• Büyük fırsatlar: Gerçek varlık tokenizasyonu, DeFi protokolleri, AI destekli risk yönetimi, küresel finansal erişimin demokratikleşmesi</div>
          <div>• Geleceğe hazırlık: Teknolojik gelişmeleri takip edin, sürekli öğrenin, portföyünüzü çeşitlendirin ve değişime uyum sağlayın</div>
        </div>
      ),
      en: (
        <div className="space-y-3">
          <div>• Future Trends: AI-powered trading algorithms, blockchain-based finance (<TermTooltip term="defi" language="en">DeFi</TermTooltip>), sustainable (<TermTooltip term="esg" language="en">ESG</TermTooltip>) investments coming to forefront</div>
          <div>• Digital transformation: <TermTooltip term="cbdc" language="en">CBDCs</TermTooltip> (central bank digital currencies), digital wallets, instant payments reshaping traditional banking</div>
          <div>• Major challenges: Cybersecurity threats, regulatory uncertainty, technological fragmentation risks</div>
          <div>• Great opportunities: Real asset tokenization, DeFi protocols, AI-powered risk management, democratization of global financial access</div>
          <div>• Future preparation: Follow technological developments, continuously learn, diversify your portfolio and adapt to change</div>
        </div>
      ),
      es: (
        <div className="space-y-3">
          <div>• Tendencias Futuras: Algoritmos de trading potenciados por IA, finanzas basadas en blockchain (<TermTooltip term="defi" language="es">DeFi</TermTooltip>), inversiones sostenibles (<TermTooltip term="esg" language="es">ESG</TermTooltip>) llegando al frente</div>
          <div>• Transformación digital: <TermTooltip term="cbdc" language="es">CBDCs</TermTooltip> (monedas digitales banco central), carteras digitales, pagos instantáneos remodelando banca tradicional</div>
          <div>• Desafíos principales: Amenazas ciberseguridad, incertidumbre regulatoria, riesgos fragmentación tecnológica</div>
          <div>• Grandes oportunidades: Tokenización activos reales, protocolos DeFi, gestión riesgo potenciada por IA, democratización acceso financiero global</div>
          <div>• Preparación futuro: Sigue desarrollos tecnológicos, aprende continuamente, diversifica tu portafolio y adáptate al cambio</div>
        </div>
      ),
      fr: (
        <div className="space-y-3">
          <div>• Tendances Futures: Algorithmes trading alimentés IA, finance basée blockchain (<TermTooltip term="defi" language="fr">DeFi</TermTooltip>), investissements durables (<TermTooltip term="esg" language="fr">ESG</TermTooltip>) arrivant au premier plan</div>
          <div>• Transformation numérique: <TermTooltip term="cbdc" language="fr">CBDCs</TermTooltip> (monnaies numériques banque centrale), portefeuilles numériques, paiements instantanés remodelant banque traditionnelle</div>
          <div>• Défis majeurs: Menaces cybersécurité, incertitude réglementaire, risques fragmentation technologique</div>
          <div>• Grandes opportunités: Tokenisation actifs réels, protocoles DeFi, gestion risque alimentée IA, démocratisation accès financier mondial</div>
          <div>• Préparation avenir: Suivez développements technologiques, apprenez continuellement, diversifiez votre portefeuille et adaptez-vous au changement</div>
        </div>
      ),
      ru: (
        <div className="space-y-3">
          <div>• Будущие тренды: ИИ-алгоритмы торговли, блокчейн-финансы (<TermTooltip term="defi" language="ru">DeFi</TermTooltip>), устойчивые (<TermTooltip term="esg" language="ru">ESG</TermTooltip>) инвестиции выходят на передний план</div>
          <div>• Цифровая трансформация: <TermTooltip term="cbdc" language="ru">CBDC</TermTooltip> (цифровые валюты центральных банков), цифровые кошельки, мгновенные платежи преобразуют традиционный банкинг</div>
          <div>• Основные вызовы: Угрозы кибербезопасности, регулятивная неопределенность, риски технологической фрагментации</div>
          <div>• Большие возможности: Токенизация реальных активов, DeFi протоколы, ИИ-управление рисками, демократизация глобального финансового доступа</div>
          <div>• Подготовка к будущему: Следите за технологическими разработками, непрерывно учитесь, диверсифицируйте портфель и адаптируйтесь к изменениям</div>
        </div>
      )
    },
    example: { 
      tr: '🚀 2025\'te fintech, AI ve stablecoin\'lerle %20 büyüdü; sürdürülebilirlik odaklandı.',
      en: '🚀 In 2025, fintech grew 20% with AI and stablecoins; sustainability focused.',
      es: '🚀 En 2025, fintech creció 20% con IA y stablecoins; se enfocó en sostenibilidad.',
      fr: '🚀 En 2025, fintech a crû 20% avec IA et stablecoins; s\'est concentré sur durabilité.',
      ru: '🚀 В 2025 году финтех вырос на 20% с ИИ и стейблкоинами; сосредоточился на устойчивости.'
    },
    icon: <Sparkles className="w-16 h-16 text-yellow-400" />
  }
]

// Quiz soruları
export const financialMarketsQuiz = [
  {
    id: 1,
    question: {
      tr: 'Finansal piyasaların temel işlevlerinden biri hangisidir?',
      en: 'Which is one of the basic functions of financial markets?',
      es: '¿Cuál es una de las funciones básicas de los mercados financieros?',
      fr: 'Quelle est l\'une des fonctions de base des marchés financiers?',
      ru: 'Какова одна из основных функций финансовых рынков?'
    },
    type: 'multiple-choice',
    answers: {
      tr: [
        'Ürün üretmek',
        'Paranın ihtiyacı olana yönlendirilmesi',
        'Vergi toplamak',
        'Yeni şirket kurmak'
      ],
      en: [
        'Product manufacturing',
        'Channeling money to those who need it',
        'Tax collection',
        'Starting new companies'
      ],
      es: [
        'Fabricación de productos',
        'Canalizar dinero a quienes lo necesitan',
        'Recaudación de impuestos',
        'Crear nuevas empresas'
      ],
      fr: [
        'Fabrication de produits',
        'Canaliser l\'argent vers ceux qui en ont besoin',
        'Collecte d\'impôts',
        'Créer de nouvelles entreprises'
      ],
      ru: [
        'Производство товаров',
        'Направление денег тем, кто в них нуждается',
        'Сбор налогов',
        'Создание новых компаний'
      ]
    },
    correct: 1,
    explanation: {
      tr: 'Finansal piyasaların temel işlevi, sermayeyi tasarruf sahiplerinden ihtiyacı olanlara yönlendirmektir.',
      en: 'The basic function of financial markets is to channel capital from savers to those who need it.',
      es: 'La función básica de los mercados financieros es canalizar capital de ahorradores a quienes lo necesitan.',
      fr: 'La fonction de base des marchés financiers est de canaliser le capital des épargnants vers ceux qui en ont besoin.',
      ru: 'Основная функция финансовых рынков - направлять капитал от вкладчиков к тем, кто в нем нуждается.'
    }
  },
  {
    id: 2,
    question: {
      tr: 'Aşağıdaki ifade doğru mu? "Finansal piyasalar yalnızca büyük şirketler için vardır."',
      en: 'Is the following statement true? "Financial markets exist only for large companies."',
      es: '¿Es verdadera la siguiente afirmación? "Los mercados financieros existen solo para grandes empresas."',
      fr: 'L\'affirmation suivante est-elle vraie? "Les marchés financiers n\'existent que pour les grandes entreprises."',
      ru: 'Верно ли следующее утверждение? "Финансовые рынки существуют только для крупных компаний."'
    },
    type: 'true-false',
    answers: {
      tr: ['Doğru', 'Yanlış'],
      en: ['True', 'False'],
      es: ['Verdadero', 'Falso'],
      fr: ['Vrai', 'Faux'],
      ru: ['Верно', 'Неверно']
    },
    correct: 1,
    explanation: {
      tr: 'Yanlış. Finansal piyasalar bireysel yatırımcılar, küçük işletmeler ve büyük şirketler dahil herkese hizmet verir.',
      en: 'False. Financial markets serve everyone including individual investors, small businesses and large corporations.',
      es: 'Falso. Los mercados financieros sirven a todos, incluidos inversores individuales, pequeñas empresas y grandes corporaciones.',
      fr: 'Faux. Les marchés financiers servent tout le monde, y compris les investisseurs individuels, les petites entreprises et les grandes corporations.',
      ru: 'Неверно. Финансовые рынки обслуживают всех, включая индивидуальных инвесторов, малый бизнес и крупные корпорации.'
    }
  },
  {
    id: 3,
    question: {
      tr: 'İlk Halka Arz (IPO) hangi piyasa türünde gerçekleşir?',
      en: 'In which type of market does an Initial Public Offering (IPO) take place?',
      es: '¿En qué tipo de mercado tiene lugar una Oferta Pública Inicial (IPO)?',
      fr: 'Dans quel type de marché a lieu une Introduction en Bourse (IPO)?',
      ru: 'На каком типе рынка происходит первичное публичное размещение (IPO)?'
    },
    type: 'multiple-choice',
    answers: {
      tr: [
        'İkincil piyasa',
        'Birincil piyasa',
        'Döviz piyasası',
        'Para piyasası'
      ],
      en: [
        'Secondary market',
        'Primary market',
        'Foreign exchange market',
        'Money market'
      ],
      es: [
        'Mercado secundario',
        'Mercado primario',
        'Mercado de divisas',
        'Mercado monetario'
      ],
      fr: [
        'Marché secondaire',
        'Marché primaire',
        'Marché des changes',
        'Marché monétaire'
      ],
      ru: [
        'Вторичный рынок',
        'Первичный рынок',
        'Валютный рынок',
        'Денежный рынок'
      ]
    },
    correct: 1,
    explanation: {
      tr: 'IPO birincil piyasada gerçekleşir çünkü şirket ilk kez hisselerini halka arz eder.',
      en: 'IPO takes place in the primary market because the company is offering its shares to the public for the first time.',
      es: 'La IPO tiene lugar en el mercado primario porque la empresa ofrece sus acciones al público por primera vez.',
      fr: 'L\'IPO a lieu sur le marché primaire car l\'entreprise offre ses actions au public pour la première fois.',
      ru: 'IPO происходит на первичном рынке, поскольку компания впервые предлагает свои акции публике.'
    }
  },
  {
    id: 4,
    question: {
      tr: 'Para piyasası araçlarının vadesi genelde en fazla kaç yıldır?',
      en: 'What is generally the maximum maturity of money market instruments?',
      es: '¿Cuál es generalmente el vencimiento máximo de los instrumentos del mercado monetario?',
      fr: 'Quelle est généralement l\'échéance maximale des instruments du marché monétaire?',
      ru: 'Какой обычно максимальный срок погашения инструментов денежного рынка?'
    },
    type: 'multiple-choice',
    answers: {
      tr: [
        '1 yıl',
        '3 yıl',
        '5 yıl',
        '10 yıl'
      ],
      en: [
        '1 year',
        '3 years',
        '5 years',
        '10 years'
      ],
      es: [
        '1 año',
        '3 años',
        '5 años',
        '10 años'
      ],
      fr: [
        '1 an',
        '3 ans',
        '5 ans',
        '10 ans'
      ],
      ru: [
        '1 год',
        '3 года',
        '5 лет',
        '10 лет'
      ]
    },
    correct: 0,
    explanation: {
      tr: 'Para piyasası araçları kısa vadeli araçlardır ve genellikle 1 yıl veya daha az vadeye sahiptir.',
      en: 'Money market instruments are short-term instruments and generally have maturities of 1 year or less.',
      es: 'Los instrumentos del mercado monetario son instrumentos a corto plazo y generalmente tienen vencimientos de 1 año o menos.',
      fr: 'Les instruments du marché monétaire sont des instruments à court terme et ont généralement des échéances d\'1 an ou moins.',
      ru: 'Инструменты денежного рынка являются краткосрочными инструментами и обычно имеют сроки погашения 1 год или меньше.'
    }
  },
  {
    id: 5,
    question: {
      tr: 'Para piyasası araçlarının öne çıkan özelliği nedir?',
      en: 'What is the prominent feature of money market instruments?',
      es: '¿Cuál es la característica prominente de los instrumentos del mercado monetario?',
      fr: 'Quelle est la caractéristique proéminente des instruments du marché monétaire?',
      ru: 'Какая главная особенность инструментов денежного рынка?'
    },
    type: 'multiple-choice',
    answers: {
      tr: [
        'Yüksek risk',
        'Kolay nakde çevrilebilirlik',
        'Sınırsız getiri',
        'Uzun vade'
      ],
      en: [
        'High risk',
        'Easy convertibility to cash',
        'Unlimited returns',
        'Long term'
      ],
      es: [
        'Alto riesgo',
        'Fácil convertibilidad a efectivo',
        'Retornos ilimitados',
        'Largo plazo'
      ],
      fr: [
        'Risque élevé',
        'Facilité de conversion en espèces',
        'Rendements illimités',
        'Long terme'
      ],
      ru: [
        'Высокий риск',
        'Легкая конвертируемость в наличные',
        'Неограниченная доходность',
        'Долгосрочность'
      ]
    },
    correct: 1,
    explanation: {
      tr: 'Para piyasası araçları yüksek likiditeye sahiptir, yani kolayca nakde çevrilebilir.',
      en: 'Money market instruments have high liquidity, meaning they can be easily converted to cash.',
      es: 'Los instrumentos del mercado monetario tienen alta liquidez, lo que significa que pueden convertirse fácilmente en efectivo.',
      fr: 'Les instruments du marché monétaire ont une liquidité élevée, ce qui signifie qu\'ils peuvent être facilement convertis en espèces.',
      ru: 'Инструменты денежного рынка обладают высокой ликвидностью, то есть их можно легко конвертировать в наличные.'
    }
  },
  {
    id: 6,
    question: {
      tr: 'Aşağıdaki ifade doğru mu? "Merkez bankası faizleri düşünce para piyasası getirileri genelde artar."',
      en: 'Is the following statement true? "When central bank rates fall, money market returns generally increase."',
      es: '¿Es verdadera la siguiente afirmación? "Cuando las tasas del banco central bajan, los retornos del mercado monetario generalmente aumentan."',
      fr: 'L\'affirmation suivante est-elle vraie? "Quand les taux de la banque centrale baissent, les rendements du marché monétaire augmentent généralement."',
      ru: 'Верно ли следующее утверждение? "Когда процентные ставки центрального банка падают, доходность денежного рынка обычно растет."'
    },
    type: 'true-false',
    answers: {
      tr: ['Doğru', 'Yanlış'],
      en: ['True', 'False'],
      es: ['Verdadero', 'Falso'],
      fr: ['Vrai', 'Faux'],
      ru: ['Верно', 'Неверно']
    },
    correct: 1,
    explanation: {
      tr: 'Yanlış. Merkez bankası faizleri düştüğünde para piyasası getirileri de genellikle düşer.',
      en: 'False. When central bank rates fall, money market returns also generally decline.',
      es: 'Falso. Cuando las tasas del banco central bajan, los retornos del mercado monetario también generalmente disminuyen.',
      fr: 'Faux. Quand les taux de la banque centrale baissent, les rendements du marché monétaire baissent aussi généralement.',
      ru: 'Неверно. Когда процентные ставки центрального банка падают, доходность денежного рынка также обычно снижается.'
    }
  },
  {
    id: 7,
    question: {
      tr: 'Hisse senedi yatırımcısına hangi hakları verir?',
      en: 'What rights does stock investment give to an investor?',
      es: '¿Qué derechos da la inversión en acciones a un inversor?',
      fr: 'Quels droits l\'investissement en actions donne-t-il à un investisseur?',
      ru: 'Какие права дает инвестиция в акции инвестору?'
    },
    type: 'multiple-choice',
    answers: {
      tr: [
        'Ortaklık ve kar payı',
        'Sabit faiz',
        'Sadece temettü',
        'Oy hakkı yok'
      ],
      en: [
        'Ownership and profit sharing',
        'Fixed interest',
        'Only dividends',
        'No voting rights'
      ],
      es: [
        'Propiedad y participación en beneficios',
        'Interés fijo',
        'Solo dividendos',
        'Sin derechos de voto'
      ],
      fr: [
        'Propriété et partage des bénéfices',
        'Intérêt fixe',
        'Seulement dividendes',
        'Pas de droits de vote'
      ],
      ru: [
        'Собственность и участие в прибыли',
        'Фиксированный процент',
        'Только дивиденды',
        'Нет права голоса'
      ]
    },
    correct: 0,
    explanation: {
      tr: 'Hisse senedi sahibi şirkette ortaklık hakkına sahiptir ve şirketin kârından pay alabilir.',
      en: 'A stockholder has ownership rights in the company and can share in the company\'s profits.',
      es: 'Un accionista tiene derechos de propiedad en la empresa y puede participar en las ganancias de la empresa.',
      fr: 'Un actionnaire a des droits de propriété dans l\'entreprise et peut partager les bénéfices de l\'entreprise.',
      ru: 'Акционер имеет права собственности в компании и может участвовать в прибыли компании.'
    }
  },
  {
    id: 8,
    question: {
      tr: 'Aşağıdaki ifade doğru mu? "Hisse senetleri kısa vadede her zaman tahvilden daha güvenlidir."',
      en: 'Is the following statement true? "Stocks are always safer than bonds in the short term."',
      es: '¿Es verdadera la siguiente afirmación? "Las acciones siempre son más seguras que los bonos a corto plazo."',
      fr: 'L\'affirmation suivante est-elle vraie? "Les actions sont toujours plus sûres que les obligations à court terme."',
      ru: 'Верно ли следующее утверждение? "Акции всегда безопаснее облигаций в краткосрочной перспективе."'
    },
    type: 'true-false',
    answers: {
      tr: ['Doğru', 'Yanlış'],
      en: ['True', 'False'],
      es: ['Verdadero', 'Falso'],
      fr: ['Vrai', 'Faux'],
      ru: ['Верно', 'Неверно']
    },
    correct: 1,
    explanation: {
      tr: 'Yanlış. Tahviller genellikle hisse senetlerinden daha az risklidir ve kısa vadede daha güvenli kabul edilir.',
      en: 'False. Bonds are generally less risky than stocks and are considered safer in the short term.',
      es: 'Falso. Los bonos son generalmente menos riesgosos que las acciones y se consideran más seguros a corto plazo.',
      fr: 'Faux. Les obligations sont généralement moins risquées que les actions et sont considérées comme plus sûres à court terme.',
      ru: 'Неверно. Облигации обычно менее рискованны, чем акции, и считаются более безопасными в краткосрочной перспективе.'
    }
  },
  {
    id: 9,
    question: {
      tr: 'Piyasa faizleri yükselince mevcut tahvil fiyatı nasıl etkilenir?',
      en: 'How are existing bond prices affected when market interest rates rise?',
      es: '¿Cómo se ven afectados los precios de los bonos existentes cuando suben las tasas de interés del mercado?',
      fr: 'Comment les prix des obligations existantes sont-ils affectés lorsque les taux d\'intérêt du marché augmentent?',
      ru: 'Как влияют на цены существующих облигаций рост рыночных процентных ставок?'
    },
    type: 'multiple-choice',
    answers: {
      tr: [
        'Düşer',
        'Yükselir',
        'Değişmez',
        'Önce yükselir sonra düşer'
      ],
      en: [
        'Falls',
        'Rises',
        'Remains unchanged',
        'First rises then falls'
      ],
      es: [
        'Baja',
        'Sube',
        'Permanece sin cambios',
        'Primero sube luego baja'
      ],
      fr: [
        'Baisse',
        'Augmente',
        'Reste inchangé',
        'Augmente d\'abord puis baisse'
      ],
      ru: [
        'Падают',
        'Растут',
        'Остаются неизменными',
        'Сначала растут, потом падают'
      ]
    },
    correct: 0,
    explanation: {
      tr: 'Faizler yükseldiğinde mevcut tahvillerin fiyatları düşer çünkü yeni ihraç edilen tahviller daha yüksek faiz öder.',
      en: 'When interest rates rise, existing bond prices fall because newly issued bonds pay higher interest.',
      es: 'Cuando las tasas de interés suben, los precios de los bonos existentes bajan porque los bonos recién emitidos pagan intereses más altos.',
      fr: 'Quand les taux d\'intérêt augmentent, les prix des obligations existantes baissent car les obligations nouvellement émises paient des intérêts plus élevés.',
      ru: 'Когда процентные ставки растут, цены существующих облигаций падают, поскольку вновь выпущенные облигации платят более высокие проценты.'
    }
  },
  {
    id: 10,
    question: {
      tr: 'Tahvil sahibine düzenli yapılan ödeme nedir?',
      en: 'What is the regular payment made to a bondholder?',
      es: '¿Cuál es el pago regular hecho a un tenedor de bonos?',
      fr: 'Quel est le paiement régulier fait à un détenteur d\'obligations?',
      ru: 'Что такое регулярный платеж держателю облигации?'
    },
    type: 'multiple-choice',
    answers: {
      tr: [
        'Temettü',
        'Kupon faizi',
        'Repo getirisi',
        'Likidite primi'
      ],
      en: [
        'Dividend',
        'Coupon interest',
        'Repo return',
        'Liquidity premium'
      ],
      es: [
        'Dividendo',
        'Interés del cupón',
        'Retorno repo',
        'Prima de liquidez'
      ],
      fr: [
        'Dividende',
        'Intérêt du coupon',
        'Rendement repo',
        'Prime de liquidité'
      ],
      ru: [
        'Дивиденд',
        'Купонный процент',
        'Доходность репо',
        'Премия за ликвидность'
      ]
    },
    correct: 1,
    explanation: {
      tr: 'Tahvil sahiplerine düzenli olarak kupon faizi ödenir.',
      en: 'Bondholders are regularly paid coupon interest.',
      es: 'A los tenedores de bonos se les paga regularmente interés del cupón.',
      fr: 'Les détenteurs d\'obligations reçoivent régulièrement des intérêts de coupon.',
      ru: 'Держателям облигаций регулярно выплачивается купонный процент.'
    }
  },
  {
    id: 11,
    question: {
      tr: 'Dünyanın en çok işlem gören para çifti aşağıdakilerden hangisidir?',
      en: 'Which of the following is the world\'s most traded currency pair?',
      es: '¿Cuál de los siguientes es el par de divisas más negociado del mundo?',
      fr: 'Laquelle des paires de devises suivantes est la plus échangée au monde?',
      ru: 'Какая из следующих валютных пар является наиболее торгуемой в мире?'
    },
    type: 'multiple-choice',
    answers: {
      tr: [
        'USD/TRY',
        'EUR/USD',
        'GBP/JPY',
        'BTC/USD'
      ],
      en: [
        'USD/TRY',
        'EUR/USD',
        'GBP/JPY',
        'BTC/USD'
      ],
      es: [
        'USD/TRY',
        'EUR/USD',
        'GBP/JPY',
        'BTC/USD'
      ],
      fr: [
        'USD/TRY',
        'EUR/USD',
        'GBP/JPY',
        'BTC/USD'
      ],
      ru: [
        'USD/TRY',
        'EUR/USD',
        'GBP/JPY',
        'BTC/USD'
      ]
    },
    correct: 1,
    explanation: {
      tr: 'EUR/USD dünyanın en çok işlem gören para çiftidir.',
      en: 'EUR/USD is the world\'s most traded currency pair.',
      es: 'EUR/USD es el par de divisas más negociado del mundo.',
      fr: 'EUR/USD est la paire de devises la plus échangée au monde.',
      ru: 'EUR/USD является наиболее торгуемой валютной парой в мире.'
    }
  },
  {
    id: 12,
    question: {
      tr: 'Kaldıraçlı işlemin temel riski nedir?',
      en: 'What is the main risk of leveraged trading?',
      es: '¿Cuál es el riesgo principal del trading apalancado?',
      fr: 'Quel est le risque principal du trading avec effet de levier?',
      ru: 'Каков основной риск торговли с кредитным плечом?'
    },
    type: 'multiple-choice',
    answers: {
      tr: [
        'Küçük sermayeyle büyük kayıp ihtimali',
        'Döviz çeşitliliği',
        'Düşük likidite',
        'Sabit getiri'
      ],
      en: [
        'Possibility of large losses with small capital',
        'Currency diversity',
        'Low liquidity',
        'Fixed returns'
      ],
      es: [
        'Posibilidad de grandes pérdidas con poco capital',
        'Diversidad de divisas',
        'Baja liquidez',
        'Retornos fijos'
      ],
      fr: [
        'Possibilité de grandes pertes avec peu de capital',
        'Diversité des devises',
        'Faible liquidité',
        'Rendements fixes'
      ],
      ru: [
        'Возможность больших потерь с малым капиталом',
        'Разнообразие валют',
        'Низкая ликвидность',
        'Фиксированная доходность'
      ]
    },
    correct: 0,
    explanation: {
      tr: 'Kaldıraç kullanımının temel riski, küçük sermayeyle büyük pozisyonlar alarak büyük kayıplar yaşama ihtimalidir.',
      en: 'The main risk of using leverage is the possibility of large losses by taking large positions with small capital.',
      es: 'El riesgo principal de usar apalancamiento es la posibilidad de grandes pérdidas al tomar posiciones grandes con poco capital.',
      fr: 'Le risque principal d\'utiliser l\'effet de levier est la possibilité de grandes pertes en prenant de grandes positions avec peu de capital.',
      ru: 'Основной риск использования кредитного плеча - это возможность больших потерь при открытии крупных позиций с малым капиталом.'
    }
  },
  {
    id: 13,
    question: {
      tr: 'Opsiyon sözleşmesi yatırımcıya ne sağlar?',
      en: 'What does an option contract provide to an investor?',
      es: '¿Qué proporciona un contrato de opción a un inversor?',
      fr: 'Que fournit un contrat d\'option à un investisseur?',
      ru: 'Что предоставляет опционный контракт инвестору?'
    },
    type: 'multiple-choice',
    answers: {
      tr: [
        'Alma veya satma hakkı',
        'Mecburi alım',
        'Temettü garantisi',
        'Sabit faiz'
      ],
      en: [
        'Right to buy or sell',
        'Mandatory purchase',
        'Dividend guarantee',
        'Fixed interest'
      ],
      es: [
        'Derecho a comprar o vender',
        'Compra obligatoria',
        'Garantía de dividendos',
        'Interés fijo'
      ],
      fr: [
        'Droit d\'acheter ou de vendre',
        'Achat obligatoire',
        'Garantie de dividendes',
        'Intérêt fixe'
      ],
      ru: [
        'Право покупать или продавать',
        'Обязательная покупка',
        'Гарантия дивидендов',
        'Фиксированный процент'
      ]
    },
    correct: 0,
    explanation: {
      tr: 'Opsiyon sözleşmesi sahibine belirli bir fiyattan alma veya satma hakkı verir, zorunluluk değil.',
      en: 'An option contract gives the holder the right, not obligation, to buy or sell at a specific price.',
      es: 'Un contrato de opción da al tenedor el derecho, no la obligación, de comprar o vender a un precio específico.',
      fr: 'Un contrat d\'option donne au détenteur le droit, pas l\'obligation, d\'acheter ou de vendre à un prix spécifique.',
      ru: 'Опционный контракт дает держателю право, а не обязанность, покупать или продавать по определенной цене.'
    }
  },
  {
    id: 14,
    question: {
      tr: 'Aşağıdaki ifade doğru mu? "Vadeli işlem sözleşmeleri gelecekteki fiyatı sabitlemek için kullanılabilir."',
      en: 'Is the following statement true? "Futures contracts can be used to lock in future prices."',
      es: '¿Es verdadera la siguiente afirmación? "Los contratos de futuros pueden usarse para fijar precios futuros."',
      fr: 'L\'affirmation suivante est-elle vraie? "Les contrats à terme peuvent être utilisés pour fixer les prix futurs."',
      ru: 'Верно ли следующее утверждение? "Фьючерсные контракты можно использовать для фиксации будущих цен."'
    },
    type: 'true-false',
    answers: {
      tr: ['Doğru', 'Yanlış'],
      en: ['True', 'False'],
      es: ['Verdadero', 'Falso'],
      fr: ['Vrai', 'Faux'],
      ru: ['Верно', 'Неверно']
    },
    correct: 0,
    explanation: {
      tr: 'Doğru. Vadeli işlem sözleşmeleri gelecekteki fiyat riskine karşı korunmak için kullanılabilir.',
      en: 'True. Futures contracts can be used to hedge against future price risk.',
      es: 'Verdadero. Los contratos de futuros pueden usarse para protegerse contra el riesgo de precios futuros.',
      fr: 'Vrai. Les contrats à terme peuvent être utilisés pour se protéger contre le risque de prix futurs.',
      ru: 'Верно. Фьючерсные контракты можно использовать для хеджирования от будущего ценового риска.'
    }
  },
  {
    id: 15,
    question: {
      tr: 'Emtia fiyatlarını etkileyen faktörlerden biri hangisidir?',
      en: 'Which is one of the factors affecting commodity prices?',
      es: '¿Cuál es uno de los factores que afectan los precios de las materias primas?',
      fr: 'Quel est l\'un des facteurs affectant les prix des matières premières?',
      ru: 'Какой из факторов влияет на цены товаров?'
    },
    type: 'multiple-choice',
    answers: {
      tr: [
        'Arz-talep dengesi',
        'Şirket bilançosu',
        'Kişisel kredi notu',
        'Kupon faizi'
      ],
      en: [
        'Supply-demand balance',
        'Company balance sheet',
        'Personal credit score',
        'Coupon interest'
      ],
      es: [
        'Balance oferta-demanda',
        'Balance de la empresa',
        'Puntuación de crédito personal',
        'Interés del cupón'
      ],
      fr: [
        'Équilibre offre-demande',
        'Bilan de l\'entreprise',
        'Score de crédit personnel',
        'Intérêt du coupon'
      ],
      ru: [
        'Баланс спроса и предложения',
        'Баланс компании',
        'Личный кредитный рейтинг',
        'Купонный процент'
      ]
    },
    correct: 0,
    explanation: {
      tr: 'Emtia fiyatları temel olarak arz-talep dengesi tarafından belirlenir.',
      en: 'Commodity prices are fundamentally determined by supply-demand balance.',
      es: 'Los precios de las materias primas están fundamentalmente determinados por el equilibrio oferta-demanda.',
      fr: 'Les prix des matières premières sont fondamentalement déterminés par l\'équilibre offre-demande.',
      ru: 'Цены на товары фундаментально определяются балансом спроса и предложения.'
    }
  },
  {
    id: 16,
    question: {
      tr: 'Aşağıdaki ifade doğru mu? "Altın genellikle enflasyona karşı korunma aracı olarak görülür."',
      en: 'Is the following statement true? "Gold is generally seen as a hedge against inflation."',
      es: '¿Es verdadera la siguiente afirmación? "El oro generalmente se ve como una cobertura contra la inflación."',
      fr: 'L\'affirmation suivante est-elle vraie? "L\'or est généralement vu comme une couverture contre l\'inflation."',
      ru: 'Верно ли следующее утверждение? "Золото обычно рассматривается как защита от инфляции."'
    },
    type: 'true-false',
    answers: {
      tr: ['Doğru', 'Yanlış'],
      en: ['True', 'False'],
      es: ['Verdadero', 'Falso'],
      fr: ['Vrai', 'Faux'],
      ru: ['Верно', 'Неверно']
    },
    correct: 0,
    explanation: {
      tr: 'Doğru. Altın tarihsel olarak enflasyona karşı korunma aracı olarak kullanılmıştır.',
      en: 'True. Gold has historically been used as a hedge against inflation.',
      es: 'Verdadero. El oro ha sido históricamente usado como cobertura contra la inflación.',
      fr: 'Vrai. L\'or a historiquement été utilisé comme couverture contre l\'inflation.',
      ru: 'Верно. Золото исторически использовалось как защита от инфляции.'
    }
  },
  {
    id: 17,
    question: {
      tr: 'Kripto paraların en büyük risklerinden biri nedir?',
      en: 'What is one of the biggest risks of cryptocurrencies?',
      es: '¿Cuál es uno de los mayores riesgos de las criptomonedas?',
      fr: 'Quel est l\'un des plus grands risques des cryptomonnaies?',
      ru: 'Каков один из самых больших рисков криптовалют?'
    },
    type: 'multiple-choice',
    answers: {
      tr: [
        'Yasal belirsizlik',
        'Düşük likidite',
        'Sabit getiri',
        'Sınırlı erişim'
      ],
      en: [
        'Legal uncertainty',
        'Low liquidity',
        'Fixed returns',
        'Limited access'
      ],
      es: [
        'Incertidumbre legal',
        'Baja liquidez',
        'Retornos fijos',
        'Acceso limitado'
      ],
      fr: [
        'Incertitude légale',
        'Faible liquidité',
        'Rendements fixes',
        'Accès limité'
      ],
      ru: [
        'Правовая неопределенность',
        'Низкая ликвидность',
        'Фиксированная доходность',
        'Ограниченный доступ'
      ]
    },
    correct: 0,
    explanation: {
      tr: 'Kripto paraların en büyük risklerinden biri yasal belirsizliktir.',
      en: 'One of the biggest risks of cryptocurrencies is legal uncertainty.',
      es: 'Uno de los mayores riesgos de las criptomonedas es la incertidumbre legal.',
      fr: 'L\'un des plus grands risques des cryptomonnaies est l\'incertitude légale.',
      ru: 'Один из самых больших рисков криптовалют - это правовая неопределенность.'
    }
  },
  {
    id: 18,
    question: {
      tr: 'Bitcoin\'in blokzincir yapısı ne sağlar?',
      en: 'What does Bitcoin\'s blockchain structure provide?',
      es: '¿Qué proporciona la estructura blockchain de Bitcoin?',
      fr: 'Que fournit la structure blockchain de Bitcoin?',
      ru: 'Что обеспечивает блокчейн-структура Bitcoin?'
    },
    type: 'multiple-choice',
    answers: {
      tr: [
        'Merkeziyetsizlik ve şeffaflık',
        'Tek merkezden kontrol',
        'Sabit fiyat',
        'Garantili faiz'
      ],
      en: [
        'Decentralization and transparency',
        'Centralized control',
        'Fixed price',
        'Guaranteed interest'
      ],
      es: [
        'Descentralización y transparencia',
        'Control centralizado',
        'Precio fijo',
        'Interés garantizado'
      ],
      fr: [
        'Décentralisation et transparence',
        'Contrôle centralisé',
        'Prix fixe',
        'Intérêt garanti'
      ],
      ru: [
        'Децентрализация и прозрачность',
        'Централизованный контроль',
        'Фиксированная цена',
        'Гарантированный процент'
      ]
    },
    correct: 0,
    explanation: {
      tr: 'Bitcoin\'in blokzincir yapısı merkeziyetsizlik ve şeffaflık sağlar.',
      en: 'Bitcoin\'s blockchain structure provides decentralization and transparency.',
      es: 'La estructura blockchain de Bitcoin proporciona descentralización y transparencia.',
      fr: 'La structure blockchain de Bitcoin fournit décentralisation et transparence.',
      ru: 'Блокчейн-структура Bitcoin обеспечивает децентрализацию и прозрачность.'
    }
  },
  {
    id: 19,
    question: {
      tr: 'Modern borsalarda işlemler genellikle nasıl gerçekleşir?',
      en: 'How do transactions generally occur in modern exchanges?',
      es: '¿Cómo ocurren generalmente las transacciones en las bolsas modernas?',
      fr: 'Comment les transactions se déroulent-elles généralement dans les bourses modernes?',
      ru: 'Как обычно происходят транзакции на современных биржах?'
    },
    type: 'multiple-choice',
    answers: {
      tr: [
        'Kağıt emirle',
        'Elektronik emir eşleştirme',
        'Fiziksel müzayede',
        'Nakit elden'
      ],
      en: [
        'Paper orders',
        'Electronic order matching',
        'Physical auction',
        'Cash in hand'
      ],
      es: [
        'Órdenes en papel',
        'Emparejamiento electrónico de órdenes',
        'Subasta física',
        'Efectivo en mano'
      ],
      fr: [
        'Ordres sur papier',
        'Appariement électronique d\'ordres',
        'Enchère physique',
        'Espèces en main'
      ],
      ru: [
        'Бумажные ордера',
        'Электронное сопоставление ордеров',
        'Физический аукцион',
        'Наличные в руки'
      ]
    },
    correct: 1,
    explanation: {
      tr: 'Modern borsalarda işlemler elektronik emir eşleştirme sistemleri ile gerçekleşir.',
      en: 'In modern exchanges, transactions occur through electronic order matching systems.',
      es: 'En las bolsas modernas, las transacciones ocurren a través de sistemas electrónicos de emparejamiento de órdenes.',
      fr: 'Dans les bourses modernes, les transactions se déroulent via des systèmes électroniques d\'appariement d\'ordres.',
      ru: 'На современных биржах транзакции происходят через электронные системы сопоставления ордеров.'
    }
  },
  {
    id: 20,
    question: {
      tr: 'Borsaların temel rolü aşağıdakilerden hangisidir?',
      en: 'Which of the following is the basic role of exchanges?',
      es: '¿Cuál de los siguientes es el papel básico de las bolsas?',
      fr: 'Lequel des suivants est le rôle de base des bourses?',
      ru: 'Какова основная роль бирж?'
    },
    type: 'multiple-choice',
    answers: {
      tr: [
        'Adil fiyat oluşumu sağlamak',
        'Sabit faiz belirlemek',
        'Merkez bankası kurmak',
        'Vergi toplamak'
      ],
      en: [
        'Providing fair price discovery',
        'Setting fixed interest rates',
        'Establishing central banks',
        'Collecting taxes'
      ],
      es: [
        'Proporcionar descubrimiento justo de precios',
        'Establecer tasas de interés fijas',
        'Establecer bancos centrales',
        'Recaudar impuestos'
      ],
      fr: [
        'Fournir une découverte de prix équitable',
        'Fixer des taux d\'intérêt fixes',
        'Établir des banques centrales',
        'Collecter des impôts'
      ],
      ru: [
        'Обеспечение справедливого ценообразования',
        'Установление фиксированных процентных ставок',
        'Создание центральных банков',
        'Сбор налогов'
      ]
    },
    correct: 0,
    explanation: {
      tr: 'Borsaların temel rolü adil ve şeffaf fiyat oluşumu sağlamaktır.',
      en: 'The basic role of exchanges is to provide fair and transparent price discovery.',
      es: 'El papel básico de las bolsas es proporcionar un descubrimiento de precios justo y transparente.',
      fr: 'Le rôle de base des bourses est de fournir une découverte de prix équitable et transparente.',
      ru: 'Основная роль бирж - обеспечивать справедливое и прозрачное ценообразование.'
    }
  },
  {
    id: 21,
    question: {
      tr: 'S&P 500 hangi şirketleri kapsar?',
      en: 'Which companies does the S&P 500 include?',
      es: '¿Qué empresas incluye el S&P 500?',
      fr: 'Quelles entreprises inclut le S&P 500?',
      ru: 'Какие компании включает S&P 500?'
    },
    type: 'multiple-choice',
    answers: {
      tr: [
        'Dünyanın tüm şirketleri',
        'ABD\'nin en büyük 500 şirketi',
        'Avrupa şirketleri',
        'Sadece teknoloji hisseleri'
      ],
      en: [
        'All companies in the world',
        'The largest 500 US companies',
        'European companies',
        'Only technology stocks'
      ],
      es: [
        'Todas las empresas del mundo',
        'Las 500 empresas más grandes de EE.UU.',
        'Empresas europeas',
        'Solo acciones tecnológicas'
      ],
      fr: [
        'Toutes les entreprises du monde',
        'Les 500 plus grandes entreprises américaines',
        'Entreprises européennes',
        'Seulement actions technologiques'
      ],
      ru: [
        'Все компании мира',
        '500 крупнейших американских компаний',
        'Европейские компании',
        'Только технологические акции'
      ]
    },
    correct: 1,
    explanation: {
      tr: 'S&P 500, Amerika Birleşik Devletleri\'nin en büyük 500 halka açık şirketini kapsar.',
      en: 'The S&P 500 includes the 500 largest publicly traded companies in the United States.',
      es: 'El S&P 500 incluye las 500 empresas que cotizan en bolsa más grandes de Estados Unidos.',
      fr: 'Le S&P 500 inclut les 500 plus grandes entreprises cotées en bourse aux États-Unis.',
      ru: 'S&P 500 включает 500 крупнейших публично торгуемых компаний в Соединенных Штатах.'
    }
  },
  {
    id: 22,
    question: {
      tr: 'Aşağıdaki ifade doğru mu? "Piyasa endeksleri portföy performansı için karşılaştırma ölçütüdür."',
      en: 'Is the following statement true? "Market indices are benchmarks for portfolio performance."',
      es: '¿Es verdadera la siguiente afirmación? "Los índices de mercado son puntos de referencia para el rendimiento del portafolio."',
      fr: 'L\'affirmation suivante est-elle vraie? "Les indices de marché sont des références pour la performance de portefeuille."',
      ru: 'Верно ли следующее утверждение? "Рыночные индексы являются эталонами для оценки эффективности портфеля."'
    },
    type: 'true-false',
    answers: {
      tr: ['Doğru', 'Yanlış'],
      en: ['True', 'False'],
      es: ['Verdadero', 'Falso'],
      fr: ['Vrai', 'Faux'],
      ru: ['Верно', 'Неверно']
    },
    correct: 0,
    explanation: {
      tr: 'Doğru. Piyasa endeksleri, yatırımcıların portföy performanslarını karşılaştırmak için kullandıkları standart ölçütlerdir.',
      en: 'True. Market indices are standard benchmarks that investors use to compare their portfolio performance.',
      es: 'Verdadero. Los índices de mercado son puntos de referencia estándar que los inversores usan para comparar el rendimiento de su portafolio.',
      fr: 'Vrai. Les indices de marché sont des références standard que les investisseurs utilisent pour comparer la performance de leur portefeuille.',
      ru: 'Верно. Рыночные индексы являются стандартными эталонами, которые инвесторы используют для сравнения эффективности своих портфелей.'
    }
  },
  {
    id: 23,
    question: {
      tr: 'Aşağıdakilerden hangisi piyasa katılımcısı değildir?',
      en: 'Which of the following is not a market participant?',
      es: '¿Cuál de los siguientes no es un participante del mercado?',
      fr: 'Lequel des suivants n\'est pas un participant de marché?',
      ru: 'Кто из нижеперечисленных не является участником рынка?'
    },
    type: 'multiple-choice',
    answers: {
      tr: [
        'Bireysel yatırımcı',
        'Meteoroloji kurumu',
        'Kurumsal yatırımcı',
        'Aracı kurum'
      ],
      en: [
        'Individual investor',
        'Meteorology institution',
        'Institutional investor',
        'Brokerage firm'
      ],
      es: [
        'Inversor individual',
        'Institución meteorológica',
        'Inversor institucional',
        'Casa de bolsa'
      ],
      fr: [
        'Investisseur individuel',
        'Institution météorologique',
        'Investisseur institutionnel',
        'Maison de courtage'
      ],
      ru: [
        'Индивидуальный инвестор',
        'Метеорологическое учреждение',
        'Институциональный инвестор',
        'Брокерская компания'
      ]
    },
    correct: 1,
    explanation: {
      tr: 'Meteoroloji kurumu finansal piyasalarda doğrudan işlem yapmaz, dolayısıyla piyasa katılımcısı değildir.',
      en: 'A meteorology institution does not directly trade in financial markets, so it is not a market participant.',
      es: 'Una institución meteorológica no opera directamente en los mercados financieros, por lo que no es un participante del mercado.',
      fr: 'Une institution météorologique ne négocie pas directement sur les marchés financiers, elle n\'est donc pas un participant de marché.',
      ru: 'Метеорологическое учреждение не торгует напрямую на финансовых рынках, поэтому оно не является участником рынка.'
    }
  },
  {
    id: 24,
    question: {
      tr: 'Hedge fonların genel özelliği nedir?',
      en: 'What is the general characteristic of hedge funds?',
      es: '¿Cuál es la característica general de los fondos de cobertura?',
      fr: 'Quelle est la caractéristique générale des hedge funds?',
      ru: 'Какова общая характеристика хедж-фондов?'
    },
    type: 'multiple-choice',
    answers: {
      tr: [
        'Yüksek risk ve getiri arayışı',
        'Sabit faizli yatırım',
        'Sadece tahvil alımı',
        'Kamu fonu olmaları'
      ],
      en: [
        'High risk and return seeking',
        'Fixed interest investment',
        'Only bond purchasing',
        'Being public funds'
      ],
      es: [
        'Búsqueda de alto riesgo y retorno',
        'Inversión de interés fijo',
        'Solo compra de bonos',
        'Ser fondos públicos'
      ],
      fr: [
        'Recherche de risque et rendement élevés',
        'Investissement à intérêt fixe',
        'Achat d\'obligations seulement',
        'Être des fonds publics'
      ],
      ru: [
        'Поиск высокого риска и доходности',
        'Инвестиции с фиксированным процентом',
        'Только покупка облигаций',
        'Быть публичными фондами'
      ]
    },
    correct: 0,
    explanation: {
      tr: 'Hedge fonlar genellikle yüksek risk alarak yüksek getiri elde etmeye çalışan alternatif yatırım araçlarıdır.',
      en: 'Hedge funds are generally alternative investment vehicles that seek high returns by taking high risks.',
      es: 'Los fondos de cobertura son generalmente vehículos de inversión alternativos que buscan altos retornos tomando altos riesgos.',
      fr: 'Les hedge funds sont généralement des véhicules d\'investissement alternatifs qui cherchent des rendements élevés en prenant des risques élevés.',
      ru: 'Хедж-фонды обычно являются альтернативными инвестиционными инструментами, которые стремятся к высокой доходности, принимая высокие риски.'
    }
  },
  {
    id: 25,
    question: {
      tr: 'Temel finans kuralı nedir?',
      en: 'What is the basic rule of finance?',
      es: '¿Cuál es la regla básica de las finanzas?',
      fr: 'Quelle est la règle de base de la finance?',
      ru: 'Каково основное правило финансов?'
    },
    type: 'multiple-choice',
    answers: {
      tr: [
        'Yüksek getiri = yüksek risk',
        'Yüksek getiri = düşük risk',
        'Risk getiriyle ilgisizdir',
        'Risk yoktur'
      ],
      en: [
        'High return = high risk',
        'High return = low risk',
        'Risk is unrelated to return',
        'There is no risk'
      ],
      es: [
        'Alto retorno = alto riesgo',
        'Alto retorno = bajo riesgo',
        'El riesgo no está relacionado con el retorno',
        'No hay riesgo'
      ],
      fr: [
        'Rendement élevé = risque élevé',
        'Rendement élevé = faible risque',
        'Le risque n\'est pas lié au rendement',
        'Il n\'y a pas de risque'
      ],
      ru: [
        'Высокая доходность = высокий риск',
        'Высокая доходность = низкий риск',
        'Риск не связан с доходностью',
        'Риска нет'
      ]
    },
    correct: 0,
    explanation: {
      tr: 'Finansın temel kuralı risk-getiri dengesini ifade eder: yüksek getiri elde etmek için yüksek risk almak gerekir.',
      en: 'The basic rule of finance expresses the risk-return trade-off: to achieve high returns, one must take high risks.',
      es: 'La regla básica de las finanzas expresa el equilibrio riesgo-retorno: para lograr altos retornos, uno debe tomar altos riesgos.',
      fr: 'La règle de base de la finance exprime l\'équilibre risque-rendement: pour obtenir des rendements élevés, il faut prendre des risques élevés.',
      ru: 'Основное правило финансов выражает соотношение риск-доходность: для достижения высокой доходности необходимо принимать высокие риски.'
    }
  },
  {
    id: 26,
    question: {
      tr: 'Aşağıdaki ifade doğru mu? "Devlet tahvilleri genellikle hisse senetlerinden daha güvenlidir."',
      en: 'Is the following statement true? "Government bonds are generally safer than stocks."',
      es: '¿Es verdadera la siguiente afirmación? "Los bonos del gobierno son generalmente más seguros que las acciones."',
      fr: 'L\'affirmation suivante est-elle vraie? "Les obligations d\'État sont généralement plus sûres que les actions."',
      ru: 'Верно ли следующее утверждение? "Государственные облигации обычно безопаснее акций."'
    },
    type: 'true-false',
    answers: {
      tr: ['Doğru', 'Yanlış'],
      en: ['True', 'False'],
      es: ['Verdadero', 'Falso'],
      fr: ['Vrai', 'Faux'],
      ru: ['Верно', 'Неверно']
    },
    correct: 0,
    explanation: {
      tr: 'Doğru. Devlet tahvilleri devlet garantisi altında olduğu için genellikle hisse senetlerinden daha güvenli kabul edilir.',
      en: 'True. Government bonds are generally considered safer than stocks because they are backed by government guarantee.',
      es: 'Verdadero. Los bonos del gobierno son generalmente considerados más seguros que las acciones porque están respaldados por la garantía gubernamental.',
      fr: 'Vrai. Les obligations d\'État sont généralement considérées comme plus sûres que les actions car elles sont garanties par l\'État.',
      ru: 'Верно. Государственные облигации обычно считаются более безопасными, чем акции, поскольку они обеспечены государственной гарантией.'
    }
  },
  {
    id: 27,
    question: {
      tr: 'Portföy çeşitlendirmesinin temel amacı nedir?',
      en: 'What is the main purpose of portfolio diversification?',
      es: '¿Cuál es el propósito principal de la diversificación del portafolio?',
      fr: 'Quel est l\'objectif principal de la diversification de portefeuille?',
      ru: 'Какова основная цель диверсификации портфеля?'
    },
    type: 'multiple-choice',
    answers: {
      tr: [
        'Riski azaltmak',
        'Getiriyi sıfırlamak',
        'İşlem maliyetini artırmak',
        'Tek yatırım alanına yoğunlaşmak'
      ],
      en: [
        'Reducing risk',
        'Zeroing returns',
        'Increasing transaction costs',
        'Concentrating on a single investment area'
      ],
      es: [
        'Reducir el riesgo',
        'Poner en cero los retornos',
        'Aumentar los costos de transacción',
        'Concentrarse en una sola área de inversión'
      ],
      fr: [
        'Réduire le risque',
        'Mettre les rendements à zéro',
        'Augmenter les coûts de transaction',
        'Se concentrer sur un seul domaine d\'investissement'
      ],
      ru: [
        'Снижение риска',
        'Обнуление доходности',
        'Увеличение транзакционных издержек',
        'Концентрация на одной области инвестиций'
      ]
    },
    correct: 0,
    explanation: {
      tr: 'Portföy çeşitlendirmesinin temel amacı, yatırımları farklı varlıklara dağıtarak genel riski azaltmaktır.',
      en: 'The main purpose of portfolio diversification is to reduce overall risk by spreading investments across different assets.',
      es: 'El propósito principal de la diversificación del portafolio es reducir el riesgo general distribuyendo las inversiones entre diferentes activos.',
      fr: 'L\'objectif principal de la diversification de portefeuille est de réduire le risque global en répartissant les investissements entre différents actifs.',
      ru: 'Основная цель диверсификации портфеля - снизить общий риск, распределив инвестиции между различными активами.'
    }
  },
  {
    id: 28,
    question: {
      tr: 'Pasif portföy yönetimi neyi ifade eder?',
      en: 'What does passive portfolio management refer to?',
      es: '¿A qué se refiere la gestión pasiva de portafolio?',
      fr: 'À quoi fait référence la gestion passive de portefeuille?',
      ru: 'Что означает пассивное управление портфелем?'
    },
    type: 'multiple-choice',
    answers: {
      tr: [
        'Uzun vadeli al-bekle stratejisi',
        'Sürekli alım-satım',
        'Günlük trade',
        'Yalnızca nakit tutma'
      ],
      en: [
        'Long-term buy-and-hold strategy',
        'Continuous trading',
        'Day trading',
        'Only holding cash'
      ],
      es: [
        'Estrategia de comprar y mantener a largo plazo',
        'Trading continuo',
        'Trading diario',
        'Solo mantener efectivo'
      ],
      fr: [
        'Stratégie d\'achat et conservation à long terme',
        'Trading continu',
        'Trading quotidien',
        'Seulement détenir des espèces'
      ],
      ru: [
        'Долгосрочная стратегия покупки и удержания',
        'Непрерывная торговля',
        'Дневная торговля',
        'Только держание наличных'
      ]
    },
    correct: 0,
    explanation: {
      tr: 'Pasif portföy yönetimi, uzun vadeli al-bekle stratejisiyle minimum müdahale yaklaşımını ifade eder.',
      en: 'Passive portfolio management refers to a minimal intervention approach with a long-term buy-and-hold strategy.',
      es: 'La gestión pasiva de portafolio se refiere a un enfoque de intervención mínima con una estrategia de comprar y mantener a largo plazo.',
      fr: 'La gestion passive de portefeuille fait référence à une approche d\'intervention minimale avec une stratégie d\'achat et conservation à long terme.',
      ru: 'Пассивное управление портфелем означает подход с минимальным вмешательством и долгосрочной стратегией покупки и удержания.'
    }
  },
  {
    id: 29,
    question: {
      tr: 'Etkin Piyasa Hipotezine göre bilgiler fiyatlara nasıl yansır?',
      en: 'According to the Efficient Market Hypothesis, how do information reflect in prices?',
      es: 'Según la Hipótesis del Mercado Eficiente, ¿cómo se reflejan las informaciones en los precios?',
      fr: 'Selon l\'Hypothèse du Marché Efficace, comment les informations se reflètent-elles dans les prix?',
      ru: 'Согласно гипотезе эффективного рынка, как информация отражается в ценах?'
    },
    type: 'multiple-choice',
    answers: {
      tr: [
        'Hızla ve anında',
        'Haftalar sonra',
        'Yavaşça',
        'Rastgele'
      ],
      en: [
        'Quickly and instantly',
        'Weeks later',
        'Slowly',
        'Randomly'
      ],
      es: [
        'Rápida e instantáneamente',
        'Semanas después',
        'Lentamente',
        'Al azar'
      ],
      fr: [
        'Rapidement et instantanément',
        'Semaines plus tard',
        'Lentement',
        'Au hasard'
      ],
      ru: [
        'Быстро и мгновенно',
        'Через недели',
        'Медленно',
        'Случайно'
      ]
    },
    correct: 0,
    explanation: {
      tr: 'Etkin Piyasa Hipotezine göre, tüm mevcut bilgiler hızla ve anında fiyatlara yansır.',
      en: 'According to the Efficient Market Hypothesis, all available information is quickly and instantly reflected in prices.',
      es: 'Según la Hipótesis del Mercado Eficiente, toda la información disponible se refleja rápida e instantáneamente en los precios.',
      fr: 'Selon l\'Hypothèse du Marché Efficace, toutes les informations disponibles se reflètent rapidement et instantanément dans les prix.',
      ru: 'Согласно гипотезе эффективного рынка, вся доступная информация быстро и мгновенно отражается в ценах.'
    }
  },
  {
    id: 30,
    question: {
      tr: 'Aşağıdaki ifade doğru mu? "Piyasalar her zaman tamamen etkin çalışır."',
      en: 'Is the following statement true? "Markets always operate completely efficiently."',
      es: '¿Es verdadera la siguiente afirmación? "Los mercados siempre operan completamente de manera eficiente."',
      fr: 'L\'affirmation suivante est-elle vraie? "Les marchés fonctionnent toujours de manière complètement efficace."',
      ru: 'Верно ли следующее утверждение? "Рынки всегда работают полностью эффективно."'
    },
    type: 'true-false',
    answers: {
      tr: ['Doğru', 'Yanlış'],
      en: ['True', 'False'],
      es: ['Verdadero', 'Falso'],
      fr: ['Vrai', 'Faux'],
      ru: ['Верно', 'Неверно']
    },
    correct: 1,
    explanation: {
      tr: 'Yanlış. Piyasalar her zaman tamamen etkin çalışmaz; duygusal kararlar, bilgi asimetrisi ve piyasa sürtünmeleri nedeniyle verimsizlikler ortaya çıkabilir.',
      en: 'False. Markets do not always operate completely efficiently; inefficiencies can arise due to emotional decisions, information asymmetry, and market frictions.',
      es: 'Falso. Los mercados no siempre operan completamente de manera eficiente; pueden surgir ineficiencias debido a decisiones emocionales, asimetría de información y fricciones del mercado.',
      fr: 'Faux. Les marchés ne fonctionnent pas toujours de manière complètement efficace; des inefficacités peuvent survenir en raison de décisions émotionnelles, d\'asymétrie d\'information et de frictions de marché.',
      ru: 'Неверно. Рынки не всегда работают полностью эффективно; неэффективности могут возникать из-за эмоциональных решений, информационной асимметрии и рыночных трений.'
    }
  },
  {
    id: 31,
    question: {
      tr: 'Yatırımcıların kayıptan kaçınma eğilimi hangi kavrama örnektir?',
      en: 'What concept does investors\' loss aversion tendency exemplify?',
      es: '¿Qué concepto ejemplifica la tendencia de aversión a las pérdidas de los inversores?',
      fr: 'Quel concept illustre la tendance d\'aversion aux pertes des investisseurs?',
      ru: 'Какую концепцию иллюстрирует тенденция инвесторов избегать потерь?'
    },
    type: 'multiple-choice',
    answers: {
      tr: [
        'Bilişsel önyargı',
        'Temel analiz',
        'Arbitraj',
        'Beta katsayısı'
      ],
      en: [
        'Cognitive bias',
        'Fundamental analysis',
        'Arbitrage',
        'Beta coefficient'
      ],
      es: [
        'Sesgo cognitivo',
        'Análisis fundamental',
        'Arbitraje',
        'Coeficiente beta'
      ],
      fr: [
        'Biais cognitif',
        'Analyse fondamentale',
        'Arbitrage',
        'Coefficient bêta'
      ],
      ru: [
        'Когнитивное смещение',
        'Фундаментальный анализ',
        'Арбитраж',
        'Бета-коэффициент'
      ]
    },
    correct: 0,
    explanation: {
      tr: 'Kayıptan kaçınma eğilimi, davranışsal finansta önemli bir bilişsel önyargı örneğidir.',
      en: 'Loss aversion tendency is an important example of cognitive bias in behavioral finance.',
      es: 'La tendencia de aversión a las pérdidas es un ejemplo importante de sesgo cognitivo en finanzas conductuales.',
      fr: 'La tendance d\'aversion aux pertes est un exemple important de biais cognitif en finance comportementale.',
      ru: 'Тенденция избегания потерь является важным примером когнитивного смещения в поведенческих финансах.'
    }
  },
  {
    id: 32,
    question: {
      tr: 'Aşağıdaki ifade doğru mu? "Sürü psikolojisi piyasa balonlarına yol açabilir."',
      en: 'Is the following statement true? "Herd psychology can lead to market bubbles."',
      es: '¿Es verdadera la siguiente afirmación? "La psicología de rebaño puede llevar a burbujas de mercado."',
      fr: 'L\'affirmation suivante est-elle vraie? "La psychologie de troupeau peut conduire à des bulles de marché."',
      ru: 'Верно ли следующее утверждение? "Стадная психология может привести к рыночным пузырям."'
    },
    type: 'true-false',
    answers: {
      tr: ['Doğru', 'Yanlış'],
      en: ['True', 'False'],
      es: ['Verdadero', 'Falso'],
      fr: ['Vrai', 'Faux'],
      ru: ['Верно', 'Неверно']
    },
    correct: 0,
    explanation: {
      tr: 'Doğru. Sürü psikolojisi, yatırımcıların birbirini takip etmesi sonucu varlık fiyatlarının aşırı yükselmesine ve balon oluşumuna neden olabilir.',
      en: 'True. Herd psychology can cause asset prices to rise excessively and form bubbles as investors follow each other.',
      es: 'Verdadero. La psicología de rebaño puede causar que los precios de los activos suban excesivamente y formen burbujas cuando los inversores se siguen unos a otros.',
      fr: 'Vrai. La psychologie de troupeau peut causer une hausse excessive des prix des actifs et former des bulles lorsque les investisseurs se suivent les uns les autres.',
      ru: 'Верно. Стадная психология может привести к чрезмерному росту цен на активы и образованию пузырей, когда инвесторы следуют друг за другом.'
    }
  },
  {
    id: 33,
    question: {
      tr: 'Türkiye\'de sermaye piyasasını kim denetler?',
      en: 'Who supervises the capital market in Turkey?',
      es: '¿Quién supervisa el mercado de capitales en Turquía?',
      fr: 'Qui supervise le marché des capitaux en Turquie?',
      ru: 'Кто контролирует рынок капитала в Турции?'
    },
    type: 'multiple-choice',
    answers: {
      tr: [
        'TCMB',
        'BDDK',
        'SPK',
        'Hazine'
      ],
      en: [
        'TCMB (Central Bank)',
        'BDDK (Banking Authority)',
        'SPK (Capital Markets Board)',
        'Treasury'
      ],
      es: [
        'TCMB (Banco Central)',
        'BDDK (Autoridad Bancaria)',
        'SPK (Junta de Mercados de Capital)',
        'Tesoro'
      ],
      fr: [
        'TCMB (Banque Centrale)',
        'BDDK (Autorité Bancaire)',
        'SPK (Conseil des Marchés de Capitaux)',
        'Trésor'
      ],
      ru: [
        'TCMB (Центральный банк)',
        'BDDK (Банковское управление)',
        'SPK (Совет рынков капитала)',
        'Казначейство'
      ]
    },
    correct: 2,
    explanation: {
      tr: 'Türkiye\'de sermaye piyasası SPK (Sermaye Piyasası Kurulu) tarafından denetlenir.',
      en: 'The capital market in Turkey is supervised by SPK (Capital Markets Board).',
      es: 'El mercado de capitales en Turquía es supervisado por SPK (Junta de Mercados de Capital).',
      fr: 'Le marché des capitaux en Turquie est supervisé par SPK (Conseil des Marchés de Capitaux).',
      ru: 'Рынок капитала в Турции контролируется SPK (Советом рынков капитала).'
    }
  },
  {
    id: 34,
    question: {
      tr: 'Basel III düzenlemeleri hangi kurum türü için geçerlidir?',
      en: 'For which type of institution do Basel III regulations apply?',
      es: '¿Para qué tipo de institución se aplican las regulaciones de Basilea III?',
      fr: 'Pour quel type d\'institution les réglementations de Bâle III s\'appliquent-elles?',
      ru: 'К какому типу учреждений применяются правила Базель III?'
    },
    type: 'multiple-choice',
    answers: {
      tr: [
        'Bankalar',
        'Borsalar',
        'Hedge fonlar',
        'Kripto madencileri'
      ],
      en: [
        'Banks',
        'Stock exchanges',
        'Hedge funds',
        'Crypto miners'
      ],
      es: [
        'Bancos',
        'Bolsas de valores',
        'Fondos de cobertura',
        'Mineros de cripto'
      ],
      fr: [
        'Banques',
        'Bourses',
        'Hedge funds',
        'Mineurs de crypto'
      ],
      ru: [
        'Банки',
        'Фондовые биржи',
        'Хедж-фонды',
        'Криптомайнеры'
      ]
    },
    correct: 0,
    explanation: {
      tr: 'Basel III düzenlemeleri bankalar için geçerli olan uluslararası bankacılık düzenleme standartlarıdır.',
      en: 'Basel III regulations are international banking regulatory standards that apply to banks.',
      es: 'Las regulaciones de Basilea III son estándares regulatorios bancarios internacionales que se aplican a los bancos.',
      fr: 'Les réglementations de Bâle III sont des normes réglementaires bancaires internationales qui s\'appliquent aux banques.',
      ru: 'Правила Базель III - это международные банковские регулятивные стандарты, которые применяются к банкам.'
    }
  },
  {
    id: 35,
    question: {
      tr: 'Küresel entegrasyonun en büyük riski nedir?',
      en: 'What is the biggest risk of global integration?',
      es: '¿Cuál es el mayor riesgo de la integración global?',
      fr: 'Quel est le plus grand risque de l\'intégration mondiale?',
      ru: 'Каков самый большой риск глобальной интеграции?'
    },
    type: 'multiple-choice',
    answers: {
      tr: [
        'Finansal bulaşma',
        'Sabit faiz',
        'Yüksek vergi',
        'Yavaş bilgi akışı'
      ],
      en: [
        'Financial contagion',
        'Fixed interest',
        'High taxes',
        'Slow information flow'
      ],
      es: [
        'Contagio financiero',
        'Interés fijo',
        'Altos impuestos',
        'Flujo lento de información'
      ],
      fr: [
        'Contagion financière',
        'Intérêt fixe',
        'Taxes élevées',
        'Flux d\'information lent'
      ],
      ru: [
        'Финансовое заражение',
        'Фиксированный процент',
        'Высокие налоги',
        'Медленный поток информации'
      ]
    },
    correct: 0,
    explanation: {
      tr: 'Küresel entegrasyonun en büyük riski finansal bulaşmadır - bir ülkedeki krizin diğer ülkelere hızla yayılması.',
      en: 'The biggest risk of global integration is financial contagion - rapid spread of crisis from one country to others.',
      es: 'El mayor riesgo de la integración global es el contagio financiero - la rápida propagación de crisis de un país a otros.',
      fr: 'Le plus grand risque de l\'intégration mondiale est la contagion financière - propagation rapide de crise d\'un pays à d\'autres.',
      ru: 'Самый большой риск глобальной интеграции - это финансовое заражение - быстрое распространение кризиса из одной страны в другие.'
    }
  },
  {
    id: 36,
    question: {
      tr: 'Aşağıdaki ifade doğru mu? "ABD borsasındaki sert düşüş Asya piyasalarını etkileyebilir."',
      en: 'Is the following statement true? "A sharp decline in the US stock market can affect Asian markets."',
      es: '¿Es verdadera la siguiente afirmación? "Una fuerte caída en el mercado de valores de EE.UU. puede afectar los mercados asiáticos."',
      fr: 'L\'affirmation suivante est-elle vraie? "Une forte baisse du marché boursier américain peut affecter les marchés asiatiques."',
      ru: 'Верно ли следующее утверждение? "Резкое падение на фондовом рынке США может повлиять на азиатские рынки."'
    },
    type: 'true-false',
    answers: {
      tr: ['Doğru', 'Yanlış'],
      en: ['True', 'False'],
      es: ['Verdadero', 'Falso'],
      fr: ['Vrai', 'Faux'],
      ru: ['Верно', 'Неверно']
    },
    correct: 0,
    explanation: {
      tr: 'Doğru. Küresel piyasalar birbiriyle bağlantılı olduğu için ABD borsasındaki sert düşüş dünya çapında diğer piyasaları etkileyebilir.',
      en: 'True. Since global markets are interconnected, a sharp decline in the US stock market can affect other markets worldwide.',
      es: 'Verdadero. Dado que los mercados globales están interconectados, una fuerte caída en el mercado de valores de EE.UU. puede afectar otros mercados a nivel mundial.',
      fr: 'Vrai. Étant donné que les marchés mondiaux sont interconnectés, une forte baisse du marché boursier américain peut affecter d\'autres marchés dans le monde.',
      ru: 'Верно. Поскольку глобальные рынки взаимосвязаны, резкое падение на американском фондовом рынке может повлиять на другие рынки по всему миру.'
    }
  },
  {
    id: 37,
    question: {
      tr: '2008 küresel krizinin temel nedeni neydi?',
      en: 'What was the main cause of the 2008 global crisis?',
      es: '¿Cuál fue la causa principal de la crisis global de 2008?',
      fr: 'Quelle était la cause principale de la crise mondiale de 2008?',
      ru: 'Какова была основная причина глобального кризиса 2008 года?'
    },
    type: 'multiple-choice',
    answers: {
      tr: [
        'Subprime mortgage balonu',
        'Altın kıtlığı',
        'Petrol savaşları',
        'Kripto çöküşü'
      ],
      en: [
        'Subprime mortgage bubble',
        'Gold shortage',
        'Oil wars',
        'Crypto crash'
      ],
      es: [
        'Burbuja de hipotecas subprime',
        'Escasez de oro',
        'Guerras del petróleo',
        'Crash de cripto'
      ],
      fr: [
        'Bulle des prêts hypothécaires subprime',
        'Pénurie d\'or',
        'Guerres du pétrole',
        'Crash crypto'
      ],
      ru: [
        'Пузырь субстандартной ипотеки',
        'Дефицит золота',
        'Нефтяные войны',
        'Крах криптовалют'
      ]
    },
    correct: 0,
    explanation: {
      tr: '2008 küresel krizinin temel nedeni ABD\'deki subprime mortgage (yüksek riskli konut kredisi) balonunun patlamasıydı.',
      en: 'The main cause of the 2008 global crisis was the burst of the subprime mortgage bubble in the US.',
      es: 'La causa principal de la crisis global de 2008 fue el estallido de la burbuja de hipotecas subprime en EE.UU.',
      fr: 'La cause principale de la crise mondiale de 2008 était l\'éclatement de la bulle des prêts hypothécaires subprime aux États-Unis.',
      ru: 'Основной причиной глобального кризиса 2008 года был лопнувший пузырь субстандартной ипотеки в США.'
    }
  },
  {
    id: 38,
    question: {
      tr: 'Aşağıdaki ifade doğru mu? "Yüksek kaldıraç krizde kayıpları artırabilir."',
      en: 'Is the following statement true? "High leverage can increase losses during a crisis."',
      es: '¿Es verdadera la siguiente afirmación? "El alto apalancamiento puede aumentar las pérdidas durante una crisis."',
      fr: 'L\'affirmation suivante est-elle vraie? "Un effet de levier élevé peut augmenter les pertes pendant une crise."',
      ru: 'Верно ли следующее утверждение? "Высокое кредитное плечо может увеличить потери во время кризиса."'
    },
    type: 'true-false',
    answers: {
      tr: ['Doğru', 'Yanlış'],
      en: ['True', 'False'],
      es: ['Verdadero', 'Falso'],
      fr: ['Vrai', 'Faux'],
      ru: ['Верно', 'Неверно']
    },
    correct: 0,
    explanation: {
      tr: 'Doğru. Yüksek kaldıraç kullanımı, kriz dönemlerinde kayıpları büyütür ve finansal durumu daha da kötüleştirebilir.',
      en: 'True. Using high leverage amplifies losses during crisis periods and can worsen the financial situation.',
      es: 'Verdadero. El uso de alto apalancamiento amplifica las pérdidas durante períodos de crisis y puede empeorar la situación financiera.',
      fr: 'Vrai. L\'utilisation d\'un effet de levier élevé amplifie les pertes pendant les périodes de crise et peut aggraver la situation financière.',
      ru: 'Верно. Использование высокого кредитного плеча усиливает потери в кризисные периоды и может ухудшить финансовое положение.'
    }
  },
  {
    id: 39,
    question: {
      tr: 'Gelecekte öne çıkması beklenen trendlerden biri hangisidir?',
      en: 'Which is one of the trends expected to emerge in the future?',
      es: '¿Cuál es una de las tendencias que se espera que emerjan en el futuro?',
      fr: 'Quelle est l\'une des tendances attendues pour l\'avenir?',
      ru: 'Какая из тенденций ожидается в будущем?'
    },
    type: 'multiple-choice',
    answers: {
      tr: [
        'Kağıt çek kullanımı',
        'AI destekli ticaret',
        'Sadece nakit işlemler',
        'Sabit kur sistemi'
      ],
      en: [
        'Paper check usage',
        'AI-powered trading',
        'Only cash transactions',
        'Fixed exchange rate system'
      ],
      es: [
        'Uso de cheques en papel',
        'Trading potenciado por IA',
        'Solo transacciones en efectivo',
        'Sistema de tipo de cambio fijo'
      ],
      fr: [
        'Utilisation de chèques papier',
        'Trading alimenté par IA',
        'Seulement transactions en espèces',
        'Système de taux de change fixe'
      ],
      ru: [
        'Использование бумажных чеков',
        'ИИ-торговля',
        'Только наличные транзакции',
        'Система фиксированного валютного курса'
      ]
    },
    correct: 1,
    explanation: {
      tr: 'Gelecekte öne çıkması beklenen ana trendlerden biri yapay zeka destekli ticaret algoritmalarıdır.',
      en: 'One of the main trends expected to emerge in the future is AI-powered trading algorithms.',
      es: 'Una de las principales tendencias que se espera que emerjan en el futuro son los algoritmos de trading potenciados por IA.',
      fr: 'L\'une des principales tendances attendues pour l\'avenir sont les algorithmes de trading alimentés par IA.',
      ru: 'Одной из основных тенденций, ожидаемых в будущем, являются торговые алгоритмы на основе ИИ.'
    }
  },
  {
    id: 40,
    question: {
      tr: 'Aşağıdaki ifade doğru mu? "Merkez bankası dijital paraları (CBDC) geleneksel bankacılığı etkilemeyecek."',
      en: 'Is the following statement true? "Central Bank Digital Currencies (CBDCs) will not affect traditional banking."',
      es: '¿Es verdadera la siguiente afirmación? "Las Monedas Digitales del Banco Central (CBDC) no afectarán la banca tradicional."',
      fr: 'L\'affirmation suivante est-elle vraie? "Les Monnaies Numériques de Banque Centrale (CBDC) n\'affecteront pas la banque traditionnelle."',
      ru: 'Верно ли следующее утверждение? "Цифровые валюты центральных банков (CBDC) не повлияют на традиционный банкинг."'
    },
    type: 'true-false',
    answers: {
      tr: ['Doğru', 'Yanlış'],
      en: ['True', 'False'],
      es: ['Verdadero', 'Falso'],
      fr: ['Vrai', 'Faux'],
      ru: ['Верно', 'Неверно']
    },
    correct: 1,
    explanation: {
      tr: 'Yanlış. CBDC\'ler geleneksel bankacılık sistemini önemli ölçüde etkileyecek ve yeniden şekillendirecektir.',
      en: 'False. CBDCs will significantly impact and reshape the traditional banking system.',
      es: 'Falso. Las CBDC impactarán significativamente y remodelarán el sistema bancario tradicional.',
      fr: 'Faux. Les CBDC impacteront significativement et remodèleront le système bancaire traditionnel.',
      ru: 'Неверно. CBDC значительно повлияют на традиционную банковскую систему и изменят ее.'
    }
  }
]