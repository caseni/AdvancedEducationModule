import { 
  TrendingUp, Activity, BarChart3, Target, Brain, 
  Lightbulb, Zap, LineChart, Eye, Settings, 
  CheckCircle, AlertTriangle, TrendingDown, Layers,
  ArrowUpRight, ArrowDownRight
} from 'lucide-react'

export const advancedTechnicalAnalysisSlides = [
  {
    title: { 
      tr: 'Giriş: Neden İleri Teknik Analiz?', 
      en: 'Introduction: Why Advanced Technical Analysis?', 
      es: 'Introducción: ¿Por qué Análisis Técnico Avanzado?', 
      fr: 'Introduction: Pourquoi l\'Analyse Technique Avancée?', 
      ru: 'Введение: Зачем продвинутый технический анализ?' 
    },
    content: { 
      tr: '• İleri teknik analiz, basit grafik okumayı bir adım öteye taşıyarak daha isabetli giriş ve çıkış sağlar\\n• Karmaşık görünen araçların hepsi mantığa dayanır; mantığını öğrenince kullanması kolaylaşır\\n• Kurumsal oyuncuların davranışlarını anlayarak onlarla aynı yönde pozisyon alabilirsiniz\\n• Amaç: önce öğren, sonra pratikte test et',
      en: '• Advanced technical analysis takes simple chart reading a step further by providing more accurate entry and exit points\\n• All seemingly complex tools are based on logic; once you understand the logic, they become easier to use\\n• By understanding institutional players\' behavior, you can position yourself in the same direction\\n• Goal: learn first, then test in practice',
      es: '• El análisis técnico avanzado lleva la lectura simple de gráficos un paso más allá proporcionando entradas y salidas más precisas\\n• Todas las herramientas aparentemente complejas se basan en lógica; una vez que entiendes la lógica, se vuelven más fáciles de usar\\n• Al entender el comportamiento de los jugadores institucionales, puedes posicionarte en la misma dirección\\n• Objetivo: aprende primero, luego prueba en la práctica',
      fr: '• L\'analyse technique avancée va au-delà de la lecture simple des graphiques en fournissant des entrées et sorties plus précises\\n• Tous les outils apparemment complexes sont basés sur la logique; une fois que vous comprenez la logique, ils deviennent plus faciles à utiliser\\n• En comprenant le comportement des acteurs institutionnels, vous pouvez vous positionner dans la même direction\\n• Objectif: apprendre d\'abord, puis tester en pratique',
      ru: '• Продвинутый технический анализ выводит простое чтение графиков на новый уровень, обеспечивая более точные точки входа и выхода\\n• Все кажущиеся сложными инструменты основаны на логике; поняв логику, их становится легче использовать\\n• Понимая поведение институциональных игроков, вы можете занимать позицию в том же направлении\\n• Цель: сначала изучить, затем проверить на практике'
    },
    example: { 
      tr: '💡 Basit destek-direnç vs İleri analiz: Basit yöntemle sadece fiyat seviyesine bakarsınız, ileri yöntemle o seviyedeki hacmi, kurumsal emirleri ve piyasa yapısını da analiz edersiniz.',
      en: '💡 Simple support-resistance vs Advanced analysis: With simple methods you only look at price levels, with advanced methods you also analyze volume, institutional orders and market structure at that level.',
      es: '💡 Soporte-resistencia simple vs Análisis avanzado: Con métodos simples solo miras niveles de precio, con métodos avanzados también analizas volumen, órdenes institucionales y estructura de mercado en ese nivel.',
      fr: '💡 Support-résistance simple vs Analyse avancée: Avec des méthodes simples vous ne regardez que les niveaux de prix, avec des méthodes avancées vous analysez aussi le volume, les ordres institutionnels et la structure de marché à ce niveau.',
      ru: '💡 Простая поддержка-сопротивление vs Продвинутый анализ: Простыми методами вы смотрите только на ценовые уровни, продвинутыми методами вы также анализируете объем, институциональные ордера и рыночную структуру на этом уровне.'
    },
    icon: <Lightbulb className="w-16 h-16 text-yellow-500" />
  },
  {
    title: { 
      tr: 'Çoklu Zaman Çerçevesi Stratejisi', 
      en: 'Multi-Timeframe Strategy', 
      es: 'Estrategia de Marco Temporal Múltiple', 
      fr: 'Stratégie Multi-Cadres Temporels', 
      ru: 'Мульти-таймфрейм стратегия' 
    },
    content: { 
      tr: '• Önce büyük zaman diliminde (haftalık/aylık) ana trendi belirleyin; sonra günlük ve kısa dilimlerde giriş arayın\\n• Büyük trendle uyumlu sinyaller daha güvenilirdir\\n• Top-down yaklaşım: Geniş perspektiften dar perspektife doğru analiz yapın\\n• Zaman uyumu: Tüm zaman dilimlerinde aynı yönde sinyal arayın',
      en: '• First determine the main trend in large timeframes (weekly/monthly); then look for entries in daily and short timeframes\\n• Signals aligned with the major trend are more reliable\\n• Top-down approach: Analyze from broad perspective to narrow perspective\\n• Time alignment: Look for signals in the same direction across all timeframes',
      es: '• Primero determina la tendencia principal en marcos temporales grandes (semanal/mensual); luego busca entradas en marcos diarios y cortos\\n• Las señales alineadas con la tendencia mayor son más confiables\\n• Enfoque top-down: Analiza desde perspectiva amplia hacia perspectiva estrecha\\n• Alineación temporal: Busca señales en la misma dirección en todos los marcos temporales',
      fr: '• Déterminez d\'abord la tendance principale dans les grands cadres temporels (hebdomadaire/mensuel); puis cherchez des entrées dans les cadres quotidiens et courts\\n• Les signaux alignés avec la tendance majeure sont plus fiables\\n• Approche descendante: Analysez de la perspective large vers la perspective étroite\\n• Alignement temporel: Cherchez des signaux dans la même direction sur tous les cadres temporels',
      ru: '• Сначала определите основной тренд на больших таймфреймах (недельный/месячный); затем ищите входы на дневных и коротких таймфреймах\\n• Сигналы, выровненные с основным трендом, более надежны\\n• Подход сверху вниз: Анализируйте от широкой перспективы к узкой перспективе\\n• Временное выравнивание: Ищите сигналы в одном направлении на всех таймфреймах'
    },
    example: { 
      tr: '📈 Uygulama: Haftalık yükseliş → günlük düzeltme → 1 saatlik dönüş sinyaliyle alım. Bu şekilde büyük trend lehine küçük pozisyon açarsınız.',
      en: '📈 Application: Weekly uptrend → daily correction → buy on 1-hour reversal signal. This way you open a small position in favor of the major trend.',
      es: '📈 Aplicación: Tendencia alcista semanal → corrección diaria → compra en señal de reversión de 1 hora. De esta manera abres una posición pequeña a favor de la tendencia mayor.',
      fr: '📈 Application: Tendance haussière hebdomadaire → correction quotidienne → achat sur signal de retournement d\'1 heure. De cette façon, vous ouvrez une petite position en faveur de la tendance majeure.',
      ru: '📈 Применение: Недельный восходящий тренд → дневная коррекция → покупка по часовому сигналу разворота. Таким образом вы открываете небольшую позицию в пользу основного тренда.'
    },
    icon: <Layers className="w-16 h-16 text-blue-500" />
  },
  {
    title: { 
      tr: 'Fiyat ve Hacim Uyumu', 
      en: 'Price and Volume Harmony', 
      es: 'Armonía de Precio y Volumen', 
      fr: 'Harmonie Prix et Volume', 
      ru: 'Гармония цены и объема' 
    },
    content: { 
      tr: '• Fiyat hareketini mutlaka hacimle doğrulayın: yükseliş hacim artışıyla geliyorsa güçlüdür\\n• OBV veya Volume Profile ile hangi fiyatlarda işlem yoğun olduğunu görün\\n• Hacim divergansı: Fiyat yeni zirve yaparken hacim azalırsa dikkatli olun\\n• Volume Profile ile değer alanını (Value Area) tespit edin',
      en: '• Always confirm price movement with volume: if rise comes with volume increase, it is strong\\n• See at which prices trading is intense with OBV or Volume Profile\\n• Volume divergence: Be careful if volume decreases while price makes new highs\\n• Identify the Value Area with Volume Profile',
      es: '• Siempre confirma el movimiento de precio con volumen: si la subida viene con aumento de volumen, es fuerte\\n• Ve en qué precios el trading es intenso con OBV o Volume Profile\\n• Divergencia de volumen: Ten cuidado si el volumen disminuye mientras el precio hace nuevos máximos\\n• Identifica el Área de Valor con Volume Profile',
      fr: '• Confirmez toujours le mouvement de prix avec le volume: si la hausse vient avec une augmentation du volume, elle est forte\\n• Voyez à quels prix le trading est intense avec OBV ou Volume Profile\\n• Divergence de volume: Soyez prudent si le volume diminue pendant que le prix fait de nouveaux sommets\\n• Identifiez la Zone de Valeur avec Volume Profile',
      ru: '• Всегда подтверждайте ценовое движение объемом: если рост идет с увеличением объема, он сильный\\n• Смотрите, на каких ценах торговля интенсивна с помощью OBV или Volume Profile\\n• Дивергенция объема: Будьте осторожны, если объем уменьшается, пока цена делает новые максимумы\\n• Определите область стоимости с помощью Volume Profile'
    },
    example: { 
      tr: '📊 Uygulama: Kırılım + hacim artışı = kırılımın gerçek olma olasılığı yüksek. Örneğin, direnç seviyesi kırılırken hacim %50 artıyorsa bu güçlü sinyal.',
      en: '📊 Application: Breakout + volume increase = high probability that the breakout is real. For example, if volume increases 50% while resistance level breaks, this is a strong signal.',
      es: '📊 Aplicación: Ruptura + aumento de volumen = alta probabilidad de que la ruptura sea real. Por ejemplo, si el volumen aumenta 50% mientras se rompe el nivel de resistencia, esta es una señal fuerte.',
      fr: '📊 Application: Cassure + augmentation du volume = forte probabilité que la cassure soit réelle. Par exemple, si le volume augmente de 50% pendant que le niveau de résistance se casse, c\'est un signal fort.',
      ru: '📊 Применение: Прорыв + увеличение объема = высокая вероятность того, что прорыв реальный. Например, если объем увеличивается на 50% при прорыве уровня сопротивления, это сильный сигнал.'
    },
    icon: <BarChart3 className="w-16 h-16 text-green-500" />
  },
  {
    title: { 
      tr: 'Gün İçi Değer ve Hacim Yoğunluğu (VWAP & Volume Profile)', 
      en: 'Intraday Value and Volume Density (VWAP & Volume Profile)', 
      es: 'Valor Intradiario y Densidad de Volumen (VWAP & Volume Profile)', 
      fr: 'Valeur Intrajournalière et Densité de Volume (VWAP & Volume Profile)', 
      ru: 'Внутридневная стоимость и плотность объема (VWAP & Volume Profile)' 
    },
    content: { 
      tr: '• VWAP, gün içindeki ortalama işlem fiyatıdır; kurumların "değer" algısını gösterir\\n• Volume Profile, hangi fiyatlarda en çok işlem olduğunu gösterir; güçlü destek/direnç çıkar\\n• POC (Point of Control): En yüksek hacimli fiyat seviyesi\\n• Value Area: İşlem hacminin %70\'inin gerçekleştiği fiyat aralığı',
      en: '• VWAP is the average trading price during the day; shows institutions\' "value" perception\\n• Volume Profile shows at which prices most trading occurs; creates strong support/resistance\\n• POC (Point of Control): The price level with highest volume\\n• Value Area: The price range where 70% of trading volume occurs',
      es: '• VWAP es el precio promedio de trading durante el día; muestra la percepción de "valor" de las instituciones\\n• Volume Profile muestra en qué precios ocurre la mayor parte del trading; crea soporte/resistencia fuerte\\n• POC (Point of Control): El nivel de precio con mayor volumen\\n• Área de Valor: El rango de precios donde ocurre el 70% del volumen de trading',
      fr: '• VWAP est le prix moyen de trading pendant la journée; montre la perception de "valeur" des institutions\\n• Volume Profile montre à quels prix la plupart du trading se produit; crée un support/résistance fort\\n• POC (Point of Control): Le niveau de prix avec le plus haut volume\\n• Zone de Valeur: La plage de prix où 70% du volume de trading se produit',
      ru: '• VWAP - это средняя торговая цена в течение дня; показывает восприятие "стоимости" институциями\\n• Volume Profile показывает, на каких ценах происходит большая часть торговли; создает сильную поддержку/сопротивление\\n• POC (Point of Control): Ценовой уровень с наибольшим объемом\\n• Область стоимости: Ценовой диапазон, где происходит 70% торгового объема'
    },
    example: { 
      tr: '📍 İpucu: Fiyat VWAP üzerindeyse alıcı baskısı hakimdir. VWAP altındaysa satıcı baskısı güçlüdür. POC seviyesi test edildiğinde güçlü tepki bekleyebilirsiniz.',
      en: '📍 Tip: If price is above VWAP, buyer pressure dominates. If below VWAP, seller pressure is strong. When POC level is tested, you can expect strong reaction.',
      es: '📍 Consejo: Si el precio está por encima de VWAP, domina la presión compradora. Si está por debajo de VWAP, la presión vendedora es fuerte. Cuando se prueba el nivel POC, puedes esperar una reacción fuerte.',
      fr: '📍 Conseil: Si le prix est au-dessus de VWAP, la pression acheteuse domine. Si en dessous de VWAP, la pression vendeuse est forte. Quand le niveau POC est testé, vous pouvez vous attendre à une réaction forte.',
      ru: '📍 Совет: Если цена выше VWAP, доминирует давление покупателей. Если ниже VWAP, давление продавцов сильное. Когда тестируется уровень POC, можно ожидать сильную реакцию.'
    },
    icon: <Activity className="w-16 h-16 text-purple-500" />
  },
  {
    title: { 
      tr: 'Emir Akışı ve Piyasa Derinliği (Level II / DOM)', 
      en: 'Order Flow and Market Depth (Level II / DOM)', 
      es: 'Flujo de Órdenes y Profundidad de Mercado (Level II / DOM)', 
      fr: 'Flux d\'Ordres et Profondeur de Marché (Level II / DOM)', 
      ru: 'Поток ордеров и глубина рынка (Level II / DOM)' 
    },
    content: { 
      tr: '• Order flow (emir akışı) büyük oyuncuların niyetini anlamaya yardımcı olur\\n• DOM/Level II, likidite derinliğini ve büyük emir bloklarını gösterir\\n• Iceberg emirleri: Büyük emirler küçük parçalara bölünerek gizlenir\\n• Bid-ask spread daraldığında volatilite artışı beklenebilir',
      en: '• Order flow helps understand the intentions of big players\\n• DOM/Level II shows liquidity depth and large order blocks\\n• Iceberg orders: Large orders are hidden by breaking into small pieces\\n• When bid-ask spread narrows, volatility increase can be expected',
      es: '• El flujo de órdenes ayuda a entender las intenciones de los grandes jugadores\\n• DOM/Level II muestra la profundidad de liquidez y grandes bloques de órdenes\\n• Órdenes iceberg: Las órdenes grandes se ocultan dividiéndose en pequeñas piezas\\n• Cuando el spread bid-ask se estrecha, se puede esperar un aumento de volatilidad',
      fr: '• Le flux d\'ordres aide à comprendre les intentions des gros joueurs\\n• DOM/Level II montre la profondeur de liquidité et les gros blocs d\'ordres\\n• Ordres iceberg: Les gros ordres sont cachés en se divisant en petites pièces\\n• Quand l\'écart bid-ask se resserre, une augmentation de volatilité peut être attendue',
      ru: '• Поток ордеров помогает понять намерения крупных игроков\\n• DOM/Level II показывает глубину ликвидности и крупные блоки ордеров\\n• Ордера-айсберги: Крупные ордера скрываются разбиением на мелкие части\\n• Когда спред bid-ask сужается, можно ожидать увеличения волатильности'
    },
    example: { 
      tr: '🧱 Uygulama: Satış duvarı kırılırsa sert yukarı hareket gelebilir — duvarı gözlemleyin. Büyük satış emri olan seviyeyi fiyat geçtiğinde, o seviye artık destek olur.',
      en: '🧱 Application: If sell wall breaks, sharp upward movement may come — observe the wall. When price passes a level with large sell orders, that level now becomes support.',
      es: '🧱 Aplicación: Si se rompe el muro de venta, puede venir un movimiento alcista agudo — observa el muro. Cuando el precio pasa un nivel con grandes órdenes de venta, ese nivel ahora se convierte en soporte.',
      fr: '🧱 Application: Si le mur de vente se casse, un mouvement haussier aigu peut venir — observez le mur. Quand le prix passe un niveau avec de gros ordres de vente, ce niveau devient maintenant un support.',
      ru: '🧱 Применение: Если стена продаж ломается, может прийти резкое восходящее движение — наблюдайте за стеной. Когда цена проходит уровень с крупными ордерами на продажу, этот уровень теперь становится поддержкой.'
    },
    icon: <Eye className="w-16 h-16 text-orange-500" />
  },
  {
    title: { 
      tr: 'SMC: Akıllı Para Kavramları — Temel Kavramlar', 
      en: 'SMC: Smart Money Concepts — Basic Concepts', 
      es: 'SMC: Conceptos de Dinero Inteligente — Conceptos Básicos', 
      fr: 'SMC: Concepts d\'Argent Intelligent — Concepts de Base', 
      ru: 'SMC: Концепции умных денег — Основные концепции' 
    },
    content: { 
      tr: '• SMC, kurumsal oyuncuların nasıl düşündüğünü anlamaya çalışır\\n• Öne çıkan öğeler: piyasa yapısı, order block, likidite havuzları, FVG\\n• Kurumsal para "akıllı" davranır: Önce likidite toplar, sonra gerçek yönüne hareket eder\\n• Retail trader\'ların aksine, kurumlar büyük hacimle işlem yapar',
      en: '• SMC tries to understand how institutional players think\\n• Key elements: market structure, order blocks, liquidity pools, FVG\\n• Institutional money behaves "smartly": First accumulates liquidity, then moves in its real direction\\n• Unlike retail traders, institutions trade with large volumes',
      es: '• SMC trata de entender cómo piensan los jugadores institucionales\\n• Elementos clave: estructura de mercado, bloques de órdenes, pools de liquidez, FVG\\n• El dinero institucional se comporta "inteligentemente": Primero acumula liquidez, luego se mueve en su dirección real\\n• A diferencia de los traders minoristas, las instituciones operan con grandes volúmenes',
      fr: '• SMC essaie de comprendre comment pensent les acteurs institutionnels\\n• Éléments clés: structure de marché, blocs d\'ordres, pools de liquidité, FVG\\n• L\'argent institutionnel se comporte "intelligemment": D\'abord accumule la liquidité, puis bouge dans sa vraie direction\\n• Contrairement aux traders de détail, les institutions tradent avec de gros volumes',
      ru: '• SMC пытается понять, как думают институциональные игроки\\n• Ключевые элементы: рыночная структура, блоки ордеров, пулы ликвидности, FVG\\n• Институциональные деньги ведут себя "умно": Сначала накапливают ликвидность, затем движутся в своем реальном направлении\\n• В отличие от розничных трейдеров, институции торгуют большими объемами'
    },
    example: { 
      tr: '🧠 Neden önemli: Kurumsal akımı bilmek daha güvenilir sinyaller verir. Örneğin, kurumlar alım yapmadan önce stop-loss\'ları temizleyebilir.',
      en: '🧠 Why important: Knowing institutional flow gives more reliable signals. For example, institutions may clear stop-losses before making purchases.',
      es: '🧠 Por qué importante: Conocer el flujo institucional da señales más confiables. Por ejemplo, las instituciones pueden limpiar stop-losses antes de hacer compras.',
      fr: '🧠 Pourquoi important: Connaître le flux institutionnel donne des signaux plus fiables. Par exemple, les institutions peuvent nettoyer les stop-losses avant de faire des achats.',
      ru: '🧠 Почему важно: Знание институционального потока дает более надежные сигналы. Например, институции могут очистить стоп-лоссы перед покупками.'
    },
    icon: <Brain className="w-16 h-16 text-indigo-500" />
  },
  {
    title: { 
      tr: 'SMC: Piyasa Yapısı', 
      en: 'SMC: Market Structure', 
      es: 'SMC: Estructura de Mercado', 
      fr: 'SMC: Structure de Marché', 
      ru: 'SMC: Рыночная структура' 
    },
    content: { 
      tr: '• Yükselişte ardışık daha yüksek zirve ve dip, düşüşte ardışık daha düşük zirve ve dip aranır\\n• Yapı kırılması trend değişimi ya da ivme sinyali olabilir\\n• CHoCH (Change of Character): Trend karakterinin değişimi\\n• BOS (Break of Structure): Yapısal kırılım',
      en: '• In uptrend look for consecutive higher highs and lows, in downtrend consecutive lower highs and lows\\n• Structure break can be a trend change or momentum signal\\n• CHoCH (Change of Character): Change in trend character\\n• BOS (Break of Structure): Structural break',
      es: '• En tendencia alcista busca máximos y mínimos consecutivamente más altos, en tendencia bajista máximos y mínimos consecutivamente más bajos\\n• La ruptura de estructura puede ser un cambio de tendencia o señal de momentum\\n• CHoCH (Change of Character): Cambio en el carácter de la tendencia\\n• BOS (Break of Structure): Ruptura estructural',
      fr: '• En tendance haussière cherchez des sommets et creux consécutivement plus hauts, en tendance baissière des sommets et creux consécutivement plus bas\\n• La cassure de structure peut être un changement de tendance ou signal de momentum\\n• CHoCH (Change of Character): Changement dans le caractère de la tendance\\n• BOS (Break of Structure): Cassure structurelle',
      ru: '• В восходящем тренде ищите последовательно более высокие вершины и впадины, в нисходящем тренде последовательно более низкие вершины и впадины\\n• Нарушение структуры может быть сменой тренда или сигналом импульса\\n• CHoCH (Change of Character): Изменение характера тренда\\n• BOS (Break of Structure): Структурный пробой'
    },
    example: { 
      tr: '📈 Uygulama: Yeni düşük dip oluştuysa trend değişimi olasılığını dikkate alın. Yapı kırıldığında eski direnç seviyesi artık destek olabilir.',
      en: '📈 Application: If a new lower low is formed, consider the possibility of trend change. When structure breaks, the old resistance level can now become support.',
      es: '📈 Aplicación: Si se forma un nuevo mínimo más bajo, considera la posibilidad de cambio de tendencia. Cuando la estructura se rompe, el antiguo nivel de resistencia ahora puede convertirse en soporte.',
      fr: '📈 Application: Si un nouveau plus bas est formé, considérez la possibilité de changement de tendance. Quand la structure se casse, l\'ancien niveau de résistance peut maintenant devenir support.',
      ru: '📈 Применение: Если формируется новая низшая впадина, рассмотрите возможность смены тренда. Когда структура ломается, старый уровень сопротивления теперь может стать поддержкой.'
    },
    icon: <TrendingUp className="w-16 h-16 text-green-500" />
  },
  {
    title: { 
      tr: 'SMC: Order Block (Kurumsal Giriş Bölgeleri)', 
      en: 'SMC: Order Block (Institutional Entry Zones)', 
      es: 'SMC: Order Block (Zonas de Entrada Institucional)', 
      fr: 'SMC: Order Block (Zones d\'Entrée Institutionnelle)', 
      ru: 'SMC: Order Block (Институциональные зоны входа)' 
    },
    content: { 
      tr: '• Order block, kurumların yoğun alım/satım yaptığı bölgedir; güçlü destek/direnç olarak çalışır\\n• Order block test edilip tepki verirse retest üzerinden giriş fırsatı doğar\\n• Bullish OB: Önceden güçlü alım yapılan bölge, tekrar test edildiğinde destek olur\\n• Bearish OB: Önceden güçlü satım yapılan bölge, tekrar test edildiğinde direnç olur',
      en: '• Order block is the area where institutions make intensive buying/selling; works as strong support/resistance\\n• If order block is tested and reacts, an entry opportunity emerges through retest\\n• Bullish OB: Previously strong buying area, becomes support when retested\\n• Bearish OB: Previously strong selling area, becomes resistance when retested',
      es: '• Order block es el área donde las instituciones hacen compra/venta intensiva; funciona como soporte/resistencia fuerte\\n• Si order block es probado y reacciona, emerge una oportunidad de entrada a través de retest\\n• Bullish OB: Área de compra previamente fuerte, se convierte en soporte cuando es re-testeada\\n• Bearish OB: Área de venta previamente fuerte, se convierte en resistencia cuando es re-testeada',
      fr: '• Order block est la zone où les institutions font des achats/ventes intensifs; fonctionne comme support/résistance fort\\n• Si order block est testé et réagit, une opportunité d\'entrée émerge à travers retest\\n• Bullish OB: Zone d\'achat précédemment forte, devient support quand retestée\\n• Bearish OB: Zone de vente précédemment forte, devient résistance quand retestée',
      ru: '• Order block - это область, где институции делают интенсивные покупки/продажи; работает как сильная поддержка/сопротивление\\n• Если order block тестируется и реагирует, возникает возможность входа через ретест\\n• Bullish OB: Ранее сильная зона покупок, становится поддержкой при повторном тестировании\\n• Bearish OB: Ранее сильная зона продаж, становится сопротивлением при повторном тестировании'
    },
    example: { 
      tr: '🎯 Pratik: Retest ettiğinde küçük pozisyonla giriş düşünülebilir. Order block içinde fiyat 15-20 dakika kalırsa güçlü tepki olasılığı yüksektir.',
      en: '🎯 Practice: When retesting, entry with small position can be considered. If price stays in order block for 15-20 minutes, high probability of strong reaction.',
      es: '🎯 Práctica: Cuando re-testea, se puede considerar entrada con posición pequeña. Si el precio permanece en order block por 15-20 minutos, alta probabilidad de reacción fuerte.',
      fr: '🎯 Pratique: Lors du retest, l\'entrée avec petite position peut être considérée. Si le prix reste dans order block pendant 15-20 minutes, forte probabilité de réaction forte.',
      ru: '🎯 Практика: При ретесте можно рассмотреть вход небольшой позицией. Если цена остается в order block 15-20 минут, высокая вероятность сильной реакции.'
    },
    icon: <Target className="w-16 h-16 text-red-500" />
  },
  {
    title: { 
      tr: 'SMC: Likidite Havuzları ve Stop-Hunt Mantığı', 
      en: 'SMC: Liquidity Pools and Stop-Hunt Logic', 
      es: 'SMC: Pools de Liquidez y Lógica Stop-Hunt', 
      fr: 'SMC: Pools de Liquidité et Logique Stop-Hunt', 
      ru: 'SMC: Пулы ликвидности и логика стоп-хант' 
    },
    content: { 
      tr: '• Likidite havuzu, traderların stop emirlerinin toplandığı seviyelerdir (eski zirve/dipler)\\n• Kurumlar bazen stop\'ları temizleyip sonra asıl yönüne devam eder (stop-hunt)\\n• Equal highs/lows: Aynı seviyedeki zirveler/dipler, likidite havuzu oluşturur\\n• Likidite sweep: Kısa süreliğine seviyeyi geçip hemen geri dönmek',
      en: '• Liquidity pool is levels where traders\' stop orders accumulate (old highs/lows)\\n• Institutions sometimes clear stops then continue in their real direction (stop-hunt)\\n• Equal highs/lows: Highs/lows at same level create liquidity pools\\n• Liquidity sweep: Briefly passing the level and immediately returning',
      es: '• Pool de liquidez son niveles donde se acumulan las órdenes stop de los traders (máximos/mínimos antiguos)\\n• Las instituciones a veces limpian stops y luego continúan en su dirección real (stop-hunt)\\n• Máximos/mínimos iguales: Máximos/mínimos al mismo nivel crean pools de liquidez\\n• Liquidity sweep: Pasar brevemente el nivel e inmediatamente regresar',
      fr: '• Pool de liquidité sont des niveaux où s\'accumulent les ordres stop des traders (anciens sommets/creux)\\n• Les institutions nettoient parfois les stops puis continuent dans leur vraie direction (stop-hunt)\\n• Sommets/creux égaux: Sommets/creux au même niveau créent des pools de liquidité\\n• Liquidity sweep: Passer brièvement le niveau et immédiatement revenir',
      ru: '• Пул ликвидности - это уровни, где накапливаются стоп-ордера трейдеров (старые максимумы/минимумы)\\n• Институции иногда очищают стопы, затем продолжают в своем реальном направлении (стоп-хант)\\n• Равные максимумы/минимумы: Максимумы/минимумы на одном уровне создают пулы ликвидности\\n• Liquidity sweep: Кратковременное прохождение уровня и немедленный возврат'
    },
    example: { 
      tr: '🎣 Taktik: Stop-hunt sonrası oluşan boşluk ya da retesti bekleyip giriş yapmak daha güvenlidir. Likidite sweep gördüğünüzde ters yöne giriş düşünün.',
      en: '🎣 Tactic: Waiting for gap or retest after stop-hunt and then entering is safer. When you see liquidity sweep, consider entry in opposite direction.',
      es: '🎣 Táctica: Esperar la brecha o retest después de stop-hunt y luego entrar es más seguro. Cuando veas liquidity sweep, considera entrada en dirección opuesta.',
      fr: '🎣 Tactique: Attendre l\'écart ou retest après stop-hunt puis entrer est plus sûr. Quand vous voyez liquidity sweep, considérez entrée dans la direction opposée.',
      ru: '🎣 Тактика: Ожидание гэпа или ретеста после стоп-ханта и затем вход безопаснее. Когда видите liquidity sweep, рассмотрите вход в противоположном направлении.'
    },
    icon: <Zap className="w-16 h-16 text-yellow-500" />
  },
  {
    title: { 
      tr: 'SMC: Fiyat Dengesi Boşlukları (FVG)', 
      en: 'SMC: Fair Value Gaps (FVG)', 
      es: 'SMC: Brechas de Valor Justo (FVG)', 
      fr: 'SMC: Écarts de Valeur Équitable (FVG)', 
      ru: 'SMC: Разрывы справедливой стоимости (FVG)' 
    },
    content: { 
      tr: '• FVG, hızlı fiyat hareketi sonrası oluşan ve tam dengelenmemiş alanlardır; genelde daha sonra retest edilir\\n• Bu bölgeler iyi hedef veya giriş noktası sunabilir\\n• Bullish FVG: Yukarı hareket sırasında oluşan boşluk, destek olarak çalışır\\n• Bearish FVG: Aşağı hareket sırasında oluşan boşluk, direnç olarak çalışır',
      en: '• FVG are areas formed after rapid price movement that are not fully balanced; usually retested later\\n• These areas can offer good target or entry points\\n• Bullish FVG: Gap formed during upward movement, works as support\\n• Bearish FVG: Gap formed during downward movement, works as resistance',
      es: '• FVG son áreas formadas después de movimiento rápido de precio que no están completamente balanceadas; usualmente re-testeadas después\\n• Estas áreas pueden ofrecer buenos puntos de objetivo o entrada\\n• Bullish FVG: Brecha formada durante movimiento alcista, funciona como soporte\\n• Bearish FVG: Brecha formada durante movimiento bajista, funciona como resistencia',
      fr: '• FVG sont des zones formées après mouvement rapide de prix qui ne sont pas complètement équilibrées; généralement retestées plus tard\\n• Ces zones peuvent offrir de bons points d\'objectif ou d\'entrée\\n• Bullish FVG: Écart formé pendant mouvement haussier, fonctionne comme support\\n• Bearish FVG: Écart formé pendant mouvement baissier, fonctionne comme résistance',
      ru: '• FVG - это области, сформированные после быстрого ценового движения, которые не полностью сбалансированы; обычно ретестируются позже\\n• Эти области могут предложить хорошие целевые или входные точки\\n• Bullish FVG: Гэп, сформированный во время восходящего движения, работает как поддержка\\n• Bearish FVG: Гэп, сформированный во время нисходящего движения, работает как сопротивление'
    },
    example: { 
      tr: '⚡ Uygulama: Hızlı mum sonrası FVG\'ye dönüşte (retest) işlem açmak, hacimle teyit edilirse güvenlidir. %50-75 doldurulma genellikle yeterlidir.',
      en: '⚡ Application: Opening trade on FVG retest after rapid candle is safe if confirmed with volume. 50-75% fill is usually sufficient.',
      es: '⚡ Aplicación: Abrir operación en retest de FVG después de vela rápida es seguro si se confirma con volumen. 50-75% de llenado usualmente es suficiente.',
      fr: '⚡ Application: Ouvrir trade sur retest FVG après chandelle rapide est sûr si confirmé avec volume. 50-75% de remplissage est généralement suffisant.',
      ru: '⚡ Применение: Открытие сделки на ретесте FVG после быстрой свечи безопасно, если подтверждено объемом. 50-75% заполнения обычно достаточно.'
    },
    icon: <ArrowUpRight className="w-16 h-16 text-cyan-500" />
  },
  {
    title: { 
      tr: 'SMC: Breaker ve Dengeleme (Mitigation)', 
      en: 'SMC: Breaker and Mitigation', 
      es: 'SMC: Breaker y Mitigación', 
      fr: 'SMC: Breaker et Mitigation', 
      ru: 'SMC: Брейкер и смягчение (Mitigation)' 
    },
    content: { 
      tr: '• Breaker/mitigation, fiyatın önce hızla geçtiği bir bölgenin daha sonra test edilip dengelenmesi olayıdır\\n• Bu test güçlü alım veya satım fırsatı sunabilir; eski order block ile örtüşmesi önemlidir\\n• Mitigation esnasında hacim artışı aranır\\n• Breaker seviyesi genellikle %50-70 arasında test edilir',
      en: '• Breaker/mitigation is when an area that price previously passed through rapidly is later tested and balanced\\n• This test can offer strong buying or selling opportunity; overlap with old order block is important\\n• Volume increase is sought during mitigation\\n• Breaker level is usually tested between 50-70%',
      es: '• Breaker/mitigación es cuando un área que el precio previamente pasó rápidamente es después testeada y balanceada\\n• Esta prueba puede ofrecer fuerte oportunidad de compra o venta; la superposición con old order block es importante\\n• Se busca aumento de volumen durante mitigación\\n• El nivel breaker usualmente es testeado entre 50-70%',
      fr: '• Breaker/mitigation est quand une zone que le prix a précédemment traversée rapidement est plus tard testée et équilibrée\\n• Ce test peut offrir forte opportunité d\'achat ou vente; le chevauchement avec old order block est important\\n• Augmentation de volume est recherchée pendant mitigation\\n• Le niveau breaker est généralement testé entre 50-70%',
      ru: '• Брейкер/смягчение - это когда область, которую цена ранее быстро прошла, позже тестируется и балансируется\\n• Этот тест может предложить сильную возможность покупки или продажи; перекрытие со старым order block важно\\n• Во время смягчения ищется увеличение объема\\n• Уровень брейкера обычно тестируется между 50-70%'
    },
    example: { 
      tr: '🔄 Örnek: Order block kırıldı, geri gelip "temizlendi" ve hızlandı → giriş sinyali. Bu durumda eski direnç artık güçlü destek olur.',
      en: '🔄 Example: Order block broke, came back and was "cleaned" and accelerated → entry signal. In this case, old resistance now becomes strong support.',
      es: '🔄 Ejemplo: Order block se rompió, regresó y fue "limpiado" y aceleró → señal de entrada. En este caso, la antigua resistencia ahora se convierte en soporte fuerte.',
      fr: '🔄 Exemple: Order block s\'est cassé, est revenu et a été "nettoyé" et a accéléré → signal d\'entrée. Dans ce cas, l\'ancienne résistance devient maintenant support fort.',
      ru: '🔄 Пример: Order block сломался, вернулся и был "очищен" и ускорился → сигнал входа. В этом случае старое сопротивление теперь становится сильной поддержкой.'
    },
    icon: <ArrowDownRight className="w-16 h-16 text-orange-500" />
  },
  {
    title: { 
      tr: 'Onay Birliği (Konfluence): SMC + Hacim + Yapı', 
      en: 'Confluence: SMC + Volume + Structure', 
      es: 'Confluencia: SMC + Volumen + Estructura', 
      fr: 'Confluence: SMC + Volume + Structure', 
      ru: 'Конфлюенс: SMC + Объем + Структура' 
    },
    content: { 
      tr: '• Tek sinyale güvenmeyin; order block + hacim artışı + uygun piyasa yapısı = güçlü onay\\n• En az iki teyit (ör. yapı + FVG veya order block + hacim) tercih edin\\n• Zaman uyumu: Farklı analiz yöntemlerinin aynı sonucu vermesi\\n• Güçlü konfluence = yüksek başarı olasılığı',
      en: '• Don\'t rely on single signal; order block + volume increase + appropriate market structure = strong confirmation\\n• Prefer at least two confirmations (e.g. structure + FVG or order block + volume)\\n• Time alignment: Different analysis methods giving same result\\n• Strong confluence = high probability of success',
      es: '• No confíes en señal única; order block + aumento volumen + estructura mercado apropiada = confirmación fuerte\\n• Prefiere al menos dos confirmaciones (ej. estructura + FVG o order block + volumen)\\n• Alineación temporal: Diferentes métodos de análisis dando mismo resultado\\n• Confluencia fuerte = alta probabilidad de éxito',
      fr: '• Ne vous fiez pas à un signal unique; order block + augmentation volume + structure marché appropriée = confirmation forte\\n• Préférez au moins deux confirmations (ex. structure + FVG ou order block + volume)\\n• Alignement temporel: Différentes méthodes d\'analyse donnant même résultat\\n• Confluence forte = forte probabilité de succès',
      ru: '• Не полагайтесь на единственный сигнал; order block + увеличение объема + подходящая рыночная структура = сильное подтверждение\\n• Предпочитайте как минимум два подтверждения (напр. структура + FVG или order block + объем)\\n• Временное выравнивание: Разные методы анализа дают одинаковый результат\\n• Сильный конфлюенс = высокая вероятность успеха'
    },
    example: { 
      tr: '✅ Kural: Konfluence varsa başарı olasılığı artar. Örneğin: FVG + Order Block + Hacim artışı + Yapısal destek = mükemmel giriş fırsatı.',
      en: '✅ Rule: If confluence exists, success probability increases. Example: FVG + Order Block + Volume increase + Structural support = perfect entry opportunity.',
      es: '✅ Regla: Si existe confluencia, la probabilidad de éxito aumenta. Ejemplo: FVG + Order Block + Aumento volumen + Soporte estructural = oportunidad entrada perfecta.',
      fr: '✅ Règle: Si confluence existe, probabilité de succès augmente. Exemple: FVG + Order Block + Augmentation volume + Support structurel = opportunité entrée parfaite.',
      ru: '✅ Правило: Если существует конфлюенс, вероятность успеха увеличивается. Пример: FVG + Order Block + Увеличение объема + Структурная поддержка = идеальная возможность входа.'
    },
    icon: <CheckCircle className="w-16 h-16 text-green-500" />
  },
  {
    title: { 
      tr: 'Dalgalanma Ölçüleri: ATR ve Kırılım İpuçları', 
      en: 'Volatility Measures: ATR and Breakout Clues', 
      es: 'Medidas de Volatilidad: ATR y Pistas de Ruptura', 
      fr: 'Mesures de Volatilité: ATR et Indices de Cassure', 
      ru: 'Меры волатильности: ATR и подсказки прорыва' 
    },
    content: { 
      tr: '• ATR ile piyasanın tipik hareket büyüklüğünü ölçün; stop ve hedef mesafesini buna göre ayarlayın\\n• Bant sıkışması + düşük ATR → kırılım beklenir; SMC ile örtüşürse daha güçlü sinyal\\n• Yüksek ATR dönemlerinde daha geniş stop-loss kullanın\\n• Volatilite patlaması genellikle önemli haber sonrası gelir',
      en: '• Measure market\'s typical movement size with ATR; adjust stop and target distance accordingly\\n• Consolidation + low ATR → breakout expected; stronger signal if overlaps with SMC\\n• Use wider stop-loss during high ATR periods\\n• Volatility explosion usually comes after important news',
      es: '• Mide el tamaño típico de movimiento del mercado con ATR; ajusta distancia stop y objetivo en consecuencia\\n• Consolidación + ATR bajo → ruptura esperada; señal más fuerte si se superpone con SMC\\n• Usa stop-loss más amplio durante períodos de ATR alto\\n• Explosión de volatilidad usualmente viene después de noticias importantes',
      fr: '• Mesurez la taille typique de mouvement du marché avec ATR; ajustez distance stop et objectif en conséquence\\n• Consolidation + ATR bas → cassure attendue; signal plus fort si chevauche avec SMC\\n• Utilisez stop-loss plus large pendant périodes ATR élevé\\n• Explosion de volatilité vient généralement après nouvelles importantes',
      ru: '• Измерьте типичный размер движения рынка с помощью ATR; соответственно настройте расстояние стопа и цели\\n• Консолидация + низкий ATR → ожидается прорыв; более сильный сигнал, если перекрывается с SMC\\n• Используйте более широкий стоп-лосс в периоды высокого ATR\\n• Взрыв волатильности обычно приходит после важных новостей'
    },
    example: { 
      tr: '📊 Uygulama: ATR\'e göре stop\'u piyasaya göre dinamik ayarlayın. ATR=50 ise stop mesafesi ~75-100 pips olabilir (ATR\'nin 1.5-2 katı).',
      en: '📊 Application: Adjust stop dynamically according to market based on ATR. If ATR=50, stop distance can be ~75-100 pips (1.5-2x ATR).',
      es: '📊 Aplicación: Ajusta stop dinámicamente según mercado basado en ATR. Si ATR=50, distancia stop puede ser ~75-100 pips (1.5-2x ATR).',
      fr: '📊 Application: Ajustez stop dynamiquement selon marché basé sur ATR. Si ATR=50, distance stop peut être ~75-100 pips (1.5-2x ATR).',
      ru: '📊 Применение: Настройте стоп динамически согласно рынку на основе ATR. Если ATR=50, расстояние стопа может быть ~75-100 пипсов (1.5-2x ATR).'
    },
    icon: <Activity className="w-16 h-16 text-blue-500" />
  },
  {
    title: { 
      tr: 'Geçmiş Testleri ve İleriye Doğru Test (Backtest & Walk-Forward)', 
      en: 'Backtesting and Walk-Forward Testing', 
      es: 'Backtesting y Testing Walk-Forward', 
      fr: 'Backtesting et Test Walk-Forward', 
      ru: 'Бэктестинг и Walk-Forward тестирование' 
    },
    content: { 
      tr: '• Stratejinizi geçmiş veride test edin; aşırı uyumdan (overfitting) kaçının\\n• Walk-forward testi ile stratejinin değişen piyasa koşullarında dayanıklılığını kontrol edin\\n• En az 200-300 işlem verisi üzerinde test yapın\\n• Maksimum drawdown ve ortalama zarar oranlarını takip edin',
      en: '• Test your strategy on historical data; avoid overfitting\\n• Check strategy resilience in changing market conditions with walk-forward testing\\n• Test on at least 200-300 trade data\\n• Track maximum drawdown and average loss ratios',
      es: '• Prueba tu estrategia en datos históricos; evita sobreajuste\\n• Verifica resistencia de estrategia en condiciones de mercado cambiantes con testing walk-forward\\n• Prueba en al menos 200-300 datos de operaciones\\n• Rastrea drawdown máximo y ratios de pérdida promedio',
      fr: '• Testez votre stratégie sur données historiques; évitez surapprentissage\\n• Vérifiez résilience stratégie dans conditions marché changeantes avec test walk-forward\\n• Testez sur au moins 200-300 données de trades\\n• Suivez drawdown maximum et ratios perte moyenne',
      ru: '• Тестируйте свою стратегию на исторических данных; избегайте переобучения\\n• Проверьте устойчивость стратегии в изменяющихся рыночных условиях с помощью walk-forward тестирования\\n• Тестируйте на минимум 200-300 торговых данных\\n• Отслеживайте максимальную просадку и средние коэффициенты потерь'
    },
    example: { 
      tr: '🧪 İpucu: Basit, iyi test edilmiş strateji genelde karmaşık ama overfit olandan üstündür. %60 kazanç oranı + 1:2 risk/ödül = karlı sistem.',
      en: '🧪 Tip: Simple, well-tested strategy is generally superior to complex but overfit one. 60% win rate + 1:2 risk/reward = profitable system.',
      es: '🧪 Consejo: Estrategia simple y bien probada es generalmente superior a una compleja pero sobreajustada. 60% tasa ganancia + 1:2 riesgo/recompensa = sistema rentable.',
      fr: '🧪 Conseil: Stratégie simple et bien testée est généralement supérieure à une complexe mais surajustée. 60% taux gain + 1:2 risque/récompense = système rentable.',
      ru: '🧪 Совет: Простая, хорошо протестированная стратегия обычно превосходит сложную, но переобученную. 60% коэффициент выигрыша + 1:2 риск/вознаграждение = прибыльная система.'
    },
    icon: <Settings className="w-16 h-16 text-gray-500" />
  },
  {
    title: { 
      tr: 'İşlem Yönetimi: Giriş, Kademeli Çıkış ve Hedef Belirleme', 
      en: 'Trade Management: Entry, Scaling Out and Target Setting', 
      es: 'Gestión de Operaciones: Entrada, Salida Escalonada y Establecimiento de Objetivos', 
      fr: 'Gestion des Trades: Entrée, Sortie Échelonnée et Définition d\'Objectifs', 
      ru: 'Управление сделками: Вход, поэтапный выход и установка целей' 
    },
    content: { 
      tr: '• Giriş: SMC retest + hacim + yapı onayıyla küçük pozisyon açın\\n• Kademeli çıkış (scaling out) ile kârı parça parça alın; risk yönetimini güçlendirin\\n• Hedef: FVG, bir sonraki yapısal seviye veya belirlenen risk/ödül oranı\\n• Trailing stop kullanarak kârı koruyun',
      en: '• Entry: Open small position with SMC retest + volume + structure confirmation\\n• Take profit piece by piece with scaling out; strengthen risk management\\n• Target: FVG, next structural level or determined risk/reward ratio\\n• Protect profit using trailing stop',
      es: '• Entrada: Abre posición pequeña con retest SMC + volumen + confirmación estructura\\n• Toma ganancias pieza por pieza con salida escalonada; fortalece gestión de riesgos\\n• Objetivo: FVG, siguiente nivel estructural o ratio riesgo/recompensa determinado\\n• Protege ganancia usando trailing stop',
      fr: '• Entrée: Ouvrez petite position avec retest SMC + volume + confirmation structure\\n• Prenez profits morceau par morceau avec sortie échelonnée; renforcez gestion risques\\n• Objectif: FVG, niveau structurel suivant ou ratio risque/récompense déterminé\\n• Protégez profit en utilisant trailing stop',
      ru: '• Вход: Откройте небольшую позицию с ретестом SMC + объем + подтверждение структуры\\n• Берите прибыль по частям с поэтапным выходом; укрепите управление рисками\\n• Цель: FVG, следующий структурный уровень или определенное соотношение риск/вознаграждение\\n• Защитите прибыль, используя трейлинг стоп'
    },
    example: { 
      tr: '💼 Özet: Planlı girin, kurallara sadık kalın, mantıklı stop ve hedef kullanın. %50 poziyon 1:1\'de, %50 poziyon 1:3\'te kapatmak iyi stratejidir.',
      en: '💼 Summary: Enter planned, stay loyal to rules, use logical stop and target. Closing 50% position at 1:1, 50% position at 1:3 is good strategy.',
      es: '💼 Resumen: Entra planificado, mantente leal a las reglas, usa stop y objetivo lógicos. Cerrar 50% posición en 1:1, 50% posición en 1:3 es buena estrategia.',
      fr: '💼 Résumé: Entrez planifié, restez loyal aux règles, utilisez stop et objectif logiques. Fermer 50% position à 1:1, 50% position à 1:3 est bonne stratégie.',
      ru: '💼 Резюме: Входите по плану, оставайтесь верными правилам, используйте логичные стоп и цель. Закрытие 50% позиции на 1:1, 50% позиции на 1:3 - хорошая стратегия.'
    },
    icon: <LineChart className="w-16 h-16 text-purple-500" />
  },
  {
    title: { 
      tr: 'Sonuç: Basitten İleriye, Onay Birliği ile Güçlen', 
      en: 'Conclusion: From Simple to Advanced, Strengthen with Confluence', 
      es: 'Conclusión: De Simple a Avanzado, Fortalece con Confluencia', 
      fr: 'Conclusion: Du Simple à l\'Avancé, Renforcez avec Confluence', 
      ru: 'Заключение: От простого к продвинутому, укрепите конфлюенсом' 
    },
    content: { 
      tr: '• SMC ile kurumsal davranışı anlamak ileri analizde büyük avantaj sağlar\\n• Her zaman en az iki teyit arayın (ör. yapı + likidite veya order block + hacim)\\n• Küçük adımlarla, test ederek, defalarca uygulayarak ustalaşın\\n• Sabırlı olun: İyi kurulum beklemek, kötü kurulumda işlem yapmaktan iyidir',
      en: '• Understanding institutional behavior with SMC provides great advantage in advanced analysis\\n• Always look for at least two confirmations (e.g. structure + liquidity or order block + volume)\\n• Master with small steps, testing, and repeated application\\n• Be patient: Waiting for good setup is better than trading in bad setup',
      es: '• Entender el comportamiento institucional con SMC proporciona gran ventaja en análisis avanzado\\n• Siempre busca al menos dos confirmaciones (ej. estructura + liquidez o order block + volumen)\\n• Domina con pasos pequeños, probando y aplicación repetida\\n• Sé paciente: Esperar buen setup es mejor que operar en mal setup',
      fr: '• Comprendre le comportement institutionnel avec SMC fournit grand avantage dans analyse avancée\\n• Cherchez toujours au moins deux confirmations (ex. structure + liquidité ou order block + volume)\\n• Maîtrisez avec petits pas, test et application répétée\\n• Soyez patient: Attendre bon setup est mieux que trader dans mauvais setup',
      ru: '• Понимание институционального поведения с SMC обеспечивает большое преимущество в продвинутом анализе\\n• Всегда ищите как минимум два подтверждения (напр. структура + ликвидность или order block + объем)\\n• Овладевайте маленькими шагами, тестированием и повторным применением\\n• Будьте терпеливы: Ожидание хорошей установки лучше, чем торговля в плохой установке'
    },
    example: { 
      tr: '🎯 Son söz: İleri teknik analiz bir araçtır, sihir değil. Tutarlı uygulama + risk yönetimi + sabır = uzun vadeli başarı formülü.',
      en: '🎯 Final word: Advanced technical analysis is a tool, not magic. Consistent application + risk management + patience = long-term success formula.',
      es: '🎯 Palabra final: El análisis técnico avanzado es una herramienta, no magia. Aplicación consistente + gestión de riesgos + paciencia = fórmula de éxito a largo plazo.',
      fr: '🎯 Mot final: L\'analyse technique avancée est un outil, pas de la magie. Application cohérente + gestion des risques + patience = formule de succès à long terme.',
      ru: '🎯 Последнее слово: Продвинутый технический анализ - это инструмент, а не магия. Последовательное применение + управление рисками + терпение = формула долгосрочного успеха.'
    },
    icon: <TrendingUp className="w-16 h-16 text-emerald-500" />
  }
]