import React, { useState } from 'react'
import { 
  ArrowLeft, BookOpen, Star, Users, Trophy, CheckCircle, 
  ChevronRight, ChevronLeft, Lightbulb, Brain, TrendingUp, 
  Coffee, BarChart3, DollarSign, Target, Play, Clock,
  LineChart, Coins, ShieldCheck, Heart, Zap, AlertTriangle
} from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from './ui/card'
import { Button } from './ui/button'
import { Badge } from './ui/badge'
import { Progress } from './ui/progress'
import { Separator } from './ui/separator'
import { useLanguage } from './useLanguage'
import { Course } from './courseData'
import { technicalAnalysisSlides } from './TechnicalAnalysisSlides'
import { fundamentalAnalysisSlides, fundamentalAnalysisQuiz } from './FundamentalAnalysisSlides'
import { financialMarketsSlides, financialMarketsQuiz } from './FinancialMarketsSlides'
import { riskManagementSlides } from './RiskManagementSlides'
import { tradingPsychologySlides } from './TradingPsychologySlides'
import { economicsSlides } from './EconomicsSlides'
import { algorithmicTradingSlides, algorithmicTradingQuiz } from './AlgorithmicTradingSlides'
import { DerivativesMarketsSlides } from './DerivativesMarketsSlides'
import { personalFinanceSlides, personalFinanceQuiz } from './PersonalFinanceSlides'
import { riskManagementQuiz } from './RiskManagementSlides'
import { tradingPsychologyQuiz } from './TradingPsychologySlides'
import { advancedTechnicalAnalysisSlides } from './AdvancedTechnicalAnalysisSlides'


interface CourseDetailProps {
  course: Course
  onBack: () => void
}

export function CourseDetail({ course, onBack }: CourseDetailProps) {
  const { language, t } = useLanguage()
  const [currentSlide, setCurrentSlide] = useState(0)
  const [isLearning, setIsLearning] = useState(false)
  const [slidesCompleted, setSlidesCompleted] = useState(false)
  const [quizAnswers, setQuizAnswers] = useState<{[key: number]: number}>({})
  const [showResults, setShowResults] = useState(false)

  // Helper function to safely get language-specific content with fallback
  const getLocalizedContent = (content: any, lang: string) => {
    if (!content) return []
    // Try requested language, then fallback to Turkish, English, then empty array
    return content[lang] || content['tr'] || content['en'] || []
  }

  const getLocalizedText = (content: any, lang: string) => {
    if (!content) return ''
    // Try requested language, then fallback to Turkish, English, then empty string
    return content[lang] || content['tr'] || content['en'] || ''
  }

  const getLevelColor = (level: string) => {
    switch (level.toLowerCase()) {
      case 'beginner': return 'bg-green-100 text-green-800 border-green-200'
      case 'intermediate': return 'bg-yellow-100 text-yellow-800 border-yellow-200'
      case 'advanced': return 'bg-red-100 text-red-800 border-red-200'
      default: return 'bg-gray-100 text-gray-800 border-gray-200'
    }
  }
  
  const getLevelText = (level: string) => {
    switch (level.toLowerCase()) {
      case 'beginner': return t('level.beginner')
      case 'intermediate': return t('level.intermediate')
      case 'advanced': return t('level.advanced')
      default: return level
    }
  }

  const getCourseIcon = (category: string, size: 'small' | 'large' = 'small') => {
    const iconSize = size === 'large' ? 'w-16 h-16' : 'w-8 h-8'
    const iconColor = 'text-white'
    
    switch (category) {
      case 'Economics':
        return <TrendingUp className={`${iconSize} ${iconColor}`} />
      case 'Technical Analysis':
      case 'Analysis':
        return <BarChart3 className={`${iconSize} ${iconColor}`} />
      case 'Risk Management':
      case 'Risk':
        return <ShieldCheck className={`${iconSize} ${iconColor}`} />
      case 'Trading Psychology':
      case 'Psychology':
        return <Brain className={`${iconSize} ${iconColor}`} />
      case 'Algorithmic Trading':
      case 'Algorithmic':
        return <Zap className={`${iconSize} ${iconColor}`} />
      case 'Personal Finance':
        return <Coins className={`${iconSize} ${iconColor}`} />
      case 'Financial Markets':
      case 'Markets':
        return <LineChart className={`${iconSize} ${iconColor}`} />
      case 'Fundamental Analysis':
      case 'Fundamental':
        return <Target className={`${iconSize} ${iconColor}`} />
      case 'Derivatives':
        return <DollarSign className={`${iconSize} ${iconColor}`} />
      default:
        return <BookOpen className={`${iconSize} ${iconColor}`} />
    }
  }

  // Educational slides for different course categories
  const getEducationSlides = (category: string) => {
    const slides: { [key: string]: any[] } = {
      'Economics': [
        {
          title: { 
            tr: 'Ekonomi Nedir?', 
            en: 'What is Economics?', 
            es: '¿Qué es la Economía?', 
            fr: 'Qu\'est-ce que l\'Économie?', 
            ru: 'Что такое экономика?' 
          },
          content: { 
            tr: '• Sınırlı kaynakların (para, zaman, doğal kaynaklar) sınırsız ihtiyaçları karşılamak için nasıl üretildiği, dağıtıldığı ve tüketildiğini inceleyen bilim dalı\n• Temel sorun: Kıtlık nedeniyle sürekli seçim yapmak zorundayız\n• Fırsat maliyeti: Bir şeyi seçmek, başka bir şeyden vazgeçmek demektir\n• Önemi: Bireysel kararları ve toplumsal politikaları yönlendirir, refahı artırır',
            en: '• Science studying how limited resources (money, time, natural resources) are produced, distributed and consumed to meet unlimited human needs\n• Basic problem: Due to scarcity we constantly have to make choices\n• Opportunity cost: Choosing one thing means giving up another\n• Importance: Guides individual decisions and social policies, increases welfare',
            es: '• Ciencia que estudia cómo se producen, distribuyen y consumen los recursos limitados (dinero, tiempo, recursos naturales) para satisfacer necesidades humanas ilimitadas\n• Problema básico: Debido a la escasez constantemente tenemos que elegir\n• Costo de oportunidad: Elegir una cosa significa renunciar a otra\n• Importancia: Guía decisiones individuales y políticas sociales, aumenta el bienestar',
            fr: '• Science étudiant comment les ressources limitées (argent, temps, ressources naturelles) sont produites, distribuées et consommées pour répondre aux besoins humains illimités\n• Problème de base: En raison de la rareté, nous devons constamment faire des choix\n• Coût d\'opportunité: Choisir une chose signifie renoncer à une autre\n• Importance: Guide les décisions individuelles et les politiques sociales, augmente le bien-être',
            ru: '• Наука, изучающая как ограниченные ресурсы (деньги, время, природные ресурсы) производятся, распределяются и потребляются для удовлетворения безграничных человеческих потреб��остей\n• Основная проблема: Из-за дефицита мы постоянно должны делать выбор\n• Альтернативные издержки: Выбор одного означает отказ от другого\n• Важность: Направляет индивидуальные решения и социальную политику, повышает благосостояние'
          },
          example: { 
            tr: '📊 2025\'te global kaynak kıtlığı enerji fiyatlarını %10 artırdı; ülkeler yenilenebilir enerjiye yönelerek refahı korudu (IMF verileri).',
            en: '📊 In 2025, global resource scarcity increased energy prices by 10%; countries preserved welfare by turning to renewable energy (IMF data).',
            es: '📊 En 2025, la escasez global de recursos aumentó los precios de la energía en 10%; los países preservaron el bienestar dirigiéndose a la energía renovable (datos del FMI).',
            fr: '📊 En 2025, la rareté mondiale des ressources a augmenté les prix de l\'énergie de 10%; les pays ont préservé le bien-être en se tournant vers l\'énergie renouvelable (données du FMI).',
            ru: '📊 В 2025 году глобальная нехватка ресурсов повысила цены на энергию на 10%; страны сохранили благосостояние, обратившись к возобновляемой энергии (данные МВФ).'
          },
          icon: <Lightbulb className="w-16 h-16 text-yellow-500" />
        },
        {
          title: { 
            tr: 'Mikroekonomi vs Makroekonomi', 
            en: 'Microeconomics vs Macroeconomics', 
            es: 'Microeconomía vs Macroeconomía', 
            fr: 'Microéconomie vs Macroéconomie', 
            ru: 'Микроэкономика против макроэкономики' 
          },
          content: { 
            tr: '• Mikroekonomi: Bireylerin ve firmaların küçük ölçekli kararlarını analiz eder\n• Makroekonomi: Tüm ekonomiyi kapsar, GDP, enflasyon, işsizlik gibi büyük göstergeleri inceler\n• Temel fark: Mikro bireysel tercihlere odaklanır, makro bu tercihlerin toplamda ekonomiyi nasıl şekillendirdiğini gösterir\n• Etkileşim: Mikro seviyedeki değişiklikler makro ekonomiyi etkiler',
            en: '• Microeconomics: Analyzes small-scale decisions of individuals and firms\n• Macroeconomics: Covers the entire economy, examines big indicators like GDP, inflation, unemployment\n• Key difference: Micro focuses on individual preferences, macro shows how these preferences shape the economy overall\n• Interaction: Micro-level changes affect the macro economy',
            es: '• Microeconomía: Analiza decisiones a pequeña escala de individuos y empresas\n• Macroeconomía: Cubre toda la economía, examina grandes indicadores como PIB, inflación, desempleo\n• Diferencia clave: Micro se enfoca en preferencias individuales, macro muestra cómo estas preferencias moldean la economía en general\n• Interacción: Los cambios a nivel micro afectan la macroeconomía',
            fr: '• Microéconomie: Analyse les décisions à petite échelle des individus et des entreprises\n• Macroéconomie: Couvre toute l\'économie, examine de grands indicateurs comme PIB, inflation, chômage\n• Différence clé: Micro se concentre sur les préférences individuelles, macro montre comment ces préférences façonnent l\'économie globale\n• Interaction: Les changements au niveau micro affectent la macroéconomie',
            ru: '• Микроэкономика: Анализирует мелкомасштабные решения отдельных лиц и фирм\n• Макроэкономика: Охватывает всю экономику, изучает крупные показатели, такие как ВВП, инфляция, безработица\n• Ключевое различие: Микро фокусируется на индивидуальных предпочтениях, макро показывает, как эти предпочтения формируют экономику в целом\n• Взаимодействие: Изменения на микроуровне влияют на макроэкономику'
          },
          example: { 
            tr: '🔍 2025\'te mikro düzeyde bir firmanın fiyat artışı, makro düzeyde ABD enflasyonunu %0.5 etkiledi; Fed politikalarıyla dengelendi.',
            en: '🔍 In 2025, a firm\'s price increase at micro level affected US inflation by 0.5% at macro level; balanced with Fed policies.',
            es: '🔍 En 2025, el aumento de precio de una empresa a nivel micro afectó la inflación de EE.UU. en 0.5% a nivel macro; equilibrado con políticas de la Fed.',
            fr: '🔍 En 2025, l\'augmentation des prix d\'une entreprise au niveau micro a affecté l\'inflation américaine de 0,5% au niveau macro; équilibré avec les politiques de la Fed.',
            ru: '🔍 В 2025 году повышение цен фирмы на микроуровне повлияло на инфляцию в США на 0,5% на макроуровне; сбалансировано политикой ФРС.'
          },
          icon: <TrendingUp className="w-16 h-16 text-purple-500" />
        },
        {
          title: { 
            tr: 'Arz ve Talep Yasası', 
            en: 'Law of Supply and Demand', 
            es: 'Ley de Oferta y Demanda', 
            fr: 'Loi de l\'Offre et de la Demande', 
            ru: 'Закон спроса и предложения' 
          },
          content: { 
            tr: '• Talep yasası: Fiyat düştükçe tüketiciler daha fazla mal ister (daha erişilebilir hale gelir)\n• Arz yasası: Fiyat arttıkça üreticiler daha fazla mal sunar (kar marjı yükselir)\n• Denge noktası: Arz ve talebin eşitlendiği fiyat seviyesi\n• Piyasa stabilitesi: Denge noktasında piyasa en stabil durumda olur',
            en: 'Demand law: As price falls, consumers want more goods because they become more accessible. Supply law: As price rises, producers offer more goods because profit margin increases. Equilibrium point: Price level where supply and demand equalize; market becomes stable here.',
            es: 'Ley de demanda: Cuando el precio baja, los consumidores quieren más bienes porque se vuelven más accesibles. Ley de oferta: Cuando el precio sube, los productores ofrecen más bienes porque aumenta el margen de beneficio. Punto de equilibrio: Nivel de precio donde se igualan oferta y demanda; el mercado se vuelve estable aquí.',
            fr: 'Loi de la demande: Lorsque le prix baisse, les consommateurs veulent plus de biens car ils deviennent plus accessibles. Loi de l\'offre: Lorsque le prix augmente, les producteurs offrent plus de biens car la marge bénéficiaire augmente. Point d\'équilibre: Niveau de prix où l\'offre et la demande s\'égalisent; le marché devient stable ici.',
            ru: 'Закон спроса: По мере падения цены потребители хотят больше товаров, поскольку они становятся более доступными. Закон предложения: По мере роста цены производители предлагают больше товаров, поскольку увеличивается маржа прибыли. Точка равновесия: Уровень цен, где предложение и спрос уравновешиваются; рынок становится стабильным здесь.'
          },
          example: { 
            tr: '⛽ 2025\'te petrol talebi arttığında fiyatlar %15 yükseldi; OPEC arzı artırarak denge sağladı, global ekonomiyi stabilize etti.',
            en: '⛽ In 2025, when oil demand increased, prices rose 15%; OPEC stabilized the global economy by increasing supply and achieving balance.',
            es: '⛽ En 2025, cuando aumentó la demanda de petróleo, los precios subieron 15%; OPEP estabilizó la economía global aumentando la oferta y logrando equilibrio.',
            fr: '⛽ En 2025, lorsque la demande de pétrole a augmenté, les prix ont augmenté de 15%; l\'OPEP a stabilisé l\'économie mondiale en augmentant l\'offre et en réalisant l\'équilibre.',
            ru: '⛽ В 2025 году, когда спрос на нефть увеличился, цены выросли на 15%; ОПЕК стабилизировал мировую экономику, увеличив предложение и достигнув баланса.'
          },
          icon: <BarChart3 className="w-16 h-16 text-blue-500" />
        },
        {
          title: { 
            tr: 'Piyasa Dengesi ve Değişimler', 
            en: 'Market Equilibrium and Changes', 
            es: 'Equilibrio de Mercado y Cambios', 
            fr: 'Équilibre de Marché et Changements', 
            ru: 'Рыночное равновесие и изменения' 
          },
          content: { 
            tr: 'Denge fiyatı: Malın arz edildiği kadar talep edildiği nokta; burada alıcı ve satıcılar memnun olur. Değişim etkileri: Talep artışı fiyatı yükseltir; arz artışı fiyatı düşürür. Müdahaleler: Hükümetin fiyat tavanı koyması kıtlık yaratabilir, taban fiyatı ise fazla stok.',
            en: 'Equilibrium price: Point where goods are demanded as much as supplied; buyers and sellers are satisfied here. Change effects: Demand increase raises price; supply increase lowers price. Interventions: Government price ceiling can create shortage, price floor creates surplus.',
            es: 'Precio de equilibrio: Punto donde los bienes se demandan tanto como se ofrecen; compradores y vendedores están satisfechos aquí. Efectos de cambio: El aumento de demanda eleva el precio; el aumento de oferta baja el precio. Intervenciones: El techo de precios del gobierno puede crear escasez, el precio mínimo crea excedente.',
            fr: 'Prix d\'équilibre: Point où les biens sont demandés autant qu\'ils sont offerts; acheteurs et vendeurs sont satisfaits ici. Effets de changement: L\'augmentation de la demande élève le prix; l\'augmentation de l\'offre baisse le prix. Interventions: Le plafond de prix du gouvernement peut créer une pénurie, le prix plancher crée un surplus.',
            ru: 'Равновесная цена: Точка, где товары требуются столько же, сколько поставляются; покупатели и пр��давцы довольны здесь. Эффекты изменений: Увеличение спроса повышает цену; увеличение предложения понижает цену. Вмешательства: Государственный потолок цен может создать дефицит, минимальная цена создает избыток.'
          },
          example: { 
            tr: '🍞 2025\'te gıda arzı azalınca fiyatlar %8 arttı; hükümet stokları serbest bırakarak dengeyi yeniden kurdu.',
            en: '🍞 In 2025, when food supply decreased, prices increased 8%; government restored balance by releasing stocks.',
            es: '🍞 En 2025, cuando disminuyó la oferta de alimentos, los precios aumentaron 8%; el gobierno restauró el equilibrio liberando existencias.',
            fr: '🍞 En 2025, lorsque l\'offre alimentaire a diminué, les prix ont augmenté de 8%; le gouvernement a restauré l\'équilibre en libérant les stocks.',
            ru: '🍞 В 2025 году, когда предложение продовольствия сократилось, цены выросли на 8%; правительство восстановило баланс, выпустив запасы.'
          },
          icon: <Target className="w-16 h-16 text-green-500" />
        },
        {
          title: { 
            tr: 'Elastikiyet Kavramı', 
            en: 'Concept of Elasticity', 
            es: 'Concepto de Elasticidad', 
            fr: 'Concept d\'Élasticité', 
            ru: 'Концепция эластичности' 
          },
          content: { 
            tr: 'Fiyat elastikiyeti: Fiyat %10 artınca talep ne kadar değişir? Elastik (>1) ise talep çok düşer (lüks mallar); inelastik (<1) ise az düşer (zorunlu mallar). Hesaplama: Yüzde değişim oranıyla ölçülür; firmalar fiyat stratejisi için kullanır. Vergi politikalarında inelastic mallar daha fazla vergi alır.',
            en: 'Price elasticity: How much does demand change when price increases 10%? If elastic (>1) demand drops a lot (luxury goods); if inelastic (<1) drops little (necessity goods). Calculation: Measured by percentage change rate; firms use for pricing strategy. In tax policy, inelastic goods receive more tax.',
            es: 'Elasticidad precio: ¿Cuánto cambia la demanda cuando el precio aumenta 10%? Si es elástica (>1) la demanda baja mucho (bienes de lujo); si es inelástica (<1) baja poco (bienes necesarios). Cálculo: Se mide por tasa de cambio porcentual; las empresas la usan para estrategia de precios. En política fiscal, los bienes inelásticos reciben más impuestos.',
            fr: 'Élasticité prix: Combien la demande change-t-elle quand le prix augmente de 10%? Si élastique (>1) la demande chute beaucoup (biens de luxe); si inélastique (<1) chute peu (biens nécessaires). Calcul: Mesuré par taux de changement en pourcentage; les entreprises l\'utilisent pour la stratégie de prix. En politique fiscale, les biens inélastiques reçoivent plus d\'impôts.',
            ru: 'Ценовая эластичность: Насколько изменяется спрос при увеличении цены на 10%? Если эластичный (>1), спрос сильно падает (предметы роскоши); если неэластичный (<1), падает мало (товары первой необходимости). Расчет: Измеряется процентной скоростью изменения; фирмы используют для ценовой стратегии. В нало��овой политике неэластичные товары получают больше налогов.'
          },
          example: { 
            tr: '⛽ 2025\'te benzin fiyatı %10 artınca talep %5 düştü (inelastik); elektrikli araç talebi elastik kaldı, %20 arttı.',
            en: '⛽ In 2025, when gasoline price increased 10%, demand dropped 5% (inelastic); electric vehicle demand remained elastic, increased 20%.',
            es: '⛽ En 2025, cuando el precio de la gasolina aumentó 10%, la demanda bajó 5% (inelástica); la demanda de vehículos eléctricos se mantuvo elástica, aumentó 20%.',
            fr: '⛽ En 2025, lorsque le prix de l\'essence a augmenté de 10%, la demande a chuté de 5% (inélastique); la demande de véhicules électriques est restée élastique, a augmenté de 20%.',
            ru: '⛽ В 2025 году, когда цена на бензин выросла на 10%, с��рос упал на 5% (неэластичный); спрос на электромобили остался эластичным, выр��с на 20%.'
          },
          icon: <LineChart className="w-16 h-16 text-orange-500" />
        },
        {
          title: { 
            tr: 'Üretim Maliyetleri ve Karar Alma', 
            en: 'Production Costs and Decision Making', 
            es: 'Costos de Producción y Toma de Decisiones', 
            fr: 'Coûts de Production et Prise de Décision', 
            ru: 'Производственные затраты и принятие решений' 
          },
          content: { 
            tr: 'Maliyet türleri: Sabit maliyetler üretimden bağımsızdır (fabrika kirası), değişkenler üretime göre değişir (hammadde). Marjinal maliyet: Bir birim daha üretmek için eklenen maliyet; firmalar karı maksimize etmek için marjinal gelire eşitler. Ölçek ekonomisi: Üretim arttıkça birim maliyet düşer.',
            en: 'Cost types: Fixed costs are independent of production (factory rent), variables change according to production (raw materials). Marginal cost: Added cost to produce one more unit; firms equalize to marginal revenue to maximize profit. Economies of scale: Unit cost decreases as production increases.',
            es: 'Tipos de costos: Los costos fijos son independientes de la producción (alquiler de fábrica), las variables cambian según la producción (materias primas). Costo marginal: Costo agregado para producir una unidad más; las empresas igualan al ingreso marginal para maximizar ganancias. Economías de escala: El costo unitario disminuye a medida que aumenta la producción.',
            fr: 'Types de coûts: Les coûts fixes sont indépendants de la production (loyer d\'usine), les variables changent selon la production (matières premières). Coût marginal: Coût ajouté pour produire une unité de plus; les entreprises égalisent au revenu marginal pour maximiser le profit. Économies d\'échelle: Le coût unitaire diminue à mesure que la production augmente.',
            ru: 'Типы затрат: Постоянные затраты не зависят от производства (аренда завода), переменные изменяются в зависимости от производства (сырье). Предельные затраты: Добавленные затраты на производство еще одной единицы; фирмы приравнивают к предельному доходу для максимизации прибыли. Эффект масштаба: Себестоимость единицы снижается по мере увеличения производства.'
          },
          example: { 
            tr: '🏭 2025\'te bir teknoloji firması ölçek ekonomisiyle maliyetleri %15 düşürdü; rekabet gücünü artırdı.',
            en: '🏭 In 2025, a technology firm reduced costs by 15% through economies of scale; increased competitiveness.',
            es: '🏭 En 2025, una empresa tecnológica redujo costos en 15% a través de economías de escala; aumentó la competitividad.',
            fr: '🏭 En 2025, une entreprise technologique a réduit les coûts de 15% grâce aux économies d\'échelle; a augmenté la compétitivité.',
            ru: '🏭 В 2025 году технологическая фирма снизила затраты на 15% за счет эффекта масштаба; повысила конкурентоспособность.'
          },
          icon: <DollarSign className="w-16 h-16 text-green-500" />
        },
        {
          title: { 
            tr: 'Piyasa Yapıları', 
            en: 'Market Structures', 
            es: 'Estructuras de Mercado', 
            fr: 'Structures de Marché', 
            ru: 'Рыночные структуры' 
          },
          content: { 
            tr: 'Tam rekabet: Çok sayıda küçük firma, aynı ürün; fiyatlar düşük tutulur. Monopol: Tek firma hakim, fiyatı belirler; yenilik teşvik eder ama pahalıya mal olur. Oligopol: Az firma, birbirlerini izler; fiyat savaşları veya anlaşmalar olur – stratejik kararlar alırlar.',
            en: 'Perfect competition: Many small firms, same product; prices kept low. Monopoly: Single dominant firm, sets price; encourages innovation but costly for consumers. Oligopoly: Few firms, monitor each other; price wars or agreements occur – they make strategic decisions.',
            es: 'Competencia perfecta: Muchas empresas pequeñas, mismo producto; precios mantenidos bajos. Monopolio: Empresa dominante única, establece precio; fomenta innovación pero costoso para consumidores. Oligopolio: Pocas empresas, se monitorean entre sí; ocurren guerras de precios o acuerdos – toman decisiones estratégicas.',
            fr: 'Concurrence parfaite: Beaucoup de petites entreprises, même produit; prix maintenus bas. Monopole: Entreprise dominante unique, fixe le prix; encourage l\'innovation mais coûteux pour les consommateurs. Oligopole: Peu d\'entreprises, se surveillent mutuellement; guerres de prix ou accords se produisent – elles prennent des décisions stratégiques.',
            ru: 'Совершенная конкуренция: Много мелких фирм, одинаковый продукт; цены держатся низкими. Монополия: Единственная доминирующая фирма, устанавливает цену; поощряет инновации, но дорого для п��требителей. Олигополия: Несколько фирм, следят друг за другом; происходят ценовые войны или со��лашения – они принимают стратегические решения.'
          },
          example: { 
            tr: '📱 2025\'te teknoloji oligopolünde (Apple, Google) fiyat savaşları tüketiciye %10 indirim getirdi.',
            en: '📱 In 2025, price wars in technology oligopoly (Apple, Google) brought 10% discount to consumers.',
            es: '📱 En 2025, las guerras de precios en el oligopolio tecnológico (Apple, Google) trajeron 10% de descuento a los consumidores.',
            fr: '📱 En 2025, les guerres de prix dans l\'oligopole technologique (Apple, Google) ont apporté 10% de remise aux consommateurs.',
            ru: '📱 В 2025 году ценовые войны в технологической олигополии (Apple, Google) принесли потребителям скидку 10%.'
          },
          icon: <Trophy className="w-16 h-16 text-yellow-500" />
        },
        {
          title: { 
            tr: 'Gayri Safi Yurtiçi Hasıla (GDP)', 
            en: 'Gross Domestic Product (GDP)', 
            es: 'Producto Interno Bruto (PIB)', 
            fr: 'Produit Intérieur Brut (PIB)', 
            ru: 'Валовой внутренний продукт (ВВП)' 
          },
          content: { 
            tr: 'GDP tanımı: Bir ülkede bir yılda üretilen tüm mal ve hizmetlerin piyasa değeri; ekonominin büyüklüğünü gösterir. Hesaplama yöntemleri: Harcama (tüketim + yatırım + hükümet + net ihracat), gelir (ücret + kar + faiz) veya üretim (sektör toplamı). Reel vs Nominal: Reel enflasyondan arındırılmış gerçek büyümeyi gösterir.',
            en: 'GDP definition: Market value of all goods and services produced in a country in one year; shows economy size. Calculation methods: Expenditure (consumption + investment + government + net exports), income (wages + profit + interest) or production (sector total). Real vs Nominal: Real shows true growth adjusted for inflation.',
            es: 'Definición del PIB: Valor de mercado de todos los bienes y servicios producidos en un país en un año; muestra el tamaño de la economía. Métodos de cálculo: Gasto (consumo + inversión + gobierno + exportaciones netas), ingreso (salarios + beneficio + interés) o producción (total sectorial). Real vs Nominal: Real muestra crecimiento verdadero ajustado por inflación.',
            fr: 'Définition du PIB: Valeur marchande de tous les biens et services produits dans un pays en un an; montre la taille de l\'économie. Méthodes de calcul: Dépense (consommation + investissement + gouvernement + exportations nettes), revenu (salaires + profit + intérêt) ou production (total sectoriel). Réel vs Nominal: Le réel montre la vraie croissance ajustée pour l\'inflation.',
            ru: 'Определение ВВП: Рыночная стоимость всех товаров и услуг, произведенных в стране за год; показывает размер экономики. Методы расчета: Расходы (потребление + инвестиции + правительство + чистый экспорт), доходы (зарплаты + прибыль + проценты) или производство (общий сектор). Реальный против номинального: Реальный показывает истинный рост с поправкой на инфляцию.'
          },
          example: { 
            tr: '📈 2025\'te global GDP %3.0 büyüdü; ABD\'de %1.6 artış tüketimle desteklendi (IMF).',
            en: '📈 In 2025, global GDP grew 3.0%; US 1.6% increase was supported by consumption (IMF).',
            es: '📈 En 2025, el PIB global creció 3.0%; el aumento del 1.6% de EE.UU. fue respaldado por el consumo (FMI).',
            fr: '📈 En 2025, le PIB mondial a augmenté de 3,0%; l\'augmentation de 1,6% des États-Unis a été soutenue par la consommation (FMI).',
            ru: '📈 В 2025 году мировой ВВП вырос на 3,0%; рост на 1,6% в США поддерживался потреблением (МВФ).'
          },
          icon: <BarChart3 className="w-16 h-16 text-blue-500" />
        },
        {
          title: { 
            tr: 'Ekonomik Büyüme Faktörleri', 
            en: 'Economic Growth Factors', 
            es: 'Factores de Crecimiento Económico', 
            fr: 'Facteurs de Croissance Économique', 
            ru: 'Факторы экономического роста' 
          },
          content: { 
            tr: 'Büyüme sürücüleri: Sermaye yatırımı (makineler), teknoloji yenilikleri (AI) ve işgücü eğitimi; bunlar üretimi artırır. Ölçüm: Yıllık GDP artış oranı; pozitif büyüme istihdamı artırır, negatif resesyon getirir. Sürdürülebilirlik: Çevreye zarar vermeden büyüme; örneğin, yeşil teknolojiler.',
            en: 'Growth drivers: Capital investment (machinery), technology innovations (AI) and workforce education; these increase production. Measurement: Annual GDP growth rate; positive growth increases employment, negative brings recession. Sustainability: Growth without environmental damage; for example, green technologies.',
            es: 'Impulsores del crecimiento: Inversión de capital (maquinaria), innovaciones tecnológicas (IA) y educación laboral; estos aumentan la producción. Medición: Tasa de crecimiento anual del PIB; el crecimiento positivo aumenta el empleo, el negativo trae recesión. Sostenibilidad: Crecimiento sin daño ambiental; por ejemplo, tecnologías verdes.',
            fr: 'Moteurs de croissance: Investissement en capital (machines), innovations technologiques (IA) et éducation de la main-d\'œuvre; ceux-ci augmentent la production. Mesure: Taux de croissance annuel du PIB; la croissance positive augmente l\'emploi, la négative apporte la récession. Durabilité: Croissance sans dommage environnemental; par exemple, technologies vertes.',
            ru: 'Драйверы роста: Капитальные инвестиции (оборудование), технологические инновации (ИИ) и образование рабочей силы; они увеличивают производство. Измерение: Годовая скорость роста ВВП; положительный рост увеличивает занятость, отрицательный приносит рецессию. Устойчивость: Рост без экологического ущерба; например, зеленые технологии.'
          },
          example: { 
            tr: '🇮🇳 2025\'te Hindistan %7.8 GDP büyümesiyle en hızlı büyüyen ekonomi oldu; dijital yatırımlar sayesinde.',
            en: '🇮🇳 In 2025, India became the fastest growing economy with 7.8% GDP growth; thanks to digital investments.',
            es: '🇮��� En 2025, India se convirtió en la economía de crecimiento más rápido con 7.8% de crecimiento del PIB; gracias a las inversiones digitales.',
            fr: '🇮🇳 En 2025, l\'Inde est devenue l\'économie à la croissance la plus rapide avec une croissance du PIB de 7,8%; grâce aux investissements numériques.',
            ru: '🇮🇳 В 2025 году Индия стала самой быстрорастущей экономикой с ростом ВВП 7,8%; благодаря цифровым инвестициям.'
          },
          icon: <TrendingUp className="w-16 h-16 text-green-500" />
        },
        {
          title: { 
            tr: 'Enflasyon ve Etkileri', 
            en: 'Inflation and Its Effects', 
            es: 'Inflación y Sus Efectos', 
            fr: 'Inflation et Ses Effets', 
            ru: 'Инфляция и её влияние' 
          },
          content: { 
            tr: 'Enflasyon tanımı: Genel fiyat seviyesinin sürekli artışı; para değerini düşürür, alım gücünü azaltır. Türleri: Talep çekişli (fazla harcama), maliyet itişli (hammadde pahalanması); düşük enflasyon sağlıklı, yüksek olan hiperenflasyon yıkıcıdır. Ölçüm: TÜFE ile, sepet malların fiyat değişimi hesaplanır.',
            en: 'Inflation definition: Continuous increase in general price level; reduces money value, decreases purchasing power. Types: Demand-pull (excess spending), cost-push (raw material price increases); low inflation is healthy, high hyperinflation is destructive. Measurement: With CPI, price change of basket goods is calculated.',
            es: 'Definición de inflación: Aumento continuo del nivel general de precios; reduce el valor del dinero, disminuye el poder adquisitivo. Tipos: Tirón de demanda (gasto excesivo), empuje de costos (aumentos de precios de materias primas); la inflación baja es saludable, la hiperinflación alta es destructiva. Medición: Con IPC, se calcula el cambio de precios de bienes de canasta.',
            fr: 'Définition de l\'inflation: Augmentation continue du niveau général des prix; réduit la valeur de l\'argent, diminue le pouvoir d\'achat. Types: Tirée par la demande (dépenses excessives), poussée par les coûts (augmentations des prix des matières premières); une faible inflation est saine, une hyperinflation élevée est destructrice. Mesure: Avec l\'IPC, le changement de prix des biens du panier est calculé.',
            ru: 'Определение инфляции: Непре��ывное повышение общего уровня цен; снижает стоимость денег, умень��ает покупательную способность. Типы: Спрос-инфля��ия (избыточные расходы), инфляция издержек (рост цен на сырье); низкая инфляция здорова, высокая гиперинфляция разрушительна. Измерение: С помощью ИПЦ рассчитывается изменение цен корзинных товаров.'
          },
          example: { 
            tr: '📊 2025\'te global enflasyon %3.4\'e yükseldi; ticaret gerilimleri nedeniyle bazı ülkelerde %5\'in üstünde kaldı.',
            en: '📊 In 2025, global inflation rose to 3.4%; remained above 5% in some countries due to trade tensions.',
            es: '📊 En 2025, la inflación global subió a 3.4%; se mantuvo por encima del 5% en algunos países debido a las tensiones comerciales.',
            fr: '📊 En 2025, l\'inflation mondiale est montée à 3,4%; est restée au-dessus de 5% dans certains pays en raison des tensions commerciales.',
            ru: '📊 В 2025 году мировая инфляция выросла до 3,4%; осталась выше 5% в некоторых странах из-за торговых напряжений.'
          },
          icon: <TrendingUp className="w-16 h-16 text-red-500" />
        },
        {
          title: { 
            tr: 'İşsizlik Türleri ve Ölçümü', 
            en: 'Types of Unemployment and Measurement', 
            es: 'Tipos de Desempleo y Medición', 
            fr: 'Types de Chômage et Mesure', 
            ru: 'Типы безработицы и измерение' 
          },
          content: { 
            tr: 'Türleri: Yapısal (beceri uyumsuzluğu), friksiyonel (iş değiştirme arası), konjonktürel (ekonomik yavaşlama); her biri farklı çözümler gerektirir. Ölçüm: İşsizlik oranı = İşsiz sayısı / İşgücü toplamı; aktif iş arayanları kapsar. Doğal oran: Tam istihdam seviyesi (%4-5), sıfır işsizlik imkansızdır.',
            en: 'Types: Structural (skill mismatch), frictional (between job changes), cyclical (economic slowdown); each requires different solutions. Measurement: Unemployment rate = Number of unemployed / Total labor force; covers active job seekers. Natural rate: Full employment level (4-5%), zero unemployment is impossible.',
            es: 'Tipos: Estructural (desajuste de habilidades), friccional (entre cambios de trabajo), cíclico (desaceleración económica); cada uno requiere diferentes soluciones. Medición: Tasa de desempleo = Número de desempleados / Fuerza laboral total; cubre a buscadores activos de empleo. Tasa natural: Nivel de pleno empleo (4-5%), cero desempleo es imposible.',
            fr: 'Types: Structurel (inadéquation des compétences), frictionnel (entre changements d\'emploi), cyclique (ralentissement économique); chacun nécessite des solutions différentes. Mesure: Taux de chômage = Nombre de chômeurs / Force de travail totale; couvre les demandeurs d\'emploi actifs. Taux naturel: Niveau de plein emploi (4-5%), zéro chômage est impossible.',
            ru: 'Типы: Структурная (несоответствие навыков), фрикционная (между сменой работы), циклическая (экономическое замедление); каждая требует разных решений. Измерение: Уровень безработицы = Количество безработных / Общая рабочая сила; охватывает активно ищущих работу. Естественная ставка: Уровень полной занятости (4-5%), нулевая безработица невозможна.'
          },
          example: { 
            tr: '📈 2025\'te ABD işsizlik %4.3\'e yükseldi; pandemi sonrası toparlanma yavaşladı.',
            en: '📈 In 2025, US unemployment rose to 4.3%; post-pandemic recovery slowed down.',
            es: '📈 En 2025, el desempleo de EE.UU. subió a 4.3%; la recuperación post-pandemia se desaceleró.',
            fr: '📈 En 2025, le chômage américain est monté à 4,3%; la reprise post-pandémie a ralenti.',
            ru: '📈 В 2025 году безработица в США выросла до 4,3%; ��осстановление после пандемии замедлилось.'
          },
          icon: <Users className="w-16 h-16 text-orange-500" />
        },
        {
          title: { 
            tr: 'Maliye Politikası', 
            en: 'Fiscal Policy', 
            es: 'Política Fiscal', 
            fr: 'Politique Budgétaire', 
            ru: 'Фискальная политика' 
          },
          content: { 
            tr: 'Araçlar: Vergi indirimleri veya artırmaları, hükümet harcamaları (altyapı); ekonomiyi canlandırır veya yavaşlatır. Genişletici politika: Büyümeyi teşvik için harcama artırılır, daraltıcı: Enflasyonu kontrol için vergiler yükseltilir. Bütçe açığı: Harcamalar geliri aşarsa borçlanırız; uzun vadede sürdürülebilir olmalı.',
            en: 'Tools: Tax cuts or increases, government spending (infrastructure); stimulates or slows the economy. Expansionary policy: Spending increased to encourage growth, contractionary: Taxes raised to control inflation. Budget deficit: If spending exceeds revenue we borrow; must be sustainable long-term.',
            es: 'Herramientas: Recortes o aumentos de impuestos, gasto gubernamental (infraestructura); estimula o frena la economía. Política expansiva: Se aumenta el gasto para fomentar el crecimiento, contractiva: Se suben impuestos para controlar la inflación. Déficit presupuestario: Si el gasto excede los ingresos, pedimos prestado; debe ser sostenible a largo plazo.',
            fr: 'Outils: Réductions ou augmentations d\'impôts, dépenses gouvernementales (infrastructure); stimule ou ralentit l\'économie. Politique expansionniste: Dépenses augmentées pour encourager la croissance, contractionniste: Impôts augmentés pour contrôler l\'inflation. Déficit budgétaire: Si les dépenses dépassent les revenus, nous empruntons; doit être durable à long terme.',
            ru: 'Инструменты: Сокращение или увеличение налогов, государственные расходы (инфраструк��ура); стимулирует или замедляет экономику. Экспансионистская политика: Расходы увеличиваются для поощрения роста, сд��рживающая: Налоги повышаются для контроля инфляции. Бюджетный дефицит: Если расходы превышают доходы, мы занимаем; должно быть устойчивым в долгосрочной перспективе.'
          },
          example: { 
            tr: '🏛️ 2025\'te ABD mali genişleme GDP\'yi %0.2 artırdı; bütçe yasalarıyla.',
            en: '🏛️ In 2025, US fiscal expansion increased GDP by 0.2%; through budget laws.',
            es: '🏛️ En 2025, la expansión fiscal de EE.UU. aumentó el PIB en 0.2%; a través de leyes presupuestarias.',
            fr: '🏛️ En 2025, l\'expansion budgétaire américaine a augmenté le PIB de 0,2%; grâce aux lois budgétaires.',
            ru: '🏛️ В 2025 году фискальная экспансия США увеличила ВВП на 0,2%; через бюджетные законы.'
          },
          icon: <DollarSign className="w-16 h-16 text-green-500" />
        },
        {
          title: { 
            tr: 'Para Politikası', 
            en: 'Monetary Policy', 
            es: 'Política Monetaria', 
            fr: 'Politique Monétaire', 
            ru: 'Монетарная политика' 
          },
          content: { 
            tr: 'Araçlar: Faiz oranlarını düşürmek (borçlanmayı ucuzlatır), rezerv zorunlulukları; para arzını kontrol eder. Amaç: Enflasyonu düşük tutmak ve büyümeyi desteklemek; örneğin, düşük faiz yatırım teşvik eder. QE (Nicel Gevşeme): Para basarak ekonomiyi canlandırır, krizlerde kullanılır.',
            en: 'Tools: Lowering interest rates (makes borrowing cheaper), reserve requirements; controls money supply. Purpose: Keep inflation low and support growth; for example, low interest encourages investment. QE (Quantitative Easing): Revitalizes economy by printing money, used in crises.',
            es: 'Herramientas: Bajar tasas de interés (hace más barato el préstamo), requisitos de reserva; controla la oferta monetaria. Propósito: Mantener la inflación baja y apoyar el crecimiento; por ejemplo, el interés bajo fomenta la inversión. QE (Relajación Cuantitativa): Revitaliza la economía imprimiendo dinero, se usa en crisis.',
            fr: 'Outils: Baisser les taux d\'intérêt (rend l\'emprunt moins cher), exigences de réserve; contrôle l\'offre de monnaie. But: Maintenir l\'inflation basse et soutenir la croissance; par exemple, un faible intérêt encourage l\'investissement. QE (Assouplissement Quantitatif): Revitalise l\'économie en imprimant de l\'argent, utilisé en crises.',
            ru: 'Инструменты: Снижение процентных ставок (делает заимствование дешевле), резервные требования; контролирует денежное предложение. Цель: Поддерживать низкую инфляцию и поддерживать рост; например, низкий процент поощряет инвестиции. QE (Количественное смягчение): Оживляет экономику печатанием денег, используется в кризисах.'
          },
          example: { 
            tr: '🏦 2025\'te ECB faizleri düşürerek Avrupa büyümesini %1.1\'e çıkardı; enflasyonu %2\'ye yaklaştırdı.',
            en: '🏦 In 2025, ECB raised European growth to 1.1% by lowering interest rates; brought inflation close to 2%.',
            es: '🏦 En 2025, el BCE elevó el crecimiento europeo a 1.1% bajando las tasas de interés; acercó la inflación al 2%.',
            fr: '🏦 En 2025, la BCE a porté la croissance européenne à 1,1% en baissant les taux d\'intérêt; a rapproché l\'inflation de 2%.',
            ru: '🏦 В 2025 году ЕЦБ повысил европейский рост до 1,1%, снизив процентные ставки; приблизил инфляцию к 2%.'
          },
          icon: <Coins className="w-16 h-16 text-yellow-500" />
        },
        {
          title: { 
            tr: 'Uluslararası Ticaret', 
            en: 'International Trade', 
            es: 'Comercio Internacional', 
            fr: 'Commerce International', 
            ru: 'Международная торговля' 
          },
          content: { 
            tr: 'Avantajlar: Karşılaştırmalı üstünlükle uzmanlaşma; bir ülke ucuz ürettiğini ihraç eder, pahalı olanı ithal eder – refah artar. Bariyerler: Tarifeler (gümrük vergisi) veya kotalar (miktar sınırı); ticareti kısıtlar, fiyatları yükseltir. Ticaret dengesi: İhracat fazlaysa surplus, ithalat fazlaysa deficit.',
            en: 'Advantages: Specialization through comparative advantage; a country exports what it produces cheaply, imports expensive ones – welfare increases. Barriers: Tariffs (customs duty) or quotas (quantity limits); restricts trade, raises prices. Trade balance: If exports exceed imports surplus, if imports exceed deficit.',
            es: 'Ventajas: Especialización a través de ventaja comparativa; un país exporta lo que produce barato, importa lo caro – aumenta el bienestar. Barreras: Aranceles (derechos de aduana) o cuotas (límites de cantidad); restringe el comercio, eleva precios. Balance comercial: Si las exportaciones superan las importaciones superávit, si las importaciones superan déficit.',
            fr: 'Avantages: Spécialisation grâce à l\'avantage comparatif; un pays exporte ce qu\'il produit à bon marché, importe ce qui est cher – le bien-être augmente. Barrières: Tarifs (droits de douane) ou quotas (limites de quantité); restreint le commerce, augmente les prix. Balance commerciale: Si les exportations dépassent les importations excédent, si les importations dépassent déficit.',
            ru: 'Преимущества: Специализация через сравнительное преимущество; страна экспортирует то, что производит дешево, импортирует дорогое – благосостояние увеличивается. Барьеры: Тарифы (таможенная пошлина) или квоты (количественные ограничения); ограничивает торговлю, повышает цены. Торговый баланс: Если экспорт превышает импорт профицит, если импорт превышает дефицит.'
          },
          example: { 
            tr: '🌍 2025\'te ABD-Çin ticaret gerilimleri global büyümeyi %0.7 yavaşlattı; tarifeler arttı.',
            en: '🌍 In 2025, US-China trade tensions slowed global growth by 0.7%; tariffs increased.',
            es: '🌍 En 2025, las tensiones comerciales EE.UU.-China desaceleraron el crecimiento global en 0.7%; aumentaron los aranceles.',
            fr: '🌍 En 2025, les tensions commerciales États-Unis-Chine ont ralenti la croissance mondiale de 0,7%; les tarifs ont augmenté.',
            ru: '🌍 В 2025 году торговые напряжения между США и Китаем замедлили мировой рост на 0,7%; тарифы увеличились.'
          },
          icon: <TrendingUp className="w-16 h-16 text-purple-500" />
        },
        {
          title: { 
            tr: 'Döviz Kurları ve Değişimler', 
            en: 'Exchange Rates and Changes', 
            es: 'Tipos de Cambio y Variaciones', 
            fr: 'Taux de Change et Variations', 
            ru: 'Обменные курсы и изменения' 
          },
          content: { 
            tr: 'Kur türleri: Sabit (hükümet belirler), dalgalı (piyasa karar verir); dalgalı daha esnektir. Devalüasyon: Para değer kaybederse ihracat ucuzlar, ithalat pahalanır – turizmi artırır. Etkiler: Yüksek kur enflasyonu yükseltir, düşük kur ticareti dengeler.',
            en: 'Exchange rate types: Fixed (government determines), floating (market decides); floating is more flexible. Devaluation: If currency loses value exports become cheaper, imports more expensive – increases tourism. Effects: High rate raises inflation, low rate balances trade.',
            es: 'Tipos de tipo de cambio: Fijo (gobierno determina), flotante (mercado decide); flotante es más flexible. Devaluación: Si la moneda pierde valor las exportaciones se vuelven más baratas, las importaciones más caras – aumenta el turismo. Efectos: Tasa alta eleva inflación, tasa baja equilibra comercio.',
            fr: 'Types de taux de change: Fixe (gouvernement détermine), flottant (marché décide); flottant est plus flexible. Dévaluation: Si la monnaie perd de la valeur les exportations deviennent moins chères, les importations plus chères – augmente le tourisme. Effets: Taux élevé élève l\'inflation, taux bas équilibre le commerce.',
            ru: 'Типы обменных курсов: Фиксированный (правительство определяет), плавающий (рынок решает); плавающий более гибкий. Девальвация: Если валюта теряет стоимость, экспорт становится дешевле, импорт дороже – увеличивает туризм. Влияние: Высокий курс повышает инфляцию, низкий курс балансирует торговлю.'
          },
          example: { 
            tr: '💱 2025\'te gelişen piyasalarda para birimleri %5 değer kaybetti; ihracat %10 arttı.',
            en: '💱 In 2025, currencies in emerging markets lost 5% value; exports increased 10%.',
            es: '💱 En 2025, las monedas en mercados emergentes perdieron 5% de valor; las exportaciones aumentaron 10%.',
            fr: '💱 En 2025, les devises des marchés émergents ont perdu 5% de valeur; les exportations ont augmenté de 10%.',
            ru: '💱 В 2025 году валюты развивающихся рынков потеряли 5% стоимости; экспорт увеличился на 10%.'
          },
          icon: <DollarSign className="w-16 h-16 text-blue-500" />
        },
        {
          title: { 
            tr: 'Kalkınma Ekonomisi', 
            en: 'Development Economics', 
            es: 'Economía del Desarrollo', 
            fr: 'Économie du Développement', 
            ru: 'Экономика развития' 
          },
          content: { 
            tr: 'Göstergeler: İGE (sağlık, eğitim, gelir), yoksulluk oranı; sadece GDP değil, yaşam kalitesini ölçer. Stratejiler: Eğitim yatırımı beceri artırır, altyapı (yol, elektrik) ticareti kolaylaştırır. Eşitsizlik: Gini katsayısı ile ölçülür; yüksek eşitsizlik büyümeyi yavaşlatır.',
            en: 'Indicators: HDI (health, education, income), poverty rate; not just GDP, measures quality of life. Strategies: Education investment increases skills, infrastructure (roads, electricity) facilitates trade. Inequality: Measured by Gini coefficient; high inequality slows growth.',
            es: 'Indicadores: IDH (salud, educación, ingreso), tasa de pobreza; no solo PIB, mide calidad de vida. Estrategias: Inversión en educación aumenta habilidades, infraestructura (caminos, electricidad) facilita comercio. Desigualdad: Se mide por coeficiente de Gini; alta desigualdad desacelera crecimiento.',
            fr: 'Indicateurs: IDH (santé, éducation, revenu), taux de pauvreté; pas seulement le PIB, mesure la qualité de vie. Stratégies: L\'investissement dans l\'éducation augmente les compétences, l\'infrastructure (routes, électricité) facilite le commerce. Inégalité: Mesurée par coefficient de Gini; haute inégalité ralentit la croissance.',
            ru: 'Показатели: ИЧР (здоровье, образование, доходы), уровень бедности; не только ВВП, измеряет качество жизни. Стратегии: Инвестиции в образование повышают навыки, инфраструктура (дороги, электричество) облегчает торговлю. Неравенство: Измеряется коэффициентом Джини; высокое неравенство з��медляет рост.'
          },
          example: { 
            tr: '🌍 2025\'te Afrika\'da nüfus art��şı b��yüme sağladı; ancak eşitsizlik %40 işsizlik yarattı.',
            en: '🌍 In 2025, population growth in Africa provided growth; however inequality created 40% unemployment.',
            es: '🌍 En 2025, el crecimiento poblacional en África proporcionó crecimiento; sin embargo la desigualdad creó 40% de desempleo.',
            fr: '🌍 En 2025, la croissance démographique en Afrique a fourni de la croissance; cependant l\'inégalité a créé 40% de chômage.',
            ru: '🌍 В 2025 году рост населения в Африке обеспечил рост; однако неравенство создало 40% ��езработицы.'
          },
          icon: <Target className="w-16 h-16 text-orange-500" />
        },
        {
          title: { 
            tr: 'Çevre Ekonomisi', 
            en: 'Environmental Economics', 
            es: 'Economía Ambiental', 
            fr: 'Économie Environnementale', 
            ru: 'Экологическая экономика' 
          },
          content: { 
            tr: 'Dışsallıklar: Fabrika kirliliği topluma maliyet yükler (negatif), aşı gibi faydalar paylaşılır (pozitif). Araçlar: Karbon vergisi kirleteni cezalandırır, yeşil tahviller çevre projelerini finanse eder. Sürdürülebilirlik: Büyümeyi çevreyle dengelemek; örneğin, yenilenebilir enerji hem iş yaratır hem doğayı korur.',
            en: 'Externalities: Factory pollution imposes cost on society (negative), benefits like vaccination are shared (positive). Tools: Carbon tax penalizes polluters, green bonds finance environmental projects. Sustainability: Balancing growth with environment; for example, renewable energy both creates jobs and protects nature.',
            es: 'Externalidades: La contaminación de fábrica impone costo a la sociedad (negativa), beneficios como vacunación se comparten (positiva). Herramientas: Impuesto al carbono penaliza a contaminadores, bonos verdes financian proyectos ambientales. Sostenibilidad: Equilibrar crecimiento con ambiente; por ejemplo, energía renovable tanto crea empleos como protege naturaleza.',
            fr: 'Externalités: La pollution d\'usine impose un coût à la société (négative), les avantages comme la vaccination sont partagés (positive). Outils: La taxe carbone pénalise les pollueurs, les obligations vertes financent les projets environnementaux. Durabilité: Équilibrer croissance avec environnement; par exemple, l\'énergie renouvelable crée des emplois et protège la nature.',
            ru: 'Внешние эффекты: Загрязнение завода накладывает затраты на общество (отрицательный), выгоды, такие как вакцинация, разделяются (положительный). Инструменты: Углеродный налог наказывает загрязнителей, зеленые облигации финансируют экологические проекты. Устойчивость: Балансировка роста с окружающей средой; например, возобновляемая энергия и создает рабочие места, и защищает природу.'
          },
          example: { 
            tr: '🌱 2025\'te iklim şokları global GDP\'yi %0.5 azalttı; yeşil politikalarla telafi edildi.',
            en: '🌱 In 2025, climate shocks reduced global GDP by 0.5%; compensated with green policies.',
            es: '🌱 En 2025, los choques climáticos redujeron el PIB global en 0.5%; compensado con políticas verdes.',
            fr: '🌱 En 2025, les chocs climatiques ont réduit le PIB mondial de 0,5%; compensé par des politiques vertes.',
            ru: '🌱 В 2025 году климатические шоки сократили мировой ВВП на 0,5%; компенсировано зеленой политикой.'
          },
          icon: <Heart className="w-16 h-16 text-green-500" />
        },
        {
          title: { 
            tr: 'Davranışsal Ekonomi', 
            en: 'Behavioral Economics', 
            es: 'Economía Conductual', 
            fr: 'Économie Comportementale', 
            ru: 'Поведенческая экономика' 
          },
          content: { 
            tr: 'Klasik varsayımlar: İnsanlar rasyonel davranır diye düşünülür, ama gerçekte önyargılar (korku, alışkanlık) kararları etkiler. Nudge tekniği: Küçük teşviklerle doğru kararlar alınır – örneğin, otomatik emeklilik kaydı tasarrufu artırır. Uygulamalar: Politikalarda kullanılır; vergileri otomatikleştirmek uyumu yükseltir.',
            en: 'Classical assumptions: People are thought to behave rationally, but in reality biases (fear, habit) affect decisions. Nudge technique: Right decisions are made with small incentives – for example, automatic retirement enrollment increases savings. Applications: Used in policies; automating taxes increases compliance.',
            es: 'Suposiciones clásicas: Se piensa que las personas se comportan racionalmente, pero en realidad los sesgos (miedo, hábito) afectan las decisiones. Técnica de empujón: Se toman decisiones correctas con pequeños incentivos – por ejemplo, inscripción automática en jubilación aumenta ahorros. Aplicaciones: Se usa en políticas; automatizar impuestos aumenta cumplimiento.',
            fr: 'Hypothèses classiques: Les gens sont censés se comporter rationnellement, mais en réalité les biais (peur, habitude) affectent les décisions. Technique de coup de pouce: De bonnes décisions sont prises avec de petites incitations – par exemple, l\'inscription automatique à la retraite augmente l\'épargne. Applications: Utilisée dans les politiques; automatiser les impôts augmente la conformité.',
            ru: 'Классические предположения: Люди, как предполагается, ведут себя рационально, но на сам��м деле предвзятости (страх, привычка) влияют на решения. Техника подталкивания: Правильные решения принимаются с небольшими стимулами – например, автоматическая регистрация в пенсионной системе увеличивает сбережения. Применения: Используется в п��литике; авто��атизация налогов повышает соответствие.'
          },
          example: { 
            tr: '🧠 2025\'te davranışsal politikalarla tasarruf oranları %5 arttı; emeklilik fonları büyüd��.',
            en: '🧠 In 2025, savings rates increased 5% with behavioral policies; pension funds grew.',
            es: '🧠 En 2025, las tasas de ahorro aumentaron 5% con políticas conductuales; los fondos de pensión crecieron.',
            fr: '🧠 En 2025, les taux d\'épargne ont augmenté de 5% avec les politiques comportementales; les fonds de pension ont grandi.',
            ru: '🧠 В 2025 году уровень сбережений увеличился на 5% благодаря поведенческой политике; пенсионные фонды выросли.'
          },
          icon: <Brain className="w-16 h-16 text-purple-500" />
        },
        {
          title: { 
            tr: 'Finansal Piyasalar', 
            en: 'Financial Markets', 
            es: 'Mercados Financieros', 
            fr: 'Marchés Financiers', 
            ru: 'Финансовые рынки' 
          },
          content: { 
            tr: 'Türleri: Hisse piyasası (sahiplik), tahvil (borç), döviz (para değişimi); sermaye akışını sağlar. Risk ve getiri: Yüksek risk yüksek getiri getirir; çeşitlendirme (farklı varlıklara yaymak) kaybı azaltır. Düzenleme: Borsaları denetler, krizleri önler – örneğin, SEC ABD\'de şeffaflık sağlar.',
            en: 'Types: Stock market (ownership), bonds (debt), forex (currency exchange); provides capital flow. Risk and return: High risk brings high return; diversification (spreading to different assets) reduces loss. Regulation: Supervises exchanges, prevents crises – for example, SEC provides transparency in US.',
            es: 'Tipos: Mercado de acciones (propiedad), bonos (deuda), divisas (intercambio de monedas); proporciona flujo de capital. Riesgo y retorno: Alto riesgo trae alto retorno; diversificación (extender a diferentes activos) reduce pérdida. Regulación: Supervisa intercambios, previene crisis – por ejemplo, SEC proporciona transparencia en EE.UU.',
            fr: 'Types: Marché boursier (propriété), obligations (dette), forex (change de devises); fournit le flux de capital. Risque et rendement: Haut risque apporte haut rendement; diversification (étendre à différents actifs) réduit la perte. Régulation: Supervise les échanges, prévient les crises – par exemple, SEC fournit la transparence aux États-Unis.',
            ru: 'Типы: Фондовый рынок (владение), облигации (долг), форекс (обмен валют); обеспечивает поток капитала. Риск и доходность: Высокий риск приносит высокую доходность; диверсификация (распределение по разным активам) снижает потери. Регулирование: Контролирует биржи, предотвращает кризисы – например, SEC обеспечивает прозрачность в США.'
          },
          example: { 
            tr: '📊 2025\'te borsa dalgalanmaları AI yatırımlarıyla %12 getiri sağladı; ancak ticaret belirsizliğiyle %5 düştü.',
            en: '📊 In 2025, stock market fluctuations provided 12% return with AI investments; however dropped 5% with trade uncertainty.',
            es: '📊 En 2025, las fluctuaciones del mercado de valores proporcionaron 12% de retorno con inversiones en IA; sin embargo cayó 5% con incertidumbre comercial.',
            fr: '📊 En 2025, les fluctuations du marché boursier ont fourni 12% de rendement avec les investissements en IA; cependant a chuté de 5% avec l\'incertitude commerciale.',
            ru: '📊 В 2025 году ����олебания фондового рынка обеспечили 12% доходности с инвестициями в ИИ; однако упали на 5% из-за торговой неопределеннос��и.'
          },
          icon: <LineChart className="w-16 h-16 text-blue-500" />
        },
        {
          title: { 
            tr: 'Ekonomik Krizler ve Kurtarma', 
            en: 'Economic Crises and Recovery', 
            es: 'Crisis Económicas y Recuperación', 
            fr: 'Crises Économiques et Récupération', 
            ru: '��кономические кризисы и восстановление' 
          },
          content: { 
            tr: 'Nedenler: Piyasa balonları (aşırı değerlenme), borç birikimi; ani şoklar (pandemi) tetikler. Kurtarma yöntemleri: Mali ve para politikalarıyla müdahale – örneğin, teşvik paketleri istihdamı korur. Dersler: Dayanıklılık için çeşitlendirme ve düzenleme; krizler fırsat da yaratır (yenilikler).',
            en: 'Causes: Market bubbles (overvaluation), debt accumulation; sudden shocks (pandemic) trigger. Recovery methods: Intervention with fiscal and monetary policies – for example, stimulus packages protect employment. Lessons: Diversification and regulation for resilience; crises also create opportunities (innovations).',
            es: 'Causas: Burbujas de mercado (sobrevaloración), acumulación de deuda; choques repentinos (pandemia) desencadenan. Métodos de recuperación: Intervención con políticas fiscales y monetarias – por ejemplo, paquetes de estímulo protegen empleo. Lecciones: Diversificación y regulación para resistencia; las crisis también crean oportunidades (innovaciones).',
            fr: 'Causes: Bulles de marché (surévaluation), accumulation de dettes; chocs soudains (pandémie) déclenchent. Méthodes de récupération: Intervention avec politiques fiscales et monétaires – par exemple, paquets de relance protègent l\'emploi. Leçons: Diversification et régulation pour résilience; les crises créent aussi des opportunités (innovations).',
            ru: 'Причины: Рыночные пузыри (переоценка), накопление долгов; внезапные шоки (пандемия) запускают. Методы восстановления: Вмешательство фискальной и монетарной политикой – например, пакеты стимулов защищают занятость. Уроки: Диверсификация и регулирование для устойчивости; кризисы также создают возможности (инновации).'
          },
          example: { 
            tr: '🔄 2025\'te ticaret krizleri global büyümeyi %0.7 yavaşlattı; IMF müdahaleleriyle toparlanma sağlandı.',
            en: '🔄 In 2025, trade crises slowed global growth by 0.7%; recovery achieved with IMF interventions.',
            es: '🔄 En 2025, las crisis comerciales desaceleraron el crecimiento global en 0.7%; se logró recuperación con intervenciones del FMI.',
            fr: '🔄 En 2025, les crises commerciales ont ralenti la croissance mondiale de 0,7%; récupération réalisée avec les interventions du FMI.',
            ru: '�� В 2025 году торговые кризисы замедлили мировой рост на 0,7%; восстановление достигнуто с помощью вмешательств МВФ.'
          },
          icon: <Zap className="w-16 h-16 text-red-500" />
        }
      ],
      'Analysis': [
        {
          title: { 
            tr: 'Teknik Analiz Nedir?', 
            en: 'What is Technical Analysis?', 
            es: '¿Qué es el Análisis Técnico?', 
            fr: 'Qu\'est-ce que l\'Analyse Technique?', 
            ru: 'Что такое технический анализ?' 
          },
          content: { 
            tr: '• Geçmiş fiyat hareketleri ve hacim verilerini kullanarak gelecekteki fiyat yönünü tahmin etme sanatı\n• Temel prensipler: Fiyat her şeyi yansıtır, fiyat hareketleri tekrarlanır, trend analizi kritiktir\n• Kullanım alanları: Kısa vadeli trading, orta vadeli yatırım stratejileri, uzun vadeli trend analizi\n• Risk yönetimi ve giriş-çıkış noktalarının belirlenmesi için kullanılır',
            en: '• Art of predicting future price direction using past price movements and volume data\n• Basic principles: Price reflects everything, price movements repeat, trend analysis is critical\n• Usage areas: Short-term trading, medium-term investment strategies, long-term trend analysis\n• Used for risk management and determining entry-exit points',
            es: '• Arte de predecir la dirección futura del precio usando movimientos de precios pasados y datos de volumen\n• Principios básicos: El precio refleja todo, los movimientos de precios se repiten, el análisis de tendencias es crítico\n• Áreas de uso: Trading a corto plazo, estrategias de inversión a mediano plazo, análisis de tendencias a largo plazo\n• Usado para gestión de riesgos y determinar puntos de entrada-salida',
            fr: '• Art de prédire la direction future des prix en utilisant les mouvements de prix passés et les données de volume\n• Principes de base: Le prix reflète tout, les mouvements de prix se répètent, l\'analyse des tendances est critique\n• Domaines d\'utilisation: Trading à court terme, stratégies d\'investissement à moyen terme, analyse des tendances à long terme\n• Utilisé pour la gestion des risques et la détermination des points d\'entrée-sortie',
            ru: '• Искусство прогнозирования будущего направления цены с использованием прошлых ценовых движений и данных объема\n• Основные принципы: Цена отражает все, ценовые движения повторяются, анализ тренда критичен\n• Области применения: Краткосрочная торговля, среднесрочные инвестиционные стратегии, долгосрочный анализ тренда\n• Используется для управления рисками и определения точек входа-выхода'
          },
          example: { 
            tr: '📈 Borsa Örneği: BIST100 geçen ay yükseldi, şimdi direnç seviyesinde. Teknik analiz bu tür kalıpları okur.',
            en: '📈 Stock Example: BIST100 rose last month, now at resistance level. Technical analysis reads such patterns.',
            es: '📈 Ejemplo Bursátil: BIST100 subió el mes pasado, ahora en nivel de resistencia. El análisis técnico lee tales patrones.',
            fr: '📈 Exemple Boursier: BIST100 a augmenté le mois dernier, maintenant au niveau de résistance. L\'analyse technique lit de tels modèles.',
            ru: '📈 Биржевой пример: BIST100 вырос в прошлом месяце, сейчас на уровне сопротивления. Технический анализ читает такие паттерны.'
          },
          icon: <LineChart className="w-16 h-16 text-purple-500" />
        },
        {
          title: { 
            tr: 'Destek ve Direnç Seviyeleri', 
            en: 'Support and Resistance Levels', 
            es: 'Niveles de Soporte y Resistencia', 
            fr: 'Niveaux de Support et Résistance', 
            ru: 'Уровни поддержки и сопротивления' 
          },
          content: { 
            tr: 'DESTEK: Fiyatın düştüğü zaman durduğu seviye. DİRENÇ: Fiyatın yükseldiği zaman durduğu seviye. Bu seviyeler psikolojik ve tarihi öneme sahiptir.',
            en: 'SUPPORT: Level where price stops when falling. RESISTANCE: Level where price stops when rising. These levels have psychological and historical importance.',
            es: 'SOPORTE: Nivel donde el precio se detiene al caer. RESISTENCIA: Nivel donde el precio se detiene al subir. Estos niveles tienen importancia psicológica e histórica.',
            fr: 'SUPPORT: Niveau où le prix s\'arrête en baissant. RÉSISTANCE: Niveau où le prix s\'arrête en montant. Ces niveaux ont une importance psychologique et historique.',
            ru: 'ПОДДЕРЖКА: Уровень, где цена останавливается при падении. СОПРОТИВЛЕНИЕ: Уровень, где цена останавливаетс�� при росте. Эти уровни имеют пс��хологическое и историческое значение.'
          },
          example: { 
            tr: '🎯 BTC Örneği: 50.000$ seviyesi BTC için güçlü destek. Her düştüğünde bu seviyeden alım geldi.',
            en: '🎯 BTC Example: $50,000 level is strong support for BTC. Every time it fell, buying came from this level.',
            es: '🎯 Ejemplo BTC: El nivel de $50,000 es un soporte fuerte para BTC. Cada vez que cayó, llegaron compras desde este nivel.',
            fr: '🎯 Exemple BTC: Le niveau de 50 000$ est un support fort pour BTC. Chaque fois qu\'il est tombé, des achats sont venus de ce niveau.',
            ru: '🎯 Пример BTC: Уровень $50,000 является сильной поддержкой д��я BTC. Каждый раз, когда он падал, поку��ки приходили с этого уровня.'
          },
          icon: <BarChart3 className="w-16 h-16 text-blue-500" />
        }
      ],
      'Personal Finance': [
        {
          title: { 
            tr: 'Kişisel Finans Nedir?', 
            en: 'What is Personal Finance?', 
            es: '¿Qué son las Finanzas Personales?', 
            fr: 'Qu\'est-ce que la Finance Personnelle?', 
            ru: 'Что такое личные финансы?' 
          },
          content: { 
            tr: [
              '• Kişisel finans, gelirinizi yönetmek, harcamaları kontrol etmek, tasarruf etmek ve geleceğe yatırım yapmak anlamına gelir',
              '• Temel prensipler: Gelir > Gider dengesi, uzun vadeli hedefler belirleme ve risk yönetimi yapma',
              '• Finansal özgürlük sağlar: Borcunuz olmadan istediğiniz hayatı yaşayabilirsiniz',
              '• Stres azaltır: Mali güvenlik ruh sağlığınızı olumlu etkiler ve gelecek endişelerini giderir'
            ],
            en: [
              '• Personal finance means managing your income, controlling expenses, saving money and investing for the future',
              '• Basic principles: Income > Expenses balance, setting long-term goals and risk management',
              '• Provides financial freedom: You can live the life you want without debt',
              '• Reduces stress: Financial security positively affects your mental health and eliminates future worries'
            ],
            es: [
              '• Las finanzas personales significan gestionar tus ingresos, controlar gastos, ahorrar dinero e invertir para el futuro',
              '• Principios básicos: Balance Ingresos > Gastos, establecer objetivos a largo plazo y gestión de riesgos',
              '• Proporciona libertad financiera: Puedes vivir la vida que quieres sin deudas',
              '• Reduce el estrés: La seguridad financiera afecta positivamente tu salud mental y elimina preocupaciones futuras'
            ],
            fr: 'La finance personnelle signifie gérer vos revenus, contrôler les dépenses, économiser de l\'argent et investir pour l\'avenir. Principes de base: Revenus > Dépenses, objectifs à long terme et gestion des risques. Pourquoi important? Il fournit la liberté financière et réduit le stress.',
            ru: 'Личные финансы означают управление доходами, контроль расходов, экономию денег и инвестирование в будущее. Основные принципы: Доходы > Расходы, долгосрочные цели и управление рисками. Почему важно? Обеспечивает финансовую свободу и снижает стресс.'
          },
          example: { 
            tr: '💡 2025\'te ABD\'de enflasyon %3 civarında seyrederken, ortalama bir aile enflasyona karşı kişisel finans planı yaparak yıllık %5 tasarruf artışı sağladı (kaynak: Federal Reserve raporları).',
            en: '💡 In 2025, while inflation in the US was around 3%, an average family achieved 5% annual savings growth by making a personal finance plan against inflation (source: Federal Reserve reports).',
            es: '💡 En 2025, mientras la inflación en EE.UU. rondaba el 3%, una familia promedio logró un crecimiento del 5% en ahorros anuales haciendo un plan de finanzas personales contra la inflación (fuente: informes de la Reserva Federal).',
            fr: '💡 En 2025, alors que l\'inflation aux ��tats-Unis était d\'environ 3%, une famille moyenne a réalisé une croissance de 5% d\'épargne annuelle en élaborant un plan de finance personnelle contre l\'inflation (source: rapports de la Réserve fédérale).',
            ru: '💡 В 2025 году, когда инфляция в США была около 3%, средняя семья добилась 5% годового роста сбережений, составив план личных финансов против инфляции (источник: отчеты Федерального резерва).'
          },
          icon: <DollarSign className="w-16 h-16 text-green-500" />
        },
        {
          title: { 
            tr: 'Finansal Hedefler Belirleme', 
            en: 'Setting Financial Goals', 
            es: 'Establecer Objetivos Financieros', 
            fr: 'Fixer des Objectifs Financiers', 
            ru: 'Постановка финансовых целей' 
          },
          content: { 
            tr: 'Kısa vadeli (1 yıl: tatil), orta vadeli (5 yıl: ev almak) ve uzun vadeli (emeklilik) hedefler belirleyin. SMART kuralı: Specific, Measurable, Achievable, Relevant, Time-bound. Hedefleri yazın ve düzenli gözden geçirin.',
            en: 'Set short-term (1 year: vacation), medium-term (5 years: buying a house) and long-term (retirement) goals. SMART rule: Specific, Measurable, Achievable, Relevant, Time-bound. Write down goals and review regularly.',
            es: 'Establece objetivos a corto plazo (1 año: vacaciones), mediano plazo (5 años: comprar una casa) y largo plazo (jubilación). Regla SMART: Específico, Medible, Alcanzable, Relevante, Con límite de tiempo. Escribe los objetivos y revísalos regularmente.',
            fr: 'Fixez des objectifs à court terme (1 an: vacances), moyen terme (5 ans: acheter une maison) et long terme (retraite). Règle SMART: Spécifique, Mesurable, Atteignable, Pertinent, Temporellement défini. Écrivez les objectifs et révisez régulièrement.',
            ru: 'Установите краткосрочные (1 год: отпуск), среднесрочные (5 лет: покупка дома) и долгосрочные (пенсия) цели. Правило SMART: Конкретный, Измеримый, Достижимый, Релевантный, Ограниченный по времени. Записывайте цели и регулярно пересматривайте.'
          },
          example: { 
            tr: '🎯 2025\'te Türkiye\'de gençler, ev alma hedefi için aylık 2.000 TL biriktirerek 5 yılda %20 peşinat topluyor; örneğin, bir yazılımcı bu yöntemle İstanbul\'da daire aldı.',
            en: '🎯 In 2025, young people in Turkey are collecting 20% down payment in 5 years by saving 2,000 TL monthly for their home buying goal; for example, a software developer bought an apartment in Istanbul with this method.',
            es: '🎯 En 2025, los jóvenes en Turquía están acumulando un 20% de enganche en 5 años ahorrando 2,000 TL mensuales para su objetivo de comprar casa; por ejemplo, un desarrollador de software compró un apartamento en Estambul con este método.',
            fr: '🎯 En 2025, les jeunes en Turquie accumulent 20% d\'acompte en 5 ans en économisant 2 000 TL par mois pour leur objectif d\'achat de maison; par exemple, un développeur de logiciels a acheté un appartement à Istanbul avec cette méthode.',
            ru: '🎯 В 2025 году молодежь в Турции накапливает 20% первоначального взноса за 5 лет, откладывая 2,000 лир в месяц для цели покупки дома; например, разработчик программного обеспечения купил квартиру в С��амбуле этим методом.'
          },
          icon: <Target className="w-16 h-16 text-blue-500" />
        },
        {
          title: { 
            tr: 'Gelir Kaynaklarını Çeşitlendirme', 
            en: 'Diversifying Income Sources', 
            es: 'Diversificar Fuentes de Ingresos', 
            fr: 'Diversifier les Sources de Revenus', 
            ru: 'Диверсификация источников дохода' 
          },
          content: { 
            tr: 'Ana gelir (maaş) yanı sıra yan işler, yatırımlar veya pasif gelir (kira) ekleyin. Riski azaltır: Bir gelir kaynağı kesilirse diğeri devam eder. Vergi avantajlarını araştırın.',
            en: 'Add side jobs, investments or passive income (rent) alongside main income (salary). Reduces risk: If one income source is cut, another continues. Research tax advantages.',
            es: 'Agrega trabajos secundarios, inversiones o ingresos pasivos (alquiler) junto al ingreso principal (salario). Reduce el riesgo: Si se corta una fuente de ingresos, otra continúa. Investiga las ventajas fiscales.',
            fr: 'Ajoutez des emplois secondaires, des investissements ou des revenus passifs (loyer) aux côtés du revenu principal (salaire). Réduit le risque: Si une source de revenus est coupée, une autre continue. Recherchez les avantages fiscaux.',
            ru: 'Добавьте подработки, инвестиции или пассивный доход (аренда) наряду с основным доходом (зарплата). Снижает риск: Если один источник дохода прекращается, другой продолжается. Исследуйте налоговые преимущества.'
          },
          example: { 
            tr: '💼 2025\'te freelance platformlarında (Upwork) çalışanlar, ana maaşlarına ek %30 gelir elde ediyor; örneğin, bir grafik tasarımcı aylık 1.500 USD ekstra kazanıyor.',
            en: '💼 In 2025, workers on freelance platforms (Upwork) earn 30% additional income on top of their main salaries; for example, a graphic designer earns an extra $1,500 USD monthly.',
            es: '💼 En 2025, los trabajadores en plataformas freelance (Upwork) obtienen un 30% de ingresos adicionales sobre sus salarios principales; por ejemplo, un diseñador gráfico gana $1,500 USD extra mensualmente.',
            fr: '💼 En 2025, les travailleurs sur les plateformes de freelance (Upwork) gagnent 30% de revenus supplémentaires en plus de leurs salaires principaux; par exemple, un graphiste gagne 1 500 USD supplémentaires par mois.',
            ru: '💼 В 2025 году работники на фриланс-платформах (Upwork) получа��т на 30% дополнит��льного дохода сверх основной зарплаты; ��апример, графический дизайнер зарабатывает дополнительно $1,500 в месяц.'
          },
          icon: <TrendingUp className="w-16 h-16 text-purple-500" />
        },
        {
          title: { 
            tr: 'Bütçe Oluşturma Temelleri', 
            en: 'Budget Creation Fundamentals', 
            es: 'Fundamentos de Creación de Presupuesto', 
            fr: 'Fondamentaux de Création de Budget', 
            ru: 'Основы создания бюджета' 
          },
          content: { 
            tr: '50/30/20 kuralı: %50 ihtiyaçlar (yemek, kira), %30 istekler (eğlence), %20 tasarruf/yatırım. Uygulamalar kullanın: Mint veya Excel. Aylık inceleme yapın.',
            en: '50/30/20 rule: 50% needs (food, rent), 30% wants (entertainment), 20% savings/investment. Use apps: Mint or Excel. Do monthly reviews.',
            es: 'Regla 50/30/20: 50% necesidades (comida, alquiler), 30% deseos (entretenimiento), 20% ahorros/inversión. Usa aplicaciones: Mint o Excel. Haz revisiones mensuales.',
            fr: 'Règle 50/30/20: 50% besoins (nourriture, loyer), 30% envies (divertissement), 20% épargne/investissement. Utilisez des applications: Mint ou Excel. Faites des révisions mensuelles.',
            ru: 'Правило 50/30/20: 50% потребности (еда, аренда), 30% желания (развлечения), 20% сбережения/инвестиции. Используйте приложения: Mint или Excel. Проводите ежемесячные обзоры.'
          },
          example: { 
            tr: '📊 2025\'te Avrupa\'da enflasyon nedeniyle aileler bütçelerini %10 kısarak, yıllık 5.000 Euro tasarruf etti; bir İtalyan aile bu kuralı uygulayarak tatil fonu oluşturdu.',
            en: '📊 In 2025, due to inflation in Europe, families cut their budgets by 10%, saving 5,000 Euros annually; an Italian family applied this rule and created a vacation fund.',
            es: '📊 En 2025, debido a la inflación en Europa, las familias recortaron sus presupuestos en un 10%, ahorrando 5,000 Euros anualmente; una familia italiana aplicó esta regla y creó un fondo de vacaciones.',
            fr: '📊 En 2025, en raison de l\'inflation en Europe, les familles ont réduit leurs budgets de 10%, économisant 5 000 Euros par an; une famille italienne a appliqué cette règle et créé un fonds de vacances.',
            ru: '📊 В 2025 году из-за инфляции в Европе семьи сократили бюджеты на 10%, сэкономив 5,000 евро в год; итальянская семья при��енила это правило и создала фонд для отпуска.'
          },
          icon: <BarChart3 className="w-16 h-16 text-blue-500" />
        },
        {
          title: { 
            tr: 'Gider Takibi ve Azaltma', 
            en: 'Expense Tracking and Reduction', 
            es: 'Seguimiento y Reducción de Gastos', 
            fr: 'Suivi et Réduction des Dépenses', 
            ru: 'Отслеживание и сокращение расходов' 
          },
          content: { 
            tr: 'Harcamaları kategorize edin: Sabit (kira) ve değişken (yemek dışı). Gereksizleri kesin: Abonelikleri gözden geçirin. Otomatik takip araçları kullanın.',
            en: 'Categorize expenses: Fixed (rent) and variable (eating out). Cut unnecessary: Review subscriptions. Use automatic tracking tools.',
            es: 'Categoriza los gastos: Fijos (alquiler) y variables (comer fuera). Corta lo innecesario: Revisa las suscripciones. Usa herramientas de seguimiento automático.',
            fr: 'Catégorisez les dépenses: Fixes (loyer) et variables (manger à l\'extérieur). Coupez l\'inutile: Révisez les abonnements. Utilisez des outils de suivi automatique.',
            ru: 'Категоризируйте расходы: Фиксированные (аренда) и переменные (питание вне дома). Урезайте ненужное: Пересмотрите подписки. Используйте автоматические инс��рументы отслеживания.'
          },
          example: { 
            tr: '☕ 2025\'te ABD\'de kahve zincirleri (Starbucks) harcamalarını azaltan bireyler, yıllık 1.000 USD tasarruf etti; bir ofis çalışanı app ile takip ederek araba taksitini erken bitirdi.',
            en: '�� In 2025, individuals in the US who reduced coffee chain (Starbucks) expenses saved $1,000 USD annually; an office worker finished car payments early by tracking with an app.',
            es: '☕ En 2025, individuos en EE.UU. que redujeron gastos en cadenas de café (Starbucks) ahorraron $1,000 USD anualmente; un trabajador de oficina terminó los pagos del auto temprano rastreando con una app.',
            fr: '☕ En 2025, les individus aux États-Unis qui ont réduit les dépenses de chaînes de café (Starbucks) ont économisé 1 000 USD par an; un employé de bureau a terminé les paiements de voiture plus tôt en suivant avec une app.',
            ru: '☕ В 2025 году люди в США, которые сократили расходы на кофейные сети (Starbucks), сэкономили $1,000 в год; офисный работник досрочно закончил выплаты за машину, отслеживая через приложение.'
          },
          icon: <LineChart className="w-16 h-16 text-red-500" />
        },
        {
          title: { 
            tr: 'Tasarruf Stratejileri', 
            en: 'Savings Strategies', 
            es: 'Estrategias de Ahorro', 
            fr: 'Stratégies d\'Épargne', 
            ru: 'Стратегии сбережений' 
          },
          content: { 
            tr: 'Otomatik transfer: Maaşın %10\'unu tasarruf hesabına aktarın. Yüksek faizli hesaplar seçin. Tasarruf meydan okumaları yapın (örneğin, haftalık artan tutar).',
            en: 'Automatic transfer: Transfer 10% of salary to savings account. Choose high-interest accounts. Do savings challenges (e.g., weekly increasing amount).',
            es: 'Transferencia automática: Transfiere el 10% del salario a una cuenta de ahorros. Elige cuentas de alto interés. Haz desafíos de ahorro (ej., cantidad semanal creciente).',
            fr: 'Transfert automatique: Transférez 10% du salaire vers un compte d\'épargne. Choisissez des comptes à haut intérêt. Faites des défis d\'épargne (ex., montant hebdomadaire croissant).',
            ru: 'Автоматический перевод: Переводите 10% зарплаты на накопительный счет. Выбирайте высокопроцентные счета. Участвуйте в вызовах по сбережениям (например, еженедельно увеличивающаяся сумма).'
          },
          example: { 
            tr: '🏦 2025\'te Türkiye\'de faiz oranları %25\'lerdeyken, vadeli hesaplar yıllık %20 getiri sağladı; bir öğretmen 10.000 TL biriktirerek acil durum fonu kurdu.',
            en: '🏦 In 2025, when interest rates in Turkey were around 25%, term deposits provided 20% annual returns; a teacher saved 10,000 TL and established an emergency fund.',
            es: '🏦 En 2025, cuando las tasas de interés en Turquía rondaban el 25%, los depósitos a plazo proporcionaron retornos anuales del 20%; un maestro ahorró 10,000 TL y estableció un fondo de emergencia.',
            fr: '🏦 En 2025, lorsque les taux d\'intérêt en Turquie étaient d\'environ 25%, les dépôts à terme ont fourni des rendements annuels de 20%; un enseignant a économisé 10 000 TL et établi un fonds d\'urgence.',
            ru: '🏦 В 2025 году, когда процентные ставки в Турции были около 25%, срочные вклады давали 20% годовой доходности; учитель накопил 10,000 лир и создал фонд эк��тренных ситуаций.'
          },
          icon: <Coins className="w-16 h-16 text-yellow-500" />
        },
        {
          title: { 
            tr: 'Acil Fon Oluşturma', 
            en: 'Building Emergency Fund', 
            es: 'Construir Fondo de Emergencia', 
            fr: 'Construire un Fonds d\'Urgence', 
            ru: 'Создание фонда экстренных ситуаций' 
          },
          content: { 
            tr: '3-6 aylık gider kadar biriktirin. Likit tutun: Kolay erişilebilir hesapta. Sadece acil durumlar için kullanın (iş kaybı, sağlık).',
            en: 'Save 3-6 months worth of expenses. Keep liquid: In easily accessible account. Use only for emergencies (job loss, health).',
            es: 'Ahorra de 3-6 meses de gastos. Mantén líquido: En cuenta fácilmente accesible. Usa solo para emergencias (pérdida de trabajo, salud).',
            fr: 'Économisez 3-6 mois de dépenses. Gardez liquide: Dans un compte facilement accessible. Utilisez seulement pour les urgences (perte d\'emploi, santé).',
            ru: 'Накопите на 3-6 месяцев расходов. Держите ликвидными: На легкодоступном счете. Используйте только для чрезвычайных ситуаций (потеря работы, здоровье).'
          },
          example: { 
            tr: '🛡️ 2025\'te pandemi sonrası işsizlik dalgasında, acil fonu olan bireyler %40 daha az stres yaşadı; bir freelancer 20.000 TL fonla 3 ay geçindi.',
            en: '🛡️ In 2025, during post-pandemic unemployment waves, individuals with emergency funds experienced 40% less stress; a freelancer survived 3 months with a 20,000 TL fund.',
            es: '🛡️ En 2025, durante las olas de desempleo post-pandemia, individuos con fondos de emergencia experimentaron 40% menos estrés; un freelancer sobrevivió 3 meses con un fondo de 20,000 TL.',
            fr: '🛡️ En 2025, pendant les vagues de chômage post-pandémie, les individus avec des fonds d\'urgence ont connu 40% moins de stress; un freelancer a survécu 3 mois avec un fonds de 20 000 TL.',
            ru: '🛡️ В 2025 году, во время волн безработицы после пандемии, люди с фондами экстренных ситуаций испытывали на 40% меньше стресса; фрил��нсер прожил 3 месяца на фонд в 20,000 лир.'
          },
          icon: <ShieldCheck className="w-16 h-16 text-green-500" />
        },
        {
          title: { 
            tr: 'Borç Yönetimi', 
            en: 'Debt Management', 
            es: 'Gestión de Deudas', 
            fr: 'Gestion des Dettes', 
            ru: 'Управление долгами' 
          },
          content: { 
            tr: 'Borç türleri: İyi (ev kredisi) vs. Kötü (kredi kartı). Kar topu yöntemi: Küçük borçlardan başlayın. Faiz oranlarını müzakere edin.',
            en: 'Debt types: Good (mortgage) vs. Bad (credit card). Snowball method: Start with small debts. Negotiate interest rates.',
            es: 'Tipos de deuda: Buena (hipoteca) vs. Mala (tarjeta de crédito). Método bola de nieve: Empieza con deudas pequeñas. Negocia tasas de interés.',
            fr: 'Types de dettes: Bonnes (hypothèque) vs. Mauvaises (carte de crédit). Méthode boule de neige: Commencez par les petites dettes. Négociez les taux d\'intérêt.',
            ru: 'Типы долгов: Хорошие (ипотека) против плохих (кредитная карта). Метод снежного кома: ��ачните с малых долгов. Договаривайтесь о процентных ставках.'
          },
          example: { 
            tr: '⚡ 2025\'te ABD\'de öğrenci borçları ortalama 30.000 USD; bir mezun kar topu yöntemiyle 5 yılda %50 azalttı.',
            en: '⚡ In 2025, student debts in the US averaged $30,000 USD; a graduate reduced it by 50% in 5 years using the snowball method.',
            es: '⚡ En 2025, las deudas estudiantiles en EE.UU. promediaron $30,000 USD; un graduado la redujo en 50% en 5 años usando el método bola de nieve.',
            fr: '⚡ En 2025, les dettes étudiantes aux États-Unis étaient en moyenne de 30 000 USD; un diplômé l\'a réduite de 50% en 5 ans en utilisant la méthode boule de neige.',
            ru: '⚡ В 2025 году студенческие долги в США составляли в среднем $30,000; выпускник сократил их на 50% за 5 лет, используя метод снежного кома.'
          },
          icon: <Zap className="w-16 h-16 text-orange-500" />
        },
        {
          title: { 
            tr: 'Kredi Kartı Kullanımı', 
            en: 'Credit Card Usage', 
            es: 'Uso de Tarjeta de Crédito', 
            fr: 'Utilisation de Carte de Crédit', 
            ru: 'Использование кредитной карты' 
          },
          content: { 
            tr: 'Tam ödeme yapın: Faizden kaçının. Ödül programlarını kullanın (puan, mil). Limiti aşmayın: Kredi skorunu koruyun.',
            en: 'Pay in full: Avoid interest. Use reward programs (points, miles). Don\'t exceed limit: Protect credit score.',
            es: 'Paga en su totalidad: Evita intereses. Usa programas de recompensas (puntos, millas). No excedas el límite: Protege tu puntaje crediticio.',
            fr: 'Payez en totalité: Évitez les intérêts. Utilisez les programmes de récompenses (points, miles). Ne dépassez pas la limite: Protégez votre score de crédit.',
            ru: 'Платите полностью: Избегайте процентов. Используйте программы вознаграждений (баллы, мили). Не превышайте лимит: Защищайте кредитный рейтинг.'
          },
          example: { 
            tr: '💳 2025\'te Türkiye\'de kredi kartı faizleri %40\'larda; bir aile puanlarla yıllık 500 TL indirim kazandı, ama gecikme cezası ödemeden.',
            en: '💳 In 2025, credit card interest rates in Turkey were around 40%; a family earned 500 TL annual discount with points, but without paying late fees.',
            es: '💳 En 2025, las tasas de interés de tarjetas de crédito en Turquía rondaban el 40%; una familia ganó 500 TL de descuento anual con puntos, pero sin pagar cargos por mora.',
            fr: '💳 En 2025, les taux d\'intérêt des cartes de crédit en Turquie étaient d\'environ 40%; une famille a gagné 500 TL de remise annuelle avec des points, mais sans payer de frais de retard.',
            ru: '💳 В 2025 году процентные ставки по кредитным карт��м в Турции были около 40%; семья заработала 500 лир годовой скидки баллами, но без оплаты штрафов за просрочку.'
          },
          icon: <Heart className="w-16 h-16 text-pink-500" />
        },
        {
          title: { 
            tr: 'Kredi Skoru ve Önemi', 
            en: 'Credit Score and Its Importance', 
            es: 'Puntaje Crediticio y Su Importancia', 
            fr: 'Score de Crédit et Son Importance', 
            ru: 'Кредитный рейтинг и его важность' 
          },
          content: { 
            tr: 'Skor: 300-850 arası, yüksek skor düşük faiz demek. Etkileyen faktörler: Ödeme tarihi (%35), borç kullanımı (%30). Düzenli kontrol edin (Credit Karma gibi).',
            en: 'Score: 300-850 range, high score means low interest. Affecting factors: Payment history (35%), debt utilization (30%). Check regularly (like Credit Karma).',
            es: 'Puntaje: Rango 300-850, puntaje alto significa interés bajo. Factores que afectan: Historial de pagos (35%), utilización de deuda (30%). Verifica regularmente (como Credit Karma).',
            fr: 'Score: Plage 300-850, score élevé signifie intérêt faible. Facteurs affectant: Historique de paiement (35%), utilisation de la dette (30%). Vérifiez régulièrement (comme Credit Karma).',
            ru: 'Рейтинг: Диапазон 300-850, высокий рейтинг означает низкий процент. Влияющие факторы: История платежей (35%), использов��ние долга (30%). Проверяйте регулярно (как Credit Karma).'
          },
          example: { 
            tr: '📊 2025\'te düşük skorlu bireyler ev kredisinde %1 fazla faiz ödüyor; bir girişimci skoru yükselterek iş kredisi aldı.',
            en: '📊 In 2025, individuals with low scores pay 1% more interest on mortgages; an entrepreneur raised their score and got a business loan.',
            es: '📊 En 2025, individuos con puntajes bajos pagan 1% más de interés en hipotecas; un emprendedor subió su puntaje y obtuvo un préstamo comercial.',
            fr: '📊 En 2025, les individus avec des scores bas paient 1% d\'intérêt en plus sur les hypothèques; un entrepreneur a augmenté son score et obtenu un prêt commercial.',
            ru: '📊 В 2025 году люди с низким рейтингом платят на 1% больше проце��тов по ипотеке; предприниматель повысил свой рейтинг и получил бизнес-кредит.'
          },
          icon: <TrendingUp className="w-16 h-16 text-green-600" />
        },
        {
          title: { 
            tr: 'Yatırım Temelleri', 
            en: 'Investment Fundamentals', 
            es: 'Fundamentos de Inversión', 
            fr: 'Fondamentaux d\'Investissement', 
            ru: 'Основы инвестирования' 
          },
          content: { 
            tr: 'Risk ve getiri dengesi: Düşük risk (tahvil) vs. Yüksek (hisse). Çeşitlendirme: Yumurtaları tek sepete koymayın. Uzun vadeli düşünün.',
            en: 'Risk and return balance: Low risk (bonds) vs. High (stocks). Diversification: Don\'t put all eggs in one basket. Think long-term.',
            es: 'Balance riesgo-retorno: Bajo riesgo (bonos) vs. Alto (acciones). Diversificación: No pongas todos los huevos en una canasta. Piensa a largo plazo.',
            fr: 'Équilibre risque-rendement: Faible risque (obligations) vs. Élevé (actions). Diversification: Ne mettez pas tous les œufs dans le même panier. Pensez �� long terme.',
            ru: 'Баланс риска и доходности: Низкий риск (облигации) против высокого (акции). Диверсификация: Не кладите все яйца в одну корзину. Думайте долгосрочно.'
          },
          example: { 
            tr: '📈 2025\'te S&P 500 yıllık %10 getiri sağladı; bir yatırımcı ETF\'lerle çeşitlendirerek %15 kazandı.',
            en: '📈 In 2025, S&P 500 provided 10% annual return; an investor gained 15% by diversifying with ETFs.',
            es: '📈 En 2025, el S&P 500 proporcionó un retorno anual del 10%; un inversionista ganó 15% diversificando con ETFs.',
            fr: '📈 En 2025, le S&P 500 a fourni un rendement annuel de 10%; un investisseur a gagné 15% en diversifiant avec des ETF.',
            ru: '📈 В 2025 году S&P 500 обеспечил 10% год��вой доходности; инвестор заработал 15%, диверсифицируя с помощью ETF.'
          },
          icon: <BarChart3 className="w-16 h-16 text-blue-600" />
        },
        {
          title: { 
            tr: 'Hisse Senetleri Yatırımı', 
            en: 'Stock Investment', 
            es: 'Inversión en Acciones', 
            fr: 'Investissement en Actions', 
            ru: 'Инвестирование в акции' 
          },
          content: { 
            tr: 'Şirket hissesi almak: Büyüme potansiyeli. Araştırma yapın: Finansal raporlar okuyun. Broker kullanın (Robinhood gibi).',
            en: 'Buying company shares: Growth potential. Do research: Read financial reports. Use brokers (like Robinhood).',
            es: 'Comprar acciones de empresa: Potencial de crecimiento. Investiga: Lee informes financieros. Usa brokers (como Robinhood).',
            fr: 'Acheter des actions d\'entreprise: Potentiel de croissance. Faites des recherches: Lisez les rapports financiers. Utilisez des courtiers (comme Robinhood).',
            ru: 'Покупка акций компании: Потенциал роста. Исследуйте: Читайте финансовые отчеты. Используйте брокеров (как Robinhood).'
          },
          example: { 
            tr: '🚀 2025\'te Tesla hisseleri %20 yükseldi; bir genç 1.000 USD yatırımla 200 USD kar etti.',
            en: '🚀 In 2025, Tesla stocks rose 20%; a young person made $200 profit with a $1,000 investment.',
            es: '🚀 En 2025, las acciones de Tesla subieron 20%; un joven hizo $200 de beneficio con una inversión de $1,000.',
            fr: '🚀 En 2025, les actions Tesla ont augmenté de 20%; un jeune a fait 200$ de profit avec un investissement de 1 000$.',
            ru: '🚀 В 2025 году акции Tesla выросли на 20%; молодой человек получил $200 прибыли с инвестицией в $1,000.'
          },
          icon: <LineChart className="w-16 h-16 text-purple-600" />
        },
        {
          title: { 
            tr: 'Tahviller ve Sabit Gelir', 
            en: 'Bonds and Fixed Income', 
            es: 'Bonos y Renta Fija', 
            fr: 'Obligations et Revenus Fixes', 
            ru: 'Облигации и фиксированный доход' 
          },
          content: { 
            tr: '• Devlet veya şirket tahvili: Düzenli faiz geliri sağlar\n• Risk-getiri profili: Düşük risk, düşük getiri\n• Enflasyon korunması: Reel değer kaybına karşı önlem alın\n• Portföy çeşitlendirmesi: Sabit gelirli yatırımlarla riski dengeleyin',
            en: 'Government or corporate bonds: Provide regular interest. Low risk, low return. Protect against inflation.',
            es: 'Bonos gubernamentales o corporativos: Proporcionan interés regular. Bajo riesgo, bajo retorno. Protege contra la inflación.',
            fr: 'Obligations gouvernementales ou d\'entreprise: Fournissent des intérêts réguliers. Faible risque, faible rendement. Protégez contre l\'inflation.',
            ru: 'Государственные или корпоративные облигации: Обеспечивают регулярные проценты. Низкий риск, низкая доходность. Защищайте от инфляции.'
          },
          example: { 
            tr: '💰 2025\'te ABD hazine tahvilleri %4 faiz verdi; emekli bir kişi 50.000 USD yatırımla yıllık 2.000 USD gelir elde etti.',
            en: '💰 In 2025, US Treasury bonds paid 4% interest; a retiree earned $2,000 USD annual income with a $50,000 investment.',
            es: '💰 En 2025, los bonos del Tesoro de EE.UU. pagaron 4% de interés; un jubilado ganó $2,000 USD de ingreso anual con una inversión de $50,000.',
            fr: '💰 En 2025, les obligations du Trésor américain ont payé 4% d\'intérêts; un retraité a gagné 2 000 USD de revenus annuels avec un investissement de 50 000 USD.',
            ru: '💰 В 2025 году облигации казначейства США платили 4% процентов; пенсионер получал $2,000 годового дохода с инвестицией в $50,000.'
          },
          icon: <DollarSign className="w-16 h-16 text-green-600" />
        },
        {
          title: { 
            tr: 'Emeklilik Planlaması', 
            en: 'Retirement Planning', 
            es: 'Planificación de Jubilación', 
            fr: 'Planification de la Retraite', 
            ru: 'Планирование пенсии' 
          },
          content: { 
            tr: '• Özel hesaplar: IRA veya 401(k) gibi vergi avantajlı hesapları kullanın\n• Erken başlama: Bileşik faiz avantajından maksimum faydalanın\n• Hedef belirleme: Emeklilikte mevcut giderlerin %80\'ini karşılayacak birikim\n• Düzenli katkı: Aylık otomatik yatırımlarla disiplinli tasarruf',
            en: 'Use accounts like IRA or 401(k). Start early: Compound interest advantage. Goal: Cover 80% of expenses in retirement.',
            es: 'Usa cuentas como IRA o 401(k). Empieza temprano: Ventaja del interés compuesto. Objetivo: Cubrir el 80% de gastos en la jubilación.',
            fr: 'Utilisez des comptes comme IRA ou 401(k). Commencez tôt: Avantage des intérêts composés. Objectif: Couvrir 80% des dépenses à la retraite.',
            ru: 'Используйте счета типа IRA или 401(k). Начинайте рано: Преимущество сложных процентов. Цель: Покрыть 80% расходов на пенсии.'
          },
          example: { 
            tr: '🏖️ 2025\'te Türkiye\'de BES (Bireysel Emeklilik) devlet katkısı %30; bir çalışan 20 yılda 500.000 TL biriktirdi.',
            en: '🏖️ In 2025, Turkey\'s PPS (Private Pension System) government contribution is 30%; a worker saved 500,000 TL in 20 years.',
            es: '🏖️ En 2025, la contribución gubernamental del SPP (Sistema Privado de Pensiones) de Turquía es del 30%; un trabajador ahorró 500,000 TL en 20 años.',
            fr: '🏖️ En 2025, la contribution gouvernementale du SPP (Système de Pension Privé) de la Turquie est de 30%; un travailleur a économisé 500 000 TL en 20 ans.',
            ru: '🏖️ В 2025 году государственный взнос в ЧПС (Частная пенсионная система) Турции составляет 30%; работник накопил 500,000 лир за 20 лет.'
          },
          icon: <Coffee className="w-16 h-16 text-brown-500" />
        },
        {
          title: { 
            tr: 'Sigorta Çeşitleri', 
            en: 'Insurance Types', 
            es: 'Tipos de Seguros', 
            fr: 'Types d\'Assurance', 
            ru: 'Виды страхования' 
          },
          content: { 
            tr: 'Sa��lık, hayat, araç sigortası: Riskleri azaltır. Poliçeleri karşılaştırın. Yeterli kapsama alın, fazla ödemeyin.',
            en: 'Health, life, auto insurance: Reduces risks. Compare policies. Get adequate coverage, don\'t overpay.',
            es: 'Seguro de salud, vida, auto: Reduce riesgos. Compara pólizas. Obtén cobertura adecuada, no pagues de más.',
            fr: 'Assurance santé, vie, auto: Réduit les risques. Comparez les polices. Obtenez une couverture adéquate, ne payez pas trop.',
            ru: 'Медицинское, жизненное, авт��страхование: Снижает риски. Сравнивайте полисы. Получите адекватное покрытие, не переплачивайте.'
          },
          example: { 
            tr: '🏥 2025\'te sağlık maliyetleri %5 arttı; sigortası olan bir aile hastane masraflarını %90 azalttı.',
            en: '🏥 In 2025, healthcare costs increased 5%; a family with insurance reduced hospital expenses by 90%.',
            es: '🏥 En 2025, los costos de salud aumentaron 5%; una familia con seguro redujo los gastos hospitalarios en 90%.',
            fr: '🏥 En 2025, les coûts de santé ont augmenté de 5%; une famille avec assurance a réduit les dépenses hospitalières de 90%.',
            ru: '🏥 В 2025 году расходы на здравоохранение выросли на 5%; семья со страховкой сократила больничные расходы на 90%.'
          },
          icon: <ShieldCheck className="w-16 h-16 text-blue-600" />
        },
        {
          title: { 
            tr: 'Vergi Planlaması', 
            en: 'Tax Planning', 
            es: 'Planificación Fiscal', 
            fr: 'Planification Fiscale', 
            ru: 'Налоговое планирование' 
          },
          content: { 
            tr: 'Vergi indirimleri: Bağışlar, eğitim giderleri. Roth IRA gibi vergi avantajlı hesaplar. Profesyonel yardım alın.',
            en: 'Tax deductions: Donations, education expenses. Tax-advantaged accounts like Roth IRA. Get professional help.',
            es: 'Deducciones fiscales: Donaciones, gastos de educación. Cuentas con ventajas fiscales como Roth IRA. Obtén ayuda profesional.',
            fr: 'Déductions fiscales: Dons, frais d\'éducation. Comptes avantagés fiscalement comme Roth IRA. Obtenez de l\'aide professionnelle.',
            ru: 'Налоговые вычеты: Пожертвования, расходы на образование. Налогово-выгодные счета типа Roth IRA. Получите профессиональную помощь.'
          },
          example: { 
            tr: '📋 2025\'te ABD\'de elektrikli araç alımı için 7.500 USD vergi kredisi; bir aile bu sayede tasarruf etti.',
            en: '📋 In 2025, there\'s a $7,500 USD tax credit for electric vehicle purchase in the US; a family saved money this way.',
            es: '📋 En 2025, hay un crédito fiscal de $7,500 USD por compra de vehículo eléctrico en EE.UU.; una familia ahorró dinero así.',
            fr: '📋 En 2025, il y a un crédit d\'impôt de 7 500 USD pour l\'achat de véhicule électrique aux États-Unis; une famille a économisé de l\'argent ainsi.',
            ru: '📋 В 2025 году есть налоговый кре��ит $7,500 за покупку электромобиля в США; семья сэкономила деньги таким образом.'
          },
          icon: <BarChart3 className="w-16 h-16 text-gray-600" />
        },
        {
          title: { 
            tr: 'Enflasyon ve Para Değeri', 
            en: 'Inflation and Money Value', 
            es: 'Inflación y Valor del Dinero', 
            fr: 'Inflation et Valeur de l\'Argent', 
            ru: 'Инфляция и стоимость денег' 
          },
          content: { 
            tr: 'Enflasyon: Paranın alım gücü azalır. Yatırımla karşılayın: % enflasyon + %2 getiri hedefleyin. Günlük etki: Kahve fiyatı artışı.',
            en: 'Inflation: Money\'s purchasing power decreases. Counter with investment: Target inflation % + 2% return. Daily impact: Coffee price increase.',
            es: 'Inflación: El poder adquisitivo del dinero disminuye. Contrárrestala con inversión: Apunta a inflación % + 2% de retorno. Impacto diario: Aumento del precio del café.',
            fr: 'Inflation: Le pouvoir d\'achat de l\'argent diminue. Contrecarrez avec l\'investissement: Visez inflation % + 2% de rendement. Impact quotidien: Augmentation du prix du café.',
            ru: 'Инфляция: Покупательная способность денег снижается. Противодействуйте инвестициями: Нацеливайтесь на инфляцию % + 2% доходности. Ежедневное влияние: Рост цены кофе.'
          },
          example: { 
            tr: '📊 2025\'te global enflasyon %3; 100 TL\'lik alışveriş 103 TL oldu, yatırım yapanlar değer korudu.',
            en: '📊 In 2025, global inflation was 3%; 100 TL shopping became 103 TL, investors preserved value.',
            es: '📊 En 2025, la inflación global fue del 3%; las compras de 100 TL se convirtieron en 103 TL, los inversionistas preservaron el valor.',
            fr: '📊 En 2025, l\'inflation mondiale était de 3%; les achats de 100 TL sont devenus 103 TL, les investisseurs ont préservé la valeur.',
            ru: '📊 В 2025 году глобальная инфляция составляла 3%; покупки на 100 лир стали с��оить 103 лиры, инвесторы сохранили стоимость.'
          },
          icon: <TrendingUp className="w-16 h-16 text-red-500" />
        },
        {
          title: { 
            tr: 'Ev Alma Finansmanı', 
            en: 'Home Buying Finance', 
            es: 'Financiamiento para Compra de Casa', 
            fr: 'Financement d\'Achat de Maison', 
            ru: 'Финансирование поку��ки дома' 
          },
          content: { 
            tr: 'Peşinat biriktirin (%20 ideal). Mortgage oranlarını karşılaştırın. Maliyetleri hesaplayın: Vergi, bakım.',
            en: 'Save down payment (20% ideal). Compare mortgage rates. Calculate costs: Tax, maintenance.',
            es: 'Ahorra enganche (20% ideal). Compara tasas hipotecarias. Calcula costos: Impuesto, mantenimiento.',
            fr: 'Économisez l\'acompte (20% idéal). Comparez les taux hypothécaires. Calculez les coûts: Taxe, entretien.',
            ru: 'Накопите первоначальный взнос (20% идеально). Сравните ипотечные ставки. Рассчитайте расходы: Налог, обслуживание.'
          },
          example: { 
            tr: '🏠 2025\'te Türkiye\'de konut kredisi faizleri %15; bir çift 300.000 TL ev için 60.000 TL peşinatla aldı.',
            en: '🏠 In 2025, housing loan rates in Turkey were 15%; a couple bought a 300,000 TL house with 60,000 TL down payment.',
            es: '🏠 En 2025, las tasas de préstamos hipotecarios en Turquía fueron del 15%; una pareja compró una casa de 300,000 TL con 60,000 TL de enganche.',
            fr: '🏠 En 2025, les taux de prêts immobiliers en Turquie étaient de 15%; un couple a acheté une maison de 300 000 TL avec un acompte de 60 000 TL.',
            ru: '🏠 В 2025 году ставки жилищных кредитов в Турции составляли 15%; пара купила дом за 300,000 лир с первоначальным взносом 60,000 лир.'
          },
          icon: <Heart className="w-16 h-16 text-orange-500" />
        },
        {
          title: { 
            tr: 'S��rdürülebilir Finans', 
            en: 'Sustainable Finance', 
            es: 'Finanzas Sostenibles', 
            fr: 'Finance Durable', 
            ru: 'Устойчивые финансы' 
          },
          content: { 
            tr: 'ESG yatırımlar: Çevre, sosyal, yönetişim odaklı. Yeşil tahviller veya etik fonlar. Kişisel etki: Sürdürülebilir harcamalar.',
            en: 'ESG investments: Environment, social, governance focused. Green bonds or ethical funds. Personal impact: Sustainable spending.',
            es: 'Inversiones ESG: Enfocadas en ambiente, social, gobernanza. Bonos verdes o fondos éticos. Impacto personal: Gastos sostenibles.',
            fr: 'Investissements ESG: Axés sur l\'environnement, le social, la gouvernance. Obligations vertes ou fonds éthiques. Impact personnel: Dépenses durables.',
            ru: 'ESG-инвестиции: Ориентированные на окружающую среду, социальные вопросы, управление. Зеленые облигации или этические фонды. Личное влияние: Устойчивые расходы.'
          },
          example: { 
            tr: '🌍 2025\'te ESG fonları %12 getiri sağladı; bir yatırımcı solar enerji hisseleriyle hem kar etti hem çevreye katkı sağladı.',
            en: '🌍 In 2025, ESG funds provided 12% returns; an investor both profited and contributed to the environment with solar energy stocks.',
            es: '🌍 En 2025, los fondos ESG proporcionaron retornos del 12%; un inversionista tanto obtuvo ganancias como contribuyó al ambiente con acciones de energía solar.',
            fr: '🌍 En 2025, les fonds ESG ont fourni des rendements de 12%; un investisseur a à la fois profité et contribué à l\'environnement avec des actions d\'énergie solaire.',
            ru: '🌍 В 2025 году ESG-фонды обеспечили 12% доходности; инв��стор как получил прибыль, так и внес вклад в окружающую среду акциями солнечной энергии.'
          },
          icon: <Heart className="w-16 h-16 text-green-500" />
        },
        {
          title: { 
            tr: 'Finansal Hatalardan Kaçınma ve Sonuç', 
            en: 'Avoiding Financial Mistakes and Conclusion', 
            es: 'Evitar Errores Financieros y Conclusión', 
            fr: 'Éviter les Erreurs Financières et Conclusion', 
            ru: 'Избегание финансовых ошибок и заключение' 
          },
          content: { 
            tr: 'Yaygın hatalar: Duygusal harcama, yatırımda acele. Sürekli öğrenin: Kitaplar, kurslar. Sonuç: Disiplinli finans, özgür hayat.',
            en: 'Common mistakes: Emotional spending, rushing in investment. Keep learning: Books, courses. Conclusion: Disciplined finance, free life.',
            es: 'Errores comunes: Gastos emocionales, prisa en inversión. Sigue aprendiendo: Libros, cursos. Conclusión: Finanzas disciplinadas, vida libre.',
            fr: 'Erreurs courantes: Dépenses émotionnelles, précipitation dans l\'investissement. Continuez à apprendre: Livres, cours. Conclusion: Finance disciplinée, vie libre.',
            ru: 'Распространенные ошибки: Эмоциональные траты, спешка в инвестициях. Продолжайте учиться: Книги, курсы. Заключение: Дисциплинированные финансы, свободная жизнь.'
          },
          example: { 
            tr: '🎯 2025\'te kripto çöküşünde acele edenler %50 kaybetti; sabırlı olanlar Bitcoin\'de %20 kazandı.',
            en: '🎯 In 2025, those who rushed during crypto crash lost 50%; patient ones gained 20% in Bitcoin.',
            es: '🎯 En 2025, quienes se apresuraron durante la caída cripto perdieron 50%; los pacientes ganaron 20% en Bitcoin.',
            fr: '🎯 En 2025, ceux qui se sont précipités pendant le crash crypto ont perdu 50%; les patients ont gagné 20% en Bitcoin.',
            ru: '🎯 В 2025 году те, кто поспешил во время краха криптовалют, потеряли 50%; терпеливые заработали 20% на Bitcoin.'
          },
          icon: <Brain className="w-16 h-16 text-purple-500" />
        }
      ],
      'Markets': [
        {
          title: { 
            tr: 'Finansal Piyasalar', 
            en: 'Financial Markets', 
            es: 'Mercados Financieros', 
            fr: 'Marchés Financiers', 
            ru: 'Финансовые рынки' 
          },
          content: { 
            tr: 'Finansal piyasalar, para ve sermayenin alınıp satıldığı yerlerdir. Borsa, tahvil, döviz ve emtia piyasaları ana kategorilerdir.',
            en: 'Financial markets are places where money and capital are bought and sold. Stock, bond, forex and commodity markets are the main categories.',
            es: 'Los mercados financieros son lugares donde se compra y vende dinero y capital. Los mercados de acciones, bonos, divisas y materias primas son las categorías principales.',
            fr: 'Les marchés financiers sont des lieux où l\'argent et le capital sont achetés et vendus. Les marchés d\'actions, d\'obligations, de change et de matières premières sont les catégories principales.',
            ru: '��инансовые рынки - это места, где покупают и продают деньги и капитал. Фондовые, облигационные, валютные и товарные рынки - основные категории.'
          },
          example: { 
            tr: '📊 Borsa İstanbul\'da günde milyarlarca lira değerinde işlem yapılır.',
            en: '📊 Billions of lira worth of transactions are made daily on Borsa Istanbul.',
            es: '📊 Se realizan transacciones por valor de miles de millones de liras diariamente en Borsa Istanbul.',
            fr: '📊 Des milliards de lires de transactions sont effectuées quotidiennement sur Borsa Istanbul.',
            ru: '📊 На Borsa Istanbul ежедневно совершаются сделки на миллиарды лир.'
          },
          icon: <LineChart className="w-16 h-16 text-blue-500" />
        }
      ],
      'Fundamental': [
        {
          title: { 
            tr: 'Temel Analiz', 
            en: 'Fundamental Analysis', 
            es: 'Análisis Fundamental', 
            fr: 'Analyse Fondamentale', 
            ru: 'Фундаментальный анализ' 
          },
          content: { 
            tr: 'Temel analiz, şirketlerin finansal tablolarını inceleyerek gerçek değerini bulmaya çalışır.',
            en: 'Fundamental analysis attempts to find the true value of companies by examining their financial statements.',
            es: 'El análisis fundamental intenta encontrar el valor real de las empresas examinando sus estados financieros.',
            fr: 'L\'analyse fondamentale tente de trouver la vraie valeur des entreprises en examinant leurs états financiers.',
            ru: 'Фундаментальный анализ пытается найти истинную стоимость компаний, изучая их финансовую отчетность.'
          },
          example: { 
            tr: '📋 Bir şirketin P/E oranı sektör ortalamas��nın altındaysa ucuz olabilir.',
            en: '📋 If a company\'s P/E ratio is below the sector average, it might be cheap.',
            es: '📋 Si el ratio P/E de una empresa está por debajo del promedio del sector, podría estar barata.',
            fr: '📋 Si le ratio P/E d\'une entreprise est en dessous de la moyenne du secteur, elle pourrait être bon marché.',
            ru: '📋 Если коэффициент P/E компании ниже среднего по сектору, она может быть дешевой.'
          },
          icon: <Target className="w-16 h-16 text-indigo-500" />
        }
      ],
      'Risk': [
        {
          title: { 
            tr: 'Risk Yönetimi', 
            en: 'Risk Management', 
            es: 'Gestión de Riesgos', 
            fr: 'Gestion des Risques', 
            ru: 'Управление рисками' 
          },
          content: { 
            tr: 'Risk yönetimi, potansiyel kayıpları sınırlamak ve sermayeyi korumak için kullanılan stratejilerin bütünüdür.',
            en: 'Risk management is a set of strategies used to limit potential losses and protect capital.',
            es: 'La gestión de riesgos es un conjunto de estrategias utilizadas para limitar pérdidas potenciales y proteger el capital.',
            fr: 'La gestion des risques est un ensemble de stratégies utilisées pour limiter les pertes potentielles et protéger le capital.',
            ru: 'Управление рисками - это набор стратегий, используемых для ограничения потенциальных потерь и защиты капитала.'
          },
          example: { 
            tr: '⚠️ Stop-Loss Örneği: 100₺\'ye aldığınız hisseye 90₺\'de stop koyarsanız, maksimum %10 zarar edersiniz.',
            en: '⚠️ Stop-Loss Example: If you put a stop at 90₺ for a stock bought at 100₺, you lose maximum 10%.',
            es: '⚠️ Ejemplo Stop-Loss: Si pones un stop en 90₺ para una acción comprada a 100₺, pierdes máximo 10%.',
            fr: '⚠️ Exemple Stop-Loss: Si vous mettez un stop à 90₺ pour une action achetée à 100₺, vous perdez maximum 10%.',
            ru: '⚠️ Пример стоп-лосса: Если вы поставите стоп на 90₺ для акции, купленной за 100₺, вы потеряете максимум 10%.'
          },
          icon: <ShieldCheck className="w-16 h-16 text-green-600" />
        }
      ],
      'Psychology': [
        {
          title: { 
            tr: 'İşlem Psikolojisi', 
            en: 'Trading Psychology', 
            es: 'Psicología del Trading', 
            fr: 'Psychologie du Trading', 
            ru: 'Психология трейдинга' 
          },
          content: { 
            tr: 'Başarılı işlem yapmanın %80\'i psikolojidir. Duygular kontrol edilmezse kayıplara yol açar.',
            en: '80% of successful trading is psychology. Uncontrolled emotions lead to losses.',
            es: 'El 80% del trading exitoso es psicología. Las emociones no controladas llevan a pérdidas.',
            fr: '80% du trading réussi est de la psychologie. Les émotions non contrôlées mènent aux pertes.',
            ru: '80% успешной торговли - это психология. Неконтролируемые эмоции приводят к потерям.'
          },
          example: { 
            tr: '😰 FOMO Örneği: "Herkes Bitcoin alıyor, ben de almalıyım!" düşüncesi genellikle zirve fiyatlarda alım yapmaya yol açar.',
            en: '😰 FOMO Example: "Everyone is buying Bitcoin, I should too!" thinking usually leads to buying at peak prices.',
            es: '😰 Ejemplo FOMO: "¡Todos están comprando Bitcoin, yo también debería!" el pensamiento usualmente lleva a comprar a precios pico.',
            fr: '😰 Exemple FOMO: "Tout le monde achète du Bitcoin, je devrais aussi!" la pensée mène généralement à acheter aux prix de pointe.',
            ru: '😰 Пример FOMO: "Все покупают биткоин, я тоже должен!" мышление обычно приводит к покупке на пиковых ценах.'
          },
          icon: <Brain className="w-16 h-16 text-pink-500" />
        }
      ],
      'Algorithmic': [
        {
          title: { 
            tr: 'Algoritmik İşlemler', 
            en: 'Algorithmic Trading', 
            es: 'Trading Algorítmico', 
            fr: 'Trading Algorithmique', 
            ru: 'Алг��ритмическая торговля' 
          },
          content: { 
            tr: 'Algoritmik işlemler, önceden belirlenen kurallara göre otomatik alım-satım yapan sistemlerdir.',
            en: 'Algorithmic trading systems automatically buy and sell according to predetermined rules.',
            es: 'Los sistemas de trading algorítmico compran y venden automáticamente según reglas predeterminadas.',
            fr: 'Les systèmes de trading algorithmique achètent et vendent automatiquement selon des règles prédéterminées.',
            ru: 'Алгоритмические торговые системы автоматически покупают и продают согласно заранее определенным правилам.'
          },
          example: { 
            tr: '🤖 Örnek: RSI 30 altına düştüğünde otomatik alım, 70 üstüne çıktığında satım yapan bot.',
            en: '🤖 Example: Bot that automatically buys when RSI drops below 30, sells when it rises above 70.',
            es: '🤖 Ejemplo: Bot que compra automáticamente cuando RSI cae por debajo de 30, vende cuando sube por encima de 70.',
            fr: '🤖 Exemple: Bot qui achète automatiquement quand RSI tombe sous 30, vend quand il monte au-dessus de 70.',
            ru: '🤖 Пример: Бот, который автоматически покупает, когда RSI падает ниже 30, продает, когда поднимается выше 70.'
          },
          icon: <Zap className="w-16 h-16 text-purple-500" />
        }
      ]
    }

    // Use external slide files for specific categories
    if (category === 'Algorithmic') {
      return algorithmicTradingSlides
    }
    
    if (category === 'Economics') {
      return economicsSlides
    }
    
    if (category === 'Analysis') {
      if (course.level === 'Advanced') {
        return advancedTechnicalAnalysisSlides
      }
      return technicalAnalysisSlides
    }
    

    
    if (category === 'Fundamental') {
      return fundamentalAnalysisSlides
    }
    
    if (category === 'Markets') {
      return financialMarketsSlides
    }
    
    if (category === 'Risk') {
      return riskManagementSlides
    }
    
    if (category === 'Psychology') {
      return tradingPsychologySlides
    }
    
    if (category === 'Personal Finance') {
      return personalFinanceSlides
    }
    
    if (category === 'Derivatives') {
      return DerivativesMarketsSlides
    }

    // Return slides for the category, or default slide if category not found
    return slides[category] || [{
      title: { 
        tr: 'Eğitime Hoş Geldiniz', 
        en: 'Welcome to Learning', 
        es: 'Bienvenido al Aprendizaje', 
        fr: 'Bienvenue à l\'Apprentissage', 
        ru: 'Добро пожаловать в обучение' 
      },
      content: { 
        tr: 'Bu kursta öğreneceğiniz bilgiler ile finansal dünyayı daha iyi anlayacaksınız.',
        en: 'With the knowledge you will learn in this course, you will better understand the financial world.',
        es: 'Con el conocimiento que aprenderás en este curso, entenderás mejor el mundo financiero.',
        fr: 'Avec les connaissances que vous apprendrez dans ce cours, vous comprendrez mieux le monde financier.',
        ru: 'С знаниями, которые вы получите в этом курсе, вы лучше поймете финансовый мир.'
      },
      example: { 
        tr: '💡 Bu kurs ile kariyerinizde önemli adımlar atacaksınız.',
        en: '💡 With this course, you will take important steps in your career.',
        es: '💡 Con este curso, darás pasos importantes en tu carrera.',
        fr: '💡 Avec ce cours, vous ferez des pas importants dans votre carrière.',
        ru: '💡 С этим курсом вы сделаете важные шаги в своей карьере.'
      },
      icon: <BookOpen className="w-16 h-16 text-blue-500" />
    }]
  }

  // Get quiz data for different categories
  const getQuizData = (category: string) => {
    // Use external quiz for Financial Markets
    if (category === 'Markets' || category === 'Financial Markets') {
      return financialMarketsQuiz
    }
    
    // Use external quiz for Personal Finance
    if (category === 'Finance' || category === 'Personal Finance' || category === 'Kişisel Finans') {
      return personalFinanceQuiz
    }
    
    // Use external quiz for Fundamental Analysis
    if (category === 'Analysis' || category === 'Fundamental Analysis' || category === 'Temel Analiz') {
      return fundamentalAnalysisQuiz
    }
    
    // Use external quiz for Risk Management
    if (category === 'Risk' || category === 'Risk Management' || category === 'Risk Yönetimi') {
      return riskManagementQuiz
    }
    
    // Use external quiz for Trading Psychology
    if (category === 'Psychology' || category === 'Trading Psychology' || category === 'İşlem Psikolojisi') {
      return tradingPsychologyQuiz
    }
    
    const quizzes: { [key: string]: any[] } = {
      'Economics': [
        {
          question: { 
            tr: 'Ekonominin temel sorusu nedir?', 
            en: 'What is the basic question of economics?', 
            es: '¿Cuál es la pregunta básica de la economía?', 
            fr: 'Quelle est la question fondamentale de l\'économie?', 
            ru: 'Какой основной вопрос экономики?' 
          },
          options: { 
            tr: ['Sınırsız kaynakları nasıl kullanmal��yız?', 'Sınırlı kaynakları nas��l kullanmalıyız?', 'Para nasıl basılır?', 'Bankalar nasıl çalışır?'],
            en: ['How should we use unlimited resources?', 'How should we use limited resources?', 'How is money printed?', 'How do banks work?'],
            es: ['¿Cómo debemos usar recursos ilimitados?', '¿Cómo debemos usar recursos limitados?', '¿Cómo se imprime el dinero?', '¿Cómo funcionan los bancos?'],
            fr: ['Comment devons-nous utiliser des ressources illimitées?', 'Comment devons-nous utiliser des ressources limitées?', 'Comment l\'argent est-il imprimé?', 'Comment les banques fonctionnent-elles?'],
            ru: ['Как нам использ��вать неограниченные ресурсы?', 'Как нам использовать ограниченные ресурсы?', 'Как печатают деньги?', 'Как работают банки?']
          },
          correct: 1
        },
        {
          question: { 
            tr: 'Enflasyon nedir?', 
            en: 'What is inflation?', 
            es: '¿Qué es la inflación?', 
            fr: 'Qu\'est-ce que l\'inflation?', 
            ru: 'Что такое инфляция?' 
          },
          options: { 
            tr: ['Fiyatların düşmesi', 'Fiyatların yükselmesi', 'Para basımı', 'Faiz artışı'],
            en: ['Price decrease', 'Price increase', 'Money printing', 'Interest increase'],
            es: ['Disminución de precios', 'Aumento de precios', 'Impresión de dinero', 'Aumento de intereses'],
            fr: ['Baisse des prix', 'Hausse des prix', 'Impression d\'argent', 'Augmentation des intérêts'],
            ru: ['Снижение цен', 'Повышение цен', 'Печать денег', 'Повышение процентной ставки']
          },
          correct: 1
        }
      ],
      'Analysis': [
        {
          question: { 
            tr: 'RSI 70 üstünde olması ne anlama gelir?', 
            en: 'What does RSI being above 70 mean?', 
            es: '¿Qué significa que RSI esté por encima de 70?', 
            fr: 'Que signifie un RSI au-dessus de 70?', 
            ru: 'Что означает RSI выше 70?' 
          },
          options: { 
            tr: ['Aşırı satış', 'Aşırı alım', 'Normal durum', 'Trend değişimi'],
            en: ['Oversold', 'Overbought', 'Normal condition', 'Trend change'],
            es: ['Sobreventa', 'Sobrecompra', 'Condición normal', 'Cambio de tendencia'],
            fr: ['Survente', 'Surachat', 'Condition normale', 'Changement de tendance'],
            ru: ['Перепроданность', 'Перекупленность', 'Нормальное состояние', 'Изме��ение ��ренда']
          },
          correct: 1
        }
      ],
      'Personal Finance': [
        {
          question: { 
            tr: '50/30/20 kuralında %50 neyi temsil eder?', 
            en: 'In the 50/30/20 rule, what does 50% represent?', 
            es: 'En la regla 50/30/20, ¿qué representa el 50%?', 
            fr: 'Dans la règle 50/30/20, que représente 50%?', 
            ru: 'В правиле 50/30/20, что представляет 50%?' 
          },
          options: { 
            tr: ['Tasarruf', 'İhtiyaçlar', 'İstekler', 'Yatırım'],
            en: ['Savings', 'Needs', 'Wants', 'Investment'],
            es: ['Ahorros', 'Necesidades', 'Deseos', 'Inversión'],
            fr: ['Épargne', 'Besoins', 'Envies', 'Investissement'],
            ru: ['Сбережения', 'Потребности', 'Желания', 'Инвестиции']
          },
          correct: 1
        }
      ],
      'Markets': [
        {
          question: { 
            tr: 'Finansal piyasaların temel işlevlerinden biri nedir?', 
            en: 'What is one of the main functions of financial markets?', 
            es: '¿Cuál es una de las funciones principales de los mercados financieros?', 
            fr: 'Quelle est l\'une des fonctions principales des marchés financiers?', 
            ru: 'Какова одна из основных функций финансовых ��ынков?' 
          },
          options: { 
            tr: ['Sadece para yaratmak', 'Kaynak dağılımı ve fiyat keşfi', 'Vergi toplamak', 'Enflasyonu artırmak'],
            en: ['Only creating money', 'Resource allocation and price discovery', 'Collecting taxes', 'Increasing inflation'],
            es: ['Solo crear dinero', 'Asignación de recursos y descubrimiento de precios', 'Recoger impuestos', 'Aumentar inflación'],
            fr: ['Créer seulement de l\'argent', 'Allocation des ressources et découverte des prix', 'Collecter des impôts', 'Augmenter l\'inflation'],
            ru: ['Только создание денег', 'Распределение ресурсов и ценообразование', 'Сбор налогов', 'Увеличение инфляции']
          },
          correct: 1
        },
        {
          question: { 
            tr: 'Faiz oranları yükseldiğinde tahvil fiyatları nasıl etkilenir?', 
            en: 'How are bond prices affected when interest rates rise?', 
            es: '¿Cómo se ven afectados los precios de los bonos cuando suben las tasas de interés?', 
            fr: 'Comment les prix des obligations sont-ils affectés lorsque les taux d\'intérêt augmentent?', 
            ru: 'Как влияют на цены облигаций повышение процентных ставок?' 
          },
          options: { 
            tr: ['Yükselir', 'Düşer', 'Değişmez', 'Dalgalanır'],
            en: ['Rise', 'Fall', 'Stay same', 'Fluctuate'],
            es: ['Suben', 'Bajan', 'Permanecen igual', 'Fluctúan'],
            fr: ['Montent', 'Baissent', 'Restent identiques', 'Fluctuent'],
            ru: ['Растут', 'Падают', 'Остаются прежними', 'Колеблются']
          },
          correct: 1
        },
        {
          question: { 
            tr: 'Türev piyasalarda future ve opsiyon arasındaki temel fark nedir?', 
            en: 'What is the main difference between futures and options in derivative markets?', 
            es: '¿Cuál es la diferencia principal entre futuros y opciones en mercados de derivados?', 
            fr: 'Quelle est la différence principale entre futures et options dans les marchés dérivés?', 
            ru: 'В чем основная разница между фьючерсами и опционами на рынках деривативов?' 
          },
          options: { 
            tr: ['Future zorunluluk, opsiyon hak verir', 'Opsiyon zorunluluk, future hak verir', 'İkisi de aynı', 'Hiçbir fark yok'],
            en: ['Futures obligate, options give right', 'Options obligate, futures give right', 'Both are same', 'No difference'],
            es: ['Futuros obligan, opciones dan derecho', 'Opciones obligan, futuros dan derecho', 'Ambos son iguales', 'No hay diferencia'],
            fr: ['Futures obligent, options donnent droit', 'Options obligent, futures donnent droit', 'Les deux sont pareils', 'Aucune différence'],
            ru: ['Фьючерсы обязывают, опционы дают право', 'Опционы обязывают, фьючерсы дают право', 'Оба одинаковы', 'Никакой разницы']
          },
          correct: 0
        },
        {
          question: { 
            tr: 'Davranışsal finansta "sürü psikolojisi" ne anlama gelir?', 
            en: 'What does "herd mentality" mean in behavioral finance?', 
            es: '¿Qué significa "mentalidad de rebaño" en finanzas conductuales?', 
            fr: 'Que signifie "mentalité de troupeau" en finance comportementale?', 
            ru: 'Что означает "стадный менталитет" в поведенческих финансах?' 
          },
          options: { 
            tr: ['Bireysel karar verme', 'Toplumun aksini yapma', 'Çoğunluğu takip etme eğilimi', 'Uzman görüşü alma'],
            en: ['Individual decision making', 'Doing opposite of society', 'Tendency to follow majority', 'Getting expert opinion'],
            es: ['Toma de decisiones individual', 'Hacer lo opuesto a la sociedad', 'Tendencia a seguir mayoría', 'Obtener opinión experta'],
            fr: ['Prise de décision individuelle', 'Faire opposé de la société', 'Tendance à suivre majorité', 'Obtenir avis d\'expert'],
            ru: ['Индивидуальное принятие решений', 'Делать противоположное обществу', '��енде��ция следовать большинству', 'Получение экспертного мнения']
          },
          correct: 2
        },
        {
          question: { 
            tr: 'Portföy yönetiminde çeşitlendirmenin amacı nedir?', 
            en: 'What is the purpose of diversification in portfolio management?', 
            es: '¿Cuál es el propósito de la diversificación en gestión de cartera?', 
            fr: 'Quel est le but de la diversification dans la gestion de portefeuille?', 
            ru: 'Какова цель диверсификации в управлении портфелем?' 
          },
          options: { 
            tr: ['Getiriyi maksimize etmek', 'Riski minimize etmek', 'İşlem sayısını artırmak', 'Vergiyi azaltmak'],
            en: ['Maximize return', 'Minimize risk', 'Increase transactions', 'Reduce taxes'],
            es: ['Maximizar retorno', 'Minimizar riesgo', 'Aumentar transacciones', 'Reducir impuestos'],
            fr: ['Maximiser rendement', 'Minimiser risque', 'Augmenter transactions', 'Réduire impôts'],
            ru: ['Максимизировать доходность', 'Минимизировать риск', 'Увеличить транзакции', 'Снизить налоги']
          },
          correct: 1
        }
      ],
      'Risk': [
        {
          question: { 
            tr: 'VaR (Value at Risk) ne anlama gelir?', 
            en: 'What does VaR (Value at Risk) mean?', 
            es: '¿Qué significa VaR (Valor en Riesgo)?', 
            fr: 'Que signifie VaR (Valeur à Risque)?', 
            ru: 'Что означает VaR (Стоимость под риском)?' 
          },
          options: { 
            tr: ['Belirli olasılıkta maksimum kayıp', 'Minimum getiri', 'Ortalama risk', 'Toplam değer'],
            en: ['Maximum loss at certain probability', 'Minimum return', 'Average risk', 'Total value'],
            es: ['Pérdida máxima en cierta probabilidad', 'Retorno mínimo', 'Riesgo promedio', 'Valor total'],
            fr: ['Perte maximale à certaine probabilité', 'Rendement minimum', 'Risque moyen', 'Valeur totale'],
            ru: ['Максимальные потери при определенной вероятности', 'Минимальная доходность', 'Средний риск', 'Общая стоимость']
          },
          correct: 0
        },
        {
          question: { 
            tr: 'Hedging stratejisinin amacı nedir?', 
            en: 'What is the purpose of hedging strategy?', 
            es: '¿Cuál es el propósito de la estrategia de cobertura?', 
            fr: 'Quel est l\'objectif de la stratégie de couverture?', 
            ru: 'Какова ц��ль стратегии хеджирования?' 
          },
          options: { 
            tr: ['Getiriyi maksimize etmek', 'Riski dengelemek', 'Spekülatif kazanç', 'İşlem hacmini artırmak'],
            en: ['Maximize return', 'Balance risk', 'Speculative gain', 'Increase trading volume'],
            es: ['Maximizar retorno', 'Equilibrar riesgo', 'Ganancia especulativa', 'Aumentar volumen de trading'],
            fr: ['Maximiser rendement', 'Équilibrer risque', 'Gain spéculatif', 'Augmenter volume de trading'],
            ru: ['Максимизировать доходность', 'Сбалансировать риск', 'Спекулятивная прибыль', 'Увеличить объем торгов']
          },
          correct: 1
        },
        {
          question: { 
            tr: 'Finansal türevlerin temel kullanım alanları nelerdir?', 
            en: 'What are the main uses of financial derivatives?', 
            es: '¿Cuáles son los principales usos de los derivados financieros?', 
            fr: 'Quels sont les principaux usages des produits dérivés financiers?', 
            ru: 'Каковы основные области применения финансовых деривативов?' 
          },
          options: { 
            tr: ['Sadece spekülasyon', 'Riskten korunma ve spekülasyon', 'Sadece arbitraj', 'Vergi avantajı'],
            en: ['Only speculation', 'Risk hedging and speculation', 'Only arbitrage', 'Tax advantage'],
            es: ['Solo especulación', 'Cobertura de riesgo y especulación', 'Solo arbitraje', 'Ventaja fiscal'],
            fr: ['Seulement spéculation', 'Couverture de risque et spéculation', 'Seulement arbitrage', 'Avantage fiscal'],
            ru: ['Только спекуляция', 'Хеджирование риска и спекуляция', 'Только арбитраж', 'Налоговое преимущество']
          },
          correct: 1
        },
        {
          question: { 
            tr: 'ESG risklerinin yönetiminde en etkili yöntem nedir?', 
            en: 'What is the most effective method in managing ESG risks?', 
            es: '¿Cuál es el método más efectivo en la gestión de riesgos ESG?', 
            fr: 'Quelle est la méthode la plus efficace dans la gestion des risques ESG?', 
            ru: 'Какой самый эффективный метод управления ESG-рисками?' 
          },
          options: { 
            tr: ['ESG uyumlu yatırımlar', 'Sadece geleneksel analiz', 'Kısa vadeli yat��rım', 'Spekülatif işlemler'],
            en: ['ESG compliant investments', 'Only traditional analysis', 'Short-term investment', 'Speculative transactions'],
            es: ['Inversiones conformes con ESG', 'Solo análisis tradicional', 'Inversión a corto plazo', 'Transacciones especulativas'],
            fr: ['Investissements conformes ESG', 'Seulement analyse traditionnelle', 'Investissement court terme', 'Transactions spéculatives'],
            ru: ['ESG-совместимые инвестиции', 'Только традиционный анализ', 'Краткосрочные инвестиции', 'Спекулятивные сделки']
          },
          correct: 0
        },
        {
          question: { 
            tr: 'Stres testinin amacı nedir?', 
            en: 'What is the purpose of stress testing?', 
            es: '¿Cuál es el propósito de las pruebas de estrés?', 
            fr: 'Quel est l\'objectif des tests de stress?', 
            ru: 'Какова цель стресс-тестирования?' 
          },
          options: { 
            tr: ['Aşırı senaryoları simüle etme', 'Normal koşulları test etme', 'Kar tahmini yapma', 'Vergi hesaplama'],
            en: ['Simulate extreme scenarios', 'Test normal conditions', 'Make profit forecast', 'Calculate taxes'],
            es: ['Simular escenarios extremos', 'Probar condiciones normales', 'Hacer pronóstico de ganancias', 'Calcular impuestos'],
            fr: ['Simuler scénarios extrêmes', 'Tester conditions normales', 'Faire prévision de profit', 'Calculer impôts'],
            ru: ['Моделировать экстремальные сценарии', 'Тестировать нормальные условия', 'Делать прогноз прибыли', 'Рассчитывать налоги']
          },
          correct: 0
        }
      ],
      'Psychology': [
        {
          question: { 
            tr: 'Başarılı işlem yapmanın yüzde kaçı psikoloji ile ilgilidir?', 
            en: 'What percentage of successful trading is related to psychology?', 
            es: '¿Qué porcentaje del trading exitoso está relacionado con la psicología?', 
            fr: 'Quel pourcentage du trading réussi est lié à la psychologie?', 
            ru: 'Какой процент успешного трейдинга связан с психологией?' 
          },
          options: { 
            tr: ['20%', '50%', '80%', '100%'],
            en: ['20%', '50%', '80%', '100%'],
            es: ['20%', '50%', '80%', '100%'],
            fr: ['20%', '50%', '80%', '100%'],
            ru: ['20%', '50%', '80%', '100%']
          },
          correct: 2
        },
        {
          question: { 
            tr: 'FOMO ne anlama gelir?', 
            en: 'What does FOMO stand for?', 
            es: '¿Qué significa FOMO?', 
            fr: 'Que signifie FOMO?', 
            ru: 'Что означает FOMO?' 
          },
          options: { 
            tr: ['Fear of Missing Out', 'Fear of Money Operations', 'Focus on Market Orders', 'Fast Options Market Orders'],
            en: ['Fear of Missing Out', 'Fear of Money Operations', 'Focus on Market Orders', 'Fast Options Market Orders'],
            es: ['Fear of Missing Out', 'Fear of Money Operations', 'Focus on Market Orders', 'Fast Options Market Orders'],
            fr: ['Fear of Missing Out', 'Fear of Money Operations', 'Focus on Market Orders', 'Fast Options Market Orders'],
            ru: ['Fear of Missing Out', 'Fear of Money Operations', 'Focus on Market Orders', 'Fast Options Market Orders']
          },
          correct: 0
        },
        {
          question: { 
            tr: 'Kayıp kaçınma önyargısının tipik sonucu nedir?', 
            en: 'What is the typical result of loss aversion bias?', 
            es: '¿Cuál es el resultado típico del sesgo de aversión a pérdidas?', 
            fr: 'Quel est le résultat typique du biais d\'aversion aux pertes?', 
            ru: 'Какой типичный результат предрассудка неприятия потерь?' 
          },
          options: { 
            tr: ['Zarar eden pozisyonları tutma, kârlı olanları erken satma', 'Kârlı pozisyonları tutma', 'Riski artırma', 'Daha fazla yatırım yapma'],
            en: ['Holding losing positions, selling profitable ones early', 'Holding profitable positions', 'Increasing risk', 'Making more investments'],
            es: ['Mantener posiciones perdedoras, vender las rentables temprano', 'Mantener posiciones rentables', 'Aumentar riesgo', 'Hacer más inversiones'],
            fr: ['Garder positions perdantes, vendre rentables tôt', 'Garder positions rentables', 'Augmenter risque', 'Faire plus d\'investissements'],
            ru: ['Удержание убыточных позиций, ранняя продажа прибыльных', 'Удержание прибыльных позиций', 'Увеличение риска', 'Больше инвестиций']
          },
          correct: 0
        },
        {
          question: { 
            tr: 'İşlem psikolojisinde mindfulness\'ın faydası nedir?', 
            en: 'What is the benefit of mindfulness in trading psychology?', 
            es: '¿Cuál es el beneficio del mindfulness en psicología del trading?', 
            fr: 'Quel est le bénéfice du mindfulness en psychologie du trading?', 
            ru: 'В чем польза осознанности в психологии трейдинга?' 
          },
          options: { 
            tr: ['Daha hızlı işlem yapma', 'Stresi azaltır, odaklanmayı artırır', 'Daha fazla risk alma', 'Işlem sayısını artırma'],
            en: ['Trading faster', 'Reduces stress, increases focus', 'Taking more risk', 'Increasing number of trades'],
            es: ['Tradear más rápido', 'Reduce estrés, aumenta foco', 'Tomar más riesgo', 'Aumentar número de trades'],
            fr: ['Trader plus vite', 'Réduit stress, augmente focus', 'Prendre plus de risque', 'Augmenter nombre de trades'],
            ru: ['Торговать бы��трее', 'Снижает стресс, повышает фокус', 'Принимать больше рисков', 'Увеличивать количество сделок']
          },
          correct: 1
        },
        {
          question: { 
            tr: 'Stop-loss emrinin psikolojik faydası nedir?', 
            en: 'What is the psychological benefit of stop-loss orders?', 
            es: '¿Cuál es el beneficio psicológico de las órdenes stop-loss?', 
            fr: 'Quel est le bénéfice psychologique des ordres stop-loss?', 
            ru: 'В чем психологическая польза стоп-лосс ордеров?' 
          },
          options: { 
            tr: ['Daha fazla kâr sağlar', 'Duygusal kararları engeller', 'İşlem hızını artırır', 'Piyasa analizini geliştirir'],
            en: ['Provides more profit', 'Prevents emotional decisions', 'Increases trading speed', 'Improves market analysis'],
            es: ['Proporciona más ganancia', 'Previene decisiones emocionales', 'Aumenta velocidad de trading', 'Mejora análisis de mercado'],
            fr: ['Fournit plus de profit', 'Prévient décisions émotionnelles', 'Augmente vitesse de trading', 'Améliore analyse marché'],
            ru: ['Обеспечивает больше прибыли', 'Предотвращает эмоциональные решения', 'Увеличивает скорость торговли', 'Улучшает анализ рынка']
          },
          correct: 1
        }
      ],
      'Algorithmic': [
        {
          question: { 
            tr: 'Algoritmik işlem nedir?',
            en: 'What is algorithmic trading?',
            es: '¿Qué es el trading algorítmico?',
            fr: 'Qu\'est-ce que le trading algorithmique?',
            ru: 'Что такое алгоритмическая торговля?'
          },
          options: { 
            tr: ['İnsanların duygularıyla yaptığı işlem', 'Bilgisayarların belirlenmiş kurallarla otomatik işlem yapması', 'Sadece büyük yatırımcıların kullandığı sistem', 'Hiç işlem yapılmaması'],
            en: ['Trading done by humans with emotions', 'Computers making automatic trades with predetermined rules', 'System used only by large investors', 'Not making any trades'],
            es: ['Trading hecho por humanos con emociones', 'Computadoras haciendo operaciones automáticas con reglas predeterminadas', 'Sistema usado solo por grandes inversores', 'No hacer ninguna operación'],
            fr: ['Trading fait par humains avec émotions', 'Ordinateurs faisant des transactions automatiques avec règles prédéterminées', 'Système utilisé seulement par grands investisseurs', 'Ne faire aucune transaction'],
            ru: ['Торговля людьми с эмоциями', 'Компьютеры совершают автоматические сделки по заранее определенным правилам', 'Система, используемая только крупными инвесторами', 'Не совершать никаких сделок']
          },
          correct: 1
        },
        {
          question: { 
            tr: 'Algoritmalar neden duygusal hatalardan korunur?',
            en: 'Why are algorithms protected from emotional errors?',
            es: '¿Por qué los algoritmos están protegidos de errores emocionales?',
            fr: 'Pourquoi les algorithmes sont-ils protégés des erreurs émotionnelles?',
            ru: 'Почему алгоритмы защищены от эмоциональных ошибок?'
          },
          options: { 
            tr: ['Çünkü bilgisayarların korkusu ve açgözlülüğü yoktur', 'Çünkü bilgisayar uyuyabilir', 'Çünkü algoritmalar yavaş çalışır', 'Çünkü internet yoktur'],
            en: ['Because computers have no fear and greed', 'Because computers can sleep', 'Because algorithms work slowly', 'Because there is no internet'],
            es: ['Porque las computadoras no tienen miedo ni avaricia', 'Porque las computadoras pueden dormir', 'Porque los algoritmos trabajan lentamente', 'Porque no hay internet'],
            fr: ['Parce que les ordinateurs n\'ont pas de peur ni d\'avidité', 'Parce que les ordinateurs peuvent dormir', 'Parce que les algorithmes travaillent lentement', 'Parce qu\'il n\'y a pas d\'internet'],
            ru: ['Потому что у компьютеров нет страха и жадности', 'Потому что компьютеры могут спать', 'Потому что алгоритмы работают медленно', 'Потому что нет интернета']
          },
          correct: 0
        },
        {
          question: { 
            tr: 'HFT (High-Frequency Trading) ne kadar hızlı işlem yapar?', 
            en: 'How fast does HFT (High-Frequency Trading) execute trades?', 
            es: '¿Qué tan rápido ejecuta operaciones HFT (Trading de Alta Frecuencia)?', 
            fr: 'À quelle vitesse HFT (Trading Haute Fréquence) exécute-t-il des opérations?', 
            ru: 'Как быстро HFT (высокочастотная торговля) выполняет сделки?' 
          },
          options: { 
            tr: ['Dakikada onlarca', 'Saniyede onlarca', 'Saniyede yüzlerce', 'Saniyede binlerce'],
            en: ['Tens per minute', 'Tens per second', 'Hundreds per second', 'Thousands per second'],
            es: ['Decenas por minuto', 'Decenas por segundo', 'Cientos por segundo', 'Miles por segundo'],
            fr: ['Dizaines par minute', 'Dizaines par seconde', 'Centaines par seconde', 'Milliers par seconde'],
            ru: ['Десятки в минуту', 'Десятки в секунду', 'Сотни в секунду', 'Тысячи в секунду']
          },
          correct: 3
        },
        {
          question: { 
            tr: 'Algoritmik işlemde hangi veri türü kullanılmaz?', 
            en: 'Which type of data is NOT used in algorithmic trading?', 
            es: '¿Qué tipo de datos NO se usa en trading algorítmico?', 
            fr: 'Quel type de données N\'EST PAS utilis�� en trading algorithmique?', 
            ru: 'Какой тип данных НЕ используется в алгоритмической торговле?' 
          },
          options: { 
            tr: ['Fiyat verileri', 'Haberler', 'Sosyal medya', 'Kişisel günlük'],
            en: ['Price data', 'News', 'Social media', 'Personal diary'],
            es: ['Datos de precios', 'Noticias', 'Redes sociales', 'Diario personal'],
            fr: ['Données de prix', 'Nouvelles', 'Médias sociaux', 'Journal personnel'],
            ru: ['Ценовые данные', 'Новости', 'Социальные сети', 'Личный дневник']
          },
          correct: 3
        },
        {
          question: { 
            tr: 'Algoritmik işlemlerde risk yönetimi için hangisi kullanılır?', 
            en: 'What is used for risk management in algorithmic trading?', 
            es: '¿Qué se usa para gestión de riesgo en trading algorítmico?', 
            fr: 'Qu\'est-ce qui est utilisé pour la gestion des risques en trading algorithmique?', 
            ru: 'Что используется для управления рисками в алгоритмической торговле?' 
          },
          options: { 
            tr: ['Stop-loss limitleri', 'Daha fazla para yatırma', 'İşlem sayısını artırma', 'Hızlı alım-satım'],
            en: ['Stop-loss limits', 'Investing more money', 'Increasing trade count', 'Rapid trading'],
            es: ['Límites stop-loss', 'Invertir más dinero', 'Aumentar número de operaciones', 'Trading rápido'],
            fr: ['Limites stop-loss', 'Investir plus d\'argent', 'Augmenter nombre d\'opérations', 'Trading rapide'],
            ru: ['Лимиты стоп-лосс', 'Инвестирование большего количества денег', 'Увеличение количества сделок', 'Быстрая торговля']
          },
          correct: 0
        },
        {
          question: { 
            tr: 'Algoritmik işlemlerin en büyük avantajı nedir?',
            en: 'What is the biggest advantage of algorithmic trading?',
            es: '¿Cuál es la mayor ventaja del trading algorítmico?',
            fr: 'Quel est le plus grand avantage du trading algorithmique?',
            ru: 'Каково самое большое преимущество алгоритмической торговли?'
          },
          options: { 
            tr: ['Daha hızlı işlem yapabilmesi', 'Daha yavaş işlem yapması', 'Yanlış haberlerle işlem yapması', 'İnsan kararlarını kopyalaması'],
            en: ['Being able to trade faster', 'Trading slower', 'Trading with false news', 'Copying human decisions'],
            es: ['Poder operar más rápido', 'Operar más lento', 'Operar con noticias falsas', 'Copiar decisiones humanas'],
            fr: ['Pouvoir trader plus vite', 'Trader plus lentement', 'Trader avec de fausses nouvelles', 'Copier les décisions humaines'],
            ru: ['Возможность торговать быстрее', 'Торговать медленнее', 'Торговать с ложными новостями', 'Копировать человеческие решения']
          },
          correct: 0
        },
        {
          question: { 
            tr: 'Hacim ağırlıklı ortalama fiyat (VWAP) algoritması ne işe yarar?',
            en: 'What does Volume Weighted Average Price (VWAP) algorithm do?',
            es: '¿Qué hace el algoritmo de Precio Promedio Ponderado por Volumen (VWAP)?',
            fr: 'Que fait l\'algorithme de Prix Moyen Pondéré par Volume (VWAP)?',
            ru: 'Что делает алгоритм средневзвешенной по объему цены (VWAP)?'
          },
          options: { 
            tr: ['İşlemleri rastgele yapar', 'Fiyatların ortalamasına göre alım-satım yapar', 'İnsanların duygularına göre karar verir', 'Sadece gece çalışır'],
            en: ['Makes trades randomly', 'Makes buy-sell decisions based on price averages', 'Makes decisions based on human emotions', 'Only works at night'],
            es: ['Hace operaciones al azar', 'Hace decisiones de compra-venta basadas en promedios de precios', 'Toma decisiones basadas en emociones humanas', 'Solo funciona de noche'],
            fr: ['Fait des transactions aléatoirement', 'Prend des décisions d\'achat-vente basées sur moyennes de prix', 'Prend des décisions basées sur émotions humaines', 'Ne fonctionne que la nuit'],
            ru: ['Совершает сделки случайно', 'Принимает решения о покупке-продаже на основе средних цен', 'Принимает решения на основе человеческих эмоций', 'Работает только ночью']
          },
          correct: 1
        },
        {
          question: { 
            tr: 'Yüksek frekanslı işlemin (HFT) özelliği nedir?',
            en: 'What is the characteristic of High Frequency Trading (HFT)?',
            es: '¿Cuál es la característica del Trading de Alta Frecuencia (HFT)?',
            fr: 'Quelle est la caractéristique du Trading Haute Fréquence (HFT)?',
            ru: 'Какова характеристика высокочастотной торговли (HFT)?'
          },
          options: { 
            tr: ['Çok yavaş çalışır', 'Saniyenin milyonda biri hızında işlem yapabilir', 'Sadece altın için çalışır', 'İnternet olmadan çalışır'],
            en: ['Works very slowly', 'Can make trades in microseconds', 'Only works for gold', 'Works without internet'],
            es: ['Funciona muy lentamente', 'Puede hacer operaciones en microsegundos', 'Solo funciona para oro', 'Funciona sin internet'],
            fr: ['Fonctionne très lentement', 'Peut faire des transactions en microsecondes', 'Ne fonctionne que pour l\'or', 'Fonctionne sans internet'],
            ru: ['Работает очень медленно', 'Может совершать сделки в микросекундах', 'Работает только с золотом', 'Работает без интернета']
          },
          correct: 1
        },
        {
          question: { 
            tr: 'Ortalama dönüşü stratejisinde temel fikir nedir?',
            en: 'What is the basic idea in mean reversion strategy?',
            es: '¿Cuál es la idea básica en la estrategia de reversión a la media?',
            fr: 'Quelle est l\'idée de base dans la stratégie de retour à la moyenne?',
            ru: 'Какова основная идея стратегии возврата к среднему?'
          },
          options: { 
            tr: ['Fiyatlar yükseldikçe daha da yükselecek', 'Fiyatlar düştükçe hep düşmeye devam edecek', 'Fiyatlar ortalamadan uzaklaşınca yeniden ortalamaya döner', 'Fiyatlar tamamen rastgele hareket eder'],
            en: ['Prices will keep rising as they rise', 'Prices will keep falling as they fall', 'Prices return to average when they deviate from it', 'Prices move completely randomly'],
            es: ['Los precios seguirán subiendo mientras suban', 'Los precios seguirán bajando mientras bajen', 'Los precios vuelven al promedio cuando se desvían de él', 'Los precios se mueven completamente al azar'],
            fr: ['Les prix continueront à monter en montant', 'Les prix continueront à baisser en baissant', 'Les prix retournent à la moyenne quand ils s\'en écartent', 'Les prix bougent complètement aléatoirement'],
            ru: ['Цены будут продолжать расти по мере роста', 'Цены будут продолжать падать по мере падения', 'Цены возвращаются к среднему, когда отклоняются от него', 'Цены движутся совершенно случайно']
          },
          correct: 2
        },
        {
          question: { 
            tr: 'Acil durdurma mekanizması (kill switch) ne işe yarar?',
            en: 'What does the emergency stop mechanism (kill switch) do?',
            es: '¿Qué hace el mecanismo de parada de emergencia (kill switch)?',
            fr: 'Que fait le mécanisme d\'arrêt d\'urgence (kill switch)?',
            ru: 'Что делает механизм экстренной остановки (kill switch)?'
          },
          options: { 
            tr: ['Daha çok kâr yapar', 'Acil durumda algoritmayı kapatır', 'Fiyatları yükseltir', 'Daha hızlı internet sağlar'],
            en: ['Makes more profit', 'Shuts down the algorithm in emergency', 'Raises prices', 'Provides faster internet'],
            es: ['Hace más ganancia', 'Cierra el algoritmo en emergencia', 'Sube los precios', 'Proporciona internet más rápido'],
            fr: ['Fait plus de profit', 'Ferme l\'algorithme en urgence', 'Augmente les prix', 'Fournit internet plus rapide'],
            ru: ['Приносит больше прибыли', 'Отключает алгоритм в экстренной ситуации', 'Повышает цены', 'Обеспечивает более быстрый интернет']
          },
          correct: 1
        },
        {
          question: { 
            tr: 'Algoritmik işlemde yapılan en büyük hatalardan biri "aşırı uyum (overfitting)"dur. Bu ne demektir?',
            en: 'One of the biggest mistakes in algorithmic trading is "overfitting". What does this mean?',
            es: 'Uno de los mayores errores en trading algorítmico es "overfitting". ¿Qué significa esto?',
            fr: 'Une des plus grosses erreurs en trading algorithmique est "overfitting". Que signifie ceci?',
            ru: 'Одна из самых больших ошибок в алгоритмической торговле - "переобучение". Что это означает?'
          },
          options: { 
            tr: ['Algoritmanın geçmiş verilere çok fazla uyum sağlaması ve gelecekte işe yaramaması', 'Algoritmanın hiç işlem yapmaması', 'Algoritmanın çok yavaş çalışması', 'Algoritmanın duygusal kararlar alması'],
            en: ['Algorithm adapting too much to historical data and not working in the future', 'Algorithm not making any trades', 'Algorithm working too slowly', 'Algorithm making emotional decisions'],
            es: ['Algoritmo adaptándose demasiado a datos históricos y no funcionando en el futuro', 'Algoritmo no haciendo ninguna operación', 'Algoritmo funcionando muy lentamente', 'Algoritmo tomando decisiones emocionales'],
            fr: ['Algorithme s\'adaptant trop aux données historiques et ne fonctionnant pas dans le futur', 'Algorithme ne faisant aucune transaction', 'Algorithme fonctionnant trop lentement', 'Algorithme prenant des décisions émotionnelles'],
            ru: ['Алгоритм слишком сильно адаптируется к историческим данным и не работает в будущем', 'Алгоритм не совершает никаких сделок', 'Алгоритм работает слишком медленно', 'Алгоритм принимает эмоциональные решения']
          },
          correct: 0
        },
        {
          question: { 
            tr: 'Aşağıdakilerden hangisi iyi bir risk yönetimi örneğidir?',
            en: 'Which of the following is a good risk management example?',
            es: '¿Cuál de los siguientes es un buen ejemplo de gestión de riesgo?',
            fr: 'Lequel des suivants est un bon exemple de gestion des risques?',
            ru: 'Какой из следующих является хорошим примером управления рисками?'
          },
          options: { 
            tr: ['Hiç zarar etmeyeceğini düşünmek', 'Zarar durdurma (stop-loss) kullanmak', 'Tüm parayı tek hisseye yatırmak', 'Rastgele işlem yapmak'],
            en: ['Thinking you will never lose', 'Using stop-loss', 'Investing all money in one stock', 'Making random trades'],
            es: ['Pensar que nunca perderás', 'Usar stop-loss', 'Invertir todo el dinero en una acción', 'Hacer operaciones aleatorias'],
            fr: ['Penser que vous ne perdrez jamais', 'Utiliser stop-loss', 'Investir tout l\'argent dans une action', 'Faire des transactions aléatoires'],
            ru: ['Думать, что вы никогда не проиграете', 'Использовать стоп-лосс', 'Инвестировать все деньги в одну акцию', 'Совершать случайные сделки']
          },
          correct: 1
        },
        {
          question: { 
            tr: 'Algoritmik işlemlerde en çok kullanılan programlama dili hangisidir?',
            en: 'Which is the most used programming language in algorithmic trading?',
            es: '¿Cuál es el lenguaje de programación más usado en trading algorítmico?',
            fr: 'Quel est le langage de programmation le plus utilisé en trading algorithmique?',
            ru: 'Какой язык программирования наиболее используется в алгоритмической торговле?'
          },
          options: { 
            tr: ['Python', 'Arapça', 'PHP', 'Word'],
            en: ['Python', 'Arabic', 'PHP', 'Word'],
            es: ['Python', 'Árabe', 'PHP', 'Word'],
            fr: ['Python', 'Arabe', 'PHP', 'Word'],
            ru: ['Python', 'Арабский', 'PHP', 'Word']
          },
          correct: 0
        },
        {
          question: { 
            tr: 'Algoritmalar hangi verilerle çalışabilir?',
            en: 'What data can algorithms work with?',
            es: '¿Con qué datos pueden trabajar los algoritmos?',
            fr: 'Avec quelles données les algorithmes peuvent-ils travailler?',
            ru: 'С какими данными могут работать алгоритмы?'
          },
          options: { 
            tr: ['Sadece fiyat verisi', 'Fiyat, haberler, sosyal medya, hatta uydu görüntüleri', 'Sadece kahve fiyatları', 'Hiç veri kullanmaz'],
            en: ['Only price data', 'Price, news, social media, even satellite images', 'Only coffee prices', 'Uses no data'],
            es: ['Solo datos de precio', 'Precio, noticias, redes sociales, incluso imágenes satelitales', 'Solo precios del café', 'No usa datos'],
            fr: ['Seulement données de prix', 'Prix, nouvelles, réseaux sociaux, même images satellite', 'Seulement prix du café', 'N\'utilise aucune donnée'],
            ru: ['Только ценовые данные', 'Цены, новости, социальные сети, даже спутниковые изображения', 'Только цены на кофе', 'Не использует данные']
          },
          correct: 1
        },
        {
          question: { 
            tr: 'Bulut (cloud) tabanlı sistemlerin avantajı nedir?',
            en: 'What is the advantage of cloud-based systems?',
            es: '¿Cuál es la ventaja de los sistemas basados en la nube?',
            fr: 'Quel est l\'avantage des systèmes basés sur le cloud?',
            ru: 'В чем преимущество облачных систем?'
          },
          options: { 
            tr: ['Dünyanın her yerinden erişim ve düşük maliyet', 'Sadece ofisten kullanılabilmesi', 'İnternetsiz çalışması', 'Sadece tek bilgisayarda çalışması'],
            en: ['Access from anywhere in the world and low cost', 'Can only be used from office', 'Works without internet', 'Only works on one computer'],
            es: ['Acceso desde cualquier lugar del mundo y bajo costo', 'Solo puede usarse desde la oficina', 'Funciona sin internet', 'Solo funciona en una computadora'],
            fr: ['Accès de partout dans le monde et faible coût', 'Ne peut être utilisé que depuis le bureau', 'Fonctionne sans internet', 'Ne fonctionne que sur un ordinateur'],
            ru: ['Доступ из любой точки мира и низкая стоимость', 'Можно использовать только из офиса', 'Работает без интернета', 'Работает только на одном компьютере']
          },
          correct: 0
        },
        {
          question: { 
            tr: 'Kuantum bilgisayarlar algoritmik işlemlerde neyi hızlandırabilir?',
            en: 'What can quantum computers accelerate in algorithmic trading?',
            es: '¿Qué pueden acelerar las computadoras cuánticas en trading algorítmico?',
            fr: 'Que peuvent accélérer les ordinateurs quantiques en trading algorithmique?',
            ru: 'Что могут ускорить квантовые компьютеры в алгоритмической торговле?'
          },
          options: { 
            tr: ['Çay demlemeyi', 'Portföy optimizasyonunu', 'Telefon konuşmalarını', 'Grafik çizmeyi'],
            en: ['Tea brewing', 'Portfolio optimization', 'Phone conversations', 'Drawing graphics'],
            es: ['Preparar té', 'Optimización de cartera', 'Conversaciones telefónicas', 'Dibujar gráficos'],
            fr: ['Infuser le thé', 'Optimisation de portefeuille', 'Conversations téléphoniques', 'Dessiner des graphiques'],
            ru: ['Заваривание чая', 'Оптимизацию портфеля', 'Телефонные разговоры', 'Рисование графиков']
          },
          correct: 1
        },
        {
          question: { 
            tr: 'Merkeziyetsiz finans (DeFi) içinde algoritmalar ne yapabilir?',
            en: 'What can algorithms do in Decentralized Finance (DeFi)?',
            es: '¿Qué pueden hacer los algoritmos en Finanzas Descentralizadas (DeFi)?',
            fr: 'Que peuvent faire les algorithmes en Finance Décentralisée (DeFi)?',
            ru: 'Что могут делать алгоритмы в децентрализованных финансах (DeFi)?'
          },
          options: { 
            tr: ['Otomatik piyasa yapıcılık (AMM)', 'Rüya yorumlama', 'Astroloji tahmini', 'Rastgele sayı üretme'],
            en: ['Automated Market Making (AMM)', 'Dream interpretation', 'Astrology prediction', 'Random number generation'],
            es: ['Creación Automática de Mercado (AMM)', 'Interpretación de sueños', 'Predicción astrológica', 'Generación de números aleatorios'],
            fr: ['Création de Marché Automatisée (AMM)', 'Interprétation des rêves', 'Prédiction astrologique', 'Génération de nombres aléatoires'],
            ru: ['Автоматизированное создание рынка (AMM)', 'Толкование снов', 'Астрологические предсказания', 'Генерация случайных чисел']
          },
          correct: 0
        },
        {
          question: { 
            tr: 'Yapay zekâ (örneğin ChatGPT gibi modeller) algoritmik işlemlerde nerede faydalı olabilir?',
            en: 'Where can artificial intelligence (like ChatGPT models) be useful in algorithmic trading?',
            es: '¿Dónde puede ser útil la inteligencia artificial (como modelos ChatGPT) en trading algorítmico?',
            fr: 'Où l\'intelligence artificielle (comme les modèles ChatGPT) peut-elle être utile en trading algorithmique?',
            ru: 'Где искусственный интеллект (как модели ChatGPT) может быть полезен в алгоритмической торговле?'
          },
          options: { 
            tr: ['Haber ve duygu analizinde', 'Yemek tariflerinde', 'Spor tahminlerinde', 'Hava durumunu değiştirmekte'],
            en: ['In news and sentiment analysis', 'In cooking recipes', 'In sports predictions', 'In changing weather'],
            es: ['En análisis de noticias y sentimientos', 'En recetas de cocina', 'En predicciones deportivas', 'En cambiar el clima'],
            fr: ['Dans l\'analyse des nouvelles et des sentiments', 'Dans les recettes de cuisine', 'Dans les prédictions sportives', 'Dans le changement de météo'],
            ru: ['В анализе новостей и настроений', 'В кулинарных рецептах', 'В спортивных прогнозах', 'В изменении погоды']
          },
          correct: 0
        },
        {
          question: { 
            tr: 'Algoritmik işlemin yatırımcıya sağladığı en önemli 3 avantajdan hangisi değildir?',
            en: 'Which is NOT one of the 3 most important advantages algorithmic trading provides to investors?',
            es: '¿Cuál NO es una de las 3 ventajas más importantes que el trading algorítmico proporciona a los inversores?',
            fr: 'Lequel N\'est PAS l\'un des 3 avantages les plus importants que le trading algorithmique apporte aux investisseurs?',
            ru: 'Что НЕ является одним из 3 наиболее важных преимуществ, которые алгоритмическая торговля предоставляет инвесторам?'
          },
          options: { 
            tr: ['Hızlı işlem yapma', 'Duygusal kararlardan kaçınma', 'Sürekli piyasa takibi', 'Daha pahalı maliyetler'],
            en: ['Fast trading execution', 'Avoiding emotional decisions', 'Continuous market monitoring', 'Higher costs'],
            es: ['Ejecución rápida de operaciones', 'Evitar decisiones emocionales', 'Monitoreo continuo del mercado', 'Costos más altos'],
            fr: ['Exécution rapide des transactions', 'Éviter les décisions émotionnelles', 'Surveillance continue du marché', 'Coûts plus élevés'],
            ru: ['Быстрое исполнение сделок', 'Избежание эмоциональных решений', 'Непрерывный мониторинг рынка', 'Более высокие затраты']
          },
          correct: 3
        },
        {
          question: { 
            tr: 'Gelecekte algoritmalar insanlardan hangi konuda en fazla üstünlük sağlayacak?',
            en: 'In which area will algorithms have the greatest advantage over humans in the future?',
            es: '¿En qué área tendrán los algoritmos la mayor ventaja sobre los humanos en el futuro?',
            fr: 'Dans quel domaine les algorithmes auront-ils le plus grand avantage sur les humains à l\'avenir?',
            ru: 'В какой области алгоритмы будут иметь наибольшее преимущество перед людьми в будущем?'
          },
          options: { 
            tr: ['Yaratıcı düşünce', 'Hızlı veri işleme ve analiz', 'Sosyal ilişkiler kurma', 'Sanatsal değerlendirme'],
            en: ['Creative thinking', 'Fast data processing and analysis', 'Building social relationships', 'Artistic evaluation'],
            es: ['Pensamiento creativo', 'Procesamiento y análisis rápido de datos', 'Construir relaciones sociales', 'Evaluación artística'],
            fr: ['Pensée créative', 'Traitement et analyse rapides des données', 'Construire des relations sociales', 'Évaluation artistique'],
            ru: ['Творческое мышление', 'Быстрая обработка и анализ данных', 'Построение социальных отношений', 'Художественная оценка']
          },
          correct: 1
        },
        {
          question: { 
            tr: 'Yapay zekâ ile algoritmik işlem birleştiğinde en muhtemel yenilik hangisi olacaktır?',
            en: 'What will be the most likely innovation when AI combines with algorithmic trading?',
            es: '¿Cuál será la innovación más probable cuando la IA se combine con el trading algorítmico?',
            fr: 'Quelle sera l\'innovation la plus probable quand l\'IA se combine avec le trading algorithmique?',
            ru: 'Какой будет наиболее вероятная инновация, когда ИИ объединится с алгоритмической торговлей?'
          },
          options: { 
            tr: ['Tamamen insan kontrolsüz işlem', 'Kendi kendine öğrenen ve adapte olan sistemler', 'Sadece kripto para işlemleri', 'Daha yavaş karar verme süreçleri'],
            en: ['Completely human-free trading', 'Self-learning and adaptive systems', 'Only cryptocurrency trading', 'Slower decision-making processes'],
            es: ['Trading completamente libre de humanos', 'Sistemas que aprenden y se adaptan por sí mismos', 'Solo trading de criptomonedas', 'Procesos de toma de decisiones más lentos'],
            fr: ['Trading complètement sans humains', 'Systèmes qui apprennent et s\'adaptent par eux-mêmes', 'Seulement trading de cryptomonnaies', 'Processus de prise de décision plus lents'],
            ru: ['Полностью безлюдная торговля', 'Самообучающиеся и адаптивные системы', 'Только торговля криптовалютами', 'Более медленные процессы принятия решений']
          },
          correct: 1
        }
      ],
      'Fundamental': [
        {
          question: { 
            tr: 'ROE (Özkaynak Kârlılığı) nasıl hesaplanır?', 
            en: 'How is ROE (Return on Equity) calculated?', 
            es: '¿Cómo se calcula ROE (Retorno sobre Patrimonio)?', 
            fr: 'Comment calcule-t-on ROE (Retour sur Capitaux Propres)?', 
            ru: 'Как рассчитывается ROE (Рентабельность собственного капитала)?' 
          },
          options: { 
            tr: ['Net Kâr / Toplam Aktif', 'Net Kâr / Özkaynak', 'Brüt Kâr / Satışlar', 'EBIT / Faiz Gideri'],
            en: ['Net Profit / Total Assets', 'Net Profit / Equity', 'Gross Profit / Sales', 'EBIT / Interest Expense'],
            es: ['Ganancia Neta / Activos Totales', 'Ganancia Neta / Patrimonio', 'Ganancia Bruta / Ventas', 'EBIT / Gastos de Interés'],
            fr: ['Profit Net / Actifs Totaux', 'Profit Net / Capitaux Propres', 'Profit Brut / Ventes', 'EBIT / Charges d\'Intérêt'],
            ru: ['Чистая прибыль / Общие активы', 'Чистая прибыль / Собственный капитал', 'Валовая прибыль / Продажи', 'EBIT / Процентные расходы']
          },
          correct: 1
        },
        {
          question: { 
            tr: 'Cari oran (Current Ratio) 1\'in altında olması ne anlama gelir?', 
            en: 'What does a Current Ratio below 1 mean?', 
            es: '¿Qué significa un Ratio Corriente por debajo de 1?', 
            fr: 'Que signifie un Ratio de Liquidité Générale inférieur à 1?', 
            ru: 'Что означает коэффициент текущей ликвидности ниже 1?' 
          },
          options: { 
            tr: ['Çok iyi likidite', 'Kısa vadeli borç ödeme zorluğu', 'Normal durum', 'Yüksek kârlılık'],
            en: ['Very good liquidity', 'Difficulty paying short-term debt', 'Normal situation', 'High profitability'],
            es: ['Muy buena liquidez', 'Dificultad para pagar deuda a corto plazo', 'Situación normal', 'Alta rentabilidad'],
            fr: ['Très bonne liquidité', 'Difficulté à payer la dette à court terme', 'Situation normale', 'Haute rentabilité'],
            ru: ['Очень хорошая ликвидность', 'Трудности с погашением краткосрочного долга', 'Нормальная ситуация', 'Высокая прибыльность']
          },
          correct: 1
        },
        {
          question: { 
            tr: 'DCF (İndirgenmiş Nakit Akışı) modelinde hangi oran kullanılır?', 
            en: 'Which rate is used in DCF (Discounted Cash Flow) model?', 
            es: '¿Qué tasa se usa en el modelo DCF (Flujo de Efectivo Descontado)?', 
            fr: 'Quel taux est utilisé dans le modèle DCF (Flux de Trésorerie Actualisé)?', 
            ru: 'Какая ставка используется в модели DCF (Дисконтированный денежный поток)?' 
          },
          options: { 
            tr: ['Enflasyon oranı', 'WACC (Ağırlıklı ortalama sermaye maliyeti)', 'Faiz oranı', 'Büyüme oranı'],
            en: ['Inflation rate', 'WACC (Weighted Average Cost of Capital)', 'Interest rate', 'Growth rate'],
            es: ['Tasa de inflación', 'WACC (Costo Promedio Ponderado de Capital)', 'Tasa de interés', 'Tasa de crecimiento'],
            fr: ['Taux d\'inflation', 'WACC (Coût Moyen Pondéré du Capital)', 'Taux d\'intérêt', 'Taux de croissance'],
            ru: ['Уровень инфляции', 'WACC (Средневзвешенная стоимость капитала)', 'Процентная ставка', 'Темп роста']
          },
          correct: 1
        }
      ]
    }

    return quizzes[category] || [
      {
        question: { 
          tr: 'Bu kurs hakkında ne öğrendiniz?', 
          en: 'What did you learn about this course?', 
          es: '¿Qué aprendiste sobre este curso?', 
          fr: 'Qu\'avez-vous appris sur ce cours?', 
          ru: 'Что вы узнали об этом курсе?' 
        },
        options: { 
          tr: ['Çok şey', 'Biraz', 'Az', 'Hiçbir şey'],
          en: ['A lot', 'Some', 'Little', 'Nothing'],
          es: ['Mucho', 'Algo', 'Poco', 'Nada'],
          fr: ['Beaucoup', 'Un peu', 'Peu', 'Rien'],
          ru: ['Много', 'Немного', 'Мало', 'Ничего']
        },
        correct: 0
      }
    ]
  }

  const slides = getEducationSlides(course.category) || []
  const currentSlideData = slides && slides[currentSlide] ? slides[currentSlide] : null
  
  const quizData = getQuizData(course.category) || []
  
  const exitLearning = () => {
    setIsLearning(false)
    setCurrentSlide(0)
    setSlidesCompleted(false)
    setQuizAnswers({})
    setShowResults(false)
  }
  


  const nextSlide = () => {
    if (slides && currentSlide < slides.length - 1) {
      setCurrentSlide(currentSlide + 1)
    } else {
      setSlidesCompleted(true)
    }
  }

  // Function to format text with colon-ended subheadings
  const formatTextWithSubheadings = (text: string | undefined) => {
    if (!text || typeof text !== 'string') {
      return text || ''
    }
    
    // Split by bullet points or line breaks
    const parts = text.split(/([•·]|\n)/g)
    
    return parts.map((part, index) => {
      if (!part || part === '•' || part === '·' || part === '\n') {
        return part
      }
      
      // Check if this part contains text ending with colon
      const colonMatch = part.match(/^(.+?:)(.*)$/)
      if (colonMatch) {
        const [, beforeColon, afterColon] = colonMatch
        return (
          <span key={index}>
            <span className="font-medium">{beforeColon}</span>
            {afterColon}
          </span>
        )
      }
      
      return part
    })
  }

  const prevSlide = () => {
    if (currentSlide > 0) {
      setCurrentSlide(currentSlide - 1)
    }
  }

  const handleQuizAnswer = (questionIndex: number, answer: number | boolean | string) => {
    setQuizAnswers({
      ...quizAnswers,
      [questionIndex]: answer
    })
  }

  const submitQuiz = () => {
    setShowResults(true)
  }

  const calculateScore = () => {
    const correct = quizData.reduce((acc, question, index) => {
      const userAnswer = quizAnswers[index]
      const isCorrect = userAnswer === question.correct
      return acc + (isCorrect ? 1 : 0)
    }, 0)
    const percentage = (correct / quizData.length) * 100
    return { correct, total: quizData.length, percentage }
  }

  const getBadgeInfo = (percentage: number) => {
    if (percentage >= 95) {
      return {
        titleKey: 'badge.perfect_expert.title',
        descriptionKey: 'badge.perfect_expert.description',
        icon: '🏆',
        gradient: 'from-yellow-400 to-yellow-600'
      }
    } else if (percentage >= 85) {
      return {
        titleKey: 'badge.gold_expert.title',
        descriptionKey: 'badge.gold_expert.description',
        icon: '🥇',
        gradient: 'from-yellow-500 to-orange-500'
      }
    } else if (percentage >= 75) {
      return {
        titleKey: 'badge.silver_expert.title',
        descriptionKey: 'badge.silver_expert.description',
        icon: '🥈',
        gradient: 'from-gray-400 to-gray-600'
      }
    } else if (percentage >= 60) {
      return {
        titleKey: 'badge.bronze_expert.title',
        descriptionKey: 'badge.bronze_expert.description',
        icon: '🥉',
        gradient: 'from-orange-600 to-red-600'
      }
    }
    return null
  }

  const getWrongAnswers = () => {
    return quizData.map((question, index) => ({
      question,
      questionIndex: index,
      userAnswer: quizAnswers[index],
      isCorrect: quizAnswers[index] === question.correct
    })).filter(item => !item.isCorrect)
  }

  const restartQuiz = () => {
    setQuizAnswers({})
    setShowResults(false)
  }

  // If learning mode is active, show slides
  if (isLearning) {
    // Show quiz results
    if (showResults) {
      const { correct, total, percentage } = calculateScore()
      const passed = (correct / total) >= 0.7
      const badgeInfo = getBadgeInfo(percentage)
      const wrongAnswers = getWrongAnswers()

      return (
        <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-blue-50 to-cyan-50 p-4">
          <div className="max-w-4xl mx-auto">
            {/* Header */}
            <div className="flex items-center justify-between mb-6">
              <Button 
                variant="outline" 
                onClick={exitLearning}
                className="flex items-center space-x-2"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>{t('back')}</span>
              </Button>
            </div>

            {/* Quiz Results */}
            <Card className="mb-8 max-h-[60vh] overflow-y-auto">
              <CardHeader className="text-center">
                <div className={`w-24 h-24 mx-auto rounded-full flex items-center justify-center mb-4 ${
                  passed 
                    ? 'bg-gradient-to-br from-green-400 to-green-600' 
                    : 'bg-gradient-to-br from-red-400 to-red-600'
                }`}>
                  {passed 
                    ? <Trophy className="w-12 h-12 text-white" />
                    : <Target className="w-12 h-12 text-white" />
                  }
                </div>
                <CardTitle className={`text-2xl ${passed ? 'text-green-700' : 'text-red-700'}`}>
                  {t(passed ? 'congratulations' : 'keepTrying')}
                </CardTitle>
                <CardDescription>
                  {t(passed ? 'quizPassed' : 'quizFailed')}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center space-y-2">
                  <div className="text-3xl font-bold">
                    {correct}/{total}
                  </div>
                  <p className="text-muted-foreground">
                    {correct} {t('correctAnswers')} / {total} {t('totalQuestions')} • %{Math.round(percentage)}
                  </p>
                  <div className="w-full bg-gray-200 rounded-full h-3 mt-4">
                    <div 
                      className={`h-3 rounded-full transition-all duration-300 ${
                        passed ? 'bg-green-500' : 'bg-red-500'
                      }`}
                      style={{ width: `${percentage}%` }}
                    ></div>
                  </div>
                </div>

                {/* Badge Section */}
                {badgeInfo && (
                  <div className="text-center py-4">
                    <div className={`inline-flex items-center space-x-3 px-6 py-3 rounded-full bg-gradient-to-r ${badgeInfo.gradient} text-white shadow-lg`}>
                      <span className="text-2xl">{badgeInfo.icon}</span>
                      <div className="text-left">
                        <div className="font-bold">{t(badgeInfo.titleKey)}</div>
                        <div className="text-sm opacity-90">{t(badgeInfo.descriptionKey)}</div>
                      </div>
                    </div>
                  </div>
                )}

                <div className="flex flex-col sm:flex-row gap-4 pt-6 mt-4 border-t border-gray-200 bg-white/80 backdrop-blur-sm sticky bottom-0">
                  <Button 
                    onClick={restartQuiz}
                    className="flex-1"
                    variant="outline"
                  >
                    {t('course.restart')}
                  </Button>
                  <Button 
                    onClick={exitLearning}
                    className="flex-1"
                  >
                    {t('course.back_to_courses')}
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Wrong Answers Section */}
            {wrongAnswers.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <AlertTriangle className="w-5 h-5 text-orange-500" />
                    <span>{t('quiz.wrong_answers_title')}</span>
                  </CardTitle>
                  <CardDescription>
                    {t('quiz.review_description')}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {wrongAnswers.map(({ question, questionIndex, userAnswer }) => (
                    <div key={questionIndex} className="p-4 bg-red-50 rounded-lg border border-red-200">
                      <div className="space-y-3">
                        {/* Question */}
                        <div className="font-medium text-red-800">
                          {questionIndex + 1}. {getLocalizedText(question.question, language)}
                        </div>
                        
                        {/* User's Wrong Answer */}
                        <div className="flex items-center space-x-2">
                          <Badge variant="destructive" className="text-xs">
                            {t('quiz.your_answer')}
                          </Badge>
                          <span className="text-red-700">
                            {question.type === 'true_false' 
                              ? (userAnswer ? t('quiz.true') : t('quiz.false'))
                              : (question.options?.[language] || question.answers?.[language])?.[userAnswer]
                            }
                          </span>
                        </div>
                        
                        {/* Correct Answer */}
                        <div className="flex items-center space-x-2">
                          <Badge variant="default" className="text-xs bg-green-500">
                            {t('quiz.correct_answer')}
                          </Badge>
                          <span className="text-green-700 font-medium">
                            {question.type === 'true_false' 
                              ? (question.correct ? t('quiz.true') : t('quiz.false'))
                              : (question.options?.[language] || question.answers?.[language])?.[question.correct]
                            }
                          </span>
                        </div>
                        
                        {/* Explanation */}
                        {question.explanation && (
                          <div className="bg-blue-50 p-3 rounded border border-blue-200">
                            <div className="text-sm text-blue-800">
                              <strong>{t('quiz.explanation')}</strong> {getLocalizedText(question.explanation, language)}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      )
    }

    // Show quiz
    if (slidesCompleted) {
      return (
        <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-blue-50 to-cyan-50 p-4">
          <div className="max-w-4xl mx-auto">
            {/* Header */}
            <div className="flex items-center justify-between mb-6">
              <Button 
                variant="outline" 
                onClick={exitLearning}
                className="flex items-center space-x-2"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>{t('back')}</span>
              </Button>
              <Badge variant="secondary" className="px-4 py-2">
                {t('course.quiz')}
              </Badge>
            </div>

            {/* Quiz */}
            <Card>
              <CardHeader className="text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-purple-400 to-purple-600 rounded-lg mx-auto flex items-center justify-center mb-4">
                  <Target className="w-8 h-8 text-white" />
                </div>
                <CardTitle>{t('testYourKnowledge')}</CardTitle>
                <CardDescription>
                  {t('quizDescription')}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {quizData.map((quiz, qIndex) => (
                  <div key={`quiz-${qIndex}`} className="space-y-4 p-4 bg-muted/30 rounded-lg">
                    <h3 className="font-medium">{qIndex + 1}. {quiz.question[language]}</h3>
                    
                    {/* True/False Questions */}
                    {quiz.type === 'true_false' ? (
                      <div className="grid gap-2">
                        <Button
                          variant={quizAnswers[qIndex] === true ? "default" : "outline"}
                          className="justify-start text-left"
                          onClick={() => handleQuizAnswer(qIndex, true)}
                        >
                          ✅ {t('quiz.true')}
                        </Button>
                        <Button
                          variant={quizAnswers[qIndex] === false ? "default" : "outline"}
                          className="justify-start text-left"
                          onClick={() => handleQuizAnswer(qIndex, false)}
                        >
                          ❌ {t('quiz.false')}
                        </Button>
                      </div>
                    ) : (
                      /* Multiple Choice Questions */
                      <div className="grid gap-2">
                        {(quiz.options?.[language] || quiz.answers?.[language] || []).map((option: string, oIndex: number) => (
                          <Button
                            key={`option-${qIndex}-${oIndex}`}
                            variant={quizAnswers[qIndex] === oIndex ? "default" : "outline"}
                            className="justify-start text-left"
                            onClick={() => handleQuizAnswer(qIndex, oIndex)}
                          >
                            {option}
                          </Button>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
                
                <div className="pt-6">
                  <Button 
                    onClick={submitQuiz}
                    className="w-full"
                    disabled={Object.keys(quizAnswers).length !== quizData.length}
                  >
                    {t('course.submit_quiz')}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      )
    }

    // Show current slide - Fixed layout
    if (currentSlideData) {
      return (
        <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-blue-50 to-cyan-50 p-4">
          <div className="max-w-4xl mx-auto">
            {/* Header */}
            <div className="flex items-center justify-between mb-6">
              <Button 
                variant="outline" 
                onClick={exitLearning}
                className="flex items-center space-x-2"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>{t('back')}</span>
              </Button>
              <div className="flex items-center space-x-4">
                <Badge variant="secondary" className="px-4 py-2">
                  {currentSlide + 1} / {slides.length}
                </Badge>
                <div className="text-sm text-muted-foreground">
                  {getLocalizedText(course.title, language)}
                </div>
              </div>
            </div>

            {/* Progress */}
            <div className="mb-8">
              <div className="flex justify-between text-sm text-muted-foreground mb-2">
                <span>{t('progress')}</span>
                <span>{slides.length > 0 ? Math.round(((currentSlide + 1) / slides.length) * 100) : 0}%</span>
              </div>
              <Progress value={slides.length > 0 ? ((currentSlide + 1) / slides.length) * 100 : 0} className="h-2" />
            </div>

            {/* Slide Content */}
            <Card className="mb-8 max-h-[60vh] overflow-y-auto">
              <CardHeader className="text-center pb-6">
                <div className="w-20 h-20 mx-auto mb-4 bg-gradient-to-br from-purple-100 to-purple-200 rounded-xl flex items-center justify-center">
                  {currentSlideData.icon || <BookOpen className="w-10 h-10 text-purple-600" />}
                </div>
                <CardTitle className="text-2xl">
                  {getLocalizedText(currentSlideData.title, language)}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="text-lg leading-relaxed">
                  {/* Check for special tooltip content */}
                  {currentSlideData.contentWithTooltips && getLocalizedText(currentSlideData.contentWithTooltips, language) ? (
                    <div className="text-left">
                      {getLocalizedText(currentSlideData.contentWithTooltips, language)}
                    </div>
                  ) : Array.isArray(getLocalizedContent(currentSlideData.content, language)) && getLocalizedContent(currentSlideData.content, language).length > 0 ? (
                    <div className="space-y-3">
                      {getLocalizedContent(currentSlideData.content, language).map((item, index) => (
                        <div key={index} className="text-left">
                          {formatTextWithSubheadings(item)}
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center">
                      {formatTextWithSubheadings(getLocalizedText(currentSlideData.content, language))}
                    </div>
                  )}
                </div>
                
                {currentSlideData.image && (
                  <div className="flex justify-center mb-6">
                    <div className="rounded-lg overflow-hidden shadow-lg max-w-full">
                      <img 
                        src={currentSlideData.image} 
                        alt={getLocalizedText(currentSlideData.title, language)}
                        className="w-full h-auto max-h-96 object-cover"
                      />
                    </div>
                  </div>
                )}

                {currentSlideData.example && (
                  <div className="bg-gradient-to-r from-blue-50 to-cyan-50 p-4 rounded-lg border-l-4 border-blue-400">
                    <div className="text-sm text-blue-800">
                      {getLocalizedText(currentSlideData.example, language)}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Navigation - Fixed Position */}
            <div className="flex justify-between items-center mt-8 pt-6 border-t border-gray-200 bg-white/80 backdrop-blur-sm sticky bottom-0">
              <Button
                variant="outline"
                onClick={prevSlide}
                disabled={currentSlide === 0}
                className="flex items-center space-x-2"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>{t('course.previous')}</span>
              </Button>

              <div className="flex space-x-2">
                {slides && slides.map((_, index) => (
                  <div
                    key={`dot-${index}`}
                    className={`w-2 h-2 rounded-full transition-colors ${
                      index === currentSlide ? 'bg-primary' : 'bg-muted-foreground/30'
                    }`}
                  />
                ))}
              </div>

              <Button
                onClick={nextSlide}
                className="flex items-center space-x-2"
              >
                <span>
                  {currentSlide === slides.length - 1 
                    ? t('course.start_quiz') 
                    : t('course.next')
                  }
                </span>
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      )
    }
  }

  // Course overview page
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <Button 
            variant="outline" 
            onClick={onBack}
            className="flex items-center space-x-2"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>{t('course.back')}</span>
          </Button>
        </div>

        {/* Course Header */}
        <div className="mb-8">
          {/* Course Title and Info */}
          <div className="mb-8">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-12 h-12 bg-gradient-to-br from-primary to-primary/80 rounded-lg flex items-center justify-center">
                  {getCourseIcon(course.category)}
                </div>
                <Badge variant="outline" className={getLevelColor(course.level)}>
                  {getLevelText(course.level)}
                </Badge>
              </div>
              
              <h1 className="text-3xl md:text-4xl font-bold mb-4 text-foreground">
                {getLocalizedText(course.title, language)}
              </h1>
              
              <p className="text-lg text-muted-foreground leading-relaxed mb-6 max-w-4xl">
                {getLocalizedText(course.description, language)}
              </p>

              {/* Start Learning Button */}
              <div className="mb-8">
                <Button 
                  onClick={() => setIsLearning(true)}
                  className="py-6 px-12 text-xl font-semibold bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white rounded-lg shadow-lg hover:shadow-xl transition-all duration-300"
                  size="lg"
                >
                  <Play className="w-6 h-6 mr-3 fill-white" />
                  {t('course.start')}
                </Button>
              </div>
            </div>

          {/* Course Stats - Enhanced Design */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <Card className="border-0 bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-950 dark:to-blue-900">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Clock className="w-6 h-6 text-white" />
                </div>
                <div className="text-2xl font-bold text-primary mb-1">{course.duration}</div>
                <div className="text-sm text-muted-foreground">{t('course.hours')}</div>
              </CardContent>
            </Card>
            
            <Card className="border-0 bg-gradient-to-br from-green-50 to-green-100 dark:from-green-950 dark:to-green-900">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-3">
                  <BookOpen className="w-6 h-6 text-white" />
                </div>
                <div className="text-2xl font-bold text-primary mb-1">{course.lessons}</div>
                <div className="text-sm text-muted-foreground">{t('course.lessons')}</div>
              </CardContent>
            </Card>
            
            <Card className="border-0 bg-gradient-to-br from-yellow-50 to-yellow-100 dark:from-yellow-950 dark:to-yellow-900">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-yellow-500 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Star className="w-6 h-6 text-white fill-white" />
                </div>
                <div className="text-2xl font-bold text-primary mb-1">{course.rating}</div>
                <div className="text-sm text-muted-foreground">{t('course.rating')}</div>
              </CardContent>
            </Card>
            
            <Card className="border-0 bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-950 dark:to-purple-900">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-purple-500 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Users className="w-6 h-6 text-white" />
                </div>
                <div className="text-2xl font-bold text-primary mb-1">{course.enrolled.toLocaleString()}</div>
                <div className="text-sm text-muted-foreground">{t('course.students')}</div>
              </CardContent>
            </Card>
          </div>
          </div>


        </div>

        {/* Course Content Sections - 2 Column Layout */}
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Left Column - Course Info */}
          <div>
            <Card className="sticky top-8">
              <CardContent className="p-6 space-y-6">
                {/* Course Basic Info */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">{t('course.contents')}</span>
                    <span className="font-medium">{course.lessons} {t('course.lessons')}</span>
                  </div>
                  
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">{t('course.category')}</span>
                    <Badge variant="secondary">{course.category}</Badge>
                  </div>
                  
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">{t('course.level')}</span>
                    <Badge variant="outline" className={getLevelColor(course.level)}>
                      {getLevelText(course.level)}
                    </Badge>
                  </div>
                </div>

                {/* Separator */}
                <hr className="border-border" />

                {/* Prerequisites */}
                <div className="space-y-3">
                  <h3 className="font-medium text-sm text-foreground">{t('course.prerequisites')}</h3>
                  <div className="space-y-2">
                    {getLocalizedContent(course.prerequisites, language).map((prereq, index) => (
                      <div key={`prereq-${index}`} className="flex items-start space-x-2">
                        <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                        <span className="text-sm text-muted-foreground">{prereq}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Separator */}
                <hr className="border-border" />

                {/* Skills Gained */}
                <div className="space-y-3">
                  <h3 className="font-medium text-sm text-foreground">{t('course.skills')}</h3>
                  <div className="flex flex-wrap gap-2">
                    {getLocalizedContent(course.skillsGained, language).map((skill, index) => (
                      <Badge key={`skill-${index}`} variant="outline" className="text-xs">
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Column - What You'll Learn */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Target className="w-5 h-5 text-primary" />
                  <span>{t('whatYouWillLearn')}</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-3">
                  {getLocalizedContent(course.outcomes, language).map((outcome: string, index: number) => (
                    <div key={`outcome-${index}`} className="flex items-start space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                      <span className="text-sm">{outcome}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}