import { LineChart, BarChart3, TrendingUp, Target, Lightbulb, Star, Users, Flag, Activity, Shield, Brain, Zap, Clock, Settings, TrendingDown, Eye, Layers, Gauge, GitBranch, Crosshair, AlertTriangle, CandlestickChart } from 'lucide-react'

export const technicalAnalysisSlides = [
  {
    title: { 
      tr: 'Teknik Analiz Nedir?', 
      en: 'What is Technical Analysis?', 
      es: '¿Qué es el Análisis Técnico?', 
      fr: 'Qu\'est-ce que l\'Analyse Technique?', 
      ru: 'Что такое технический анализ?' 
    },
    content: { 
      tr: [
        '• Teknik analiz, geçmiş fiyat hareketleri ve işlem hacmini kullanarak gelecekteki fiyat yönünü tahmin etme yöntemidir.',
        '• Bu yöntem, grafikler, trend çizgileri, teknik indikatörler ve destek-direnç seviyelerini kullanarak yatırımcılara alım-satım zamanlaması ve fırsatları belirleme imkânı sağlar.',
        '• Temel prensip: "Fiyat her şeyi yansıtır" - tüm piyasa bilgileri fiyatlarda zaten mevcuttur.',
        '• Zaman çerçeveleri: Kısa vadeli (günlük trading), orta vadeli (swing trading), uzun vadeli (position trading) analizler mümkündür.'
      ],
      en: [
        '• Technical analysis is a method of predicting future price direction using past price movements and trading volume.',
        '• This method uses charts, trend lines, technical indicators and support-resistance levels to provide investors with buy-sell timing and opportunity identification.',
        '• Basic principle: "Price reflects everything" - all market information is already present in prices.',
        '• Time frames: Short-term (day trading), medium-term (swing trading), long-term (position trading) analyses are possible.'
      ],
      es: [
        '• El análisis técnico es un método para predecir la dirección futura del precio usando movimientos de precios pasados y volumen de trading.',
        '• Este método usa gráficos, líneas de tendencia, indicadores técnicos y niveles de soporte-resistencia para proporcionar a los inversores timing de compra-venta e identificación de oportunidades.',
        '• Principio básico: "El precio refleja todo" - toda la información del mercado ya está presente en los precios.',
        '• Marcos temporales: Análisis a corto plazo (day trading), mediano plazo (swing trading), largo plazo (position trading) son posibles.'
      ],
      fr: [
        '• L\'analyse technique est une méthode de prédiction de la direction future des prix en utilisant les mouvements de prix passés et le volume de trading.',
        '• Cette méthode utilise des graphiques, lignes de tendance, indicateurs techniques et niveaux de support-résistance pour fournir aux investisseurs un timing d\'achat-vente et identification d\'opportunités.',
        '• Principe de base: "Le prix reflète tout" - toute l\'information du marché est déjà présente dans les prix.',
        '• Cadres temporels: Analyses à court terme (day trading), moyen terme (swing trading), long terme (position trading) sont possibles.'
      ],
      ru: [
        '• Технический анализ - это метод прогнозирования будущего направления цены, используя прошлые движения цен и объем торгов.',
        '• Этот метод использует графики, линии тренда, технические индикаторы и уровни поддержки-сопротивления для предоставления инвесторам времени покупки-продажи и выявления возможностей.',
        '• Основной принцип: "Цена отражает все" - вся рыночная информация уже присутствует в ценах.',
        '• Временные рамки: Краткосрочный (дневная торговля), среднесрочный (свинг-трейдинг), долгосрочный (позиционная торговля) анализы возможны.'
      ]
    },
    example: { 
      tr: '📈 Tesla hissesi 180$ destek seviyesinden alındığında teknik analiz ile 220$\'a kadar %22 kazanç sağladı.',
      en: '📈 Tesla stock bought from 180$ support level with technical analysis provided 22% gain up to 220$.',
      es: '📈 Las acciones de Tesla compradas desde el nivel de soporte de 180$ con análisis técnico proporcionaron una ganancia del 22% hasta 220$.',
      fr: '📈 L\'action Tesla achetée au niveau de support de 180$ avec analyse technique a fourni un gain de 22% jusqu\'à 220$.',
      ru: '📈 Акции Tesla, купленные с уровня поддержки 180$ с техническим анализом, обеспечили прибыль 22% до 220$.'
    },
    icon: <LineChart className="w-16 h-16 text-blue-500" />
  },
  {
    title: { 
      tr: 'Fiyat Grafik Türleri', 
      en: 'Price Chart Types', 
      es: 'Tipos de Gráficos de Precios', 
      fr: 'Types de Graphiques de Prix', 
      ru: 'Типы ценовых графиков' 
    },
    content: { 
      tr: [
        '• Çizgi Grafiği: Sadece kapanış fiyatlarını birleştirir; trendin genel yönünü hızlıca görmenizi sağlar.',
        '• Çubuk Grafiği: Açılış, kapanış, en yüksek ve en düşük fiyatları gösterir; fiyat hareketlerinin detayını anlamaya yardımcı olur.',
        '• Mum Grafiği: Fiyat hareketlerini renkli mumlarla gösterir; alım-satım kararlarını hızlı ve görsel olarak destekler.',
        '• Mum grafikler en çok tercih edilen türdür çünkü hem fiyat bilgilerini hem de piyasa duygusunu (bullish/bearish) görsel olarak sunar.',
        '• Her grafik türünün kendine özgü avantajları vardır; başlangıçta mum grafiklerle başlamak önerilir.'
      ],
      en: [
        '• Line Chart: Only connects closing prices; allows you to quickly see the general direction of the trend.',
        '• Bar Chart: Shows opening, closing, highest and lowest prices; helps understand the detail of price movements.',
        '• Candlestick Chart: Shows price movements with colored candles; supports buy-sell decisions quickly and visually.',
        '• Candlestick charts are the most preferred type because they present both price information and market sentiment (bullish/bearish) visually.',
        '• Each chart type has its own unique advantages; it is recommended to start with candlestick charts for beginners.'
      ],
      es: [
        '• Gráfico de Línea: Solo conecta precios de cierre; permite ver rápidamente la dirección general de la tendencia.',
        '• Gráfico de Barras: Muestra precios de apertura, cierre, más alto y más bajo; ayuda a entender el detalle de los movimientos de precios.',
        '• Gráfico de Velas: Muestra movimientos de precios con velas de colores; apoya decisiones de compra-venta rápida y visualmente.',
        '• Los gráficos de velas son el tipo más preferido porque presentan tanto información de precios como sentimiento del mercado (alcista/bajista) visualmente.',
        '• Cada tipo de gráfico tiene sus propias ventajas únicas; se recomienda empezar con gráficos de velas para principiantes.'
      ],
      fr: [
        '• Graphique Linéaire: Connecte seulement les prix de clôture; permet de voir rapidement la direction générale de la tendance.',
        '• Graphique en Barres: Montre les prix d\'ouverture, de clôture, le plus haut et le plus bas; aide à comprendre le détail des mouvements de prix.',
        '• Graphique en Chandeliers: Montre les mouvements de prix avec des bougies colorées; supporte les décisions d\'achat-vente rapidement et visuellement.',
        '• Les graphiques en chandeliers sont le type le plus pr��féré car ils présentent à la fois l\'information des prix et le sentiment du marché (haussier/baissier) visuellement.',
        '• Chaque type de graphique a ses propres avantages uniques; il est recommandé de commencer avec les graphiques en chandeliers pour les débutants.'
      ],
      ru: [
        '• Линейный График: Соединяет только цены закрытия; позволяет быстро увидеть общее направление тренда.',
        '• Барный График: Показывает цены открытия, закрытия, максимальные и минимальные; помогает понять детали ценовых движений.',
        '• График Свечей: Показывает ценовые движения цветными свечами; поддерживает решения покупки-продажи быстро и визуально.',
        '• Графики свечей являются наиболее предпочтительным типом, потому что они представляют как ценовую информацию, так и рыночные настроения (бычьи/медвежьи) визуально.',
        '• Каждый тип графика имеет свои уникальные преимущества; рекомендуется начинать с графиков свечей для новичков.'
      ]
    },
    example: { 
      tr: '📊 Bitcoin mum grafiğinde yeşil mumlar alım baskısını, kırmızı mumlar satım baskısını gösterir.',
      en: '📊 In Bitcoin candlestick chart, green candles show buying pressure, red candles show selling pressure.',
      es: '📊 En el gráfico de velas de Bitcoin, las velas verdes muestran presión de compra, las velas rojas muestran presión de venta.',
      fr: '📊 Dans le graphique en chandeliers de Bitcoin, les bougies vertes montrent la pression d\'achat, les bougies rouges montrent la pression de vente.',
      ru: '📊 На свечном графике Bitcoin зеленые свечи показывают давление покупок, красные свечи показывают давление продаж.'
    },
    icon: <CandlestickChart className="w-16 h-16 text-green-500" />
  },
  {
    title: { 
      tr: 'Destek ve Direnç Seviyeleri', 
      en: 'Support and Resistance Levels', 
      es: 'Niveles de Soporte y Resistencia', 
      fr: 'Niveaux de Support et Résistance', 
      ru: 'Уровни поддержки и сопротивления' 
    },
    content: { 
      tr: [
        '• Destek: Fiyatın düşüş sırasında durduğu ve yukarı döndüğü bölgedir; alıcıların yoğun olduğu noktadır.',
        '• Direnç: Fiyatın yükseliş sırasında durduğu ve geri döndüğü bölgedir; satıcıların etkili olduğu seviyedir.',
        '• Tespit: Geçmişteki yüksek ve düşük fiyatlar, yuvarlak sayılar veya Fibonacci seviyeleriyle belirlenir.',
        '• Strateji: Destek seviyelerinden alım, direnç seviyelerinden satış yapılır; kırılımlar önemli fırsatlar sunar.',
        '• Güç faktörleri: Bir seviye ne kadar çok test edilirse o kadar güçlüdür; hacim konfirmasyonu da önemlidir.'
      ],
      en: [
        '• Support: The area where price stops falling and turns up; it is the point where buyers are concentrated.',
        '• Resistance: The area where price stops rising and turns back; it is the level where sellers are effective.',
        '• Identification: Determined by past high and low prices, round numbers or Fibonacci levels.',
        '• Strategy: Buy from support levels, sell from resistance levels; breakouts offer important opportunities.',
        '• Strength factors: The more a level is tested, the stronger it becomes; volume confirmation is also important.'
      ],
      es: [
        '• Soporte: El área donde el precio deja de caer y gira hacia arriba; es el punto donde los compradores se concentran.',
        '• Resistencia: El área donde el precio deja de subir y gira hacia atrás; es el nivel donde los vendedores son efectivos.',
        '• Identificación: Determinado por precios altos y bajos pasados, números redondos o niveles de Fibonacci.',
        '• Estrategia: Comprar desde niveles de soporte, vender desde niveles de resistencia; las rupturas ofrecen oportunidades importantes.',
        '• Factores de fuerza: Cuanto más se prueba un nivel, más fuerte se vuelve; la confirmación de volumen también es importante.'
      ],
      fr: [
        '• Support: La zone où le prix arrête de baisser et remonte; c\'est le point où les acheteurs se concentrent.',
        '• Résistance: La zone où le prix arrête de monter et repart; c\'est le niveau où les vendeurs sont efficaces.',
        '• Identification: Déterminé par les prix hauts et bas passés, nombres ronds ou niveaux de Fibonacci.',
        '• Stratégie: Acheter aux niveaux de support, vendre aux niveaux de résistance; les cassures offrent des opportunités importantes.',
        '• Facteurs de force: Plus un niveau est testé, plus il devient fort; la confirmation de volume est aussi importante.'
      ],
      ru: [
        '• Поддержка: Область, где цена перестает падать и поворачивает вверх; это точка, где сосредоточены покупатели.',
        '• Сопротивление: Область, где цена перестает расти и поворачивает назад; это уровень, где продавцы эффективны.',
        '• Определение: Определяется прошлыми максимальными и минимальными ценами, круглыми числами или уровнями Фибоначчи.',
        '• Стратегия: Покупать с уровней поддержки, продавать с уровней сопротивления; прорывы предлагают важные возможности.',
        '• Факторы силы: Чем больше тестируется уровень, тем сильнее он становится; подтверждение объемом также важно.'
      ]
    },
    example: { 
      tr: '🎯 Bitcoin 30.000$ seviyesi 5 kez test edilerek güçlü destek haline geldi; buradan %15 yükseliş sağlandı.',
      en: '🎯 Bitcoin 30,000$ level became strong support after being tested 5 times; 15% rise was achieved from here.',
      es: '🎯 El nivel de Bitcoin de 30,000$ se convirtió en un soporte fuerte después de ser probado 5 veces; se logró una subida del 15% desde aquí.',
      fr: '🎯 Le niveau Bitcoin de 30 000$ est devenu un support fort après avoir été testé 5 fois; une hausse de 15% a été réalisée depuis ici.',
      ru: '🎯 Уровень Bitcoin 30,000$ стал сильной поддержкой после 5 тестирований; с этого места был достигнут рост на 15%.'
    },
    icon: <Target className="w-16 h-16 text-green-500" />
  },
  {
    title: { 
      tr: 'Basit Trend Çizgileri', 
      en: 'Simple Trend Lines', 
      es: 'Líneas de Tendencia Simples', 
      fr: 'Lignes de Tendance Simples', 
      ru: 'Простые линии тренда' 
    },
    content: { 
      tr: [
        '• Fiyatın diplerini veya zirvelerini birleştirerek trend çizgisi oluşturun; bu, trendin yönünü anlamanıza yardımcı olur. Çizginin kırılımı trend değişimi sinyalidir.',
        '• Yükseliş trendinde ardışık yüksek dipler ve yüksek tepeler, düşüş trendinde ise ardışık düşük dipler ve düşük zirveler oluşur.',
        '• Yatay trend ise fiyatın belirgin bir yön göstermediği ve yatay seyrettiği durumlardır.',
        '• İpucu: "Trend sizin dostunuzdur" — trend yönünde pozisyon almak genellikle daha güvenlidir.',
        '• Trend çizgilerini doğru çizmek için en az 2, ideal olarak 3 veya daha fazla nokta gereklidir.'
      ],
      en: [
        '• Create trend lines by connecting price lows or highs; this helps you understand the direction of the trend. Breaking the line is a signal of trend change.',
        '• In uptrends, consecutive higher lows and higher highs form, while in downtrends, consecutive lower lows and lower highs form.',
        '• Horizontal trend is when price shows no clear direction and moves sideways.',
        '• Tip: "Trend is your friend" — taking positions in the direction of the trend is generally safer.',
        '• To draw trend lines correctly, you need at least 2, ideally 3 or more points.'
      ],
      es: [
        '• Crea líneas de tendencia conectando mínimos o máximos de precios; esto te ayuda a entender la dirección de la tendencia. Romper la línea es una señal de cambio de tendencia.',
        '• En tendencias alcistas, se forman mínimos y máximos consecutivamente más altos, mientras que en tendencias bajistas se forman mínimos y máximos consecutivamente más bajos.',
        '• La tendencia horizontal es cuando el precio no muestra una dirección clara y se mueve lateralmente.',
        '• Consejo: "La tendencia es tu amiga" — tomar posiciones en la dirección de la tendencia es generalmente más seguro.',
        '• Para dibujar líneas de tendencia correctamente, necesitas al menos 2, idealmente 3 o más puntos.'
      ],
      fr: [
        '• Créez des lignes de tendance en connectant les plus bas ou plus hauts des prix; cela vous aide à comprendre la direction de la tendance. Casser la ligne est un signal de changement de tendance.',
        '• Dans les tendances haussières, des plus bas et plus hauts consécutivement plus élevés se forment, tandis que dans les tendances baissières, des plus bas et plus hauts consécutivement plus bas se forment.',
        '• La tendance horizontale est quand le prix ne montre pas de direction claire et bouge latéralement.',
        '• Conseil: "La tendance est votre amie" — prendre des positions dans la direction de la tendance est généralement plus sûr.',
        '• Pour dessiner correctement les lignes de tendance, vous avez besoin d\'au moins 2, idéalement 3 points ou plus.'
      ],
      ru: [
        '• Создавайте линии тренда, соединяя минимумы или максимумы цен; это помогает понять направление тренда. Пробой линии - сигнал изменения тренда.',
        '• В восходящих трендах формируются последовательно более высокие минимумы и максимумы, в то время как в нисходящих трендах формируются последовательно более низкие минимумы и максимумы.',
        '• Горизонтальный тренд - когда цена не показывает четкого направления и движется боком.',
        '• Совет: "Тренд - ваш друг" — открытие позиций в направлении тренда обычно безопаснее.',
        '• Для правильного построения линий тренда нужно минимум 2, идеально 3 или более точек.'
      ]
    },
    example: { 
      tr: '📊 Apple hissesi 6 aylık yükseliş trendinde 150$\'dan 200$\'a %33 kazanç sağladı.',
      en: '📊 Apple stock in 6-month uptrend provided 33% gain from $150 to $200.',
      es: '📊 Las acciones de Apple en tendencia alcista de 6 meses proporcionaron una ganancia del 33% de $150 a $200.',
      fr: '📊 L\'action Apple en tendance haussière de 6 mois a fourni un gain de 33% de 150$ à 200$.',
      ru: '📊 Акции Apple в 6-месячном восходящем тренде обеспечили прибыль 33% с $150 до $200.'
    },
    icon: <TrendingUp className="w-16 h-16 text-blue-500" />
  },
  {
    title: { 
      tr: 'Temel Teknik İndikatörler', 
      en: 'Basic Technical Indicators', 
      es: 'Indicadores Técnicos Básicos', 
      fr: 'Indicateurs Techniques de Base', 
      ru: 'Основные технические индикаторы' 
    },
    content: { 
      tr: [
        '• Hareketli Ortalamalar (MA): Fiyatların ortalamasını alarak trend yönünü gösterir; yaygın olarak 20, 50 ve 200 günlük MA kullanılır.',
        '• RSI (Göreceli Güç Endeksi): 0-100 arası değer alır; 70 üzeri aşırı alım, 30 altı aşırı satım bölgesini gösterir.',
        '• MACD (Hareketli Ortalama Yakınsama / Iraksama): Kısa ve uzun dönem hareketli ortalamalar arasındaki farkı gösterir; MACD çizgisi sinyal çizgisini keserse alım veya satım sinyali oluşur.',
        '• Bollinger Bands: Orta hat ve üst-alt bantlar ile fiyatın volatilitesini ve potansiyel dönüş noktalarını gösterir.',
        '• Hacim (Volume): Fiyat hareketlerinin gücünü doğrular; yüksek hacimli hareketler trendin güvenilirliğini artırır.',
        '• Momentum ve Volatilite: Fiyatın ne kadar hızlı hareket ettiğini ve dalgalanma şiddetini ölçer; trend gücü ve riskleri değerlendirir.'
      ],
      en: [
        '• Moving Averages (MA): Shows trend direction by averaging prices; commonly 20, 50 and 200-day MA are used.',
        '• RSI (Relative Strength Index): Values between 0-100; above 70 overbought, below 30 oversold zone.',
        '• MACD (Moving Average Convergence Divergence): Shows difference between short and long term moving averages; buy or sell signal occurs when MACD line crosses signal line.',
        '• Bollinger Bands: Shows volatility and potential reversal points with middle line and upper-lower bands.',
        '• Volume: Confirms strength of price movements; high volume movements increase trend reliability.',
        '• Momentum and Volatility: Measures how fast price moves and intensity of fluctuations; evaluates trend strength and risks.'
      ],
      es: [
        '• Medias Móviles (MA): Muestra dirección de tendencia promediando precios; comúnmente se usan MA de 20, 50 y 200 días.',
        '• RSI (Índice de Fuerza Relativa): Valores entre 0-100; arriba de 70 sobrecomprado, debajo de 30 zona sobrevendida.',
        '• MACD (Convergencia Divergencia de Media Móvil): Muestra diferencia entre medias móviles de corto y largo plazo; señal de compra o venta ocurre cuando línea MACD cruza línea de señal.',
        '• Bandas de Bollinger: Muestra volatilidad y puntos de reversión potenciales con línea media y bandas superior-inferior.',
        '• Volumen: Confirma fuerza de movimientos de precio; movimientos de alto volumen aumentan confiabilidad de tendencia.',
        '• Momentum y Volatilidad: Mide qué tan rápido se mueve el precio e intensidad de fluctuaciones; evalúa fuerza de tendencia y riesgos.'
      ],
      fr: [
        '• Moyennes Mobiles (MA): Montre la direction de tendance en moyennant les prix; communément les MA de 20, 50 et 200 jours sont utilisées.',
        '• RSI (Indice de Force Relative): Valeurs entre 0-100; au-dessus de 70 suracheté, en dessous de 30 zone survendue.',
        '• MACD (Convergence Divergence de Moyenne Mobile): Montre la différence entre moyennes mobiles court et long terme; signal d\'achat ou vente se produit quand ligne MACD croise ligne de signal.',
        '• Bandes de Bollinger: Montre volatilité et points de retournement potentiels avec ligne médiane et bandes supérieure-inférieure.',
        '• Volume: Confirme la force des mouvements de prix; mouvements à fort volume augmentent la fiabilité de tendance.',
        '• Momentum et Volatilité: Mesure à quelle vitesse le prix bouge et intensité des fluctuations; évalue force de tendance et risques.'
      ],
      ru: [
        '• Скользящие Средние (MA): Показывает направление тренда, усредняя цены; обычно используются 20, 50 и 200-дневные MA.',
        '• RSI (Индекс Относительной Силы): Значения между 0-100; выше 70 перекупленность, ниже 30 зона перепроданности.',
        '• MACD (Схождение Расхождение Скользящих Средних): Показывает разность между краткосрочными и долгосрочными скользящими средними; сигнал покупки или продажи возникает, когда линия MACD пересекает сигнальную линию.',
        '• Полосы Боллинджера: Показывает волатильность и потенциальные точки разворота со средней линией и верхними-нижними полосами.',
        '• Объем: Подтверждает силу ценовых движений; движения с высоким объемом увеличивают надежность тренда.',
        '• Моментум и Волатильность: Измеряет, как быстро движется цена и интенсивность флуктуаций; оценивает силу тренда и риски.'
      ]
    },
    example: { 
      tr: '📈 EUR/USD\'de RSI 30\'un altına düştüğünde aşırı satım sinyali verdi; fiyat %2 yükseldi.',
      en: '📈 EUR/USD RSI dropping below 30 gave oversold signal; price rose 2%.',
      es: '📈 EUR/USD RSI cayendo por debajo de 30 dio señal de sobreventa; precio subió 2%.',
      fr: '📈 EUR/USD RSI tombant en dessous de 30 a donné signal de survente; prix a monté de 2%.',
      ru: '📈 EUR/USD RSI, падая ниже 30, дал сигнал перепроданности; цена выросла на 2%.'
    },
    icon: <BarChart3 className="w-16 h-16 text-purple-500" />
  },
  {
    title: { 
      tr: 'Grafik Formasyonları ve Basit Formasyonlar', 
      en: 'Chart Patterns and Simple Formations', 
      es: 'Patrones de Gráficos y Formaciones Simples', 
      fr: 'Modèles de Graphiques et Formations Simples', 
      ru: 'Графические паттерны и простые формации' 
    },
    content: { 
      tr: [
        '• Üçgen Formasyonları: Yükselen, düşen ve simetrik üçgenler; kırılım yönü trendin devamını veya değişimini gösterir.',
        '• Baş-Omuz: Ortadaki tepe en yüksek; boyun çizgisi kırılırsa güçlü satış sinyali verir.',
        '• İkili Tepe / İkili Dip: Fiyat aynı seviyeyi iki kez test eder; ikili tepe satış, ikili dip alım sinyali oluşturur.',
        '• Bayrak ve Flama: Kısa süreli konsolidasyonlar genellikle mevcut trendin devamını işaret eder.',
        '• Dikdörtgen: Fiyat yatay destek ve direnç arasında hareket eder; kırılım yönü trend devamını gösterir.',
        '• Formasyonların tamamlanması için hacim konfirmasyonu önemlidir; düşük hacimli kırılımlar yanıltıcı olabilir.'
      ],
      en: [
        '• Triangle Patterns: Ascending, descending and symmetrical triangles; breakout direction shows trend continuation or change.',
        '• Head and Shoulders: Middle peak is highest; gives strong sell signal if neckline breaks.',
        '• Double Top / Double Bottom: Price tests same level twice; double top creates sell signal, double bottom creates buy signal.',
        '• Flag and Pennant: Brief consolidations usually indicate continuation of existing trend.',
        '• Rectangle: Price moves between horizontal support and resistance; breakout direction shows trend continuation.',
        '• Volume confirmation is important for pattern completion; low volume breakouts can be misleading.'
      ],
      es: [
        '• Patrones de Triángulo: Triángulos ascendentes, descendentes y simétricos; dirección de ruptura muestra continuación o cambio de tendencia.',
        '• Cabeza y Hombros: El pico del medio es el más alto; da señal de venta fuerte si se rompe la línea del cuello.',
        '• Doble Techo / Doble Suelo: El precio prueba el mismo nivel dos veces; doble techo crea señal de venta, doble suelo crea señal de compra.',
        '• Bandera y Banderín: Las consolidaciones breves usualmente indican continuación de tendencia existente.',
        '• Rectángulo: El precio se mueve entre soporte y resistencia horizontal; dirección de ruptura muestra continuación de tendencia.',
        '• La confirmación de volumen es importante para la finalización del patrón; rupturas de bajo volumen pueden ser engañosas.'
      ],
      fr: [
        '• Modèles de Triangle: Triangles ascendants, descendants et symétriques; direction de cassure montre continuation ou changement de tendance.',
        '• Tête et Épaules: Le pic du milieu est le plus haut; donne signal de vente fort si ligne de cou se casse.',
        '• Double Sommet / Double Creux: Le prix teste le même niveau deux fois; double sommet crée signal de vente, double creux crée signal d\'achat.',
        '• Drapeau et Fanion: Les consolidations brèves indiquent habituellement continuation de tendance existante.',
        '• Rectangle: Le prix bouge entre support et résistance horizontaux; direction de cassure montre continuation de tendance.',
        '• La confirmation de volume est importante pour la finalisation du modèle; cassures à faible volume peuvent être trompeuses.'
      ],
      ru: [
        '• Треугольные Паттерны: Восходящие, нисходящие и симметричные треугольники; направление пробоя показывает продолжение или изменение тренда.',
        '• Голова и Плечи: Средний пик самый высокий; дает сильный сигнал продажи, если пробивается линия шеи.',
        '• Двойная Вершина / Двойное Дно: Цена тестирует один уровень дважды; двойная вершина создает сигнал продажи, двойное дно создает сигнал покупки.',
        '• Флаг и Вымпел: Краткие консолидации обычно указывают на продолжение существующего тренда.',
        '• Прямоугольник: Цена движется между горизонтальной поддержкой и сопротивлением; направление пробоя показывает продолжение тренда.',
        '• Подтверждение объемом важно для завершения паттерна; пробои с низким объемом могут вводить в заблуждение.'
      ]
    },
    example: { 
      tr: '📊 Gold\'da baş-omuz formasyonu tamamlandıktan sonra 1800$\'dan 1650$\'a %8.3 düşüş yaşandı.',
      en: '📊 After head and shoulders formation completed in Gold, 8.3% decline occurred from $1800 to $1650.',
      es: '📊 Después de que se completó la formación cabeza y hombros en el oro, ocurrió una caída del 8.3% de $1800 a $1650.',
      fr: '📊 Après que la formation tête et épaules s\'est terminée dans l\'or, une baisse de 8,3% s\'est produite de 1800$ à 1650$.',
      ru: '📊 После завершения формации голова и плечи в золоте произошло снижение на 8,3% с $1800 до $1650.'
    },
    icon: <Layers className="w-16 h-16 text-orange-500" />
  },
  {
    title: { 
      tr: 'Hacim Analizi', 
      en: 'Volume Analysis', 
      es: 'Análisis de Volumen', 
      fr: 'Analyse du Volume', 
      ru: 'Анализ объема' 
    },
    content: { 
      tr: [
        '• Hacim Önemi: Fiyat hareketlerinin arkasındaki alış veya satış gücünü gösterir.',
        '• Konfirmasyon: Yükselişte artan hacim boğa 🐂, düşüşte artan hacim ayı 🐻 hareketleri teyit eder.',
        '• Patternler: Climax (zirve hacim), exhaustion (tükeniş), accumulation (birikim) ve distribution (dağıtım).',
        '• OBV (Hacim Dengesi): Fiyat ve hacmi birleştirerek erken sinyal verir; trendin yönünü doğrulamada yardımcı olur.',
        '• Hacim artışları genellikle önemli haberleri, kurumsal hareketleri veya trend değişimlerini işaret eder.',
        '• Düşük hacimli hareketler genellikle geçici olup, yüksek hacimli hareketler kalıcı trend değişimlerini gösterebilir.'
      ],
      en: [
        '• Volume Importance: Shows the buying or selling power behind price movements.',
        '• Confirmation: Rising volume in uptrend confirms bull 🐂, rising volume in downtrend confirms bear 🐻 movements.',
        '• Patterns: Climax (peak volume), exhaustion, accumulation and distribution.',
        '• OBV (On Balance Volume): Gives early signals by combining price and volume; helps confirm trend direction.',
        '• Volume increases usually indicate important news, institutional movements or trend changes.',
        '• Low volume movements are usually temporary, while high volume movements can show permanent trend changes.'
      ],
      es: [
        '• Importancia del Volumen: Muestra el poder de compra o venta detrás de los movimientos de precios.',
        '• Confirmación: Volumen creciente en tendencia alcista confirma movimientos toro 🐂, volumen creciente en tendencia bajista confirma movimientos oso 🐻.',
        '• Patrones: Clímax (volumen pico), agotamiento, acumulación y distribución.',
        '• OBV (Volumen en Balance): Da señales tempranas combinando precio y volumen; ayuda a confirmar dirección de tendencia.',
        '• Los aumentos de volumen usualmente indican noticias importantes, movimientos institucionales o cambios de tendencia.',
        '• Los movimientos de bajo volumen son usualmente temporales, mientras que los movimientos de alto volumen pueden mostrar cambios permanentes de tendencia.'
      ],
      fr: [
        '• Importance du Volume: Montre le pouvoir d\'achat ou de vente derrière les mouvements de prix.',
        '• Confirmation: Volume croissant en tendance haussière confirme les mouvements taureau 🐂, volume croissant en tendance baissière confirme les mouvements ours 🐻.',
        '• Modèles: Climax (volume de pointe), épuisement, accumulation et distribution.',
        '• OBV (Volume en Équilibre): Donne des signaux précoces en combinant prix et volume; aide à confirmer la direction de tendance.',
        '• Les augmentations de volume indiquent habituellement des nouvelles importantes, mouvements institutionnels ou changements de tendance.',
        '• Les mouvements à faible volume sont habituellement temporaires, tandis que les mouvements à fort volume peuvent montrer des changements permanents de tendance.'
      ],
      ru: [
        '• Важность Объема: Показывает силу покупок или продаж за ценовыми движениями.',
        '• Подтверждение: Растущий объем в восходящем тренде подтверждает бычьи 🐂, растущий объем в нисходящем тренде подтверждает медвежьи 🐻 движения.',
        '• Паттерны: Кульминация (пиковый объем), истощение, накопление и распределение.',
        '• OBV (Балансовый Объем): Дает ранние сигналы, сочетая цену и объем; по��огает подтвердить направление тренда.',
        '• Увеличения объема обычно указывают на важные новости, институциональные движения или изменения тренда.',
        '• Движения с низким объемом обычно временные, в то время как движения с высоким объемом могут показывать постоянные изменения тренда.'
      ]
    },
    example: { 
      tr: '💰 Microsoft hissesinde hacim 3 katına çıktığında fiyat %5 yükseldi.',
      en: '💰 When Microsoft stock volume tripled, price rose 5%.',
      es: '💰 Cuando el volumen de acciones de Microsoft se triplicó, el precio subió 5%.',
      fr: '💰 Quand le volume de l\'action Microsoft a triplé, le prix a augmenté de 5%.',
      ru: '💰 Когда объем акций Microsoft утроился, цена выросла на 5%.'
    },
    icon: <Activity className="w-16 h-16 text-cyan-500" />
  },
  {
    title: { 
      tr: 'Çoklu-Zaman Analizi', 
      en: 'Multi-Timeframe Analysis', 
      es: 'Análisis Multi-Temporal', 
      fr: 'Analyse Multi-Temporelle', 
      ru: 'Мульти-таймфреймовый анализ' 
    },
    content: { 
      tr: [
        '• Farklı zaman dilimlerinde analiz yapmak trendin gücünü anlamaya yardımcı olur.',
        '• Uzun vadeli trend (haftalık/aylık) genel yönü, orta vadeli trend (günlük) giriş noktalarını ve kısa vadeli trendi (1Saat/4Saat) alım-satım zamanlamasını gösterir.',
        '• 15 dakika ve 5 dakika gibi kısa süreli zaman dilimleri intraday trading için kullanılır.',
        '• Tüm zaman çerçevelerinde trend uyumu, güçlü sinyali gösterir; çakışmalar dikkatle değerlendirilmelidir.',
        '• Top-down yaklaşım: Büyük zaman diliminden başlayıp küçüğe doğru analiz yapın.',
        '• Risk yönetimi: Zarar durdur küçük zaman dilimine göre, kar hedefi büyük zaman dilimine göre belirleyin.'
      ],
      en: [
        '• Analyzing in different timeframes helps understand trend strength.',
        '• Long-term trend (weekly/monthly) shows general direction, medium-term trend (daily) shows entry points, and short-term trend (1Hour/4Hour) shows buy-sell timing.',
        '• Short-term timeframes like 15 minutes and 5 minutes are used for intraday trading.',
        '• Trend alignment in all timeframes shows strong signal; conflicts should be carefully evaluated.',
        '• Top-down approach: Start analyzing from large timeframe and move to smaller ones.',
        '• Risk management: Set stop-loss according to small timeframe, profit target according to large timeframe.'
      ],
      es: [
        '• Analizar en diferentes marcos temporales ayuda a entender la fuerza de la tendencia.',
        '• La tendencia a largo plazo (semanal/mensual) muestra dirección general, tendencia a mediano plazo (diaria) muestra puntos de entrada, y tendencia a corto plazo (1Hora/4Hora) muestra timing de compra-venta.',
        '• Los marcos temporales de corto plazo como 15 minutos y 5 minutos se usan para trading intradía.',
        '• La alineación de tendencia en todos los marcos temporales muestra señal fuerte; los conflictos deben evaluarse cuidadosamente.',
        '• Enfoque de arriba-abajo: Comienza analizando desde marco temporal grande y muévete a los más pequeños.',
        '• Gestión de riesgos: Establece stop-loss según marco temporal pequeño, objetivo de ganancia según marco temporal grande.'
      ],
      fr: [
        '• Analyser dans différents cadres temporels aide à comprendre la force de tendance.',
        '• La tendance à long terme (hebdomadaire/mensuelle) montre la direction générale, tendance à moyen terme (quotidienne) montre les points d\'entrée, et tendance à court terme (1Heure/4Heure) montre le timing d\'achat-vente.',
        '• Les cadres temporels courts comme 15 minutes et 5 minutes sont utilisés pour le trading intrajournalier.',
        '• L\'alignement de tendance dans tous les cadres temporels montre un signal fort; les conflits doivent être évalués soigneusement.',
        '• Approche descendante: Commencez à analyser depuis le grand cadre temporel et déplacez-vous vers les plus petits.',
        '• Gestion des risques: Définissez stop-loss selon petit cadre temporel, objectif de profit selon grand cadre temporel.'
      ],
      ru: [
        '• Анализ в разных таймфреймах помогает понять силу тренда.',
        '• Долгосрочный тренд (недельный/месячный) показывает общее направление, среднесрочный тренд (дневной) показывает точки входа, и краткосрочный тренд (1Час/4Час) показывает время покупки-продажи.',
        '• Краткосрочные таймфреймы как 15 минут и 5 минут используются для внутридневной торговли.',
        '• Выравнивание тренда во всех таймфреймах показывает сильный сигнал; конфликты должны оцениваться внимательно.',
        '• Подход сверху-вниз: Начинайте анализ с большого таймфрейма и переходите к меньшим.',
        '• Управление рисками: Устанавливайте стоп-лосс по малому таймфрейму, цель прибыли по большому таймфрейму.'
      ]
    },
    example: { 
      tr: '⏰ EURUSD weekly uptrend, daily pullback, 1H reversal sinyali ile başarılı alım fırsatı sağlandı.',
      en: '⏰ EURUSD weekly uptrend, daily pullback, 1H reversal signal provided successful buying opportunity.',
      es: '⏰ EURUSD tendencia alcista semanal, retroceso diario, señal de reversión 1H proporcionó oportunidad de compra exitosa.',
      fr: '⏰ EURUSD tendance haussière hebdomadaire, recul quotidien, signal de retournement 1H a fourni opportunité d\'achat réussie.',
      ru: '⏰ EURUSD недельный восходящий тренд, дневной откат, сигнал разворота 1H обеспечили успешную возможность покупки.'
    },
    icon: <Clock className="w-16 h-16 text-indigo-500" />
  },
  {
    title: { 
      tr: 'Fibonacci Düzeltme Seviyeleri ve Gelişmiş İpuçları', 
      en: 'Fibonacci and Advanced Tips', 
      es: 'Fibonacci y Consejos Avanzados', 
      fr: 'Fibonacci et Conseils Avancés', 
      ru: 'Фибоначчи и продвинутые советы' 
    },
    content: { 
      tr: [
        '• Fibonacci Düzeltme Seviyeleri: Fiyatın geri çekilme seviyelerini belirler; potansiyel dönüş noktalarını gösterir.',
        '• Pivot Noktaları: Günlük, haftalık ve aylık destek-direnç tahminleri sağlar.',
        '• Korelasyon Analizi: Farklı varlıkların birbirine bağlı hareketlerini ölçer; portföy çeşitlendirmesinde faydalıdır.',
        '• Uyumsuzluk: Fiyat ve indikatörün zıt hareketi, trendin zayıfladığını ve dönüş ihtimalini gösterir.',
        '• Çoklu Onaylama: Birden fazla indikatör ve analiz yönteminin aynı sonucu vermesi güvenilirliği artırır.',
        '• Market sentiment ve haber takibi teknik analizle birleştirildiğinde daha etkili sonuçlar verir.'
      ],
      en: [
        '• Fibonacci Retracement: Determines price pullback levels; shows potential reversal points.',
        '• Pivot Points: Provides daily, weekly and monthly support-resistance predictions.',
        '• Correlation Analysis: Measures interconnected movements of different assets; useful for portfolio diversification.',
        '• Divergence: Opposite movement of price and indicator shows trend weakening and reversal possibility.',
        '• Multiple confirmation: Multiple indicators and analysis methods giving same result increases reliability.',
        '• Market sentiment and news tracking combined with technical analysis gives more effective results.'
      ],
      es: [
        '• Fibonacci Retracement: Determina niveles de retroceso de precios; muestra puntos de reversión potenciales.',
        '• Puntos Pivot: Proporciona predicciones de soporte-resistencia diarias, semanales y mensuales.',
        '• Análisis de Correlación: Mide movimientos interconectados de diferentes activos; útil para diversificación de portafolio.',
        '• Divergencia: Movimiento opuesto de precio e indicador muestra debilitamiento de tendencia y posibilidad de reversión.',
        '• Confirmación múltiple: Múltiples indicadores y métodos de análisis dando el mismo resultado aumenta confiabilidad.',
        '• El sentimiento del mercado y seguimiento de noticias combinado con análisis técnico da resultados más efectivos.'
      ],
      fr: [
        '• Fibonacci Retracement: Détermine les niveaux de recul des prix; montre les points de retournement potentiels.',
        '• Points Pivot: Fournit des prédictions de support-résistance quotidiennes, hebdomadaires et mensuelles.',
        '• Analyse de Corrélation: Mesure les mouvements interconnectés de différents actifs; utile pour la diversification de portefeuille.',
        '• Divergence: Mouvement opposé du prix et de l\'indicateur montre affaiblissement de tendance et possibilité de retournement.',
        '• Confirmation multiple: Plusieurs indicateurs et méthodes d\'analyse donnant le même résultat augmente la fiabilité.',
        '• Le sentiment du marché et suivi des nouvelles combiné avec analyse technique donne des résultats plus efficaces.'
      ],
      ru: [
        '• Fibonacci Retracement: Определяет уровни отката цены; показывает потенциальные точки разворота.',
        '• Пивот Точки: Предоставляет ежедневные, еженедельные и ежемесячные прогнозы поддержки-сопротивления.',
        '• Корреляционный Анализ: Измеряет взаимосвязанные движения разных активов; полезен для диверсификации портфеля.',
        '• Дивергенция: Противоположное движение цены и индикатора показывает ослабление тренда и возможность разворота.',
        '• Множественное подтверждение: Несколько индикаторов и методов анализа, дающих один результат, увеличивает надежность.',
        '• Рыночные настроения и отслеживание новостей в сочетании с техническим анализом дает более эффективные результаты.'
      ]
    },
    example: { 
      tr: '📏 Bitcoin 65000$\'dan 45000$\'a düşüş sonrası %61.8 Fibonacci seviyesi olan 57000$\'dan güçlü toparlanma başladı.',
      en: '📏 After Bitcoin decline from 65000$ to 45000$, strong recovery started from 57000$ which is 61.8% Fibonacci level.',
      es: '📏 Después de la caída de Bitcoin de 65000$ a 45000$, comenzó una fuerte recuperación desde 57000$ que es el nivel Fibonacci del 61.8%.',
      fr: '📏 Après la baisse de Bitcoin de 65000$ à 45000$, forte reprise a commencé depuis 57000$ qui est le niveau Fibonacci de 61,8%.',
      ru: '📏 После снижения Bitcoin с 65000$ до 45000$, сильное восстановление началось с 57000$, что является уровнем Фибоначчи 61.8%.'
    },
    icon: <GitBranch className="w-16 h-16 text-yellow-500" />
  },
  {
    title: { 
      tr: 'Yaygın Hatalar', 
      en: 'Common Mistakes', 
      es: 'Errores Comunes', 
      fr: 'Erreurs Courantes', 
      ru: 'Распространенные ошибки' 
    },
    content: { 
      tr: [
        '• Çok fazla indikatör kullanmak kafa karışıklığına sebep olur; maksimum 2 veya 3 indikatörün birbiriyle konfirmasyonunu takip etmek yeterli olacaktır.',
        '• Kendi işlem stratejinizi oluşturmadan sadece internet ve sosyal medyadaki analistlerin işlem fikirlerini kopyalamak.',
        '• Hatalı Destek-direnç seviyesi belirlemek yanlış yönlendirir.',
        '• Stop-loss kullanmamak risklidir.',
        '• Trend karşıtı işlem açmak sizi zarara sürükler. Nehrin akıntısına ters yüzemezsiniz.',
        '• Duygusal kararlar almak ve planınızdan sapmak başarısızlığa yol açar.',
        '• Risk yönetimi kurallarını ihmal etmek ve pozisyon büyüklüğünü yanlış hesaplamak.'
      ],
      en: [
        '• Using too many indicators causes confusion; following confirmation of maximum 2 or 3 indicators with each other will be sufficient.',
        '• Only copying trade ideas from analysts on internet and social media without creating your own trading strategy.',
        '• Incorrectly determining support-resistance levels misleads.',
        '• Not using stop-loss is risky.',
        '• Opening trades against the trend will lead you to loss. You cannot swim against the river current.',
        '• Making emotional decisions and deviating from your plan leads to failure.',
        '• Neglecting risk management rules and miscalculating position size.'
      ],
      es: [
        '• Usar demasiados indicadores causa confusión; seguir confirmación de máximo 2 o 3 indicadores entre sí será suficiente.',
        '• Solo copiar ideas de trading de analistas en internet y redes sociales sin crear tu propia estrategia de trading.',
        '• Determinar incorrectamente niveles de soporte-resistencia desvía.',
        '• No usar stop-loss es arriesgado.',
        '• Abrir operaciones contra la tendencia te llevará a pérdidas. No puedes nadar contra la corriente del río.',
        '• Tomar decisiones emocionales y desviarse de tu plan lleva al fracaso.',
        '• Descuidar reglas de gestión de riesgos y calcular mal el tamaño de posición.'
      ],
      fr: [
        '• Utiliser trop d\'indicateurs cause de la confusion; suivre confirmation de maximum 2 ou 3 indicateurs entre eux sera suffisant.',
        '• Seulement copier des idées de trading d\'analystes sur internet et réseaux sociaux sans créer votre propre stratégie de trading.',
        '• Déterminer incorrectement les niveaux de support-résistance induit en erreur.',
        '• Ne pas utiliser stop-loss est risqué.',
        '• Ouvrir des transactions contre la tendance vous mènera à la perte. Vous ne pouvez pas nager contre le courant de la rivière.',
        '• Prendre des décisions émotionnelles et dévier de votre plan mène à l\'échec.',
        '• Négliger les règles de gestion des risques et mal calculer la taille de position.'
      ],
      ru: [
        '• Использование слишком многих индикаторов вызывает путаницу; следование подтверждению максимум 2 или 3 индикаторов друг с другом будет достаточно.',
        '• Только копирование торговых идей аналитиков из интернета и социальных сетей без создания собственной торговой стратегии.',
        '• Неправильное определение уровней поддержки-сопротивления вводит в заблуждение.',
        '• Не использовать стоп-лосс рискованно.',
        '• Открытие сделок против тренда приведет к убыткам. Вы не можете плыть против течения реки.',
        '• Принятие эмоциональных решений и отклонение от плана ведет к неудаче.',
        '• Пренебрежение правилами управления рисками и неправильный расчет размера позиции.'
      ]
    },
    example: { 
      tr: '⚠️ Trader 7 farklı indikatör kullanarak karışık sinyaller aldı ve %15 zarar etti; sadece 2 indikatör kullansaydı başarılı olabilirdi.',
      en: '⚠️ Trader using 7 different indicators received mixed signals and lost 15%; could have been successful using only 2 indicators.',
      es: '⚠️ El trader usando 7 indicadores diferentes recibió señales mixtas y perdió 15%; podría haber tenido éxito usando solo 2 indicadores.',
      fr: '⚠️ Le trader utilisant 7 indicateurs différents a reçu des signaux mixtes et a perdu 15%; aurait pu réussir en utilisant seulement 2 indicateurs.',
      ru: '⚠️ Трейдер, используя 7 различных индикаторов, получил смешанные сигналы и потерял 15%; мог бы быть успешным, используя только 2 индикатора.'
    },
    icon: <AlertTriangle className="w-16 h-16 text-red-500" />
  }
]

export const technicalAnalysisQuiz = [
  {
    id: 1,
    type: 'multiple-choice',
    question: {
      tr: 'Teknik analizde temel varsayım hangisidir?',
      en: 'What is the basic assumption in technical analysis?',
      es: '¿Cuál es la suposición básica en el análisis técnico?',
      fr: 'Quelle est l\'hypothèse de base dans l\'analyse technique?',
      de: 'Was ist die grundlegende Annahme in der technischen Analyse?',
      it: 'Qual è l\'assunto fondamentale nell\'analisi tecnica?',
      ru: 'Какое основное предположение в техническом анализе?'
    },
    options: {
      tr: [
        'Fiyat her şeyi yansıtır',
        'Şirketin finansal tabloları fiyatı belirler',
        'Makroekonomik göstergeler fiyat üzerinde etkili değildir',
        'Yalnızca haber akışı önemlidir'
      ],
      en: [
        'Price reflects everything',
        'Company financial statements determine price',
        'Macroeconomic indicators have no effect on price',
        'Only news flow matters'
      ],
      es: [
        'El precio refleja todo',
        'Los estados financieros de la empresa determinan el precio',
        'Los indicadores macroeconómicos no tienen efecto en el precio',
        'Solo importa el flujo de noticias'
      ],
      fr: [
        'Le prix reflète tout',
        'Les états financiers de l\'entreprise déterminent le prix',
        'Les indicateurs macroéconomiques n\'ont pas d\'effet sur le prix',
        'Seul le flux d\'actualités compte'
      ],
      de: [
        'Der Preis spiegelt alles wider',
        'Unternehmensabschlüsse bestimmen den Preis',
        'Makroökonomische Indikatoren haben keinen Einfluss auf den Preis',
        'Nur der Nachrichtenfluss ist wichtig'
      ],
      it: [
        'Il prezzo riflette tutto',
        'I bilanci aziendali determinano il prezzo',
        'Gli indicatori macroeconomici non hanno effetto sul prezzo',
        'Solo il flusso di notizie conta'
      ],
      ru: [
        'Цена отражает все',
        'Финансовые отчеты компании определяют цену',
        'Макроэкономические показатели не влияют на цену',
        'Важен только поток новостей'
      ]
    },
    correctAnswer: 0,
    explanation: {
      tr: 'Teknik analizin temel varsayımı "fiyat her şeyi yansıtır" ilkesidir. Bu, tüm mevcut bilgilerin halihazırda fiyatlara yansıdığını kabul eder.',
      en: 'The basic assumption of technical analysis is the principle "price reflects everything". This assumes that all available information is already reflected in prices.',
      es: 'La suposición básica del análisis técnico es el principio "el precio refleja todo". Esto asume que toda la información disponible ya se refleja en los precios.',
      fr: 'L\'hypothèse de base de l\'analyse technique est le principe "le prix reflète tout". Ceci suppose que toute l\'information disponible est déjà reflétée dans les prix.',
      de: 'Die grundlegende Annahme der technischen Analyse ist das Prinzip "der Preis spiegelt alles wider". Dies geht davon aus, dass alle verfügbaren Informationen bereits in den Preisen widergespiegelt sind.',
      it: 'L\'assunto fondamentale dell\'analisi tecnica è il principio "il prezzo riflette tutto". Questo presume che tutte le informazioni disponibili siano già riflesse nei prezzi.',
      ru: 'Основное предположение технического анализа - принцип "цена отражает все". Это предполагает, что вся доступная информация уже отражена в ценах.'
    }
  },
  {
    id: 2,
    type: 'multiple-choice',
    question: {
      tr: 'Destek seviyesi ile ilgili doğru ifade hangisidir?',
      en: 'Which is the correct statement about support level?',
      es: '¿Cuál es la declaración correcta sobre el nivel de soporte?',
      fr: 'Quelle est la déclaration correcte concernant le niveau de support?',
      de: 'Welche ist die richtige Aussage über das Unterstützungsniveau?',
      it: 'Qual è l\'affermazione corretta sul livello di supporto?',
      ru: 'Какое утверждение о уровне поддержки правильное?'
    },
    options: {
      tr: [
        'Fiyatın yükseliş trendinde takıldığı nokta',
        'Fiyatın düşüş trendinde durduğu ve yukarı döndüğü bölge',
        'Sadece yuvarlak sayılardan oluşur',
        'Trendin kırıldığı nokta'
      ],
      en: [
        'Point where price gets stuck in uptrend',
        'Area where price stops in downtrend and turns upward',
        'Consists only of round numbers',
        'Point where trend breaks'
      ],
      es: [
        'Punto donde el precio se atasca en tendencia alcista',
        'Área donde el precio se detiene en tendencia bajista y gira hacia arriba',
        'Consiste solo en números redondos',
        'Punto donde se rompe la tendencia'
      ],
      fr: [
        'Point où le prix reste bloqué dans la tendance haussière',
        'Zone où le prix s\'arrête dans la tendance baissière et tourne vers le haut',
        'Ne consiste qu\'en nombres ronds',
        'Point où la tendance se casse'
      ],
      de: [
        'Punkt, wo der Preis im Aufwärtstrend stecken bleibt',
        'Bereich, wo der Preis im Abwärtstrend stoppt und nach oben dreht',
        'Besteht nur aus runden Zahlen',
        'Punkt, wo der Trend bricht'
      ],
      it: [
        'Punto dove il prezzo si blocca nel trend rialzista',
        'Area dove il prezzo si ferma nel trend ribassista e gira verso l\'alto',
        'Consiste solo in numeri tondi',
        'Punto dove il trend si rompe'
      ],
      ru: [
        'Точка, где цена застревает в восходящем тренде',
        'Область, где цена останавливается в нисходящем тренде и поворачивает вверх',
        'Состоит только из круглых чисел',
        'Точка, где тренд ломается'
      ]
    },
    correctAnswer: 1,
    explanation: {
      tr: 'Destek seviyesi, fiyatın düşüş trendinde durduğu ve genellikle yukarı döndüğü bölgedir. Bu seviye alım baskısının arttığı noktayı gösterir.',
      en: 'Support level is the area where price stops in a downtrend and usually turns upward. This level shows the point where buying pressure increases.',
      es: 'El nivel de soporte es el área donde el precio se detiene en una tendencia bajista y generalmente gira hacia arriba. Este nivel muestra el punto donde aumenta la presión de compra.',
      fr: 'Le niveau de support est la zone où le prix s\'arrête dans une tendance baissière et tourne généralement vers le haut. Ce niveau montre le point où la pression d\'achat augmente.',
      de: 'Das Unterstützungsniveau ist der Bereich, wo der Preis in einem Abwärtstrend stoppt und meist nach oben dreht. Dieses Niveau zeigt den Punkt, wo der Kaufdruck zunimmt.',
      it: 'Il livello di supporto è l\'area dove il prezzo si ferma in un trend ribassista e solitamente gira verso l\'alto. Questo livello mostra il punto dove aumenta la pressione di acquisto.',
      ru: 'Уровень поддержки - это область, где цена останавливается в нисходящем тренде и обычно поворачивает вверх. Этот уровень показывает точку, где увеличивается давление покупок.'
    }
  },
  {
    id: 3,
    type: 'true-false',
    question: {
      tr: 'Trend çizgisi, fiyatın yönünü belirlemede yardımcı olur ve trend yönünde pozisyon almak daha güvenlidir.',
      en: 'Trend line helps determine price direction and taking positions in trend direction is safer.',
      es: 'La línea de tendencia ayuda a determinar la dirección del precio y tomar posiciones en la dirección de la tendencia es más seguro.',
      fr: 'La ligne de tendance aide à déterminer la direction du prix et prendre des positions dans la direction de la tendance est plus sûr.',
      de: 'Die Trendlinie hilft bei der Bestimmung der Preisrichtung und Positionen in Trendrichtung zu nehmen ist sicherer.',
      it: 'La linea di tendenza aiuta a determinare la direzione del prezzo e prendere posizioni nella direzione del trend è più sicuro.',
      ru: 'Линия тренда помогает определить направление цены и занимать позиции в направлении тренда безопаснее.'
    },
    correctAnswer: true,
    explanation: {
      tr: 'Doğru. Trend çizgileri fiyat yönünü gösterir ve genel olarak "trend sizin dostunuzdur" ilkesi geçerlidir. Trend yönünde işlem yapmak daha yüksek başarı oranı sağlar.',
      en: 'True. Trend lines show price direction and generally the principle "trend is your friend" applies. Trading in trend direction provides higher success rate.',
      es: 'Verdadero. Las líneas de tendencia muestran la dirección del precio y generalmente se aplica el principio "la tendencia es tu amiga". Operar en la dirección de la tendencia proporciona una mayor tasa de éxito.',
      fr: 'Vrai. Les lignes de tendance montrent la direction du prix et généralement le principe "la tendance est votre amie" s\'applique. Trader dans la direction de la tendance fournit un taux de succès plus élevé.',
      de: 'Wahr. Trendlinien zeigen die Preisrichtung und generell gilt das Prinzip "der Trend ist dein Freund". Der Handel in Trendrichtung bietet eine höhere Erfolgsrate.',
      it: 'Vero. Le linee di tendenza mostrano la direzione del prezzo e generalmente si applica il principio "il trend è tuo amico". Fare trading nella direzione del trend fornisce un tasso di successo più alto.',
      ru: 'Верно. Линии тренда показывают направление цены и в целом действует принцип "тренд - ваш друг". Торговля в направлении тренда обеспечивает более высокий процент успеха.'
    }
  },
  {
    id: 4,
    type: 'multiple-choice',
    question: {
      tr: 'RSI (Relative Strength Index) hangi seviyede aşırı alım sinyali verir?',
      en: 'At which level does RSI (Relative Strength Index) give overbought signal?',
      es: '¿En qué nivel da el RSI (Índice de Fuerza Relativa) señal de sobrecompra?',
      fr: 'À quel niveau le RSI (Relative Strength Index) donne-t-il un signal de surachat?',
      de: 'Auf welchem Niveau gibt der RSI (Relative Strength Index) ein überkauftes Signal?',
      it: 'A quale livello l\'RSI (Relative Strength Index) dà segnale di ipercomprato?',
      ru: 'На каком уровне RSI (Relative Strength Index) дает сигнал перекупленности?'
    },
    options: {
      tr: ['30', '50', '70', '90'],
      en: ['30', '50', '70', '90'],
      es: ['30', '50', '70', '90'],
      fr: ['30', '50', '70', '90'],
      de: ['30', '50', '70', '90'],
      it: ['30', '50', '70', '90'],
      ru: ['30', '50', '70', '90']
    },
    correctAnswer: 2,
    explanation: {
      tr: 'RSI 70 seviyesinin üzerinde aşırı alım bölgesine girer ve satış sinyali verebilir. 30 seviyesinin altında ise aşırı satım bölgesindedir.',
      en: 'RSI enters overbought zone above 70 level and may give sell signal. Below 30 level it is in oversold zone.',
      es: 'El RSI entra en zona de sobrecompra por encima del nivel 70 y puede dar señal de venta. Por debajo del nivel 30 está en zona de sobreventa.',
      fr: 'Le RSI entre en zone de surachat au-dessus du niveau 70 et peut donner un signal de vente. En dessous du niveau 30, il est en zone de survente.',
      de: 'Der RSI tritt über dem Niveau 70 in die überkaufte Zone ein und kann ein Verkaufssignal geben. Unter dem Niveau 30 ist er in der überverkauften Zone.',
      it: 'L\'RSI entra in zona di ipercomprato sopra il livello 70 e può dare segnale di vendita. Sotto il livello 30 è in zona di ipervenduto.',
      ru: 'RSI входит в зону перекупленности выше уровня 70 и может дать сигнал к продаже. Ниже уровня 30 находится в зоне перепроданности.'
    }
  },
  {
    id: 5,
    type: 'multiple-choice',
    question: {
      tr: 'MACD indikatöründe hangi durum alım sinyali olarak kabul edilir?',
      en: 'Which situation in MACD indicator is considered as buy signal?',
      es: '¿Qué situación en el indicador MACD se considera como señal de compra?',
      fr: 'Quelle situation dans l\'indicateur MACD est considérée comme signal d\'achat?',
      de: 'Welche Situation im MACD-Indikator wird als Kaufsignal betrachtet?',
      it: 'Quale situazione nell\'indicatore MACD è considerata come segnale di acquisto?',
      ru: 'Какая ситуация в индикаторе MACD считается сигналом к покупке?'
    },
    options: {
      tr: [
        'MACD çizgisi sinyal çizgisinin altına düşerse',
        'MACD çizgisi sinyal çizgisini yukarı keserse',
        'Fiyat hareketleri MACD ile uyumlu değilse',
        'RSI 70 üzerine çıkarsa'
      ],
      en: [
        'MACD line falls below signal line',
        'MACD line crosses signal line upward',
        'Price movements are not compatible with MACD',
        'RSI rises above 70'
      ],
      es: [
        'La línea MACD cae por debajo de la línea de señal',
        'La línea MACD cruza la línea de señal hacia arriba',
        'Los movimientos de precios no son compatibles con MACD',
        'El RSI sube por encima de 70'
      ],
      fr: [
        'La ligne MACD tombe en dessous de la ligne de signal',
        'La ligne MACD croise la ligne de signal vers le haut',
        'Les mouvements de prix ne sont pas compatibles avec MACD',
        'Le RSI monte au-dessus de 70'
      ],
      de: [
        'MACD-Linie fällt unter die Signallinie',
        'MACD-Linie kreuzt die Signallinie nach oben',
        'Preisbewegungen sind nicht mit MACD kompatibel',
        'RSI steigt über 70'
      ],
      it: [
        'La linea MACD scende sotto la linea del segnale',
        'La linea MACD attraversa la linea del segnale verso l\'alto',
        'I movimenti dei prezzi non sono compatibili con MACD',
        'L\'RSI sale sopra 70'
      ],
      ru: [
        'Линия MACD опускается ниже сигнальной линии',
        'Линия MACD пересекает сигнальную линию вверх',
        'Движения цен не совместимы с MACD',
        'RSI поднимается выше 70'
      ]
    },
    correctAnswer: 1,
    explanation: {
      tr: 'MACD\'de alım sinyali, MACD çizgisinin sinyal çizgisini aşağıdan yukarı kesmesidir. Bu bullish crossover olarak adlandırılır.',
      en: 'Buy signal in MACD is when MACD line crosses the signal line from below to above. This is called bullish crossover.',
      es: 'La señal de compra en MACD es cuando la línea MACD cruza la línea de señal de abajo hacia arriba. Esto se llama cruce alcista.',
      fr: 'Le signal d\'achat dans MACD est quand la ligne MACD croise la ligne de signal de bas en haut. Ceci s\'appelle un croisement haussier.',
      de: 'Das Kaufsignal in MACD ist, wenn die MACD-Linie die Signallinie von unten nach oben kreuzt. Dies wird bullish crossover genannt.',
      it: 'Il segnale di acquisto in MACD è quando la linea MACD attraversa la linea del segnale dal basso verso l\'alto. Questo è chiamato crossover rialzista.',
      ru: 'Сигнал к покупке в MACD - это когда линия MACD пересекает сигнальную линию снизу вверх. Это называется бычьим пересечением.'
    }
  },
  {
    id: 6,
    type: 'short-answer',
    question: {
      tr: 'Bollinger Bandları neyi gösterir?',
      en: 'What do Bollinger Bands show?',
      es: '¿Qué muestran las Bandas de Bollinger?',
      fr: 'Que montrent les Bandes de Bollinger?',
      de: 'Was zeigen Bollinger-Bänder?',
      it: 'Cosa mostrano le Bande di Bollinger?',
      ru: 'Что показывают полосы Боллинджера?'
    },
    correctAnswer: {
      tr: 'Fiyatın volatilitesini ve potansiyel dönüş noktalarını gösterir; üst ve alt bantlar ile trend içindeki hareketleri sınırlar.',
      en: 'Shows price volatility and potential reversal points; limits movements within trend with upper and lower bands.',
      es: 'Muestra la volatilidad del precio y puntos de reversión potenciales; limita movimientos dentro de la tendencia con bandas superiores e inferiores.',
      fr: 'Montre la volatilité des prix et les points de retournement potentiels; limite les mouvements dans la tendance avec les bandes supérieures et inférieures.',
      de: 'Zeigt Preisvolatilität und potenzielle Umkehrpunkte; begrenzt Bewegungen innerhalb des Trends mit oberen und unteren Bändern.',
      it: 'Mostra la volatilità del prezzo e punti di inversione potenziali; limita i movimenti all\'interno del trend con bande superiori e inferiori.',
      ru: 'Показывает волатильность цены и потенциальные точки разворота; ограничивает движения в рамках тренда верхними и нижними полосами.'
    }
  },
  {
    id: 7,
    type: 'multiple-choice',
    question: {
      tr: 'Baş-Omuz formasyonu genellikle hangi yön sinyali verir?',
      en: 'Head and Shoulders formation usually gives which direction signal?',
      es: '¿La formación Cabeza y Hombros generalmente da qué señal de dirección?',
      fr: 'La formation Tête et Épaules donne généralement quel signal de direction?',
      de: 'Die Kopf-und-Schultern-Formation gibt normalerweise welches Richtungssignal?',
      it: 'La formazione Testa e Spalle di solito dà quale segnale di direzione?',
      ru: 'Формация \"Голова и плечи\" обычно дает сигнал в каком направлении?'
    },
    options: {
      tr: ['Yukarı', 'Aşağı', 'Yatay', 'Belirsiz'],
      en: ['Upward', 'Downward', 'Sideways', 'Uncertain'],
      es: ['Hacia arriba', 'Hacia abajo', 'Lateral', 'Incierto'],
      fr: ['Vers le haut', 'Vers le bas', 'Latéral', 'Incertain'],
      de: ['Nach oben', 'Nach unten', 'Seitwärts', 'Ungewiss'],
      it: ['Verso l\'alto', 'Verso il basso', 'Laterale', 'Incerto'],
      ru: ['Вверх', 'Вниз', 'Боком', 'Неопределенно']
    },
    correctAnswer: 1,
    explanation: {
      tr: 'Baş-Omuz formasyonu tipik bir dönüş formasyonudur ve genellikle düşüş sinyali verir. Bu formasyon yükseliş trendinin sonunda görülür.',
      en: 'Head and Shoulders formation is a typical reversal pattern and usually gives a downward signal. This formation appears at the end of an uptrend.',
      es: 'La formación Cabeza y Hombros es un patrón de reversión típico y generalmente da una señal bajista. Esta formación aparece al final de una tendencia alcista.',
      fr: 'La formation Tête et Épaules est un modèle de retournement typique et donne généralement un signal baissier. Cette formation apparaît à la fin d\'une tendance haussière.',
      de: 'Die Kopf-und-Schultern-Formation ist ein typisches Umkehrmuster und gibt normalerweise ein Abwärtssignal. Diese Formation erscheint am Ende eines Aufwärtstrends.',
      it: 'La formazione Testa e Spalle è un pattern di inversione tipico e di solito dà un segnale ribassista. Questa formazione appare alla fine di un trend rialzista.',
      ru: 'Формация \"Голова и плечи\" - это типичная модель разворота и обычно дает сигнал к снижению. Эта формация появляется в конце восходящего тренда.'
    }
  },
  {
    id: 8,
    type: 'multiple-choice',
    question: {
      tr: 'Volume (hacim) analizi neden önemlidir?',
      en: 'Why is Volume analysis important?',
      es: '¿Por qué es importante el análisis de Volumen?',
      fr: 'Pourquoi l\'analyse du Volume est-elle importante?',
      de: 'Warum ist die Volumen-Analyse wichtig?',
      it: 'Perché l\'analisi del Volume è importante?',
      ru: 'Почему анализ объема важен?'
    },
    options: {
      tr: [
        'Fiyat hareketlerini doğrulamak için',
        'Yalnızca kısa vadeli traderlar için',
        'Trend çizgilerini çizmek için',
        'Fundamental analiz için'
      ],
      en: [
        'To confirm price movements',
        'Only for short-term traders',
        'To draw trend lines',
        'For fundamental analysis'
      ],
      es: [
        'Para confirmar movimientos de precios',
        'Solo para traders a corto plazo',
        'Para dibujar líneas de tendencia',
        'Para análisis fundamental'
      ],
      fr: [
        'Pour confirmer les mouvements de prix',
        'Seulement pour les traders à court terme',
        'Pour dessiner des lignes de tendance',
        'Pour l\'analyse fondamentale'
      ],
      de: [
        'Um Preisbewegungen zu bestätigen',
        'Nur für kurzfristige Trader',
        'Um Trendlinien zu zeichnen',
        'Für die Fundamentalanalyse'
      ],
      it: [
        'Per confermare i movimenti dei prezzi',
        'Solo per trader a breve termine',
        'Per disegnare linee di tendenza',
        'Per analisi fondamentale'
      ],
      ru: [
        'Для подтверждения движений цены',
        'Только для краткосрочных трейдеров',
        'Для рисования линий тренда',
        'Для фундаментального анализа'
      ]
    },
    correctAnswer: 0,
    explanation: {
      tr: 'Volume analizi, fiyat hareketlerinin güvenilirliğini doğrulamak için kullanılır. Yüksek hacimle gerçekleşen fiyat hareketleri daha güçlü kabul edilir.',
      en: 'Volume analysis is used to confirm the reliability of price movements. Price movements occurring with high volume are considered stronger.',
      es: 'El análisis de volumen se usa para confirmar la confiabilidad de los movimientos de precios. Los movimientos de precios que ocurren con alto volumen se consideran más fuertes.',
      fr: 'L\'analyse du volume est utilisée pour confirmer la fiabilité des mouvements de prix. Les mouvements de prix se produisant avec un volume élevé sont considérés comme plus forts.',
      de: 'Die Volumen-Analyse wird verwendet, um die Zuverlässigkeit von Preisbewegungen zu bestätigen. Preisbewegungen mit hohem Volumen werden als stärker betrachtet.',
      it: 'L\'analisi del volume è usata per confermare l\'affidabilità dei movimenti dei prezzi. I movimenti dei prezzi che avvengono con alto volume sono considerati più forti.',
      ru: 'Анализ объема используется для подтверждения надежности движений цены. Движения цены, происходящие с высоким объемом, считаются более сильными.'
    }
  },
  {
    id: 9,
    type: 'true-false',
    question: {
      tr: 'Tüm zaman çerçevelerinde aynı yönde trend olması güçlü bir sinyal verir.',
      en: 'Having trends in the same direction across all timeframes gives a strong signal.',
      es: 'Tener tendencias en la misma dirección en todos los marcos temporales da una señal fuerte.',
      fr: 'Avoir des tendances dans la même direction sur tous les délais donne un signal fort.',
      de: 'Trends in die gleiche Richtung über alle Zeitrahmen hinweg geben ein starkes Signal.',
      it: 'Avere tendenze nella stessa direzione su tutti i timeframe dà un segnale forte.',
      ru: 'Наличие трендов в одном направлении на всех таймфреймах дает сильный сигнал.'
    },
    correctAnswer: true,
    explanation: {
      tr: 'Doğru. Multi-timeframe uyumu güçlü bir sinyaldir. Farklı zaman çerçevelerinde aynı yönde trend olması, hareketin güvenilirliğini artırır.',
      en: 'True. Multi-timeframe alignment is a strong signal. Having trends in the same direction across different timeframes increases the reliability of the movement.',
      es: 'Verdadero. La alineación multi-temporal es una señal fuerte. Tener tendencias en la misma dirección en diferentes marcos temporales aumenta la confiabilidad del movimiento.',
      fr: 'Vrai. L\'alignement multi-temporel est un signal fort. Avoir des tendances dans la même direction sur différents délais augmente la fiabilité du mouvement.',
      de: 'Wahr. Multi-Zeitrahmen-Ausrichtung ist ein starkes Signal. Trends in die gleiche Richtung über verschiedene Zeitrahmen hinweg zu haben, erhöht die Zuverlässigkeit der Bewegung.',
      it: 'Vero. L\'allineamento multi-timeframe è un segnale forte. Avere tendenze nella stessa direzione su diversi timeframe aumenta l\'affidabilità del movimento.',
      ru: 'Верно. Выравнивание по нескольким таймфреймам - это сильный сигнал. Наличие трендов в одном направлении на разных таймфреймах повышает надежность движения.'
    }
  },
  {
    id: 10,
    type: 'multiple-choice',
    question: {
      tr: 'Risk yönetiminde tek işlemde sermayenin maksimum kaçını riske atmak önerilir?',
      en: 'In risk management, what maximum percentage of capital is recommended to risk in a single trade?',
      es: 'En la gestión de riesgos, ¿qué porcentaje máximo del capital se recomienda arriesgar en una sola operación?',
      fr: 'En gestion des risques, quel pourcentage maximum du capital est-il recommandé de risquer dans une seule transaction?',
      de: 'Im Risikomanagement, welcher maximale Prozentsatz des Kapitals wird empfohlen, in einem einzigen Trade zu riskieren?',
      it: 'Nella gestione del rischio, quale percentuale massima del capitale è raccomandata rischiare in una singola operazione?',
      ru: 'В управлении рисками какой максимальный процент капитала рекомендуется рисковать в одной сделке?'
    },
    options: {
      tr: ['%10', '%5', '%1-2', '%20'],
      en: ['10%', '5%', '1-2%', '20%'],
      es: ['10%', '5%', '1-2%', '20%'],
      fr: ['10%', '5%', '1-2%', '20%'],
      de: ['10%', '5%', '1-2%', '20%'],
      it: ['10%', '5%', '1-2%', '20%'],
      ru: ['10%', '5%', '1-2%', '20%']
    },
    correctAnswer: 2,
    explanation: {
      tr: 'Risk yönetiminde tek işlemde sermayenin maksimum %1-2\'sini riske atmak önerilir. Bu konservatif yaklaşım uzun vadeli başarı için kritiktir.',
      en: 'In risk management, it is recommended to risk maximum 1-2% of capital in a single trade. This conservative approach is critical for long-term success.',
      es: 'En la gestión de riesgos, se recomienda arriesgar máximo 1-2% del capital en una sola operación. Este enfoque conservador es crítico para el éxito a largo plazo.',
      fr: 'En gestion des risques, il est recommandé de risquer maximum 1-2% du capital dans une seule transaction. Cette approche conservatrice est critique pour le succès à long terme.',
      de: 'Im Risikomanagement wird empfohlen, maximal 1-2% des Kapitals in einem einzigen Trade zu riskieren. Dieser konservative Ansatz ist kritisch für langfristigen Erfolg.',
      it: 'Nella gestione del rischio, è raccomandato rischiare massimo 1-2% del capitale in una singola operazione. Questo approccio conservativo è critico per il successo a lungo termine.',
      ru: 'В управлении рисками рекомендуется рисковать максимум 1-2% капитала в одной сделке. Этот консервативный подход критически важен для долгосрочного успеха.'
    }
  },
  {
    id: 11,
    type: 'multiple-choice',
    question: {
      tr: 'Hangi durum, yaygın bir teknik analiz hatası değildir?',
      en: 'Which situation is NOT a common technical analysis mistake?',
      es: '¿Qué situación NO es un error común del análisis técnico?',
      fr: 'Quelle situation n\'est PAS une erreur courante d\'analyse technique?',
      de: 'Welche Situation ist KEIN häufiger technischer Analysefehler?',
      it: 'Quale situazione NON è un errore comune dell\'analisi tecnica?',
      ru: 'Какая ситуация НЕ является распространенной ошибкой технического анализа?'
    },
    options: {
      tr: [
        'Aşırı indikatör kullanımı',
        'Stop-loss kullanmamak',
        'Trend yönünde pozisyon almak',
        'Onay bias\'ı'
      ],
      en: [
        'Using too many indicators',
        'Not using stop-loss',
        'Taking positions in trend direction',
        'Confirmation bias'
      ],
      es: [
        'Usar demasiados indicadores',
        'No usar stop-loss',
        'Tomar posiciones en dirección de la tendencia',
        'Sesgo de confirmación'
      ],
      fr: [
        'Utiliser trop d\'indicateurs',
        'Ne pas utiliser stop-loss',
        'Prendre des positions dans la direction de la tendance',
        'Biais de confirmation'
      ],
      de: [
        'Zu viele Indikatoren verwenden',
        'Keinen Stop-Loss verwenden',
        'Positionen in Trendrichtung einnehmen',
        'Bestätigungsfehler'
      ],
      it: [
        'Usare troppi indicatori',
        'Non usare stop-loss',
        'Prendere posizioni nella direzione del trend',
        'Bias di conferma'
      ],
      ru: [
        'Использование слишком многих индикаторов',
        'Не использовать стоп-лосс',
        'Занимать позиции в направлении тренда',
        'Предвзятость подтверждения'
      ]
    },
    correctAnswer: 2,
    explanation: {
      tr: 'Trend yönünde pozisyon almak yaygın bir hata değildir, aksine doğru bir yaklaşımdır. "Trend sizin dostunuzdur" prensibi geçerlidir.',
      en: 'Taking positions in trend direction is not a common mistake, but rather a correct approach. The principle "trend is your friend" applies.',
      es: 'Tomar posiciones en la dirección de la tendencia no es un error común, sino un enfoque correcto. Se aplica el principio "la tendencia es tu amiga".',
      fr: 'Prendre des positions dans la direction de la tendance n\'est pas une erreur courante, mais plutôt une approche correcte. Le principe "la tendance est votre amie" s\'applique.',
      de: 'Positionen in Trendrichtung einzunehmen ist kein häufiger Fehler, sondern ein korrekter Ansatz. Das Prinzip "der Trend ist dein Freund" gilt.',
      it: 'Prendere posizioni nella direzione del trend non è un errore comune, ma piuttosto un approccio corretto. Si applica il principio "il trend è tuo amico".',
      ru: 'Занимать позиции в направлении тренда - это не распространенная ошибка, а правильный подход. Действует принцип "тренд - ваш друг".'
    }
  },
  {
    id: 12,
    type: 'short-answer',
    question: {
      tr: 'Multi-timeframe analiz nedir ve neden önemlidir?',
      en: 'What is multi-timeframe analysis and why is it important?',
      es: '¿Qué es el análisis multi-temporal y por qué es importante?',
      fr: 'Qu\'est-ce que l\'analyse multi-temporelle et pourquoi est-elle importante?',
      de: 'Was ist Multi-Zeitrahmen-Analyse und warum ist sie wichtig?',
      it: 'Cos\'è l\'analisi multi-timeframe e perché è importante?',
      ru: 'Что такое мульти-таймфрейм анализ и почему он важен?'
    },
    correctAnswer: {
      tr: 'Farklı zaman çerçevelerinde trend ve giriş noktalarını analiz etme yöntemidir; trend uyumu ve giriş zamanlamasını optimize eder.',
      en: 'Method of analyzing trends and entry points across different timeframes; optimizes trend alignment and entry timing.',
      es: 'Método de analizar tendencias y puntos de entrada en diferentes marcos temporales; optimiza la alineación de tendencias y el timing de entrada.',
      fr: 'Méthode d\'analyse des tendances et points d\'entrée sur différents délais; optimise l\'alignement des tendances et le timing d\'entrée.',
      de: 'Methode zur Analyse von Trends und Einstiegspunkten über verschiedene Zeitrahmen; optimiert Trend-Ausrichtung und Einstiegs-Timing.',
      it: 'Metodo di analisi di tendenze e punti di ingresso su diversi timeframe; ottimizza l\'allineamento delle tendenze e il timing di ingresso.',
      ru: 'Метод анализа тре��дов и точек входа на разных таймфреймах; оптимизирует выравнивание трендов и время входа.'
    }
  },
  {
    id: 13,
    type: 'multiple-choice',
    question: {
      tr: 'Yükselen üçgen formasyonu genellikle hangi trendin devamını gösterir?',
      en: 'Ascending triangle formation usually shows continuation of which trend?',
      es: '¿La formación de triángulo ascendente generalmente muestra continuación de qué tendencia?',
      fr: 'La formation triangle ascendant montre généralement la continuation de quelle tendance?',
      de: 'Die aufsteigende Dreiecksformation zeigt normalerweise die Fortsetzung welchen Trends?',
      it: 'La formazione triangolo ascendente di solito mostra la continuazione di quale trend?',
      ru: 'Формация восходящий треугольник обычно показывает продолжение какого тренда?'
    },
    options: {
      tr: ['Düşüş', 'Yükseliş', 'Yatay', 'Belirsiz'],
      en: ['Downtrend', 'Uptrend', 'Sideways', 'Uncertain'],
      es: ['Tendencia bajista', 'Tendencia alcista', 'Lateral', 'Incierto'],
      fr: ['Tendance baissière', 'Tendance haussière', 'Latéral', 'Incertain'],
      de: ['Abwärtstrend', 'Aufwärtstrend', 'Seitwärts', 'Ungewiss'],
      it: ['Trend ribassista', 'Trend rialzista', 'Laterale', 'Incerto'],
      ru: ['Нисходящий тренд', 'Восходящий тренд', 'Боком', 'Неопределенно']
    },
    correctAnswer: 1,
    explanation: {
      tr: 'Yükselen üçgen formasyonu genellikle yükseliş trendinin devamını gösterir. Bu formasyon yükseliş momentumunun güçlü olduğunu işaret eder.',
      en: 'Ascending triangle formation usually shows continuation of uptrend. This formation signals that upward momentum is strong.',
      es: 'La formación de triángulo ascendente generalmente muestra continuación de la tendencia alcista. Esta formación señala que el momentum alcista es fuerte.',
      fr: 'La formation triangle ascendant montre généralement la continuation de la tendance haussière. Cette formation signale que le momentum haussier est fort.',
      de: 'Die aufsteigende Dreiecksformation zeigt normalerweise die Fortsetzung des Aufwärtstrends. Diese Formation signalisiert starkes Aufwärtsmomentum.',
      it: 'La formazione triangolo ascendente di solito mostra la continuazione del trend rialzista. Questa formazione segnala che il momentum rialzista è forte.',
      ru: 'Формация восходящий треугольник обычно показывает продолжение восходящего тренда. Эта формация сигнализирует о сильном восходящем импульсе.'
    }
  },
  {
    id: 14,
    type: 'true-false',
    question: {
      tr: 'Stop-loss belirlerken keyfi yüzdeler yerine teknik seviyelere göre hareket etmek önerilir.',
      en: 'When setting stop-loss, it is recommended to act according to technical levels rather than arbitrary percentages.',
      es: 'Al establecer stop-loss, se recomienda actuar según niveles técnicos en lugar de porcentajes arbitrarios.',
      fr: 'Lors de la définition du stop-loss, il est recommandé d\'agir selon des niveaux techniques plutôt que des pourcentages arbitraires.',
      de: 'Bei der Festlegung von Stop-Loss wird empfohlen, nach technischen Levels statt willkürlichen Prozentsätzen zu handeln.',
      it: 'Quando si imposta lo stop-loss, è raccomandato agire secondo livelli tecnici piuttosto che percentuali arbitrarie.',
      ru: 'При установке стоп-лосса рекомендуется действовать согласно техническим уровням, а не произвольным процентам.'
    },
    correctAnswer: true,
    explanation: {
      tr: 'Doğru. Stop-loss\'lar destek/direnç seviyeleri, trend çizgileri gibi teknik seviyelere göre yerleştirilmelidir, keyfi yüzdelere göre değil.',
      en: 'True. Stop-losses should be placed according to technical levels like support/resistance levels, trend lines, not according to arbitrary percentages.',
      es: 'Verdadero. Los stop-losses deben colocarse según niveles técnicos como niveles de soporte/resistencia, líneas de tendencia, no según porcentajes arbitrarios.',
      fr: 'Vrai. Les stop-losses doivent être placés selon des niveaux techniques comme les niveaux de support/résistance, lignes de tendance, pas selon des pourcentages arbitraires.',
      de: 'Wahr. Stop-Losses sollten nach technischen Levels wie Unterstützungs-/Widerstandslevels, Trendlinien platziert werden, nicht nach willkürlichen Prozentsätzen.',
      it: 'Vero. Gli stop-loss dovrebbero essere posizionati secondo livelli tecnici come livelli di supporto/resistenza, linee di tendenza, non secondo percentuali arbitrarie.',
      ru: 'Верно. Стоп-лоссы должны размещаться согласно техническим уровням, таким как уровни поддержки/сопротивления, линии тренда, а не согласно произвольным процентам.'
    }
  },
  {
    id: 15,
    type: 'multiple-choice',
    question: {
      tr: 'Bayrak ve flama formasyonları genellikle hangi hareketi işaret eder?',
      en: 'Flag and pennant formations usually indicate which movement?',
      es: '¿Las formaciones de bandera y banderín generalmente indican qué movimiento?',
      fr: 'Les formations drapeau et flamme indiquent généralement quel mouvement?',
      de: 'Flaggen- und Wimpelformationen zeigen normalerweise welche Bewegung an?',
      it: 'Le formazioni bandiera e pennone di solito indicano quale movimento?',
      ru: 'Формации флаг и вымпел обычно указывают на какое движение?'
    },
    options: {
      tr: [
        'Trendin devamı',
        'Trendin tersine dönmesi',
        'Yatay konsolidasyon',
        'Volatilite düşüşü'
      ],
      en: [
        'Trend continuation',
        'Trend reversal',
        'Horizontal consolidation',
        'Volatility decline'
      ],
      es: [
        'Continuación de tendencia',
        'Reversión de tendencia',
        'Consolidación horizontal',
        'Declive de volatilidad'
      ],
      fr: [
        'Continuation de tendance',
        'Retournement de tendance',
        'Consolidation horizontale',
        'Déclin de volatilité'
      ],
      de: [
        'Trend-Fortsetzung',
        'Trend-Umkehr',
        'Horizontale Konsolidierung',
        'Volatilitätsrückgang'
      ],
      it: [
        'Continuazione del trend',
        'Inversione del trend',
        'Consolidamento orizzontale',
        'Declino della volatilità'
      ],
      ru: [
        'Продолжение тренда',
        'Разворот тренда',
        'Горизонтальная консолидация',
        'Снижение волатильности'
      ]
    },
    correctAnswer: 0,
    explanation: {
      tr: 'Bayrak ve flama formasyonları trend devam formasyonlarıdır. Kısa süreli konsolidasyon sonrası trendin önceki yönünde devam edeceğini işaret ederler.',
      en: 'Flag and pennant formations are trend continuation patterns. They indicate that after short-term consolidation, the trend will continue in its previous direction.',
      es: 'Las formaciones de bandera y banderín son patrones de continuación de tendencia. Indican que después de consolidación a corto plazo, la tendencia continuará en su dirección anterior.',
      fr: 'Les formations drapeau et flamme sont des modèles de continuation de tendance. Elles indiquent qu\'après consolidation à court terme, la tendance continuera dans sa direction précédente.',
      de: 'Flaggen- und Wimpelformationen sind Trend-Fortsetzungsmuster. Sie zeigen an, dass nach kurzfristiger Konsolidierung der Trend in seiner vorherigen Richtung weitergehen wird.',
      it: 'Le formazioni bandiera e pennone sono pattern di continuazione del trend. Indicano che dopo consolidamento a breve termine, il trend continuerà nella sua direzione precedente.',
      ru: 'Формации флаг и вымпел - это модели продолжения тренда. Они указывают, что после краткосрочной консолидации тренд продолжится в своем предыдущем направлении.'
    }
  }
]