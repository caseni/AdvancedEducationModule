// This file is no longer needed - original useLanguage.tsx has been updated with German and Portuguese translations

interface LanguageContextType {
  language: Language
  setLanguage: (lang: Language) => void
  t: (key: string) => string
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

interface TranslationData {
  [key: string]: {
    [lang in Language]: string
  }
}

const translations: TranslationData = {
  // Navigation & Headers
  'platform.title': {
    tr: 'Finans Eğitim Akademi',
    en: 'Finance Education Academy',
    es: 'Academia de Educación Financiera',
    fr: 'Académie d\'Éducation Financière',
    ru: 'Академия Финансового Образования',
    de: 'Finanzbildungs-Akademie',
    pt: 'Academia de Educação Financeira'
  },
  'platform.subtitle': {
    tr: 'Kapsamlı eğitim programları ile işlem ve finans dünyasında profesyonel kariyerinizi inşa edin.',
    en: 'Build your professional career in trading and finance with comprehensive educational programs.',
    es: 'Construye tu carrera profesional en trading y finanzas con programas educativos integrales.',
    fr: 'Construisez votre carrière professionnelle en trading et finance avec des programmes éducatifs complets.',
    ru: 'Постройте свою профессиональную карьеру в трейдинге и финансах с комплексными образовательными программами.',
    de: 'Bauen Sie Ihre Karriere im Trading und Finanzwesen mit umfassenden Bildungsprogrammen auf.',
    pt: 'Construa sua carreira profissional em trading e finanças com programas educacionais abrangentes.'
  },

  // Categories
  'categories.title': {
    tr: 'Eğitim Seviyeleri',
    en: 'Education Levels',
    es: 'Niveles de Educación',
    fr: 'Niveaux d\'Éducation',
    ru: 'Уровни Образования',
    de: 'Bildungsstufen',
    pt: 'Níveis de Educação'
  },
  'categories.subtitle': {
    tr: 'İlgi alanınıza göre filtreleyerek hızlıca başlayın',
    en: 'Filter by your interests and get started quickly',
    es: 'Filtra por tus intereses y comienza rápidamente',
    fr: 'Filtrez selon vos intérêts et commencez rapidement',
    ru: 'Фильтруйте по своим интересам и быстро начинайте',
    de: 'Filtern Sie nach Ihren Interessen und starten Sie schnell',
    pt: 'Filtre pelos seus interesses e comece rapidamente'
  },
  'categories.all': {
    tr: 'Tüm Eğitimler',
    en: 'All Courses',
    es: 'Todos los Cursos',
    fr: 'Tous les Cours',
    ru: 'Все Курсы',
    de: 'Alle Kurse',
    pt: 'Todos os Cursos'
  },
  'categories.economics': {
    tr: 'Temel Ekonomi',
    en: 'Basic Economics',
    es: 'Economía Básica',
    fr: 'Économie de Base',
    ru: 'Основы Экономики',
    de: 'Grundlagen der Wirtschaft',
    pt: 'Economia Básica'
  },
  'categories.analysis': {
    tr: 'Analiz',
    en: 'Analysis',
    es: 'Análisis',
    fr: 'Analyse',
    ru: 'Анализ',
    de: 'Analyse',
    pt: 'Análise'
  },
  'categories.risk': {
    tr: 'Risk Yönetimi',
    en: 'Risk Management',
    es: 'Gestión de Riesgos',
    fr: 'Gestion des Risques',
    ru: 'Управление Рисками',
    de: 'Risikomanagement',
    pt: 'Gestão de Riscos'
  },
  'categories.psychology': {
    tr: 'Psikoloji',
    en: 'Psychology',
    es: 'Psicología',
    fr: 'Psychologie',
    ru: 'Психология',
    de: 'Psychologie',
    pt: 'Psicologia'
  },
  'categories.algorithmic': {
    tr: 'Algoritmik İşlemler',
    en: 'Algorithmic Trading',
    es: 'Trading Algorítmico',
    fr: 'Trading Algorithmique',
    ru: 'Алгоритмическая Торговля',
    de: 'Algorithmischer Handel',
    pt: 'Trading Algorítmico'
  },
  'categories.finance': {
    tr: 'Finans',
    en: 'Finance',
    es: 'Finanzas',
    fr: 'Finance',
    ru: 'Финансы',
    de: 'Finanzen',
    pt: 'Finanças'
  },
  'categories.crypto': {
    tr: 'Kripto',
    en: 'Crypto',
    es: 'Cripto',
    fr: 'Crypto',
    ru: 'Крипто',
    de: 'Krypto',
    pt: 'Cripto'
  },

  // Course Actions
  'course.start': {
    tr: 'Eğitime Başla',
    en: 'Start Course',
    es: 'Comenzar Curso',
    fr: 'Commencer le Cours',
    ru: 'Начать Курс',
    de: 'Kurs Beginnen',
    pt: 'Iniciar Curso'
  },
  'course.startLearning': {
    tr: 'Eğitime Başla',
    en: 'Start Course',
    es: 'Comenzar Curso',
    fr: 'Commencer le Cours',
    ru: 'Начать Курс',
    de: 'Kurs Beginnen',
    pt: 'Iniciar Curso'
  },
  'course.continue': {
    tr: 'Devam Et',
    en: 'Continue',
    es: 'Continuar',
    fr: 'Continuer',
    ru: 'Продолжить',
    de: 'Fortfahren',
    pt: 'Continuar'
  },

  // Course Details
  'course.lessons': {
    tr: 'ders',
    en: 'lessons',
    es: 'lecciones',
    fr: 'leçons',
    ru: 'уроков',
    de: 'Lektionen',
    pt: 'aulas'
  },
  'course.hours': {
    tr: 'dakika',
    en: 'minutes',
    es: 'minutos',
    fr: 'minutes',
    ru: 'минут',
    de: 'Minuten',
    pt: 'minutos'
  },
  'course.progress': {
    tr: 'İlerleme',
    en: 'Progress',
    es: 'Progreso',
    fr: 'Progrès',
    ru: 'Прогресс',
    de: 'Fortschritt',
    pt: 'Progresso'
  },
  'course.outcomes': {
    tr: 'Bu eğitimde:',
    en: 'In this course:',
    es: 'En este curso:',
    fr: 'Dans ce cours:',
    ru: 'В этом курсе:',
    de: 'In diesem Kurs:',
    pt: 'Neste curso:'
  },

  // Levels
  'level.beginner': {
    tr: 'Başlangıç',
    en: 'Beginner',
    es: 'Principiante',
    fr: 'Débutant',
    ru: 'Новичок',
    de: 'Anfänger',
    pt: 'Iniciante'
  },
  'level.intermediate': {
    tr: 'Orta',
    en: 'Intermediate',
    es: 'Intermedio',
    fr: 'Intermédiaire',
    ru: 'Средний',
    de: 'Fortgeschritten',
    pt: 'Intermediário'
  },
  'level.advanced': {
    tr: 'İleri',
    en: 'Advanced',
    es: 'Avanzado',
    fr: 'Avancé',
    ru: 'Продвинутый',
    de: 'Experte',
    pt: 'Avançado'
  },
  'level.filter': {
    tr: 'Seviye Filtresi',
    en: 'Level Filter',
    es: 'Filtro de Nivel',
    fr: 'Filtre de Niveau',
    ru: 'Фильтр Уровня',
    de: 'Level-Filter',
    pt: 'Filtro de Nível'
  },
  'level.filterHelp': {
    tr: 'Eğitim seviyenize göre filtreleyin',
    en: 'Filter by your education level',
    es: 'Filtrar por tu nivel educativo',
    fr: 'Filtrer par votre niveau d\'éducation',
    ru: 'Фильтровать по уровню образования',
    de: 'Nach Ihrem Bildungsniveau filtern',
    pt: 'Filtrar pelo seu nível educacional'
  },
  'course.course': {
    tr: 'eğitim',
    en: 'course',
    es: 'curso',
    fr: 'cours',
    ru: 'курс',
    de: 'Kurs',
    pt: 'curso'
  },
  'course.courses': {
    tr: 'eğitim',
    en: 'courses',
    es: 'cursos',
    fr: 'cours',
    ru: 'курсы',
    de: 'Kurse',
    pt: 'cursos'
  },

  // Course Counts
  'courses.available': {
    tr: 'eğitim mevcut',
    en: 'courses available',
    es: 'cursos disponibles',
    fr: 'cours disponibles',
    ru: 'курсов доступно',
    de: 'Kurse verfügbar',
    pt: 'cursos disponíveis'
  },

  // Course Detail Page
  'course.curriculum': {
    tr: 'Eğitim Müfredatı',
    en: 'Course Curriculum',
    es: 'Currículo del Curso',
    fr: 'Programme du Cours',
    ru: 'Учебная Программа',
    de: 'Kurs-Lehrplan',
    pt: 'Currículo do Curso'
  },
  'course.curriculum.desc': {
    tr: 'Detaylı ders planı ve konular',
    en: 'Detailed lesson plan and topics',
    es: 'Plan detallado de lecciones y temas',
    fr: 'Plan de cours détaillé et sujets',
    ru: 'Подробный план урока и темы',
    de: 'Detaillierter Unterrichtsplan und Themen',
    pt: 'Plano de aula detalhado e tópicos'
  },
  'course.module': {
    tr: 'Modül',
    en: 'Module',
    es: 'Módulo',
    fr: 'Module',
    ru: 'Модуль',
    de: 'Modul',
    pt: 'Módulo'
  },
  'course.lessons.title': {
    tr: 'Dersler',
    en: 'Lessons',
    es: 'Lecciones',
    fr: 'Leçons',
    ru: 'Уроки',
    de: 'Lektionen',
    pt: 'Aulas'
  },
  'course.topics.title': {
    tr: 'Kapsanan Konular',
    en: 'Covered Topics',
    es: 'Temas Cubiertos',
    fr: 'Sujets Couverts',
    ru: 'Охваченные Темы',
    de: 'Behandelte Themen',
    pt: 'Tópicos Cobertos'
  },
  'course.prerequisites': {
    tr: 'Ön Koşullar',
    en: 'Prerequisites',
    es: 'Prerrequisitos',
    fr: 'Prérequis',
    ru: 'Предварительные Требования',
    de: 'Voraussetzungen',
    pt: 'Pré-requisitos'
  },
  'course.skills': {
    tr: 'Kazanılacak Beceriler',
    en: 'Skills You\'ll Gain',
    es: 'Habilidades que Obtendrás',
    fr: 'Compétences que Vous Acquerrez',
    ru: 'Навыки, Которые Вы Получите',
    de: 'Fähigkeiten, die Sie erwerben',
    pt: 'Habilidades que Você Ganhará'
  },
  'course.enroll': {
    tr: 'Eğitime Kayıt Ol',
    en: 'Enroll in Course',
    es: 'Inscribirse en el Curso',
    fr: 'S\'inscrire au Cours',
    ru: 'Записаться на Курс',
    de: 'Für Kurs Anmelden',
    pt: 'Inscrever-se no Curso'
  },
  'course.includes': {
    tr: 'Bu eğitime dahil:',
    en: 'This course includes:',
    es: 'Este curso incluye:',
    fr: 'Ce cours comprend:',
    ru: 'Этот курс включает:',
    de: 'Dieser Kurs umfasst:',
    pt: 'Este curso inclui:'
  },
  'course.info': {
    tr: 'Eğitim Bilgileri',
    en: 'Course Information',
    es: 'Información del Curso',
    fr: 'Informations sur le Cours',
    ru: 'Информация о Курсе',
    de: 'Kurs-Informationen',
    pt: 'Informações do Curso'
  },
  'course.level': {
    tr: 'Seviye:',
    en: 'Level:',
    es: 'Nivel:',
    fr: 'Niveau:',
    ru: 'Уровень:',
    de: 'Level:',
    pt: 'Nível:'
  },
  'course.category': {
    tr: 'Kategori:',
    en: 'Category:',
    es: 'Categoría:',
    fr: 'Catégorie:',
    ru: 'Категория:',
    de: 'Kategorie:',
    pt: 'Categoria:'
  },
  'course.updated': {
    tr: 'Son Güncelleme:',
    en: 'Last Updated:',
    es: 'Última Actualización:',
    fr: 'Dernière Mise à Jour:',
    ru: 'Последнее Обновление:',
    de: 'Zuletzt Aktualisiert:',
    pt: 'Última Atualização:'
  },
  'course.language': {
    tr: 'Dil:',
    en: 'Language:',
    es: 'Idioma:',
    fr: 'Langue:',
    ru: 'Язык:',
    de: 'Sprache:',
    pt: 'Idioma:'
  },
  'back': {
    tr: 'Geri Dön',
    en: 'Back',
    es: 'Volver',
    fr: 'Retour',
    ru: 'Назад',
    de: 'Zurück',
    pt: 'Voltar'
  },
  'total.duration': {
    tr: 'Toplam Süre',
    en: 'Total Duration',
    es: 'Duración Total',
    fr: 'Durée Totale',
    ru: 'Общая Продолжительность',
    de: 'Gesamtdauer',
    pt: 'Duração Total'
  },
  'rating': {
    tr: 'Puan',
    en: 'Rating',
    es: 'Calificación',
    fr: 'Note',
    ru: 'Рейтинг',
    de: 'Bewertung',
    pt: 'Avaliação'
  },
  'students': {
    tr: 'Öğrenci',
    en: 'Students',
    es: 'Estudiantes',
    fr: 'Étudiants',
    ru: 'Студенты',
    de: 'Studenten',
    pt: 'Estudantes'
  },
  'days.ago': {
    tr: 'gün önce',
    en: 'days ago',
    es: 'días atrás',
    fr: 'jours auparavant',
    ru: 'дней назад',
    de: 'Tage her',
    pt: 'dias atrás'
  },
  'content.video': {
    tr: 'video içeriği',
    en: 'video content',
    es: 'contenido de video',
    fr: 'contenu vidéo',
    ru: 'видео контент',
    de: 'Video-Inhalte',
    pt: 'conteúdo de vídeo'
  },
  'content.text': {
    tr: 'metin içeriği',
    en: 'text content',
    es: 'contenido de texto',
    fr: 'contenu textuel',
    ru: 'текстовый контент',
    de: 'Text-Inhalte',
    pt: 'conteúdo de texto'
  },
  'content.quiz': {
    tr: 'quiz içeriği',
    en: 'quiz content',
    es: 'contenido de cuestionario',
    fr: 'contenu de quiz',
    ru: 'контент викторины',
    de: 'Quiz-Inhalte',
    pt: 'conteúdo de quiz'
  },
  'content.practice': {
    tr: 'pratik içeriği',
    en: 'practice content',
    es: 'contenido de práctica',
    fr: 'contenu pratique',
    ru: 'практический контент',
    de: 'Praxis-Inhalte',
    pt: 'conteúdo prático'
  },
  'certificate.quiz': {
    tr: 'Sertifika sınavı',
    en: 'Certificate quiz',
    es: 'Examen de certificado',
    fr: 'Quiz de certificat',
    ru: 'Сертификационная викторина',
    de: 'Zertifikats-Quiz',
    pt: 'Quiz de certificado'
  },
  'unlimited.access': {
    tr: 'Sınırsız erişim',
    en: 'Unlimited access',
    es: 'Acceso ilimitado',
    fr: 'Accès illimité',
    ru: 'Неограниченный доступ',
    de: 'Unbegrenzter Zugang',
    pt: 'Acesso ilimitado'
  },
  'multilang': {
    tr: 'Çoklu Dil',
    en: 'Multi-language',
    es: 'Multi-idioma',
    fr: 'Multi-langue',
    ru: 'Мультиязычный',
    de: 'Mehrsprachig',
    pt: 'Multi-idioma'
  },
  'instructor': {
    tr: 'Eğitmen',
    en: 'Instructor',
    es: 'Instructor',
    fr: 'Instructeur',
    ru: 'Инструктор',
    de: 'Kursleiter',
    pt: 'Instrutor'
  },

  // Course Detail Learning Mode
  'lessons': {
    tr: 'Dersler',
    en: 'Lessons',
    es: 'Lecciones',
    fr: 'Leçons',
    ru: 'Уроки',
    de: 'Lektionen',
    pt: 'Aulas'
  },
  'quizzes': {
    tr: 'Sınavlar',
    en: 'Quizzes',
    es: 'Cuestionarios',
    fr: 'Quiz',
    ru: 'Викторины',
    de: 'Quiz',
    pt: 'Questionários'
  },
  'startCourse': {
    tr: 'Eğitime Başla',
    en: 'Start Course',
    es: 'Comenzar Curso',
    fr: 'Commencer le Cours',
    ru: 'Начать Курс',
    de: 'Kurs Beginnen',
    pt: 'Iniciar Curso'
  },
  'courseContent': {
    tr: 'Eğitim İçeriği',
    en: 'Course Content',
    es: 'Contenido del Curso',
    fr: 'Contenu du Cours',
    ru: 'Содержание Курса',
    de: 'Kurs-Inhalt',
    pt: 'Conteúdo do Curso'
  },
  'whatYouWillLearn': {
    tr: 'Neler Öğreneceksiniz',
    en: 'What You Will Learn',
    es: 'Qué Aprenderás',
    fr: 'Ce que Vous Apprendrez',
    ru: 'Что Вы Изучите',
    de: 'Was Sie Lernen Werden',
    pt: 'O Que Você Aprenderá'
  },
  'progress': {
    tr: 'İlerleme',
    en: 'Progress',
    es: 'Progreso',
    fr: 'Progrès',
    ru: 'Прогресс',
    de: 'Fortschritt',
    pt: 'Progresso'
  },
  'previous': {
    tr: 'Önceki',
    en: 'Previous',
    es: 'Anterior',
    fr: 'Précédent',
    ru: 'Предыдущий',
    de: 'Vorherige',
    pt: 'Anterior'
  },
  'next': {
    tr: 'Sonraki',
    en: 'Next',
    es: 'Siguiente',
    fr: 'Suivant',
    ru: 'Следующий',
    de: 'Weiter',
    pt: 'Próximo'
  },
  'takeQuiz': {
    tr: 'Sınava Geç',
    en: 'Take Quiz',
    es: 'Tomar Cuestionario',
    fr: 'Passer le Quiz',
    ru: 'Пройти Викторину',
    de: 'Quiz Machen',
    pt: 'Fazer Quiz'
  },
  'backToLessons': {
    tr: 'Derslere Dön',
    en: 'Back to Lessons',
    es: 'Volver a Lecciones',
    fr: 'Retour aux Leçons',
    ru: 'Вернуться к Урокам',
    de: 'Zurück zu den Lektionen',
    pt: 'Voltar às Aulas'
  },
  'quiz': {
    tr: 'Sınav',
    en: 'Quiz',
    es: 'Cuestionario',
    fr: 'Quiz',
    ru: 'Викторина',
    de: 'Quiz',
    pt: 'Quiz'
  },
  'testYourKnowledge': {
    tr: 'Bilginizi Test Edin',
    en: 'Test Your Knowledge',
    es: 'Pon a Prueba tu Conocimiento',
    fr: 'Testez Vos Connaissances',
    ru: 'Проверьте Свои Знания',
    de: 'Testen Sie Ihr Wissen',
    pt: 'Teste Seu Conhecimento'
  },
  'quizDescription': {
    tr: 'Öğrendiklerinizi pekiştirmek için aşağıdaki soruları yanıtlayın.',
    en: 'Answer the following questions to reinforce what you have learned.',
    es: 'Responde las siguientes preguntas para reforzar lo que has aprendido.',
    fr: 'Répondez aux questions suivantes pour renforcer ce que vous avez appris.',
    ru: 'Ответьте на следующие вопросы, чтобы закрепить то, что вы изучили.',
    de: 'Beantworten Sie die folgenden Fragen, um das Gelernte zu vertiefen.',
    pt: 'Responda às seguintes perguntas para reforçar o que aprendeu.'
  },
  'submitQuiz': {
    tr: 'Sınavı Tamamla',
    en: 'Submit Quiz',
    es: 'Enviar Cuestionario',
    fr: 'Soumettre le Quiz',
    ru: 'Отправить Викторину',
    de: 'Quiz Einreichen',
    pt: 'Enviar Quiz'
  },
  'congratulations': {
    tr: 'Tebrikler!',
    en: 'Congratulations!',
    es: '¡Felicitaciones!',
    fr: 'Félicitations!',
    ru: 'Поздравления!',
    de: 'Glückwunsch!',
    pt: 'Parabéns!'
  },
  'keepTrying': {
    tr: 'Devam Edin!',
    en: 'Keep Trying!',
    es: '¡Sigue Intentando!',
    fr: 'Continuez!',
    ru: 'Продолжайте Попытки!',
    de: 'Bleiben Sie dran!',
    pt: 'Continue Tentando!'
  },
  'quizPassed': {
    tr: 'Sınavı başarıyla geçtiniz!',
    en: 'You passed the quiz successfully!',
    es: '¡Pasaste el cuestionario con éxito!',
    fr: 'Vous avez réussi le quiz avec succès!',
    ru: 'Вы успешно прошли викторину!',
    de: 'Sie haben das Quiz erfolgreich bestanden!',
    pt: 'Você passou no quiz com sucesso!'
  },
  'quizFailed': {
    tr: 'Sınavı geçemediniz. Tekrar deneyebilirsiniz.',
    en: 'You did not pass the quiz. You can try again.',
    es: 'No pasaste el cuestionario. Puedes intentar de nuevo.',
    fr: 'Vous n\'avez pas réussi le quiz. Vous pouvez réessayer.',
    ru: 'Вы не прошли викторину. Вы можете попробовать еще раз.',
    de: 'Sie haben das Quiz nicht bestanden. Sie können es nochmal versuchen.',
    pt: 'Você não passou no quiz. Pode tentar novamente.'
  },
  'correctAnswers': {
    tr: 'Doğru Cevaplar',
    en: 'Correct Answers',
    es: 'Respuestas Correctas',
    fr: 'Réponses Correctes',
    ru: 'Правильные Ответы',
    de: 'Richtige Antworten',
    pt: 'Respostas Corretas'
  },
  'totalQuestions': {
    tr: 'Toplam Soru',
    en: 'Total Questions',
    es: 'Total de Preguntas',
    fr: 'Total des Questions',
    ru: 'Всего Вопросов',
    de: 'Gesamte Fragen',
    pt: 'Total de Perguntas'
  },
  'reviewLessons': {
    tr: 'Dersleri Gözden Geçir',
    en: 'Review Lessons',
    es: 'Revisar Lecciones',
    fr: 'Réviser les Leçons',
    ru: 'Повторить Уроки',
    de: 'Lektionen Wiederholen',
    pt: 'Revisar Aulas'
  },
  'backToCourses': {
    tr: 'Eğitimlere Dön',
    en: 'Back to Courses',
    es: 'Volver a Cursos',
    fr: 'Retour aux Cours',
    ru: 'Вернуться к Курсам',
    de: 'Zurück zu den Kursen',
    pt: 'Voltar aos Cursos'
  },
  'moreTopics': {
    tr: 'daha fazla konu',
    en: 'more topics',
    es: 'más temas',
    fr: 'plus de sujets',
    ru: 'больше тем',
    de: 'weitere Themen',
    pt: 'mais tópicos'
  },

  // Course Detail Page - Additional keys
  'course.back': {
    tr: 'Geri',
    en: 'Back',
    es: 'Volver',
    fr: 'Retour',
    ru: 'Назад',
    de: 'Zurück',
    pt: 'Voltar'
  },
  'course.students': {
    tr: 'Öğrenci',
    en: 'Students',
    es: 'Estudiantes',
    fr: 'Étudiants',
    ru: 'Студенты',
    de: 'Studenten',
    pt: 'Estudantes'
  },
  'course.rating': {
    tr: 'Değerlendirme',
    en: 'Rating',
    es: 'Calificación',
    fr: 'Évaluation',
    ru: 'Рейтинг',
    de: 'Bewertung',
    pt: 'Avaliação'
  },
  'course.contents': {
    tr: 'İçerik',
    en: 'Contents',
    es: 'Contenidos',
    fr: 'Contenu',
    ru: 'Содержание',
    de: 'Inhalte',
    pt: 'Conteúdos'
  },
  'course.quiz_questions': {
    tr: 'quiz sorusu',
    en: 'quiz questions',
    es: 'preguntas de quiz',
    fr: 'questions de quiz',
    ru: 'вопросов викторины',
    de: 'Quiz-Fragen',
    pt: 'perguntas de quiz'
  },
  'course.start_learning': {
    tr: 'Eğitime Başla',
    en: 'Start Learning',
    es: 'Comenzar Aprendizaje',
    fr: 'Commencer l\'Apprentissage',
    ru: 'Начать Обучение',
    de: 'Lernen Beginnen',
    pt: 'Começar a Aprender'
  },
  'course.quiz_completed': {
    tr: 'Quiz Tamamlandı!',
    en: 'Quiz Completed!',
    es: '¡Quiz Completado!',
    fr: 'Quiz Terminé!',
    ru: 'Викторина Завершена!',
    de: 'Quiz Abgeschlossen!',
    pt: 'Quiz Concluído!'
  },
  'course.passed': {
    tr: 'Başarılı! Eğitimi geçtiniz.',
    en: 'Success! You passed the course.',
    es: '¡Éxito! Pasaste el curso.',
    fr: 'Succès! Vous avez réussi le cours.',
    ru: 'Успех! Вы прошли курс.',
    de: 'Erfolg! Sie haben den Kurs bestanden.',
    pt: 'Sucesso! Você passou no curso.'
  },
  'course.failed': {
    tr: 'Başarısız. Tekrar deneyebilirsiniz.',
    en: 'Failed. You can try again.',
    es: 'Fallido. Puedes intentar de nuevo.',
    fr: 'Échec. Vous pouvez réessayer.',
    ru: 'Неудача. Вы можете попробовать еще раз.',
    de: 'Fehlgeschlagen. Sie können es nochmal versuchen.',
    pt: 'Falhou. Você pode tentar novamente.'
  },
  'course.restart': {
    tr: 'Yeniden Başla',
    en: 'Restart',
    es: 'Reiniciar',
    fr: 'Redémarrer',
    ru: 'Перезапустить',
    de: 'Neu Starten',
    pt: 'Reiniciar'
  },
  'course.back_to_courses': {
    tr: 'Eğitimlere Dön',
    en: 'Back to Courses',
    es: 'Volver a Cursos',
    fr: 'Retour aux Cours',
    ru: 'Вернуться к Курсам',
    de: 'Zurück zu den Kursen',
    pt: 'Voltar aos Cursos'
  },
  'course.quiz': {
    tr: 'Quiz',
    en: 'Quiz',
    es: 'Quiz',
    fr: 'Quiz',
    ru: 'Викторина',
    de: 'Quiz',
    pt: 'Quiz'
  },
  'course.previous': {
    tr: 'Önceki',
    en: 'Previous',
    es: 'Anterior',
    fr: 'Précédent',
    ru: 'Предыдущий',
    de: 'Vorherige',
    pt: 'Anterior'
  },
  'course.next': {
    tr: 'Sonraki',
    en: 'Next',
    es: 'Siguiente',
    fr: 'Suivant',
    ru: 'Следующий',
    de: 'Weiter',
    pt: 'Próximo'
  },
  'course.submit_quiz': {
    tr: 'Quiz\'i Tamamla',
    en: 'Submit Quiz',
    es: 'Enviar Quiz',
    fr: 'Soumettre le Quiz',
    ru: 'Отправить Викторину',
    de: 'Quiz Einreichen',
    pt: 'Enviar Quiz'
  },
  'course.start_quiz': {
    tr: 'Quiz\'e Başla',
    en: 'Start Quiz',
    es: 'Comenzar Quiz',
    fr: 'Commencer le Quiz',
    ru: 'Начать Викторину',
    de: 'Quiz Beginnen',
    pt: 'Iniciar Quiz'
  },
  'course.ready_to_start': {
    tr: 'Eğitime Başlamaya Hazır mısınız?',
    en: 'Ready to Start Learning?',
    es: '¿Listo para Comenzar a Aprender?',
    fr: 'Prêt à Commencer l\'Apprentissage?',
    ru: 'Готовы Начать Обучение?',
    de: 'Bereit mit dem Lernen zu beginnen?',
    pt: 'Pronto para Começar a Aprender?'
  },
  'course.start_description': {
    tr: 'Interaktif eğitim modüllerimizle öğrenmeye başlayın',
    en: 'Start learning with our interactive education modules',
    es: 'Comienza a aprender con nuestros módulos educativos interactivos',
    fr: 'Commencez à apprendre avec nos modules éducatifs interactifs',
    ru: 'Начните обучение с нашими интерактивными образовательными модулями',
    de: 'Beginnen Sie das Lernen mit unseren interaktiven Bildungsmodulen',
    pt: 'Comece a aprender com nossos módulos educacionais interativos'
  },
  'course.start_learning_now': {
    tr: 'Şimdi Eğitime Başla',
    en: 'Start Learning Now',
    es: 'Comenzar a Aprender Ahora',
    fr: 'Commencer l\'Apprentissage Maintenant',
    ru: 'Начать Обучение Сейчас',
    de: 'Jetzt mit dem Lernen Beginnen',
    pt: 'Começar a Aprender Agora'
  },
  'course.interactive_learning': {
    tr: 'Etkileşimli slaytlar ve quiz\'lerle zenginleştirilmiş eğitim deneyimi',
    en: 'Enhanced learning experience with interactive slides and quizzes',
    es: 'Experiencia de aprendizaje mejorada con diapositivas interactivas y cuestionarios',
    fr: 'Expérience d\'apprentissage améliorée avec des diapositives interactives et des quiz',
    ru: 'Улучшенный опыт обучения с интерактивными слайдами и викторинами',
    de: 'Verbesserte Lernerfahrung mit interaktiven Folien und Quiz',
    pt: 'Experiência de aprendizado aprimorada com slides interativos e questionários'
  },
  'course.expert_badge': {
    tr: 'Uzmanı',
    en: 'Expert',
    es: 'Experto',
    fr: 'Expert',
    ru: 'Эксперт',
    de: 'Experte',
    pt: 'Especialista'
  }
}

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>('tr')
  const [forceUpdate, setForceUpdate] = useState(0)

  const t = (key: string): string => {
    const translation = translations[key]
    if (!translation) {
      console.warn(`Translation key "${key}" not found`)
      return key
    }
    return translation[language] || translation.tr || key
  }

  const changeLanguage = (lang: Language) => {
    setLanguage(lang)
    setForceUpdate(prev => prev + 1)
  }

  return (
    <LanguageContext.Provider value={{ language, setLanguage: changeLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  )
}

export function useLanguage() {
  const context = useContext(LanguageContext)
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider')
  }
  return context
}