import { Language } from './useLanguage'

export interface CourseModule {
  title: { [lang in Language]: string }
  lessons: string[]
  duration: string
  topics: { [lang in Language]: string[] }
}

export interface Course {
  id: number
  category: string
  level: 'Beginner' | 'Intermediate' | 'Advanced'
  duration: string
  lessons: number
  rating: number
  enrolled: number
  progress: number
  hasQuiz: boolean
  contentTypes: string[]
  lastUpdated: string
  tags: string[]
  title: { [lang in Language]: string }
  description: { [lang in Language]: string }
  outcomes: { [lang in Language]: string[] }
  modules: CourseModule[]
  prerequisites: { [lang in Language]: string[] }
  skillsGained: { [lang in Language]: string[] }
}

export const courses: Course[] = [
  // Personal Finance Fundamentals Course
  {
    id: 6,
    category: 'Personal Finance',
    level: 'Beginner',
    duration: '8',
    lessons: 20,
    rating: 4.9,
    enrolled: 3200,
    progress: 0,
    hasQuiz: true,
    contentTypes: ['video', 'text', 'quiz', 'calculator'],
    lastUpdated: '1',
    tags: ['kişisel', 'finans', 'bütçe', 'tasarruf'],
    title: {
      tr: 'Kişisel Finans',
      en: 'Personal Finance Fundamentals',
      es: 'Fundamentos de Finanzas Personales',
      fr: 'Fondamentaux de Finance Personnelle',
      ru: 'Основы личных финансов'
    },
    description: {
      tr: '2025 güncel örnekleriyle kapsamlı kişisel finans eğitimi: Bütçe yapma, tasarruf stratejileri, yatırım temelleri, borç yönetimi, emeklilik planlaması ve sürdürülebilir finans.',
      en: 'Comprehensive personal finance education with 2025 current examples: Budgeting, savings strategies, investment fundamentals, debt management, retirement planning and sustainable finance.',
      es: 'Educación integral de finanzas personales con ejemplos actuales de 2025: Presupuesto, estrategias de ahorro, fundamentos de inversión, gestión de deudas, planificación de jubilación y finanzas sostenibles.',
      fr: 'Éducation financière personnelle complète avec des exemples actuels de 2025: Budget, stratégies d\'épargne, fondamentaux d\'investissement, gestion des dettes, planification de la retraite et finance durable.',
      ru: 'Комплексное образование по личным финансам с актуальными примерами 2025 года: Бюджетирование, стратегии сбережений, основы инвестирования, управление долгами, планирование пенсии и устойчивые финансы.'
    },
    outcomes: {
      tr: [
        'Kişisel finans planı oluşturup uygulayabileceksiniz',
        'Gelir kaynaklarınızı çeşitlendirebileceksiniz',
        'Acil durum fonu ve tasarruf stratejileri geliştireceksiniz',
        'Yatırım araçlarını tanıyıp risk yönetimi yapabileceksiniz',
        'Borç yönetimi ve kredi skorunu optimize edebileceksiniz',
        'Emeklilik planlaması ve vergi stratejileri uygulayabileceksiniz',
        'Ev alma sürecini finansal olarak planlayabileceksiniz',
        'Sürdürülebilir finans ilkelerini hayata geçirebileceksiniz'
      ],
      en: [
        'You will be able to create and implement personal financial plans',
        'You will be able to diversify your income sources',
        'You will develop emergency fund and savings strategies',
        'You will understand investment tools and manage risks',
        'You will manage debt and optimize credit score',
        'You will implement retirement planning and tax strategies',
        'You will be able to financially plan the home buying process',
        'You will implement sustainable finance principles'
      ],
      es: [
        'Podrás crear e implementar planes financieros personales',
        'Podrás diversificar tus fuentes de ingresos',
        'Desarrollarás fondo de emergencia y estrategias de ahorro',
        'Entenderás herramientas de inversión y gestionarás riesgos',
        'Gestionarás deudas y optimizarás puntuación crediticia',
        'Implementarás planificación de jubilación y estrategias fiscales',
        'Podrás planificar financieramente el proceso de compra de casa',
        'Implementarás principios de finanzas sostenibles'
      ],
      fr: [
        'Vous pourrez créer et mettre en œuvre des plans financiers personnels',
        'Vous pourrez diversifier vos sources de revenus',
        'Vous développerez fonds d\'urgence et stratégies d\'épargne',
        'Vous comprendrez les outils d\'investissement et gérerez les risques',
        'Vous gérerez les dettes et optimiserez le score de crédit',
        'Vous mettrez en œuvre planification retraite et stratégies fiscales',
        'Vous pourrez planifier financièrement le processus d\'achat de maison',
        'Vous mettrez en œuvre les principes de finance durable'
      ],
      ru: [
        'Вы сможете создавать и внедрять планы личных финансов',
        'Вы сможете диверсифицировать источники дохода',
        'Вы разработаете фонд экстренных ситуаций и стратегии сбережений',
        'Вы поймете инвестиционные инструменты и будете управлять рисками',
        'Вы будете управлять долгами и оптимизировать кредитный рейтинг',
        'Вы внедрите планирование пенсии и налоговые стратегии',
        'Вы сможете финансово планировать процесс покупки дома',
        'Вы внедрите принципы устойчивых финансов'
      ]
    },
    modules: [
      {
        title: {
          tr: 'Bütçe Yönetimi',
          en: 'Budget Management',
          es: 'Gestión de Presupuesto',
          fr: 'Gestion de Budget',
          ru: 'Управление бюджетом'
        },
        lessons: ['50-30-20 Kuralı', 'Gelir-Gider Analizi', 'Acil Durum Fonu', 'Bütçe Araçları'],
        duration: '1 saat',
        topics: {
          tr: ['Gelir kategorileri', 'Sabit ve değişken giderler', '3-6 aylık acil fon', 'Dijital bütçe uygulamaları'],
          en: ['Income categories', 'Fixed and variable expenses', '3-6 month emergency fund', 'Digital budgeting apps'],
          es: ['Categorías de ingresos', 'Gastos fijos y variables', 'Fondo de emergencia de 3-6 meses', 'Apps de presupuesto digital'],
          fr: ['Catégories de revenus', 'Dépenses fixes et variables', 'Fonds d\'urgence de 3-6 mois', 'Applications de budget numérique'],
          ru: ['Категории доходов', 'Постоянные и переменные расходы', 'Резервный фонд на 3-6 месяцев', 'Цифровые бюджетные приложения']
        }
      },
      {
        title: {
          tr: 'Tasarruf Stratejileri',
          en: 'Savings Strategies',
          es: 'Estrategias de Ahorro',
          fr: 'Stratégies d\'Épargne',
          ru: 'Стратегии сбережений'
        },
        lessons: ['Otomatik Tasarruf', 'Tasarruf Hedefleri', 'Yüksek Faizli Hesaplar', 'Bileşik Faiz'],
        duration: '1.5 saat',
        topics: {
          tr: ['Maaştan otomatik kesinti', 'SMART hedefler', 'Vadeli mevduat', 'Paranın zaman değeri'],
          en: ['Automatic salary deductions', 'SMART goals', 'Time deposits', 'Time value of money'],
          es: ['Deducciones salariales automáticas', 'Objetivos SMART', 'Depósitos a plazo', 'Valor temporal del dinero'],
          fr: ['Déductions salariales automatiques', 'Objectifs SMART', 'Dépôts à terme', 'Valeur temporelle de l\'argent'],
          ru: ['Автоматические вычеты из зарплаты', 'SMART цели', 'Срочные вклады', 'Временная стоимость денег']
        }
      }
    ],
    prerequisites: {
      tr: ['Temel matematik bilgisi'],
      en: ['Basic mathematics knowledge'],
      es: ['Conocimientos básicos de matemáticas'],
      fr: ['Connaissances de base en mathématiques'],
      ru: ['Базовые знания математики']
    },
    skillsGained: {
      tr: ['Bütçe planlama', 'Tasarruf disiplini', 'Borç yönetimi', 'Finansal hedef belirleme'],
      en: ['Budget planning', 'Savings discipline', 'Debt management', 'Financial goal setting'],
      es: ['Planificación de presupuesto', 'Disciplina de ahorro', 'Gestión de deudas', 'Establecimiento de objetivos financieros'],
      fr: ['Planification budgétaire', 'Discipline d\'épargne', 'Gestion de dettes', 'Définition d\'objectifs financiers'],
      ru: ['Планирование бюджета', 'Дисциплина сбережений', 'Управление долгами', 'Постановка финансовых целей']
    }
  },

  // Financial Markets Introduction Course
  {
    id: 7,
    category: 'Markets',
    level: 'Beginner',
    duration: '8',
    lessons: 20,
    rating: 4.8,
    enrolled: 3400,
    progress: 0,
    hasQuiz: true,
    contentTypes: ['video', 'text', 'quiz', 'simulation'],
    lastUpdated: '1',
    tags: ['piyasalar', 'borsa', 'tahvil', 'yatırım', 'kripto', 'forex', 'türev'],
    title: {
      tr: 'Finansal Piyasalar',
      en: 'Financial Markets Comprehensive',
      es: 'Mercados Financieros Integrales',
      fr: 'Marchés Financiers Complets',
      ru: 'Полные финансовые рынки'
    },
    description: {
      tr: '2025 güncel örnekleriyle kapsamlı finansal piyasalar eğitimi: Para ve sermaye piyasaları, borsa işleyişi, tahvil piyasası, forex, türev ürünler, emtia, kripto para, piyasa endeksleri, davranışsal finans, global entegrasyon ve gelecek trendleri.',
      en: 'Comprehensive financial markets education with 2025 current examples: Money and capital markets, stock exchange operations, bond market, forex, derivatives, commodities, cryptocurrencies, market indices, behavioral finance, global integration and future trends.',
      es: 'Educación integral de mercados financieros con ejemplos actuales de 2025: Mercados monetarios y de capital, operaciones bursátiles, mercado de bonos, forex, derivados, materias primas, criptomonedas, índices de mercado, finanzas conductuales, integración global y tendencias futuras.',
      fr: 'Éducation complète des marchés financiers avec exemples actuels de 2025: Marchés monétaires et de capitaux, opérations boursières, marché obligataire, forex, produits dérivés, matières premières, cryptomonnaies, indices de marché, finance comportementale, intégration mondiale et tendances futures.',
      ru: 'Комплексное образование по финансовым рынкам с актуальными примерами 2025 года: Денежные и капитальные рынки, биржевые операции, рынок облигаций, форекс, деривативы, товары, криптовалюты, рыночные индексы, поведенческие финансы, глобальная интеграция и будущие тренды.'
    },
    outcomes: {
      tr: [
        'Tüm finansal piyasa türlerini detaylı anlayacaksınız (para, sermaye, döviz, emtia, kripto)',
        'Para ve sermaye piyasası araçlarını karşılaştırabileceksiniz',
        'Borsa işleyişi ve endeks sistemini kavrayacaksınız',
        'Risk-getiri dengesini değerlendirip portföy yönetimi yapabileceksiniz',
        'Türev ürünler ve emtia piyasalarında işlem stratejileri geliştireceksiniz',
        'Davranışsal finans ilkelerini yatırım kararlarında uygulayacaksınız',
        'Global piyasa entegrasyonu ve gelecek trendlerini analiz edebileceksiniz',
        'Finansal kriz süreçlerini anlayıp risk yönetimi yapabileceksiniz'
      ],
      en: [
        'You will understand all financial market types in detail (money, capital, forex, commodity, crypto)',
        'You will be able to compare money and capital market instruments',
        'You will understand stock exchange operations and index systems',
        'You will evaluate risk-return balance and manage portfolios',
        'You will develop trading strategies in derivatives and commodity markets',
        'You will apply behavioral finance principles in investment decisions',
        'You will analyze global market integration and future trends',
        'You will understand financial crisis processes and manage risks'
      ],
      es: [
        'Entenderás todos los tipos de mercados financieros en detalle (monetario, capital, forex, materias primas, cripto)',
        'Podrás comparar instrumentos de mercados monetarios y de capital',
        'Entenderás operaciones bursátiles y sistemas de índices',
        'Evaluarás balance riesgo-retorno y gestionarás carteras',
        'Desarrollarás estrategias comerciales en derivados y mercados de materias primas',
        'Aplicarás principios de finanzas conductuales en decisiones de inversión',
        'Analizarás integración de mercados globales y tendencias futuras',
        'Entenderás procesos de crisis financieras y gestionarás riesgos'
      ],
      fr: [
        'Vous comprendrez tous les types de marchés financiers en détail (monétaire, capital, forex, matières premières, crypto)',
        'Vous pourrez comparer les instruments des marchés monétaires et de capitaux',
        'Vous comprendrez les opérations boursières et systèmes d\'indices',
        'Vous évaluerez l\'équilibre risque-rendement et gérerez des portefeuilles',
        'Vous développerez des stratégies de trading dans les dérivés et marchés de matières premières',
        'Vous appliquerez les principes de finance comportementale dans les décisions d\'investissement',
        'Vous analyserez l\'intégration des marchés mondiaux et tendances futures',
        'Vous comprendrez les processus de crise financière et gérerez les risques'
      ],
      ru: [
        'Вы подробно поймете все типы финансовых рынков (денежный, капитальный, форекс, товарный, криптовалютный)',
        'Вы сможете сравнивать инструменты денежного и капитального рынков',
        'Вы поймете биржевые операции и индексные системы',
        'Вы оцените баланс риск-доходность и будете управлять портфелями',
        'Вы разработаете торговые стратегии на рынках деривативов и товаров',
        'Вы примените принципы поведенческих финансов в инвестиционных решениях',
        'Вы проанализируете глобальную интеграцию рынков и будущие тренды',
        'Вы поймете процессы финансовых кризисов и будете управлять рисками'
      ]
    },
    modules: [
      {
        title: {
          tr: 'Piyasa Türleri ve İşleyişi',
          en: 'Market Types and Operations',
          es: 'Tipos de Mercado y Operaciones',
          fr: 'Types de Marchés et Opérations',
          ru: 'Типы рынков и операции'
        },
        lessons: ['Finansal Piyasalar Nedir', 'Piyasa Türleri', 'Para Piyasası', 'Sermaye Piyasası', 'Borsalar ve İşleyişi'],
        duration: '2.5 saat',
        topics: {
          tr: ['Piyasa işlevleri', 'Birincil-ikincil piyasalar', 'IPO süreçleri', 'Elektronik ticaret', 'Likidite sağlama'],
          en: ['Market functions', 'Primary-secondary markets', 'IPO processes', 'Electronic trading', 'Liquidity provision'],
          es: ['Funciones del mercado', 'Mercados primarios-secundarios', 'Procesos IPO', 'Trading electrónico', 'Provisión de liquidez'],
          fr: ['Fonctions de marché', 'Marchés primaires-secondaires', 'Processus IPO', 'Trading électronique', 'Provision de liquidité'],
          ru: ['Функции рынка', 'Первичные-вторичные рынки', 'IPO процессы', 'Электронная торговля', 'Обеспечение ликвидности']
        }
      },
      {
        title: {
          tr: 'Yatırım Araçları',
          en: 'Investment Instruments',
          es: 'Instrumentos de Inversión',
          fr: 'Instruments d\'Investissement',
          ru: 'Инвестиционные инструменты'
        },
        lessons: ['Hisse Senetleri', 'Tahvil Piyasası', 'Türev Piyasalar', 'Emtia Piyasaları', 'Kripto Para Piyasaları'],
        duration: '2.5 saat',
        topics: {
          tr: ['Temettü politikaları', 'Faiz-fiyat ilişkisi', 'Vadeli işlemler', 'Opsiyon stratejileri', 'Blockchain teknolojisi'],
          en: ['Dividend policies', 'Interest-price relationship', 'Futures contracts', 'Option strategies', 'Blockchain technology'],
          es: ['Políticas de dividendos', 'Relación interés-precio', 'Contratos futuros', 'Estrategias de opciones', 'Tecnología blockchain'],
          fr: ['Politiques de dividendes', 'Relation intérêt-prix', 'Contrats futures', 'Stratégies d\'options', 'Technologie blockchain'],
          ru: ['Дивидендная политика', 'Связь процент-цена', 'Фьючерсные контракты', 'Опционные стратегии', 'Технология блокчейн']
        }
      },
      {
        title: {
          tr: 'Piyasa Analizi ve Risk Yönetimi',
          en: 'Market Analysis and Risk Management',
          es: 'Análisis de Mercado y Gestión de Riesgos',
          fr: 'Analyse de Marché et Gestion des Risques',
          ru: 'Рыночный анализ и управление рисками'
        },
        lessons: ['Piyasa Endeksleri', 'Risk-Getiri Dengesi', 'Portföy Yönetimi', 'Piyasa Verimliliği', 'Davranışsal Finans'],
        duration: '2 saat',
        topics: {
          tr: ['S&P 500 analizi', 'Çeşitlendirme ilkeleri', 'Beta katsayısı', 'Etkin piyasa hipotezi', 'Yatırımcı psikolojisi'],
          en: ['S&P 500 analysis', 'Diversification principles', 'Beta coefficient', 'Efficient market hypothesis', 'Investor psychology'],
          es: ['Análisis S&P 500', 'Principios de diversificación', 'Coeficiente beta', 'Hipótesis de mercado eficiente', 'Psicología del inversor'],
          fr: ['Analyse S&P 500', 'Principes de diversification', 'Coefficient bêta', 'Hypothèse de marché efficace', 'Psychologie de l\'investisseur'],
          ru: ['Анализ S&P 500', 'Принципы диверсификации', 'Коэффициент бета', 'Гипотеза эффективного рынка', 'Психология инвестора']
        }
      },
      {
        title: {
          tr: 'Global Piyasalar ve Gelecek',
          en: 'Global Markets and Future',
          es: 'Mercados Globales y Futuro',
          fr: 'Marchés Mondiaux et Avenir',
          ru: 'Глобальные рынки и будущее'
        },
        lessons: ['Piyasa Düzenlemeleri', 'Global Entegrasyon', 'Finansal Krizler', 'Gelecek Trendleri'],
        duration: '1 saat',
        topics: {
          tr: ['SEC ve SPK kuralları', 'Finansal bulaşma', 'Kriz yönetimi', 'DeFi ve fintech', 'ESG yatırımları'],
          en: ['SEC and regulatory rules', 'Financial contagion', 'Crisis management', 'DeFi and fintech', 'ESG investments'],
          es: ['Reglas SEC y regulatorias', 'Contagio financiero', 'Gestión de crisis', 'DeFi y fintech', 'Inversiones ESG'],
          fr: ['Règles SEC et réglementaires', 'Contagion financière', 'Gestion de crise', 'DeFi et fintech', 'Investissements ESG'],
          ru: ['Правила SEC и регулятивные', 'Финансовое заражение', 'Антикризисное управление', 'DeFi и финтех', 'ESG инвестиции']
        }
      }
    ],
    prerequisites: {
      tr: ['Temel ekonomi bilgisi'],
      en: ['Basic economics knowledge'],
      es: ['Conocimientos básicos de economía'],
      fr: ['Connaissances de base en économie'],
      ru: ['Базовые знания экономики']
    },
    skillsGained: {
      tr: ['Kapsamlı piyasa analizi', 'Çok araçlı yatırım stratejileri', 'Gelişmiş risk yönetimi', 'Global portföy çeşitlendirme', 'Davranışsal finans uygulama', 'Türev ürün stratejileri', 'Kriz yönetimi'],
      en: ['Comprehensive market analysis', 'Multi-instrument investment strategies', 'Advanced risk management', 'Global portfolio diversification', 'Behavioral finance application', 'Derivative product strategies', 'Crisis management'],
      es: ['Análisis integral de mercado', 'Estrategias de inversión multi-instrumento', 'Gestión avanzada de riesgos', 'Diversificación global de cartera', 'Aplicación de finanzas conductuales', 'Estrategias de productos derivados', 'Gestión de crisis'],
      fr: ['Analyse complète de marché', 'Stratégies d\'investissement multi-instruments', 'Gestion avancée des risques', 'Diversification mondiale de portefeuille', 'Application de finance comportementale', 'Stratégies de produits dérivés', 'Gestion de crise'],
      ru: ['Комплексный рыночный анализ', 'Мульти-инструментальные инвестиционные стратегии', 'Продвинутое управление рисками', 'Глобальная диверсификация портфеля', 'Применение поведенческих финансов', 'Стратегии производных продуктов', 'Антикризисное управление']
    }
  },

  // Fundamental Analysis Course
  {
    id: 8,
    category: 'Fundamental',
    level: 'Intermediate',
    duration: '5',
    lessons: 16,
    rating: 4.8,
    enrolled: 1950,
    progress: 0,
    hasQuiz: true,
    contentTypes: ['video', 'text', 'quiz', 'practice'],
    lastUpdated: '1',
    tags: ['temel', 'analiz', 'finansal', 'tablolar'],
    title: {
      tr: 'Temel Analiz',
      en: 'Fundamental Analysis',
      es: 'Análisis Fundamental',
      fr: 'Analyse Fondamentale',
      ru: 'Фундаментальный анализ'
    },
    description: {
      tr: 'Şirket değerlemesi için finansal tabloların incelenmesi, bilanço analizi ve temel finansal oranlar.',
      en: 'Examining financial statements for company valuation, balance sheet analysis and basic financial ratios.',
      es: 'Examinando estados financieros para valoración de empresas, análisis de balance y ratios financieros básicos.',
      fr: 'Examen des états financiers pour l\'évaluation d\'entreprise, analyse du bilan et ratios financiers de base.',
      ru: 'Изучение финансовой отчетности для оценки компаний, анализ баланса и основные финансовые коэффициенты.'
    },
    outcomes: {
      tr: [
        'Finansal tabloları okuyabileceksiniz',
        'Şirket değerlemesi yapabileceksiniz',
        'Temel finansal oranları hesaplayacaksınız',
        'Yatırım kararlarında temel analiz kullanacaksınız'
      ],
      en: [
        'You will be able to read financial statements',
        'You will be able to perform company valuations',
        'You will calculate basic financial ratios',
        'You will use fundamental analysis in investment decisions'
      ],
      es: [
        'Podrás leer estados financieros',
        'Podrás realizar valoraciones de empresas',
        'Calcularás ratios financieros básicos',
        'Usarás análisis fundamental en decisiones de inversión'
      ],
      fr: [
        'Vous pourrez lire les états financiers',
        'Vous pourrez effectuer des évaluations d\'entreprises',
        'Vous calculerez des ratios financiers de base',
        'Vous utiliserez l\'analyse fondamentale dans les décisions d\'investissement'
      ],
      ru: [
        'Вы сможете читать финансовую отчетность',
        'Вы сможете проводить оценку компаний',
        'Вы рассчитаете основные финансовые коэффициенты',
        'Вы будете использовать фундаментальный анализ в инвестиционных решениях'
      ]
    },
    modules: [
      {
        title: {
          tr: 'Finansal Tablolar',
          en: 'Financial Statements',
          es: 'Estados Financieros',
          fr: 'États Financiers',
          ru: 'Финансовые отчеты'
        },
        lessons: ['Bilanço', 'Gelir Tablosu', 'Nakit Akışı', 'Özkaynak Değişimi'],
        duration: '2 saat',
        topics: {
          tr: ['Aktif-pasif', 'Gelir-gider', 'Operasyonel nakit', 'Sermaye hareketleri'],
          en: ['Assets-liabilities', 'Revenue-expenses', 'Operational cash', 'Capital movements'],
          es: ['Activos-pasivos', 'Ingresos-gastos', 'Efectivo operacional', 'Movimientos de capital'],
          fr: ['Actifs-passifs', 'Revenus-dépenses', 'Trésorerie opérationnelle', 'Mouvements de capitaux'],
          ru: ['Активы-обязательства', 'Доходы-расходы', 'Операционные денежные средства', 'Движение капитала']
        }
      },
      {
        title: {
          tr: 'Finansal Oranlar',
          en: 'Financial Ratios',
          es: 'Ratios Financieros',
          fr: 'Ratios Financiers',
          ru: 'Финансовые коэффициенты'
        },
        lessons: ['Karlılık Oranları', 'Likidite Oranları', 'Kaldıraç Oranları', 'Verimlilik Oranları'],
        duration: '2.5 saat',
        topics: {
          tr: ['ROE, ROA', 'Cari oran', 'Borç/Özkaynak', 'Aktif devir hızı'],
          en: ['ROE, ROA', 'Current ratio', 'Debt/Equity', 'Asset turnover'],
          es: ['ROE, ROA', 'Ratio corriente', 'Deuda/Patrimonio', 'Rotación de activos'],
          fr: ['ROE, ROA', 'Ratio de liquidité', 'Dette/Capitaux propres', 'Rotation des actifs'],
          ru: ['ROE, ROA', 'Коэффициент текущей ликвидности', 'Долг/Капитал', 'Оборачиваемость активов']
        }
      }
    ],
    prerequisites: {
      tr: ['Temel muhasebe bilgisi', 'Finansal matematik'],
      en: ['Basic accounting knowledge', 'Financial mathematics'],
      es: ['Conocimientos básicos de contabilidad', 'Matemáticas financieras'],
      fr: ['Connaissances de base en comptabilité', 'Mathématiques financières'],
      ru: ['Базовые знания бухгалтерского учета', 'Финансовая математика']
    },
    skillsGained: {
      tr: ['Finansal tablo analizi', 'Şirket değerleme', 'Oran analizi', 'Yatırım değerlendirmesi'],
      en: ['Financial statement analysis', 'Company valuation', 'Ratio analysis', 'Investment evaluation'],
      es: ['Análisis de estados financieros', 'Valoración de empresas', 'Análisis de ratios', 'Evaluación de inversiones'],
      fr: ['Analyse d\'états financiers', 'Évaluation d\'entreprise', 'Analyse de ratios', 'Évaluation d\'investissement'],
      ru: ['Анализ финансовой отчетности', 'Оценка компании', 'Анализ коэффициентов', 'Оценка инвестиций']
    }
  },

  // Economics Course
  {
    id: 1,
    category: 'Economics',
    level: 'Beginner',
    duration: '10',
    lessons: 20,
    rating: 4.8,
    enrolled: 1580,
    progress: 0,
    hasQuiz: true,
    contentTypes: ['video', 'text', 'quiz'],
    lastUpdated: '1',
    tags: ['temel', 'ekonomi', 'piyasa'],
    title: {
      tr: 'Temel Ekonomi',
      en: 'Basic Economics',
      es: 'Economía Básica',
      fr: 'Économie de Base',
      ru: 'Основы Экономики'
    },
    description: {
      tr: '2025 güncel örnekleriyle kapsamlı ekonomi eğitimi: Mikroekonomi, makroekonomi, piyasa yapıları, GDP, enflasyon, işsizlik, para ve maliye politikaları, uluslararası ticaret, davranışsal ekonomi.',
      en: 'Comprehensive economics education with 2025 current examples: Microeconomics, macroeconomics, market structures, GDP, inflation, unemployment, monetary and fiscal policies, international trade, behavioral economics.',
      es: 'Educación económica integral con ejemplos actuales de 2025: Microeconomía, macroeconomía, estructuras de mercado, PIB, inflación, desempleo, políticas monetarias y fiscales, comercio internacional, economía conductual.',
      fr: 'Éducation économique complète avec des exemples actuels de 2025: Microéconomie, macroéconomie, structures de marché, PIB, inflation, chômage, politiques monétaires et budgétaires, commerce international, économie comportementale.',
      ru: 'Комплексное экономическое образование с актуальными примерами 2025 года: Микроэкономика, макроэкономика, рыночные структуры, ВВП, инфляция, безработица, денежно-кредитная и фискальная политика, международная торговля, поведенческая экономика.'
    },
    outcomes: {
      tr: [
        'Ekonominin temel ilkelerini ve kaynak dağılım mekanizmalarını anlayacaksınız',
        'Mikro ve makroekonomik süreçleri ayırt edebileceksiniz',
        'Arz-talep yasası ve elastikiyet kavramını uygulayabileceksiniz',
        'Piyasa yapıları ve rekabet türlerini karşılaştırabileceksiniz',
        'GDP, enflasyon ve işsizlik göstergelerini yorumlayabileceksiniz',
        'Para ve maliye politikalarının etkilerini değerlendirebileceksiniz',
        'Uluslararası ticaret ve döviz kurlarının işleyişini kavrayacaksınız',
        'Davranışsal ekonomi ve çevre ekonomisi perspektiflerini anlayacaksınız',
        'Ekonomik kriz ve kurtarma süreçlerini analiz edebileceksiniz'
      ],
      en: [
        'You will understand basic principles of economics and resource allocation mechanisms',
        'You will be able to distinguish micro and macroeconomic processes',
        'You will be able to apply law of supply-demand and elasticity concept',
        'You will be able to compare market structures and competition types',
        'You will be able to interpret GDP, inflation and unemployment indicators',
        'You will be able to evaluate effects of monetary and fiscal policies',
        'You will understand functioning of international trade and exchange rates',
        'You will understand behavioral economics and environmental economics perspectives',
        'You will be able to analyze economic crisis and recovery processes'
      ],
      es: [
        'Entenderás los principios básicos de la economía y mecanismos de asignación de recursos',
        'Podrás distinguir procesos micro y macroeconómicos',
        'Podrás aplicar la ley de oferta-demanda y concepto de elasticidad',
        'Podrás comparar estructuras de mercado y tipos de competencia',
        'Podrás interpretar indicadores de PIB, inflación y desempleo',
        'Podrás evaluar efectos de políticas monetarias y fiscales',
        'Entenderás funcionamiento de comercio internacional y tipos de cambio',
        'Entenderás perspectivas de economía conductual y ambiental',
        'Podrás analizar procesos de crisis económica y recuperación'
      ],
      fr: [
        'Vous comprendrez les principes de base de l\'économie et mécanismes d\'allocation des ressources',
        'Vous pourrez distinguer les processus micro et macroéconomiques',
        'Vous pourrez appliquer la loi de l\'offre-demande et concept d\'élasticité',
        'Vous pourrez comparer les structures de marché et types de concurrence',
        'Vous pourrez interpréter les indicateurs PIB, inflation et chômage',
        'Vous pourrez évaluer les effets des politiques monétaires et budgétaires',
        'Vous comprendrez le fonctionnement du commerce international et taux de change',
        'Vous comprendrez les perspectives d\'économie comportementale et environnementale',
        'Vous pourrez analyser les processus de crise économique et de récupération'
      ],
      ru: [
        'Вы поймете основные принципы экономики и механизмы распределения ресурсов',
        'Вы сможете различать микро- и макроэкономические процессы',
        'Вы сможете применять закон спроса-предложения и концепцию эластичности',
        'Вы сможете сравнивать рыночные структуры и типы конкуренции',
        'Вы сможете интерпретировать показатели ВВП, инфляции и безработицы',
        'Вы сможете оценивать эффекты денежно-кредитной и фискальной политики',
        'Вы поймете функционирование международной торговли и обменных курсов',
        'Вы поймете перспективы поведенческой и экологической экономики',
        'Вы сможете анализировать процессы экономического кризиса и восстановления'
      ]
    },
    modules: [
      {
        title: {
          tr: 'Mikroekonomi Temelleri',
          en: 'Microeconomics Fundamentals',
          es: 'Fundamentos de Microeconomía',
          fr: 'Fondamentaux de Microéconomie',
          ru: 'Основы микроэкономики'
        },
        lessons: ['Arz ve Talep', 'Elastikiyet', 'Tüketici Teorisi', 'Üretici Teorisi'],
        duration: '3 saat',
        topics: {
          tr: ['Piyasa dengesi', 'Fiyat elastikiyeti', 'Marjinal fayda', 'Maliyet analizi'],
          en: ['Market equilibrium', 'Price elasticity', 'Marginal utility', 'Cost analysis'],
          es: ['Equilibrio de mercado', 'Elasticidad precio', 'Utilidad marginal', 'Análisis de costos'],
          fr: ['Équilibre du marché', 'Élasticité-prix', 'Utilité marginale', 'Analyse des coûts'],
          ru: ['Рыночное равновесие', 'Ценовая эластичность', 'Предельная полезность', 'Анализ затрат']
        }
      },
      {
        title: {
          tr: 'Makroekonomi Temelleri',
          en: 'Macroeconomics Fundamentals',
          es: 'Fundamentos de Macroeconomía',
          fr: 'Fondamentaux de Macroéconomie',
          ru: 'Основы макроэкономики'
        },
        lessons: ['GDP', 'Enflasyon', 'İşsizlik', 'Para Politikası'],
        duration: '3.5 saat',
        topics: {
          tr: ['Büyüme oranları', 'TÜFE hesaplama', 'Phillips eğrisi', 'Merkez bankası araçları'],
          en: ['Growth rates', 'CPI calculation', 'Phillips curve', 'Central bank tools'],
          es: ['Tasas de crecimiento', 'Cálculo IPC', 'Curva Phillips', 'Herramientas banco central'],
          fr: ['Taux de croissance', 'Calcul IPC', 'Courbe Phillips', 'Outils banque centrale'],
          ru: ['Темпы роста', 'Расчет ИПЦ', 'Кривая Филлипса', 'Инструменты центрального банка']
        }
      }
    ],
    prerequisites: {
      tr: ['Temel matematik bilgisi'],
      en: ['Basic mathematics knowledge'],
      es: ['Conocimientos básicos de matemáticas'],
      fr: ['Connaissances de base en mathématiques'],
      ru: ['Базовые знания математики']
    },
    skillsGained: {
      tr: ['Ekonomik analiz', 'Piyasa yorumlama', 'Politik değerlendirme', 'Makro görüş'],
      en: ['Economic analysis', 'Market interpretation', 'Policy evaluation', 'Macro perspective'],
      es: ['Análisis económico', 'Interpretación de mercado', 'Evaluación de políticas', 'Perspectiva macro'],
      fr: ['Analyse économique', 'Interprétation de marché', 'Évaluation de politiques', 'Perspective macro'],
      ru: ['Экономический анализ', 'Интерпретация рынка', 'Оценка политики', 'Макро перспектива']
    }
  },

  // Technical Analysis Course
  {
    id: 2,
    category: 'Analysis',
    level: 'Intermediate',
    duration: '6',
    lessons: 18,
    rating: 4.7,
    enrolled: 2100,
    progress: 0,
    hasQuiz: true,
    contentTypes: ['video', 'text', 'quiz', 'practice'],
    lastUpdated: '2',
    tags: ['technical', 'charts', 'patterns'],
    title: {
      tr: 'Teknik Analiz',
      en: 'Technical Analysis',
      es: 'Análisis Técnico',
      fr: 'Analyse Technique',
      ru: 'Технический анализ'
    },
    description: {
      tr: '2025 güncel yaklaşımlarıyla kapsamlı teknik analiz eğitimi: Grafik türleri, trend analizi, destek-direnç, mum kalıpları, teknik göstergeler, hacim analizi, Fibonacci, Elliot Wave teorisi, işlem psikolojisi ve risk yönetimi.',
      en: 'Comprehensive technical analysis education with 2025 current approaches: Chart types, trend analysis, support-resistance, candlestick patterns, technical indicators, volume analysis, Fibonacci, Elliott Wave theory, trading psychology and risk management.',
      es: 'Educación integral de análisis técnico con enfoques actuales de 2025: Tipos de gráficos, análisis de tendencias, soporte-resistencia, patrones de velas, indicadores técnicos, análisis de volumen, Fibonacci, teoría Elliott Wave, psicología de trading y gestión de riesgos.',
      fr: 'Éducation complète d\'analyse technique avec approches actuelles de 2025: Types de graphiques, analyse de tendance, support-résistance, motifs chandelles, indicateurs techniques, analyse volume, Fibonacci, théorie Elliott Wave, psychologie trading et gestion des risques.',
      ru: 'Комплексное образование по техническому анализу с актуальными подходами 2025 года: Типы графиков, анализ трендов, поддержка-сопротивление, свечные паттерны, технические индикаторы, анализ объема, Фибоначчи, теория волн Эллиотта, торговая психология и управление рисками.'
    },
    outcomes: {
      tr: [
        'Grafik analizinde ustalaşacaksınız',
        'Teknik göstergeleri kullanacaksınız',
        'İşlem stratejileri geliştireceksiniz'
      ],
      en: [
        'Master chart analysis',
        'Use technical indicators',
        'Develop trading strategies'
      ],
      es: [
        'Dominarás el análisis de gráficos',
        'Usarás indicadores técnicos',
        'Desarrollarás estrategias de trading'
      ],
      fr: [
        'Maîtriser l\'analyse de graphiques',
        'Utiliser des indicateurs techniques',
        'Développer des stratégies de trading'
      ],
      ru: [
        'Овладеете анализом графиков',
        'Используйте технические индикаторы',
        'Разработайте торговые стратегии'
      ]
    },
    modules: [
      {
        title: {
          tr: 'Grafik Analizi',
          en: 'Chart Analysis',
          es: 'Análisis de Gráficos',
          fr: 'Analyse de Graphiques',
          ru: 'Анализ графиков'
        },
        lessons: ['Grafik Türleri', 'Trend Çizgileri', 'Destek Direnç', 'Mum Kalıpları'],
        duration: '2.5 saat',
        topics: {
          tr: ['Çizgi-çubuk-mum', 'Yükseliş-düşüş trendleri', 'Kırılım stratejileri', 'Doji, hammer, engulfing'],
          en: ['Line-bar-candlestick', 'Uptrend-downtrend', 'Breakout strategies', 'Doji, hammer, engulfing'],
          es: ['Línea-barra-vela', 'Tendencia alcista-bajista', 'Estrategias ruptura', 'Doji, martillo, envolvente'],
          fr: ['Ligne-barre-chandelle', 'Tendance haussière-baissière', 'Stratégies cassure', 'Doji, marteau, engloutissant'],
          ru: ['Линия-бар-свеча', 'Восходящий-нисходящий тренд', 'Стратегии прорыва', 'Доджи, молот, поглощение']
        }
      },
      {
        title: {
          tr: 'Teknik Göstergeler',
          en: 'Technical Indicators',
          es: 'Indicadores Técnicos',
          fr: 'Indicateurs Techniques',
          ru: 'Технические индикаторы'
        },
        lessons: ['Trend Göstergeleri', 'Momentum', 'Volatilite', 'Hacim'],
        duration: '3.5 saat',
        topics: {
          tr: ['MA, MACD', 'RSI, Stochastic', 'Bollinger Bands', 'Volume analysis'],
          en: ['MA, MACD', 'RSI, Stochastic', 'Bollinger Bands', 'Volume analysis'],
          es: ['MA, MACD', 'RSI, Estocástico', 'Bandas Bollinger', 'Análisis volumen'],
          fr: ['MA, MACD', 'RSI, Stochastique', 'Bandes Bollinger', 'Analyse volume'],
          ru: ['MA, MACD', 'RSI, Стохастик', 'Полосы Боллинджера', 'Анализ объема']
        }
      }
    ],
    prerequisites: {
      tr: ['Temel finansal piyasa bilgisi'],
      en: ['Basic financial markets knowledge'],
      es: ['Conocimientos básicos de mercados financieros'],
      fr: ['Connaissances de base des marchés financiers'],
      ru: ['Базовые знания финансовых рынков']
    },
    skillsGained: {
      tr: ['Grafik okuma', 'Pattern tanıma', 'Gösterge kullanımı', 'Timing'],
      en: ['Chart reading', 'Pattern recognition', 'Indicator usage', 'Timing'],
      es: ['Lectura de gráficos', 'Reconocimiento de patrones', 'Uso de indicadores', 'Timing'],
      fr: ['Lecture de graphiques', 'Reconnaissance de motifs', 'Usage d\'indicateurs', 'Timing'],
      ru: ['Чтение графиков', 'Распознавание паттернов', 'Использование индикаторов', 'Тайминг']
    }
  },

  // Risk Management Course
  {
    id: 3,
    category: 'Risk',
    level: 'Intermediate',
    duration: '4',
    lessons: 14,
    rating: 4.9,
    enrolled: 1200,
    progress: 0,
    hasQuiz: true,
    contentTypes: ['video', 'text', 'quiz', 'calculator'],
    lastUpdated: '2',
    tags: ['risk', 'portfolio', 'management'],
    title: {
      tr: 'Risk Yönetimi',
      en: 'Risk Management',
      es: 'Gestión de Riesgos',
      fr: 'Gestion des Risques',
      ru: 'Управление рисками'
    },
    description: {
      tr: '2025 güncel örnekleriyle kapsamlı risk yönetimi eğitimi: Risk türleri, VaR hesaplamaları, portföy çeşitlendirmesi, hedge stratejileri, stress testing, likidite riski, operasyonel risk, ESG riskleri ve modern risk ölçüm teknikleri.',
      en: 'Comprehensive risk management education with 2025 current examples: Risk types, VaR calculations, portfolio diversification, hedge strategies, stress testing, liquidity risk, operational risk, ESG risks and modern risk measurement techniques.',
      es: 'Educación integral de gestión de riesgos con ejemplos actuales de 2025: Tipos de riesgo, cálculos VaR, diversificación de cartera, estrategias de cobertura, pruebas de estrés, riesgo de liquidez, riesgo operacional, riesgos ESG y técnicas modernas de medición de riesgos.',
      fr: 'Éducation complète de gestion des risques avec exemples actuels de 2025: Types de risques, calculs VaR, diversification de portefeuille, stratégies de couverture, tests de stress, risque de liquidité, risque opérationnel, risques ESG et techniques modernes de mesure des risques.',
      ru: 'Комплексное образование по управлению рисками с актуальными примерами 2025 года: Типы рисков, расчеты VaR, диверсификация портфеля, стратегии хеджирования, стресс-тестирование, риск ликвидности, операционный риск, ESG риски и современные техники измерения рисков.'
    },
    outcomes: {
      tr: [
        'Risk türlerini tanımlayacaksınız',
        'Portföy riskini hesaplayacaksınız',
        'Hedging stratejileri uygulayacaksınız'
      ],
      en: [
        'Identify risk types',
        'Calculate portfolio risk',
        'Apply hedging strategies'
      ],
      es: [
        'Identificarás tipos de riesgo',
        'Calcularás riesgo de cartera',
        'Aplicarás estrategias de cobertura'
      ],
      fr: [
        'Identifier les types de risques',
        'Calculer le risque de portefeuille',
        'Appliquer des stratégies de couverture'
      ],
      ru: [
        'Определите типы рисков',
        'Рассчитайте риск портфеля',
        'Примените стратегии хеджирования'
      ]
    },
    modules: [
      {
        title: {
          tr: 'Risk Türleri',
          en: 'Risk Types',
          es: 'Tipos de Riesgo',
          fr: 'Types de Risques',
          ru: 'Типы рисков'
        },
        lessons: ['Piyasa Riski', 'Kredi Riski', 'Operasyonel Risk', 'Likidite Riski'],
        duration: '2 saat',
        topics: {
          tr: ['Sistematik-sistematik olmayan', 'Temerrüt riski', 'İnsan hatası', 'Nakit akışı'],
          en: ['Systematic-unsystematic', 'Default risk', 'Human error', 'Cash flow'],
          es: ['Sistemático-no sistemático', 'Riesgo incumplimiento', 'Error humano', 'Flujo efectivo'],
          fr: ['Systématique-non systématique', 'Risque défaut', 'Erreur humaine', 'Flux trésorerie'],
          ru: ['Систематический-несистематический', 'Риск дефолта', 'Человеческая ошибка', 'Денежный поток']
        }
      },
      {
        title: {
          tr: 'Risk Ölçümü',
          en: 'Risk Measurement',
          es: 'Medición de Riesgo',
          fr: 'Mesure du Risque',
          ru: 'Измерение риска'
        },
        lessons: ['VaR', 'Stress Testing', 'Beta', 'Sharpe Ratio'],
        duration: '2 saat',
        topics: {
          tr: ['Parametrik-Monte Carlo', 'Senaryo analizi', 'Sistematik risk', 'Risk-ayarlı getiri'],
          en: ['Parametric-Monte Carlo', 'Scenario analysis', 'Systematic risk', 'Risk-adjusted return'],
          es: ['Paramétrico-Monte Carlo', 'Análisis escenario', 'Riesgo sistemático', 'Retorno ajustado riesgo'],
          fr: ['Paramétrique-Monte Carlo', 'Analyse scénario', 'Risque systématique', 'Rendement ajusté risque'],
          ru: ['Параметрический-Монте Карло', 'Сценарный анализ', 'Систематический риск', 'Доходность с поправкой на риск']
        }
      }
    ],
    prerequisites: {
      tr: ['Temel finans bilgisi', 'İstatistik temelleri'],
      en: ['Basic finance knowledge', 'Statistics fundamentals'],
      es: ['Conocimientos básicos de finanzas', 'Fundamentos de estadística'],
      fr: ['Connaissances de base en finance', 'Fondamentaux de statistiques'],
      ru: ['Базовые знания финансов', 'Основы статистики']
    },
    skillsGained: {
      tr: ['Risk analizi', 'Portföy optimizasyonu', 'Hedge uygulama', 'Stress test'],
      en: ['Risk analysis', 'Portfolio optimization', 'Hedge application', 'Stress testing'],
      es: ['Análisis de riesgo', 'Optimización de cartera', 'Aplicación cobertura', 'Prueba estrés'],
      fr: ['Analyse de risque', 'Optimisation de portefeuille', 'Application couverture', 'Test de stress'],
      ru: ['Анализ рисков', 'Оптимизация портфеля', 'Применение хеджирования', 'Стресс-тестирование']
    }
  },

  // Trading Psychology Course
  {
    id: 4,
    category: 'Psychology',
    level: 'Beginner',
    duration: '3',
    lessons: 12,
    rating: 4.6,
    enrolled: 1800,
    progress: 0,
    hasQuiz: true,
    contentTypes: ['video', 'text', 'quiz'],
    lastUpdated: '3',
    tags: ['psychology', 'emotions', 'mindset'],
    title: {
      tr: 'İşlem Psikolojisi',
      en: 'Trading Psychology',
      es: 'Psicología de Trading',
      fr: 'Psychologie du Trading',
      ru: 'Торговая психология'
    },
    description: {
      tr: '2025 güncel yaklaşımlarıyla kapsamlı işlem psikolojisi eğitimi: Duygusal zeka, korku ve açgözlülük yönetimi, bilişsel önyargılar, disiplin geliştirme, stres yönetimi, zihinsel dayanıklılık, meditasyon teknikleri ve sürdürülebilir trading alışkanlıkları.',
      en: 'Comprehensive trading psychology education with 2025 current approaches: Emotional intelligence, fear and greed management, cognitive biases, discipline development, stress management, mental resilience, meditation techniques and sustainable trading habits.',
      es: 'Educación integral de psicología de trading con enfoques actuales de 2025: Inteligencia emocional, gestión del miedo y la codicia, sesgos cognitivos, desarrollo de disciplina, gestión del estrés, resistencia mental, técnicas de meditación y hábitos de trading sostenibles.',
      fr: 'Éducation complète de psychologie du trading avec approches actuelles de 2025: Intelligence émotionnelle, gestion de la peur et de la cupidité, biais cognitifs, développement de la discipline, gestion du stress, résilience mentale, techniques de méditation et habitudes de trading durables.',
      ru: 'Комплексное образование по торговой психологии с актуальными подходами 2025 года: Эмоциональный интеллект, управление страхом и жадностью, когнитивные предрассудки, развитие дисциплины, управление стрессом, ментальная устойчивость, техники медитации и устойчивые торговые привычки.'
    },
    outcomes: {
      tr: [
        'Duygusal kontrolü geliştireceksiniz',
        'Trading disiplini oluşturacaksınız',
        'Psikolojik tuzaklardan kaçınacaksınız'
      ],
      en: [
        'Develop emotional control',
        'Build trading discipline',
        'Avoid psychological traps'
      ],
      es: [
        'Desarrollarás control emocional',
        'Construirás disciplina de trading',
        'Evitarás trampas psicológicas'
      ],
      fr: [
        'Développer le contrôle émotionnel',
        'Construire la discipline de trading',
        'Éviter les pièges psychologiques'
      ],
      ru: [
        'Развить эмоциональный контроль',
        'Построить торговую дисциплину',
        'Избежать психологических ловушек'
      ]
    },
    modules: [
      {
        title: {
          tr: 'Duygusal Kontrol',
          en: 'Emotional Control',
          es: 'Control Emocional',
          fr: 'Contrôle Émotionnel',
          ru: 'Эмоциональный контроль'
        },
        lessons: ['Korku Yönetimi', 'Açgözlülük', 'Sabır', 'Stres'],
        duration: '1.5 saat',
        topics: {
          tr: ['FOMO', 'Kar alma acelesi', 'Uzun vadeli bakış', 'Rahatlama teknikleri'],
          en: ['FOMO', 'Profit taking rush', 'Long-term view', 'Relaxation techniques'],
          es: ['FOMO', 'Prisa tomar ganancias', 'Visión largo plazo', 'Técnicas relajación'],
          fr: ['FOMO', 'Précipitation prise profits', 'Vision long terme', 'Techniques relaxation'],
          ru: ['FOMO', 'Спешка с прибылью', 'Долгосрочное видение', 'Техники расслабления']
        }
      },
      {
        title: {
          tr: 'Trading Disiplini',
          en: 'Trading Discipline',
          es: 'Disciplina de Trading',
          fr: 'Discipline de Trading',
          ru: 'Торговая дисциплина'
        },
        lessons: ['Plan Takibi', 'Risk Limitleri', 'Günlük Rutinler', 'Kayıt Tutma'],
        duration: '1.5 saat',
        topics: {
          tr: ['Strateji sadakati', 'Stop-loss disiplini', 'Trading saatleri', 'Performans analizi'],
          en: ['Strategy loyalty', 'Stop-loss discipline', 'Trading hours', 'Performance analysis'],
          es: ['Lealtad estrategia', 'Disciplina stop-loss', 'Horas trading', 'Análisis rendimiento'],
          fr: ['Loyauté stratégie', 'Discipline stop-loss', 'Heures trading', 'Analyse performance'],
          ru: ['Верность стратегии', 'Дисциплина стоп-лосс', 'Торговые часы', 'Анализ производительности']
        }
      }
    ],
    prerequisites: {
      tr: ['Temel trading bilgisi'],
      en: ['Basic trading knowledge'],
      es: ['Conocimientos básicos de trading'],
      fr: ['Connaissances de base en trading'],
      ru: ['Базовые знания торговли']
    },
    skillsGained: {
      tr: ['Duygusal farkındalık', 'Disiplin', 'Stres yönetimi', 'Zihinsel dayanıklılık'],
      en: ['Emotional awareness', 'Discipline', 'Stress management', 'Mental resilience'],
      es: ['Conciencia emocional', 'Disciplina', 'Gestión estrés', 'Resistencia mental'],
      fr: ['Conscience émotionnelle', 'Discipline', 'Gestion stress', 'Résilience mentale'],
      ru: ['Эмоциональная осознанность', 'Дисциплина', 'Управление стрессом', 'Ментальная устойчивость']
    }
  },

  // Algorithmic Trading Course
  {
    id: 5,
    category: 'Algorithmic',
    level: 'Advanced',
    duration: '10',
    lessons: 25,
    rating: 4.8,
    enrolled: 650,
    progress: 0,
    hasQuiz: true,
    contentTypes: ['video', 'text', 'quiz', 'practice'],
    lastUpdated: '1',
    tags: ['algorithmic', 'programming', 'automation'],
    title: {
      tr: 'Algoritmik İşlemler',
      en: 'Algorithmic Trading',
      es: 'Trading Algorítmico',
      fr: 'Trading Algorithmique',
      ru: 'Алгоритмическая торговля'
    },
    description: {
      tr: '2025 güncel teknolojileriyle kapsamlı algoritmik işlem eğitimi: Python programming, API entegrasyonu, trading botları, machine learning, backtesting, optimization, high-frequency trading, market making stratejileri ve yapay zeka uygulamaları.',
      en: 'Comprehensive algorithmic trading education with 2025 current technologies: Python programming, API integration, trading bots, machine learning, backtesting, optimization, high-frequency trading, market making strategies and AI applications.',
      es: 'Educación integral de trading algorítmico con tecnologías actuales de 2025: Programación Python, integración API, bots de trading, machine learning, backtesting, optimización, trading de alta frecuencia, estrategias market making y aplicaciones IA.',
      fr: 'Éducation complète de trading algorithmique avec technologies actuelles de 2025: Programmation Python, intégration API, bots de trading, machine learning, backtesting, optimisation, trading haute fréquence, stratégies market making et applications IA.',
      ru: 'Комплексное образование по алгоритмической торговле с актуальными технологиями 2025 года: Программирование Python, интеграция API, торговые боты, машинное обучение, бэктестинг, оптимизация, высокочастотная торговля, стратегии маркет-мейкинга и приложения ИИ.'
    },
    outcomes: {
      tr: [
        'Trading algoritmaları geliştireceksiniz',
        'Backtesting yapabileceksiniz',
        'Bot programlayabileceksiniz'
      ],
      en: [
        'Develop trading algorithms',
        'Perform backtesting',
        'Program trading bots'
      ],
      es: [
        'Desarrollarás algoritmos de trading',
        'Realizarás backtesting',
        'Programarás bots de trading'
      ],
      fr: [
        'Développer des algorithmes de trading',
        'Effectuer du backtesting',
        'Programmer des bots de trading'
      ],
      ru: [
        'Разработать торговые алгоритмы',
        'Выполнить бэктестинг',
        'Программировать торговых ботов'
      ]
    },
    modules: [
      {
        title: {
          tr: 'Python Temelleri',
          en: 'Python Fundamentals',
          es: 'Fundamentos Python',
          fr: 'Fondamentaux Python',
          ru: 'Основы Python'
        },
        lessons: ['Syntax', 'Pandas', 'Numpy', 'API'],
        duration: '4 saat',
        topics: {
          tr: ['Veri yapıları', 'DataFrame', 'Matematiksel işlemler', 'REST API'],
          en: ['Data structures', 'DataFrame', 'Mathematical operations', 'REST API'],
          es: ['Estructuras datos', 'DataFrame', 'Operaciones matemáticas', 'REST API'],
          fr: ['Structures données', 'DataFrame', 'Opérations mathématiques', 'REST API'],
          ru: ['Структуры данных', 'DataFrame', 'Математические операции', 'REST API']
        }
      },
      {
        title: {
          tr: 'Trading Stratejileri',
          en: 'Trading Strategies',
          es: 'Estrategias de Trading',
          fr: 'Stratégies de Trading',
          ru: 'Торговые стратегии'
        },
        lessons: ['Moving Average', 'Mean Reversion', 'Momentum', 'Arbitrage'],
        duration: '3 saat',
        topics: {
          tr: ['MA crossover', 'Ortalama dönüş', 'Trend takibi', 'Fiyat farklılıkları'],
          en: ['MA crossover', 'Mean reversion', 'Trend following', 'Price differences'],
          es: ['Cruce MA', 'Reversión media', 'Seguimiento tendencia', 'Diferencias precio'],
          fr: ['Croisement MA', 'Retour moyenne', 'Suivi tendance', 'Différences prix'],
          ru: ['Пересечение MA', 'Возврат к среднему', 'Следование тренду', 'Ценовые различия']
        }
      },
      {
        title: {
          tr: 'Backtesting ve Optimizasyon',
          en: 'Backtesting and Optimization',
          es: 'Backtesting y Optimización',
          fr: 'Backtesting et Optimisation',
          ru: 'Бэктестинг и оптимизация'
        },
        lessons: ['Backtrader', 'Performance Metrics', 'Walk Forward', 'Parameter Optimization'],
        duration: '3 saat',
        topics: {
          tr: ['Strategi testi', 'Sharpe, Sortino', 'İleriye test', 'Grid search'],
          en: ['Strategy testing', 'Sharpe, Sortino', 'Forward testing', 'Grid search'],
          es: ['Prueba estrategia', 'Sharpe, Sortino', 'Prueba adelante', 'Búsqueda grid'],
          fr: ['Test stratégie', 'Sharpe, Sortino', 'Test avant', 'Recherche grille'],
          ru: ['Тестирование стратегии', 'Шарп, Сортино', 'Форвард-тест', 'Поиск по сетке']
        }
      }
    ],
    prerequisites: {
      tr: ['Programlama temelleri', 'Teknik analiz', 'İleri matematik'],
      en: ['Programming fundamentals', 'Technical analysis', 'Advanced mathematics'],
      es: ['Fundamentos programación', 'Análisis técnico', 'Matemáticas avanzadas'],
      fr: ['Fondamentaux programmation', 'Analyse technique', 'Mathématiques avancées'],
      ru: ['Основы программирования', 'Технический анализ', 'Продвинутая математика']
    },
    skillsGained: {
      tr: ['Python programlama', 'Algorithm geliştirme', 'Backtest', 'Bot programlama'],
      en: ['Python programming', 'Algorithm development', 'Backtesting', 'Bot programming'],
      es: ['Programación Python', 'Desarrollo algoritmos', 'Backtesting', 'Programación bots'],
      fr: ['Programmation Python', 'Développement algorithmes', 'Backtesting', 'Programmation bots'],
      ru: ['Программирование Python', 'Разработка алгоритмов', 'Бэктестинг', 'Программирование ботов']
    }
  },

  // Derivatives Markets Course
  {
    id: 9,
    category: 'Markets',
    level: 'Advanced',
    duration: '14',
    lessons: 28,
    rating: 4.7,
    enrolled: 428,
    progress: 0,
    hasQuiz: true,
    contentTypes: ['video', 'text', 'quiz', 'simulation'],
    lastUpdated: '2',
    tags: ['derivatives', 'options', 'futures', 'swaps', 'hedging', 'arbitrage', 'pricing', 'advanced'],
    title: {
      tr: 'Türev Piyasalar',
      en: 'Derivatives Markets',
      es: 'Mercados de Derivados',
      fr: 'Marchés de Dérivés',
      ru: 'Рынки деривативов'
    },
    description: {
      tr: '2025 güncel düzenlemeleriyle kapsamlı türev piyasalar eğitimi: Forward, futures, opsiyon ve swap sözleşmeleri, fiyatlama modelleri, hedging stratejileri, arbitraj fırsatları, risk yönetimi, Black-Scholes modeli, Greeks analizi, volatilite trading ve türev araçlarla portföy optimizasyonu.',
      en: 'Comprehensive derivatives markets education with 2025 current regulations: Forward, futures, option and swap contracts, pricing models, hedging strategies, arbitrage opportunities, risk management, Black-Scholes model, Greeks analysis, volatility trading and portfolio optimization with derivatives.',
      es: 'Educación integral de mercados de derivados con regulaciones actuales de 2025: Contratos forward, futuros, opciones y swaps, modelos de precios, estrategias de cobertura, oportunidades de arbitraje, gestión de riesgos, modelo Black-Scholes, análisis de Greeks, trading de volatilidad y optimización de cartera con derivados.',
      fr: 'Éducation complète des marchés de dérivés avec réglementations actuelles de 2025: Contrats forward, futures, options et swaps, modèles de tarification, stratégies de couverture, opportunités d\'arbitrage, gestion des risques, modèle Black-Scholes, analyse des Greeks, trading de volatilité et optimisation de portefeuille avec dérivés.',
      ru: 'Комплексное образование по рынкам деривативов с актуальными регулированиями 2025 года: Форвардные, фьючерсные, опционные и своп-контракты, модели ценообразования, стратегии хеджирования, арбитражные возможности, управление рисками, модель Блэка-Шоулза, анализ Greeks, торговля волатильностью и оптимизация портфеля с деривативами.'
    },
    outcomes: {
      tr: [
        'Türev araçların temel işleyişi ve piyasa mekanizmalarını anlayacaksınız',
        'Forward ve futures sözleşmelerinin fiyatlamasını ve kullanımını kavrayacaksınız',
        'Opsiyon stratejileri ile risk yönetimi ve gelir üretme tekniklerini öğreneceksiniz',
        'Swap sözleşmeleri ve faiz riski yönetimini uygulayabileceksiniz',
        'Türev piyasalarda arbitraj fırsatlarını tespit edebileceksiniz',
        'Black-Scholes ve diğer fiyatlama modellerini kullanabileceksiniz',
        'Türev araçlarla portföy hedging stratejileri geliştirebileceksiniz',
        'Düzenleyici çerçevede güvenli türev işlemleri yapabileceksiniz'
      ],
      en: [
        'You will understand basic functioning and market mechanisms of derivative instruments',
        'You will grasp pricing and usage of forward and futures contracts',
        'You will learn risk management and income generation techniques with option strategies',
        'You will be able to apply swap contracts and interest rate risk management',
        'You will be able to identify arbitrage opportunities in derivatives markets',
        'You will be able to use Black-Scholes and other pricing models',
        'You will be able to develop portfolio hedging strategies with derivatives',
        'You will be able to conduct safe derivative transactions within regulatory framework'
      ],
      es: [
        'Entenderás el funcionamiento básico y mecanismos de mercado de instrumentos derivados',
        'Comprenderás la fijación de precios y uso de contratos forward y futuros',
        'Aprenderás técnicas de gestión de riesgos y generación de ingresos con estrategias de opciones',
        'Podrás aplicar contratos swap y gestión de riesgo de tasa de interés',
        'Podrás identificar oportunidades de arbitraje en mercados de derivados',
        'Podrás usar Black-Scholes y otros modelos de precios',
        'Podrás desarrollar estrategias de cobertura de cartera con derivados',
        'Podrás realizar transacciones seguras de derivados dentro del marco regulatorio'
      ],
      fr: [
        'Vous comprendrez le fonctionnement de base et mécanismes de marché des instruments dérivés',
        'Vous saisirez la tarification et l\'utilisation des contrats forward et futures',
        'Vous apprendrez les techniques de gestion des risques et génération de revenus avec stratégies d\'options',
        'Vous pourrez appliquer les contrats swap et gestion du risque de taux d\'intérêt',
        'Vous pourrez identifier les opportunités d\'arbitrage sur les marchés dérivés',
        'Vous pourrez utiliser Black-Scholes et autres modèles de tarification',
        'Vous pourrez développer des stratégies de couverture de portefeuille avec dérivés',
        'Vous pourrez effectuer des transactions sûres de dérivés dans le cadre réglementaire'
      ],
      ru: [
        'Вы поймете основное функционирование и рыночные механизмы производных инструментов',
        'Вы поймете ценообразование и использование форвардных и фьючерсных контрактов',
        'Вы изучите техники управления рисками и получения доходов с опционными стратегиями',
        'Вы сможете применять своп-контракты и управление процентным риском',
        'Вы сможете выявлять арбитражные возможности на рынках деривативов',
        'Вы сможете использовать Black-Scholes и другие модели ценообразования',
        'Вы сможете разрабатывать стратегии хеджирования портфеля с деривативами',
        'Вы сможете проводить безопасные операции с деривативами в рамках регулирования'
      ]
    },
    modules: [
      {
        title: {
          tr: 'Türev Araçlara Giriş',
          en: 'Introduction to Derivatives',
          es: 'Introducción a Derivados',
          fr: 'Introduction aux Dérivés',
          ru: 'Введение в деривативы'
        },
        lessons: ['Türev Tanımı', 'Tarihçe', 'Piyasa Türleri', 'Katılımcılar'],
        duration: '3 saat',
        topics: {
          tr: ['Dayanak varlık kavramı', 'Risk yönetimi vs spekülasyon', 'OTC vs organize piyasalar', 'Hedger, spekülatör, arbitrajcı'],
          en: ['Underlying asset concept', 'Risk management vs speculation', 'OTC vs organized markets', 'Hedger, speculator, arbitrageur'],
          es: ['Concepto de activo subyacente', 'Gestión de riesgos vs especulación', 'OTC vs mercados organizados', 'Coberturista, especulador, arbitrajista'],
          fr: ['Concept d\'actif sous-jacent', 'Gestion des risques vs spéculation', 'OTC vs marchés organisés', 'Couvreur, spéculateur, arbitrageur'],
          ru: ['Концепция базового актива', 'Управление рисками vs спекуляция', 'OTC vs организованные рынки', 'Хеджер, спекулянт, арбитражер']
        }
      },
      {
        title: {
          tr: 'Forward ve Futures Sözleşmeler',
          en: 'Forward and Futures Contracts',
          es: 'Contratos Forward y Futuros',
          fr: 'Contrats Forward et Futures',
          ru: 'Форвардные и фьючерсные контракты'
        },
        lessons: ['Forward Temelleri', 'Futures Özellikleri', 'Fiyatlama Modelleri', 'Hedging Stratejileri'],
        duration: '4 saat',
        topics: {
          tr: ['Forward fiyatlama formülü', 'Teminat sistemi', 'Günlük değerleme', 'Baz riski', 'Uzun/kısa koruma'],
          en: ['Forward pricing formula', 'Margin system', 'Mark-to-market', 'Basis risk', 'Long/short hedge'],
          es: ['Fórmula de precio forward', 'Sistema de margen', 'Mark-to-market', 'Riesgo de base', 'Cobertura larga/corta'],
          fr: ['Formule de prix forward', 'Système de marge', 'Mark-to-market', 'Risque de base', 'Couverture longue/courte'],
          ru: ['Формула форвардного ценообразования', 'Маржинальная система', 'Переоценка', 'Базисный риск', 'Длинный/короткий хедж']
        }
      },
      {
        title: {
          tr: 'Opsiyon Sözleşmeleri',
          en: 'Option Contracts',
          es: 'Contratos de Opciones',
          fr: 'Contrats d\'Options',
          ru: 'Опционные контракты'
        },
        lessons: ['Call/Put Opsiyonlar', 'Black-Scholes Modeli', 'Greeks', 'Opsiyon Stratejileri'],
        duration: '4 saat',
        topics: {
          tr: ['Strike, premium, expiration', 'Volatilite etkisi', 'Delta, gamma, theta, vega', 'Covered call, protective put'],
          en: ['Strike, premium, expiration', 'Volatility effect', 'Delta, gamma, theta, vega', 'Covered call, protective put'],
          es: ['Strike, prima, expiración', 'Efecto volatilidad', 'Delta, gamma, theta, vega', 'Covered call, protective put'],
          fr: ['Strike, prime, expiration', 'Effet volatilité', 'Delta, gamma, theta, vega', 'Covered call, protective put'],
          ru: ['Страйк, премия, экспирация', 'Эффект волатильности', 'Дельта, гамма, тета, вега', 'Покрытый колл, защитный пут']
        }
      },
      {
        title: {
          tr: 'Swap Sözleşmeleri ve Risk Yönetimi',
          en: 'Swap Contracts and Risk Management',
          es: 'Contratos Swap y Gestión de Riesgos',
          fr: 'Contrats Swap et Gestion des Risques',
          ru: 'Своп-контракты и управление рисками'
        },
        lessons: ['Faiz Oranı Swapları', 'Para Swapları', 'CDS', 'Portföy Hedging'],
        duration: '3 saat',
        topics: {
          tr: ['Sabit-değişken faiz değişimi', 'Para birimi riski', 'Kredi temerrüt sigortası', 'VAR hesaplama'],
          en: ['Fixed-floating rate exchange', 'Currency risk', 'Credit default insurance', 'VAR calculation'],
          es: ['Intercambio tasa fija-flotante', 'Riesgo cambiario', 'Seguro incumplimiento crédito', 'Cálculo VAR'],
          fr: ['Échange taux fixe-flottant', 'Risque de change', 'Assurance défaut crédit', 'Calcul VAR'],
          ru: ['Обмен фиксированной-плавающей ставки', 'Валютный риск', 'Страхование кредитного дефолта', 'Расчет VAR']
        }
      }
    ],
    prerequisites: {
      tr: ['İleri düzey finansal piyasa bilgisi', 'Matematik ve istatistik temelleri', 'Risk yönetimi deneyimi', 'Yeterli sermaye ve risk toleransı'],
      en: ['Advanced financial markets knowledge', 'Mathematics and statistics fundamentals', 'Risk management experience', 'Adequate capital and risk tolerance'],
      es: ['Conocimiento avanzado de mercados financieros', 'Fundamentos de matemáticas y estadísticas', 'Experiencia en gestión de riesgos', 'Capital adecuado y tolerancia al riesgo'],
      fr: ['Connaissances avancées des marchés financiers', 'Fondamentaux mathématiques et statistiques', 'Expérience en gestion des risques', 'Capital adéquat et tolérance au risque'],
      ru: ['Продвинутые знания финансовых рынков', 'Основы математики и статистики', 'Опыт управления рисками', 'Достаточный капитал и толерантность к риску']
    },
    skillsGained: {
      tr: ['Türev fiyatlama modelleri', 'Hedging stratejileri', 'Arbitraj analizi', 'Risk ölçümü', 'Portföy optimizasyonu', 'Regülasyon uyumu'],
      en: ['Derivative pricing models', 'Hedging strategies', 'Arbitrage analysis', 'Risk measurement', 'Portfolio optimization', 'Regulatory compliance'],
      es: ['Modelos de precios de derivados', 'Estrategias de cobertura', 'Análisis de arbitraje', 'Medición de riesgos', 'Optimización de cartera', 'Cumplimiento regulatorio'],
      fr: ['Modèles de prix des dérivés', 'Stratégies de couverture', 'Analyse d\'arbitrage', 'Mesure des risques', 'Optimisation de portefeuille', 'Conformité réglementaire'],
      ru: ['Модели ценообразования деривативов', 'Стратегии хеджирования', 'Арбитражный анализ', 'Измерение рисков', 'Оптимизация портфеля', 'Соблюдение регулирования']
    }
  },

  // Advanced Technical Analysis Course
  {
    id: 10,
    category: 'Analysis',
    level: 'Advanced',
    duration: '8',
    lessons: 16,
    rating: 4.9,
    enrolled: 856,
    progress: 0,
    hasQuiz: true,
    contentTypes: ['video', 'text', 'quiz', 'practice'],
    lastUpdated: '3',
    tags: ['ileri', 'teknik', 'analiz', 'SMC', 'grafik'],
    title: {
      tr: 'İleri Seviye Teknik Analiz',
      en: 'Advanced Technical Analysis',
      es: 'Análisis Técnico Avanzado',
      fr: 'Analyse Technique Avancée',
      ru: 'Продвинутый технический анализ'
    },
    description: {
      tr: '2025 güncel yaklaşımlarıyla kapsamlı ileri teknik analiz eğitimi: Çoklu zaman çerçevesi stratejileri, SMC (Akıllı Para Kavramları), kurumsal davranış analizi, fiyat-hacim uyumu, VWAP, Level II/DOM, emir akışı, FVG, likidite havuzları, konfluence teknikleri ve profesyonel işlem yönetimi.',
      en: 'Comprehensive advanced technical analysis education with 2025 current approaches: Multi-timeframe strategies, SMC (Smart Money Concepts), institutional behavior analysis, price-volume harmony, VWAP, Level II/DOM, order flow, FVG, liquidity pools, confluence techniques and professional trade management.',
      es: 'Educación integral de análisis técnico avanzado con enfoques actuales de 2025: Estrategias de marco temporal múltiple, SMC (Smart Money Concepts), análisis de comportamiento institucional, armonía precio-volumen, VWAP, Level II/DOM, flujo de órdenes, FVG, pools de liquidez, técnicas de confluencia y gestión profesional de trading.',
      fr: 'Éducation complète d\'analyse technique avancée avec approches actuelles de 2025: Stratégies multi-cadres temporels, SMC (Smart Money Concepts), analyse comportement institutionnel, harmonie prix-volume, VWAP, Level II/DOM, flux d\'ordres, FVG, pools de liquidité, techniques de confluence et gestion professionnelle de trading.',
      ru: 'Комплексное образование по продвинутому техническому анализу с актуальными подходами 2025 года: Мульти-таймфрейм стратегии, SMC (Smart Money Concepts), анализ институционального поведения, гармония цена-объем, VWAP, Level II/DOM, поток ордеров, FVG, пулы ликвидности, техники конфлюенса и профессиональное управление сделками.'
    },
    outcomes: {
      tr: [
        'Çoklu zaman çerçevesi analizi ile daha isabetli giriş ve çıkış yapabileceksiniz',
        'SMC (Akıllı Para Kavramları) ile kurumsal davranışları anlayacaksınız',
        'VWAP ve Volume Profile ile kurumsal değer algısını takip edebileceksiniz',
        'Level II/DOM ve emir akışı ile büyük oyuncuların niyetini çözebileceksiniz',
        'FVG, Order Block ve likidite havuzları ile güçlü giriş noktaları bulacaksınız',
        'Konfluence teknikleri ile sinyal kalitesini artıracaksınız',
        'ATR ve volatilite ölçümü ile dinamik risk yönetimi yapabileceksiniz',
        'Backtest ve walk-forward test ile stratejilerinizi doğrulayabileceksiniz'
      ],
      en: [
        'You will make more accurate entries and exits with multi-timeframe analysis',
        'You will understand institutional behavior with SMC (Smart Money Concepts)',
        'You will track institutional value perception with VWAP and Volume Profile',
        'You will decode big players\' intentions with Level II/DOM and order flow',
        'You will find strong entry points with FVG, Order Block and liquidity pools',
        'You will improve signal quality with confluence techniques',
        'You will perform dynamic risk management with ATR and volatility measurement',
        'You will validate your strategies with backtest and walk-forward testing'
      ],
      es: [
        'Harás entradas y salidas más precisas con análisis multi-temporal',
        'Entenderás el comportamiento institucional con SMC (Smart Money Concepts)',
        'Rastrearás la percepción de valor institucional con VWAP y Volume Profile',
        'Decodificarás las intenciones de grandes jugadores con Level II/DOM y flujo de órdenes',
        'Encontrarás puntos de entrada fuertes con FVG, Order Block y pools de liquidez',
        'Mejorarás la calidad de señales con técnicas de confluencia',
        'Realizarás gestión dinámica de riesgos con ATR y medición de volatilidad',
        'Validarás tus estrategias con backtest y testing walk-forward'
      ],
      fr: [
        'Vous ferez des entrées et sorties plus précises avec l\'analyse multi-temporelle',
        'Vous comprendrez le comportement institutionnel avec SMC (Smart Money Concepts)',
        'Vous suivrez la perception de valeur institutionnelle avec VWAP et Volume Profile',
        'Vous décoderez les intentions des gros joueurs avec Level II/DOM et flux d\'ordres',
        'Vous trouverez des points d\'entrée forts avec FVG, Order Block et pools de liquidité',
        'Vous améliorerez la qualité des signaux avec des techniques de confluence',
        'Vous effectuerez une gestion dynamique des risques avec ATR et mesure de volatilité',
        'Vous validerez vos stratégies avec backtest et test walk-forward'
      ],
      ru: [
        'Вы будете делать более точные входы и выходы с мульти-таймфрейм анализом',
        'Вы поймете институциональное поведение с SMC (Smart Money Concepts)',
        'Вы будете отслеживать институциональное восприятие стоимости с VWAP и Volume Profile',
        'Вы расшифруете намерения крупных игроков с Level II/DOM и потоком ордеров',
        'Вы найдете сильные точки входа с FVG, Order Block и пулами ликвидности',
        'Вы улучшите качество сигналов с техниками конфлюенса',
        'Вы будете выполнять динамическое управление рисками с ATR и измерением волатильности',
        'Вы проверите свои стратегии с бэктестом и walk-forward тестированием'
      ]
    },
    modules: [
      {
        title: {
          tr: 'Çoklu Zaman Çerçevesi ve Fiyat-Hacim Analizi',
          en: 'Multi-Timeframe and Price-Volume Analysis',
          es: 'Análisis Multi-Temporal y Precio-Volumen',
          fr: 'Analyse Multi-Temporelle et Prix-Volume',
          ru: 'Мульти-таймфрейм и анализ цены-объема'
        },
        lessons: ['Çoklu Zaman Çerçevesi Stratejisi', 'Fiyat ve Hacim Uyumu', 'VWAP ve Volume Profile', 'Kurumsal Değer Algısı'],
        duration: '2 saat',
        topics: {
          tr: ['Haftalık-günlük-saatlik uyum', 'Hacim onayı teknikleri', 'POC ve value area', 'Kurumsal giriş seviyeleri'],
          en: ['Weekly-daily-hourly alignment', 'Volume confirmation techniques', 'POC and value area', 'Institutional entry levels'],
          es: ['Alineación semanal-diaria-horaria', 'Técnicas confirmación volumen', 'POC y área de valor', 'Niveles entrada institucional'],
          fr: ['Alignement hebdomadaire-quotidien-horaire', 'Techniques confirmation volume', 'POC et zone de valeur', 'Niveaux entrée institutionnelle'],
          ru: ['Выравнивание недельно-дневно-часовое', 'Техники подтверждения объема', 'POC и область стоимости', 'Институциональные уровни входа']
        }
      },
      {
        title: {
          tr: 'SMC: Akıllı Para Kavramları',
          en: 'SMC: Smart Money Concepts',
          es: 'SMC: Conceptos de Dinero Inteligente',
          fr: 'SMC: Concepts d\'Argent Intelligent',
          ru: 'SMC: Концепции умных денег'
        },
        lessons: ['Piyasa Yapısı', 'Order Block Analizi', 'Likidite Havuzları', 'FVG ve Mitigation'],
        duration: '3 saat',
        topics: {
          tr: ['Yapısal kırılımlar', 'Kurumsal giriş bölgeleri', 'Stop-hunt mantığı', 'Fiyat dengesi boşlukları'],
          en: ['Structural breaks', 'Institutional entry zones', 'Stop-hunt logic', 'Fair value gaps'],
          es: ['Roturas estructurales', 'Zonas entrada institucional', 'Lógica stop-hunt', 'Brechas valor justo'],
          fr: ['Cassures structurelles', 'Zones entrée institutionnelle', 'Logique stop-hunt', 'Lacunes valeur équitable'],
          ru: ['Структурные прорывы', 'Институциональные зоны входа', 'Логика стоп-хант', 'Разрывы справедливой стоимости']
        }
      },
      {
        title: {
          tr: 'Emir Akışı ve Piyasa Derinliği',
          en: 'Order Flow and Market Depth',
          es: 'Flujo de Órdenes y Profundidad de Mercado',
          fr: 'Flux d\'Ordres et Profondeur de Marché',
          ru: 'Поток ордеров и глубина рынка'
        },
        lessons: ['Level II/DOM Analizi', 'Emir Akışı Okuma', 'Büyük Blok Tespiti', 'Likidite Analizi'],
        duration: '2 saat',
        topics: {
          tr: ['Bid-ask spread', 'Iceberg emirleri', 'Satış duvarları', 'Likidite derinliği'],
          en: ['Bid-ask spread', 'Iceberg orders', 'Sell walls', 'Liquidity depth'],
          es: ['Diferencial bid-ask', 'Órdenes iceberg', 'Muros de venta', 'Profundidad liquidez'],
          fr: ['Écart bid-ask', 'Ordres iceberg', 'Murs de vente', 'Profondeur liquidité'],
          ru: ['Спред bid-ask', 'Айсберг ордера', 'Стены продаж', 'Глубина ликвидности']
        }
      },
      {
        title: {
          tr: 'İleri Stratejiler ve Test Yöntemleri',
          en: 'Advanced Strategies and Testing Methods',
          es: 'Estrategias Avanzadas y Métodos de Prueba',
          fr: 'Stratégies Avancées et Méthodes de Test',
          ru: 'Продвинутые стратегии и методы тестирования'
        },
        lessons: ['Konfluence Teknikleri', 'ATR ve Volatilite', 'Backtest Yöntemleri', 'İşlem Yönetimi'],
        duration: '1 saat',
        topics: {
          tr: ['Çoklu teyit sistemleri', 'Dinamik stop-loss', 'Walk-forward test', 'Kademeli çıkış stratejileri'],
          en: ['Multiple confirmation systems', 'Dynamic stop-loss', 'Walk-forward testing', 'Scaling out strategies'],
          es: ['Sistemas confirmación múltiple', 'Stop-loss dinámico', 'Testing walk-forward', 'Estrategias salida escalonada'],
          fr: ['Systèmes confirmation multiple', 'Stop-loss dynamique', 'Test walk-forward', 'Stratégies sortie échelonnée'],
          ru: ['Системы множественного подтверждения', 'Динамический стоп-лосс', 'Walk-forward тестирование', 'Стратегии поэтапного выхода']
        }
      }
    ],
    prerequisites: {
      tr: ['Temel teknik analiz bilgisi', 'Grafik okuma deneyimi', 'Risk yönetimi temelleri', 'Piyasa psikolojisi anlayışı'],
      en: ['Basic technical analysis knowledge', 'Chart reading experience', 'Risk management fundamentals', 'Market psychology understanding'],
      es: ['Conocimiento análisis técnico básico', 'Experiencia lectura gráficos', 'Fundamentos gestión riesgos', 'Comprensión psicología mercado'],
      fr: ['Connaissances analyse technique de base', 'Expérience lecture graphiques', 'Fondamentaux gestion risques', 'Compréhension psychologie marché'],
      ru: ['Базовые знания технического анализа', 'Опыт чтения графиков', 'Основы управления рисками', 'Понимание рыночной психологии']
    },
    skillsGained: {
      tr: ['İleri grafik analizi', 'SMC uygulama', 'Kurumsal davranış analizi', 'Profesyonel işlem yönetimi', 'Konfluence analizi', 'Volatilite ölçümü'],
      en: ['Advanced chart analysis', 'SMC application', 'Institutional behavior analysis', 'Professional trade management', 'Confluence analysis', 'Volatility measurement'],
      es: ['Análisis gráfico avanzado', 'Aplicación SMC', 'Análisis comportamiento institucional', 'Gestión trading profesional', 'Análisis confluencia', 'Medición volatilidad'],
      fr: ['Analyse graphique avancée', 'Application SMC', 'Analyse comportement institutionnel', 'Gestion trading professionnelle', 'Analyse confluence', 'Mesure volatilité'],
      ru: ['Продвинутый анализ графиков', 'Применение SMC', 'Анализ институционального поведения', 'Профессиональное управление сделками', 'Анализ конфлюенса', 'Измерение волатильности']
    }
  }
]

export const getCoursesForLanguage = (language: Language) => {
  return courses.map(course => ({
    ...course,
    title: course.title[language],
    description: course.description[language],
    outcomes: course.outcomes[language]
  }))
}