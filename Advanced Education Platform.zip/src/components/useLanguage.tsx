import { useState, createContext, useContext, ReactNode } from 'react'

export type Language = 'tr' | 'en' | 'es' | 'fr' | 'ru'

interface LanguageContextType {
  language: Language
  setLanguage: (lang: Language) => void
  t: (key: string) => string
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

interface TranslationData {
  [key: string]: {
    [lang in Language]: string
  }
}

const translations: TranslationData = {
  // Navigation & Headers
  'platform.title': {
    tr: 'Finans Eğitim Akademi',
    en: 'Finance Education Academy',
    es: 'Academia de Educación Financiera',
    fr: 'Académie d\'Éducation Financière',
    ru: 'Академия Финансового Образования'
  },
  'platform.subtitle': {
    tr: 'Kapsamlı eğitim programları ile işlem ve finans dünyasında profesyonel kariyerinizi inşa edin.',
    en: 'Build your professional career in trading and finance with comprehensive educational programs.',
    es: 'Construye tu carrera profesional en trading y finanzas con programas educativos integrales.',
    fr: 'Construisez votre carrière professionnelle en trading et finance avec des programmes éducatifs complets.',
    ru: 'Постройте свою профессиональную карьеру в трейдинге и финансах с комплексными образовательными программами.'
  },

  // Categories
  'categories.title': {
    tr: 'Eğitim Seviyeleri',
    en: 'Education Levels',
    es: 'Niveles de Educación',
    fr: 'Niveaux d\'Éducation',
    ru: 'Уровни Образования'
  },
  'categories.subtitle': {
    tr: 'İlgi alanınıza göre filtreleyerek hızlıca başlayın',
    en: 'Filter by your interests and get started quickly',
    es: 'Filtra por tus intereses y comienza rápidamente',
    fr: 'Filtrez selon vos intérêts et commencez rapidement',
    ru: 'Фильтруйте по своим интересам и быстро начинайте'
  },
  'categories.all': {
    tr: 'Tüm Eğitimler',
    en: 'All Courses',
    es: 'Todos los Cursos',
    fr: 'Tous les Cours',
    ru: 'Все Курсы'
  },
  'categories.economics': {
    tr: 'Temel Ekonomi',
    en: 'Basic Economics',
    es: 'Economía Básica',
    fr: 'Économie de Base',
    ru: 'Основы Экономики'
  },
  'categories.analysis': {
    tr: 'Analiz',
    en: 'Analysis',
    es: 'Análisis',
    fr: 'Analyse',
    ru: 'Анализ'
  },
  'categories.risk': {
    tr: 'Risk Yönetimi',
    en: 'Risk Management',
    es: 'Gestión de Riesgos',
    fr: 'Gestion des Risques',
    ru: 'Управление Рисками'
  },
  'categories.psychology': {
    tr: 'Psikoloji',
    en: 'Psychology',
    es: 'Psicología',
    fr: 'Psychologie',
    ru: 'Психология'
  },
  'categories.algorithmic': {
    tr: 'Algoritmik İşlemler',
    en: 'Algorithmic Trading',
    es: 'Trading Algorítmico',
    fr: 'Trading Algorithmique',
    ru: 'Алгоритмическая Торговля'
  },
  'categories.finance': {
    tr: 'Finans',
    en: 'Finance',
    es: 'Finanzas',
    fr: 'Finance',
    ru: 'Финансы'
  },
  'categories.crypto': {
    tr: 'Kripto',
    en: 'Crypto',
    es: 'Cripto',
    fr: 'Crypto',
    ru: 'Крипто'
  },

  // Course Actions
  'course.start': {
    tr: 'Eğitime Başla',
    en: 'Start Course',
    es: 'Comenzar Curso',
    fr: 'Commencer le Cours',
    ru: 'Начать Курс'
  },
  'course.startLearning': {
    tr: 'Eğitime Başla',
    en: 'Start Course',
    es: 'Comenzar Curso',
    fr: 'Commencer le Cours',
    ru: 'Начать Курс'
  },
  'course.continue': {
    tr: 'Devam Et',
    en: 'Continue',
    es: 'Continuar',
    fr: 'Continuer',
    ru: 'Продолжить'
  },

  // Course Details
  'course.lessons': {
    tr: 'ders',
    en: 'lessons',
    es: 'lecciones',
    fr: 'leçons',
    ru: 'уроков'
  },
  'course.hours': {
    tr: 'dakika',
    en: 'minutes',
    es: 'minutos',
    fr: 'minutes',
    ru: 'минут'
  },
  'course.progress': {
    tr: 'İlerleme',
    en: 'Progress',
    es: 'Progreso',
    fr: 'Progrès',
    ru: 'Прогресс'
  },
  'course.outcomes': {
    tr: 'Bu eğitimde:',
    en: 'In this course:',
    es: 'En este curso:',
    fr: 'Dans ce cours:',
    ru: 'В этом курсе:'
  },

  // Levels
  'level.beginner': {
    tr: 'Başlangıç',
    en: 'Beginner',
    es: 'Principiante',
    fr: 'Débutant',
    ru: 'Новичок'
  },
  'level.intermediate': {
    tr: 'Orta',
    en: 'Intermediate',
    es: 'Intermedio',
    fr: 'Intermédiaire',
    ru: 'Средний'
  },
  'level.advanced': {
    tr: 'İleri',
    en: 'Advanced',
    es: 'Avanzado',
    fr: 'Avancé',
    ru: 'Продвинутый'
  },
  'level.filter': {
    tr: 'Seviye Filtresi',
    en: 'Level Filter',
    es: 'Filtro de Nivel',
    fr: 'Filtre de Niveau',
    ru: 'Фильтр Уровня'
  },
  'level.filterHelp': {
    tr: 'Eğitim seviyenize göre filtreleyin',
    en: 'Filter by your education level',
    es: 'Filtrar por tu nivel educativo',
    fr: 'Filtrer par votre niveau d\'éducation',
    ru: 'Фильтровать по уровню образования'
  },
  'course.course': {
    tr: 'eğitim',
    en: 'course',
    es: 'curso',
    fr: 'cours',
    ru: 'курс'
  },
  'course.courses': {
    tr: 'eğitim',
    en: 'courses',
    es: 'cursos',
    fr: 'cours',
    ru: 'курсы'
  },

  // Course Counts
  'courses.available': {
    tr: 'eğitim mevcut',
    en: 'courses available',
    es: 'cursos disponibles',
    fr: 'cours disponibles',
    ru: 'курсов доступно'
  },

  // Course Detail Page
  'course.curriculum': {
    tr: 'Eğitim Müfredatı',
    en: 'Course Curriculum',
    es: 'Currículo del Curso',
    fr: 'Programme du Cours',
    ru: 'Учебная Программа'
  },
  'course.curriculum.desc': {
    tr: 'Detaylı ders planı ve konular',
    en: 'Detailed lesson plan and topics',
    es: 'Plan detallado de lecciones y temas',
    fr: 'Plan de cours détaillé et sujets',
    ru: 'Подробный план урока и темы'
  },
  'course.module': {
    tr: 'Modül',
    en: 'Module',
    es: 'Módulo',
    fr: 'Module',
    ru: 'Модуль'
  },
  'course.lessons.title': {
    tr: 'Dersler',
    en: 'Lessons',
    es: 'Lecciones',
    fr: 'Leçons',
    ru: 'Уроки'
  },
  'course.topics.title': {
    tr: 'Kapsanan Konular',
    en: 'Covered Topics',
    es: 'Temas Cubiertos',
    fr: 'Sujets Couverts',
    ru: 'Охваченные Темы'
  },
  'course.prerequisites': {
    tr: 'Ön Koşullar',
    en: 'Prerequisites',
    es: 'Prerrequisitos',
    fr: 'Prérequis',
    ru: 'Предварительные Требования'
  },
  'course.skills': {
    tr: 'Kazanılacak Beceriler',
    en: 'Skills You\'ll Gain',
    es: 'Habilidades que Obtendrás',
    fr: 'Compétences que Vous Acquerrez',
    ru: 'Навыки, Которые Вы Получите'
  },
  'course.enroll': {
    tr: 'Eğitime Kayıt Ol',
    en: 'Enroll in Course',
    es: 'Inscribirse en el Curso',
    fr: 'S\'inscrire au Cours',
    ru: 'Записаться на Курс'
  },
  'course.includes': {
    tr: 'Bu eğitime dahil:',
    en: 'This course includes:',
    es: 'Este curso incluye:',
    fr: 'Ce cours comprend:',
    ru: 'Этот курс включает:'
  },
  'course.info': {
    tr: 'Eğitim Bilgileri',
    en: 'Course Information',
    es: 'Información del Curso',
    fr: 'Informations sur le Cours',
    ru: 'Информация о Курсе'
  },
  'course.level': {
    tr: 'Seviye:',
    en: 'Level:',
    es: 'Nivel:',
    fr: 'Niveau:',
    ru: 'Уровень:'
  },
  'course.category': {
    tr: 'Kategori:',
    en: 'Category:',
    es: 'Categoría:',
    fr: 'Catégorie:',
    ru: 'Категория:'
  },
  'course.updated': {
    tr: 'Son Güncelleme:',
    en: 'Last Updated:',
    es: 'Última Actualización:',
    fr: 'Dernière Mise à Jour:',
    ru: 'Последнее Обновление:'
  },
  'course.language': {
    tr: 'Dil:',
    en: 'Language:',
    es: 'Idioma:',
    fr: 'Langue:',
    ru: 'Язык:'
  },
  'back': {
    tr: 'Geri Dön',
    en: 'Back',
    es: 'Volver',
    fr: 'Retour',
    ru: 'Назад'
  },
  'total.duration': {
    tr: 'Toplam Süre',
    en: 'Total Duration',
    es: 'Duración Total',
    fr: 'Durée Totale',
    ru: 'Общая Продолжительность'
  },
  'rating': {
    tr: 'Puan',
    en: 'Rating',
    es: 'Calificación',
    fr: 'Note',
    ru: 'Рейтинг'
  },
  'students': {
    tr: 'Öğrenci',
    en: 'Students',
    es: 'Estudiantes',
    fr: 'Étudiants',
    ru: 'Студенты'
  },
  'days.ago': {
    tr: 'gün önce',
    en: 'days ago',
    es: 'días atrás',
    fr: 'jours auparavant',
    ru: 'дней назад'
  },
  'content.video': {
    tr: 'video içeriği',
    en: 'video content',
    es: 'contenido de video',
    fr: 'contenu vidéo',
    ru: 'видео контент'
  },
  'content.text': {
    tr: 'metin içeriği',
    en: 'text content',
    es: 'contenido de texto',
    fr: 'contenu textuel',
    ru: 'текстовый контент'
  },
  'content.quiz': {
    tr: 'quiz içeriği',
    en: 'quiz content',
    es: 'contenido de cuestionario',
    fr: 'contenu de quiz',
    ru: 'контент викторины'
  },
  'content.practice': {
    tr: 'pratik içeriği',
    en: 'practice content',
    es: 'contenido de práctica',
    fr: 'contenu pratique',
    ru: 'практический контент'
  },
  'certificate.quiz': {
    tr: 'Sertifika sınavı',
    en: 'Certificate quiz',
    es: 'Examen de certificado',
    fr: 'Quiz de certificat',
    ru: 'Сертификационная викторина'
  },
  'unlimited.access': {
    tr: 'Sınırsız erişim',
    en: 'Unlimited access',
    es: 'Acceso ilimitado',
    fr: 'Accès illimité',
    ru: 'Неограниченный доступ'
  },
  'multilang': {
    tr: 'Çoklu Dil',
    en: 'Multi-language',
    es: 'Multi-idioma',
    fr: 'Multi-langue',
    ru: 'Мультиязычный'
  },
  'instructor': {
    tr: 'Eğitmen',
    en: 'Instructor',
    es: 'Instructor',
    fr: 'Instructeur',
    ru: 'Инструктор'
  },

  // Course Detail Learning Mode
  'lessons': {
    tr: 'Dersler',
    en: 'Lessons',
    es: 'Lecciones',
    fr: 'Leçons',
    ru: 'Уроки'
  },
  'quizzes': {
    tr: 'Sınavlar',
    en: 'Quizzes',
    es: 'Cuestionarios',
    fr: 'Quiz',
    ru: 'Викторины'
  },
  'startCourse': {
    tr: 'Eğitime Başla',
    en: 'Start Course',
    es: 'Comenzar Curso',
    fr: 'Commencer le Cours',
    ru: 'Начать Курс'
  },
  'courseContent': {
    tr: 'Eğitim İçeriği',
    en: 'Course Content',
    es: 'Contenido del Curso',
    fr: 'Contenu du Cours',
    ru: 'Содержание Курса'
  },
  'whatYouWillLearn': {
    tr: 'Neler Öğreneceksiniz',
    en: 'What You Will Learn',
    es: 'Qué Aprenderás',
    fr: 'Ce que Vous Apprendrez',
    ru: 'Что Вы Изучите'
  },
  'progress': {
    tr: 'İlerleme',
    en: 'Progress',
    es: 'Progreso',
    fr: 'Progrès',
    ru: 'Прогресс'
  },
  'previous': {
    tr: 'Önceki',
    en: 'Previous',
    es: 'Anterior',
    fr: 'Précédent',
    ru: 'Предыдущий'
  },
  'next': {
    tr: 'Sonraki',
    en: 'Next',
    es: 'Siguiente',
    fr: 'Suivant',
    ru: 'Следующий'
  },
  'takeQuiz': {
    tr: 'Sınava Geç',
    en: 'Take Quiz',
    es: 'Tomar Cuestionario',
    fr: 'Passer le Quiz',
    ru: 'Пройти Викторину'
  },
  'backToLessons': {
    tr: 'Derslere Dön',
    en: 'Back to Lessons',
    es: 'Volver a Lecciones',
    fr: 'Retour aux Leçons',
    ru: 'Вернуться к Урокам'
  },
  'quiz': {
    tr: 'Sınav',
    en: 'Quiz',
    es: 'Cuestionario',
    fr: 'Quiz',
    ru: 'Викторина'
  },
  'testYourKnowledge': {
    tr: 'Bilginizi Test Edin',
    en: 'Test Your Knowledge',
    es: 'Pon a Prueba tu Conocimiento',
    fr: 'Testez Vos Connaissances',
    ru: 'Проверьте Свои Знания'
  },
  'quizDescription': {
    tr: 'Öğrendiklerinizi pekiştirmek için aşağıdaki soruları yanıtlayın.',
    en: 'Answer the following questions to reinforce what you have learned.',
    es: 'Responde las siguientes preguntas para reforzar lo que has aprendido.',
    fr: 'Répondez aux questions suivantes pour renforcer ce que vous avez appris.',
    ru: 'Ответьте на следующие вопросы, чтобы закрепить то, что вы изучили.'
  },
  'submitQuiz': {
    tr: 'Sınavı Tamamla',
    en: 'Submit Quiz',
    es: 'Enviar Cuestionario',
    fr: 'Soumettre le Quiz',
    ru: 'Отправить Викторину'
  },
  'congratulations': {
    tr: 'Tebrikler!',
    en: 'Congratulations!',
    es: '¡Felicitaciones!',
    fr: 'Félicitations!',
    ru: 'Поздравления!'
  },
  'keepTrying': {
    tr: 'Devam Edin!',
    en: 'Keep Trying!',
    es: '¡Sigue Intentando!',
    fr: 'Continuez!',
    ru: 'Продолжайте Попытки!'
  },
  'quizPassed': {
    tr: 'Sınavı başarıyla geçtiniz!',
    en: 'You passed the quiz successfully!',
    es: '¡Pasaste el cuestionario con éxito!',
    fr: 'Vous avez réussi le quiz avec succès!',
    ru: 'Вы успешно прошли викторину!'
  },
  'quizFailed': {
    tr: 'Sınavı geçemediniz. Tekrar deneyebilirsiniz.',
    en: 'You did not pass the quiz. You can try again.',
    es: 'No pasaste el cuestionario. Puedes intentar de nuevo.',
    fr: 'Vous n\'avez pas réussi le quiz. Vous pouvez réessayer.',
    ru: 'Вы не прошли викторину. Вы можете попробовать еще раз.'
  },
  'correctAnswers': {
    tr: 'Doğru Cevaplar',
    en: 'Correct Answers',
    es: 'Respuestas Correctas',
    fr: 'Réponses Correctes',
    ru: 'Правильные Ответы'
  },
  'totalQuestions': {
    tr: 'Toplam Soru',
    en: 'Total Questions',
    es: 'Total de Preguntas',
    fr: 'Total des Questions',
    ru: 'Всего Вопросов'
  },
  'reviewLessons': {
    tr: 'Dersleri Gözden Geçir',
    en: 'Review Lessons',
    es: 'Revisar Lecciones',
    fr: 'Réviser les Leçons',
    ru: 'Повторить Уроки'
  },
  'backToCourses': {
    tr: 'Eğitimlere Dön',
    en: 'Back to Courses',
    es: 'Volver a Cursos',
    fr: 'Retour aux Cours',
    ru: 'Вернуться к Курсам'
  },
  'moreTopics': {
    tr: 'daha fazla konu',
    en: 'more topics',
    es: 'más temas',
    fr: 'plus de sujets',
    ru: 'больше тем'
  },

  // Course Detail Page - Additional keys
  'course.back': {
    tr: 'Geri',
    en: 'Back',
    es: 'Volver',
    fr: 'Retour',
    ru: 'Назад'
  },
  'course.students': {
    tr: 'Öğrenci',
    en: 'Students',
    es: 'Estudiantes',
    fr: 'Étudiants',
    ru: 'Студенты'
  },
  'course.rating': {
    tr: 'Değerlendirme',
    en: 'Rating',
    es: 'Calificación',
    fr: 'Évaluation',
    ru: 'Рейтинг'
  },
  'course.contents': {
    tr: 'İçerik',
    en: 'Contents',
    es: 'Contenidos',
    fr: 'Contenu',
    ru: 'Содержание'
  },
  'course.quiz_questions': {
    tr: 'quiz sorusu',
    en: 'quiz questions',
    es: 'preguntas de quiz',
    fr: 'questions de quiz',
    ru: 'вопросов викторины'
  },
  'course.start_learning': {
    tr: 'Eğitime Başla',
    en: 'Start Learning',
    es: 'Comenzar Aprendizaje',
    fr: 'Commencer l\'Apprentissage',
    ru: 'Начать Обучение'
  },
  'course.quiz_completed': {
    tr: 'Quiz Tamamlandı!',
    en: 'Quiz Completed!',
    es: '¡Quiz Completado!',
    fr: 'Quiz Terminé!',
    ru: 'Викторина Завершена!'
  },
  'course.passed': {
    tr: 'Başarılı! Eğitimi geçtiniz.',
    en: 'Success! You passed the course.',
    es: '¡Éxito! Pasaste el curso.',
    fr: 'Succès! Vous avez réussi le cours.',
    ru: 'Успех! Вы прошли курс.'
  },
  'course.failed': {
    tr: 'Başarısız. Tekrar deneyebilirsiniz.',
    en: 'Failed. You can try again.',
    es: 'Fallido. Puedes intentar de nuevo.',
    fr: 'Échec. Vous pouvez réessayer.',
    ru: 'Неудача. Вы можете попробовать еще раз.'
  },
  'course.restart': {
    tr: 'Yeniden Başla',
    en: 'Restart',
    es: 'Reiniciar',
    fr: 'Redémarrer',
    ru: 'Перезапустить'
  },
  'course.back_to_courses': {
    tr: 'Eğitimlere Dön',
    en: 'Back to Courses',
    es: 'Volver a Cursos',
    fr: 'Retour aux Cours',
    ru: 'Вернуться к Курсам'
  },
  'course.quiz': {
    tr: 'Quiz',
    en: 'Quiz',
    es: 'Quiz',
    fr: 'Quiz',
    ru: 'Викторина'
  },
  'course.previous': {
    tr: 'Önceki',
    en: 'Previous',
    es: 'Anterior',
    fr: 'Précédent',
    ru: 'Предыдущий'
  },
  'course.next': {
    tr: 'Sonraki',
    en: 'Next',
    es: 'Siguiente',
    fr: 'Suivant',
    ru: 'Следующий'
  },
  'course.submit_quiz': {
    tr: 'Quiz\'i Tamamla',
    en: 'Submit Quiz',
    es: 'Enviar Quiz',
    fr: 'Soumettre le Quiz',
    ru: 'Отправить Викторину'
  },
  'course.start_quiz': {
    tr: 'Quiz\'e Başla',
    en: 'Start Quiz',
    es: 'Comenzar Quiz',
    fr: 'Commencer le Quiz',
    ru: 'Начать Викторину'
  },
  'course.ready_to_start': {
    tr: 'Eğitime Başlamaya Hazır mısınız?',
    en: 'Ready to Start Learning?',
    es: '¿Listo para Comenzar a Aprender?',
    fr: 'Prêt à Commencer l\'Apprentissage?',
    ru: 'Готовы Начать Обучение?'
  },
  'course.start_description': {
    tr: 'Interaktif eğitim modüllerimizle öğrenmeye başlayın',
    en: 'Start learning with our interactive education modules',
    es: 'Comienza a aprender con nuestros módulos educativos interactivos',
    fr: 'Commencez à apprendre avec nos modules éducatifs interactifs',
    ru: 'Начните обучение с нашими интерактивными образовательными модулями'
  },
  'course.start_learning_now': {
    tr: 'Şimdi Eğitime Başla',
    en: 'Start Learning Now',
    es: 'Comenzar a Aprender Ahora',
    fr: 'Commencer l\'Apprentissage Maintenant',
    ru: 'Начать Обучение Сейчас'
  },
  'course.interactive_learning': {
    tr: 'Etkileşimli slaytlar ve quiz\'lerle zenginleştirilmiş eğitim deneyimi',
    en: 'Enhanced learning experience with interactive slides and quizzes',
    es: 'Experiencia de aprendizaje mejorada con diapositivas interactivas y cuestionarios',
    fr: 'Expérience d\'apprentissage améliorée avec des diapositives interactives et des quiz',
    ru: 'Улучшенный опыт обучения с интерактивными слайдами и викторинами'
  },
  'course.expert_badge': {
    tr: 'Uzmanı',
    en: 'Expert',
    es: 'Experto',
    fr: 'Expert',
    ru: 'Эксперт'
  },

  // Quiz Results and Badge System
  'quiz.wrong_answers_title': {
    tr: 'Yanlış Cevaplar ve Açıklamalar',
    en: 'Wrong Answers and Explanations',
    es: 'Respuestas Incorrectas y Explicaciones',
    fr: 'Réponses Incorrectes et Explications',
    ru: 'Неправильные ответы и объяснения'
  },
  'quiz.review_description': {
    tr: 'Doğru cevapları ve açıklamaları inceleyin',
    en: 'Review the correct answers and explanations',
    es: 'Revisa las respuestas correctas y explicaciones',
    fr: 'Examinez les bonnes réponses et explications',
    ru: 'Ознакомьтесь с правильными ответами и объяснениями'
  },
  'quiz.your_answer': {
    tr: 'Sizin Cevabınız',
    en: 'Your Answer',
    es: 'Su Respuesta',
    fr: 'Votre Réponse',
    ru: 'Ваш ответ'
  },
  'quiz.correct_answer': {
    tr: 'Doğru Cevap',
    en: 'Correct Answer',
    es: 'Respuesta Correcta',
    fr: 'Bonne Réponse',
    ru: 'Правильный ответ'
  },
  'quiz.explanation': {
    tr: 'Açıklama:',
    en: 'Explanation:',
    es: 'Explicación:',
    fr: 'Explication:',
    ru: 'Объяснение:'
  },

  // Badge Titles and Descriptions
  'badge.perfect_expert.title': {
    tr: 'Mükemmel Uzman',
    en: 'Perfect Expert',
    es: 'Experto Perfecto',
    fr: 'Expert Parfait',
    ru: 'Идеальный эксперт'
  },
  'badge.perfect_expert.description': {
    tr: 'Neredeyse tüm soruları doğru cevapladınız!',
    en: 'You answered almost all questions correctly!',
    es: '¡Respondiste casi todas las preguntas correctamente!',
    fr: 'Vous avez répondu correctement à presque toutes les questions!',
    ru: 'Вы ответили правильно почти на все вопросы!'
  },
  'badge.gold_expert.title': {
    tr: 'Altın Uzman',
    en: 'Gold Expert',
    es: 'Experto Dorado',
    fr: 'Expert en Or',
    ru: 'Золотой эксперт'
  },
  'badge.gold_expert.description': {
    tr: 'Çok iyi bir performans sergileydiniz!',
    en: 'You performed very well!',
    es: '¡Tuviste un muy buen desempeño!',
    fr: 'Vous avez très bien performé!',
    ru: 'Вы показали очень хорошие результаты!'
  },
  'badge.silver_expert.title': {
    tr: 'Gümüş Uzman',
    en: 'Silver Expert',
    es: 'Experto Plata',
    fr: 'Expert Argent',
    ru: 'Серебряный эксперт'
  },
  'badge.silver_expert.description': {
    tr: 'İyi bir sonuç elde ettiniz!',
    en: 'You achieved a good result!',
    es: '¡Lograste un buen resultado!',
    fr: 'Vous avez obtenu un bon résultat!',
    ru: 'Вы получили хороший результат!'
  },
  'badge.bronze_expert.title': {
    tr: 'Bronz Uzman',
    en: 'Bronze Expert',
    es: 'Experto Bronce',
    fr: 'Expert Bronze',
    ru: 'Бронзовый эксперт'
  },
  'badge.bronze_expert.description': {
    tr: 'Geçer bir sonuç, daha iyisini yapabilirsiniz!',
    en: 'A passing result, you can do better!',
    es: '¡Un resultado aprobatorio, puedes hacerlo mejor!',
    fr: 'Un résultat passable, vous pouvez faire mieux!',
    ru: 'Проходной результат, вы можете лучше!'
  },
  'quiz.true': {
    tr: 'Doğru',
    en: 'True',
    es: 'Verdadero',
    fr: 'Vrai',
    ru: 'Правда'
  },
  'quiz.false': {
    tr: 'Yanlış',
    en: 'False',
    es: 'Falso',
    fr: 'Faux',
    ru: 'Ложь'
  },
  'quiz.type_answer': {
    tr: 'Cevabınızı buraya yazın...',
    en: 'Type your answer here...',
    es: 'Escribe tu respuesta aquí...',
    fr: 'Tapez votre réponse ici...',
    ru: 'Введите ваш ответ здесь...'
  },
  'quiz.short_answer_hint': {
    tr: 'Kısa ama ayrıntılı bir cevap yazın',
    en: 'Write a short but detailed answer',
    es: 'Escribe una respuesta corta pero detallada',
    fr: 'Écrivez une réponse courte mais détaillée',
    ru: 'Напишите краткий, но подробный ответ'
  }
}

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>('tr')
  const [forceUpdate, setForceUpdate] = useState(0)

  const t = (key: string): string => {
    const translation = translations[key]
    if (!translation) {
      console.warn(`Translation key "${key}" not found`)
      return key
    }
    return translation[language] || translation.tr || key
  }

  const changeLanguage = (lang: Language) => {
    setLanguage(lang)
    setForceUpdate(prev => prev + 1)
  }

  return (
    <LanguageContext.Provider value={{ language, setLanguage: changeLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  )
}

export function useLanguage() {
  const context = useContext(LanguageContext)
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider')
  }
  return context
}