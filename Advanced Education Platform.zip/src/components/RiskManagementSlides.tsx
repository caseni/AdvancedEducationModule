import { Shield, AlertTriangle, Target, TrendingDown, CreditCard, Droplets, Percent, DollarSign, Zap, BarChart3, Umbrella, PieChart, Layers, Users, Activity, Brain, Leaf, Cpu, AlertCircle, Sparkles } from 'lucide-react'

export const riskManagementSlides = [
  {
    title: { 
      tr: 'Risk Yönetimi Nedir?', 
      en: 'What is Risk Management?', 
      es: '¿Qué es la Gestión de Riesgos?', 
      fr: 'Qu\'est-ce que la Gestion des Risques?', 
      ru: 'Что такое управление рисками?' 
    },
    content: { 
      tr: [
        '• Risk yönetimi, gelecekte olabilecek olumsuz sürprizlere karşı hazırlıklı olmaktır.',
        '• Amaç, "kaybedersem ne kadarını göze alabilirim?" sorusuna cevap verip, sermayeyi korumaktır.',
        '• Örneğin; bir yatırımcı, tüm parasını tek bir hisseye koyarsa büyük risk almış olur.',
        '• Ama aynı parayı farklı hisselere, biraz da altına ve dövize bölüştürürse risk azalır.'
      ],
      en: [
        '• Risk management is being prepared for potential negative surprises in the future.',
        '• The goal is to answer "how much can I afford to lose?" and protect capital.',
        '• For example, if an investor puts all money into one stock, they take big risk.',
        '• But if they divide the same money among different stocks, some gold and currency, risk decreases.'
      ],
      es: [
        '• La gestión de riesgos es estar preparado para posibles sorpresas negativas en el futuro.',
        '• El objetivo es responder "¿cuánto puedo permitirme perder?" y proteger el capital.',
        '• Por ejemplo, si un inversor pone todo su dinero en una acción, toma un gran riesgo.',
        '• Pero si divide el mismo dinero entre diferentes acciones, algo de oro y divisas, el riesgo disminuye.'
      ],
      fr: [
        '• La gestion des risques consiste à être préparé aux surprises négatives potentielles à l\'avenir.',
        '• L\'objectif est de répondre à "combien puis-je me permettre de perdre?" et protéger le capital.',
        '• Par exemple, si un investisseur met tout son argent dans une action, il prend un gros risque.',
        '• Mais s\'il divise le même argent entre différentes actions, un peu d\'or et de devises, le risque diminue.'
      ],
      ru: [
        '• Управление рисками - это подготовка к потенциальным негативным сюрпризам в будущем.',
        '• Цель - ответить "сколько я могу позволить себе потерять?" и защитить капитал.',
        '• Например, если инвестор вложит все деньги в одну акцию, он возьмет большой риск.',
        '• Но если он разделит те же деньги между разными акциями, немного золота и валют, риск уменьшится.'
      ]
    },
    example: { 
      tr: '🎯 100.000 TL\'niz varsa hepsini Bitcoin\'e koymak yerine %30 hisse, %30 altın, %40 mevduat yapın.',
      en: '🎯 If you have 100,000 TL, instead of putting it all in Bitcoin, invest 30% stocks, 30% gold, 40% deposits.',
      es: '🎯 Si tienes 100,000 TL, en lugar de ponerlo todo en Bitcoin, invierte 30% acciones, 30% oro, 40% depósitos.',
      fr: '🎯 Si vous avez 100 000 TL, au lieu de tout mettre dans Bitcoin, investissez 30% actions, 30% or, 40% dépôts.',
      ru: '🎯 Если у вас есть 100 000 лир, вместо того чтобы вкладывать все в биткойн, инвестируйте 30% в акции, 30% в золото, 40% в депозиты.'
    },
    icon: <Shield className="w-16 h-16 text-blue-500" />
  },
  {
    title: { 
      tr: 'Finansal Risk Türleri', 
      en: 'Financial Risk Types', 
      es: 'Tipos de Riesgo Financiero', 
      fr: 'Types de Risque Financier', 
      ru: 'Типы финансовых рисков' 
    },
    content: { 
      tr: [
        '• Piyasa riski: Döviz kuru, faiz veya hisse senedi fiyatı değiştiğinde zarar etme ihtimali. (Örn: Dolar düşerse dolar yatırımı zarar görür.)',
        '• Kredi riski: Borç verdiğiniz kişi ödeyemezse yaşanan kayıp. (Örn: Bankanın krediyi geri alamaması.)',
        '• Likidite riski: Elinizdeki varlığı satmak istediğinizde alıcı bulamamak. (Örn: Büyük bir evi acil satmak isteyince hemen müşteri çıkmaması.)',
        '• Operasyonel risk: İnsan hatası, teknik arıza veya siber saldırılar.',
        '• İtibar ve düzenleyici risk: Şirketin yanlış haberlere veya yasalara uymamasına bağlı güven kaybı.'
      ],
      en: [
        '• Market risk: Possibility of loss when currency rates, interest rates or stock prices change. (E.g.: Dollar investment loses if dollar falls.)',
        '• Credit risk: Loss when borrower cannot pay. (E.g.: Bank cannot recover loan.)',
        '• Liquidity risk: Not finding buyers when you want to sell your asset. (E.g.: Not immediately finding customers when urgently wanting to sell a big house.)',
        '• Operational risk: Human error, technical failure or cyber attacks.',
        '• Reputation and regulatory risk: Loss of trust due to company\'s false news or non-compliance with laws.'
      ],
      es: [
        '• Riesgo de mercado: Posibilidad de pérdida cuando cambian tipos de cambio, tasas de interés o precios de acciones. (Ej.: Inversión en dólares pierde si el dólar cae.)',
        '• Riesgo de crédito: Pérdida cuando el prestatario no puede pagar. (Ej.: El banco no puede recuperar el préstamo.)',
        '• Riesgo de liquidez: No encontrar compradores cuando quieres vender tu activo. (Ej.: No encontrar inmediatamente clientes cuando urgentemente quieres vender una casa grande.)',
        '• Riesgo operacional: Error humano, falla técnica o ataques cibernéticos.',
        '• Riesgo de reputación y regulatorio: Pérdida de confianza debido a noticias falsas de la empresa o incumplimiento de leyes.'
      ],
      fr: [
        '• Risque de marché: Possibilité de perte quand changent taux de change, taux d\'intérêt ou prix d\'actions. (Ex.: Investissement en dollars perd si le dollar chute.)',
        '• Risque de crédit: Perte quand l\'emprunteur ne peut pas payer. (Ex.: La banque ne peut pas récupérer le prêt.)',
        '• Risque de liquidité: Ne pas trouver d\'acheteurs quand vous voulez vendre votre actif. (Ex.: Ne pas trouver immédiatement de clients quand vous voulez urgemment vendre une grande maison.)',
        '• Risque opérationnel: Erreur humaine, défaillance technique ou cyberattaques.',
        '• Risque de réputation et réglementaire: Perte de confiance due aux fausses nouvelles de l\'entreprise ou non-conformité aux lois.'
      ],
      ru: [
        '• Рыночный риск: Возможность потерь при изменении валютных курсов, процентных ставок или цен на акции. (Например: инвестиции в доллары теряют, если доллар падает.)',
        '• Кредитный риск: Потери, когда заемщик не может платить. (Например: банк не может вернуть кредит.)',
        '• Риск ликвидности: Неспособность найти покупателей, когда вы хотите продать свой актив. (Например: не найти сразу клиентов, когда срочно хотите продать большой дом.)',
        '• Операционный риск: Человеческая ошибка, техническая неисправность или кибератаки.',
        '• Репутационный и регулятивный риск: Потеря доверия из-за ложных новостей компании или несоблюдения законов.'
      ]
    },
    example: { 
      tr: '💸 2023\'te FTX kripto borsası çöktü - müşteriler paralarını kaybetti. Bu operasyonel risk örneği.',
      en: '💸 In 2023, FTX crypto exchange collapsed - customers lost their money. This is operational risk example.',
      es: '💸 En 2023, el exchange de cripto FTX colapsó - los clientes perdieron su dinero. Este es ejemplo de riesgo operacional.',
      fr: '💸 En 2023, l\'exchange crypto FTX s\'est effondré - les clients ont perdu leur argent. C\'est un exemple de risque opérationnel.',
      ru: '💸 В 2023 году криптобиржа FTX рухнула - клиенты потеряли свои деньги. Это пример операционного риска.'
    },
    icon: <AlertTriangle className="w-16 h-16 text-red-500" />
  },
  {
    title: { 
      tr: 'Risk Ölçüm Yöntemleri', 
      en: 'Risk Measurement Methods', 
      es: 'Métodos de Medición de Riesgos', 
      fr: 'Méthodes de Mesure des Risques', 
      ru: 'Методы измерения рисков' 
    },
    content: { 
      tr: [
        '• Olası Kayıp Tahmini (VaR): "Bir günde en kötü ihtimalle en fazla ne kadar kaybederim?" sorusuna yanıt arar.',
        '• Aşırı Kayıplar (CVaR): Olağanüstü durumlarda ortalama kayıp ne olur?',
        '• Stres Testi: Büyük kriz senaryoları düşünülür: "Borsa %20 düşerse portföy ne hale gelir?"',
        '• Duyarlılık Analizi: Küçük değişikliklerin etkisine bakılır. Örn: Faiz %1 artarsa tahvillerin değeri ne kadar düşer?',
        '• Simülasyon: Binlerce farklı senaryo denenerek olası sonuçlar önceden görülür.'
      ],
      en: [
        '• Value at Risk (VaR): Seeks answer to "What is the maximum I could lose in one day in worst case?"',
        '• Conditional VaR (CVaR): What is the average loss in extraordinary situations?',
        '• Stress Test: Major crisis scenarios are considered: "What happens to portfolio if stock market drops 20%?"',
        '• Sensitivity Analysis: Effects of small changes are examined. E.g.: How much do bond values drop if interest rises 1%?',
        '• Simulation: Possible outcomes are foreseen by trying thousands of different scenarios.'
      ],
      es: [
        '• Valor en Riesgo (VaR): Busca respuesta a "¿Cuál es lo máximo que podría perder en un día en el peor caso?"',
        '• VaR Condicional (CVaR): ¿Cuál es la pérdida promedio en situaciones extraordinarias?',
        '• Prueba de Estrés: Se consideran escenarios de crisis mayores: "¿Qué pasa con la cartera si el mercado de valores cae 20%?"',
        '• Análisis de Sensibilidad: Se examinan efectos de pequeños cambios. Ej.: ¿Cuánto caen los valores de bonos si el interés sube 1%?',
        '• Simulación: Los resultados posibles se prevén probando miles de escenarios diferentes.'
      ],
      fr: [
        '• Valeur à Risque (VaR): Cherche réponse à "Quel est le maximum que je pourrais perdre en un jour dans le pire cas?"',
        '• VaR Conditionnelle (CVaR): Quelle est la perte moyenne dans des situations extraordinaires?',
        '• Test de Stress: Des scénarios de crise majeure sont considérés: "Que se passe-t-il avec le portefeuille si le marché boursier chute de 20%?"',
        '• Analyse de Sensibilité: Les effets de petits changements sont examinés. Ex.: De combien chutent les valeurs d\'obligations si l\'intérêt monte de 1%?',
        '• Simulation: Les résultats possibles sont prévus en essayant des milliers de scénarios différents.'
      ],
      ru: [
        '• Стоимость под Риском (VaR): Ищет ответ на "Максимум сколько я мог бы потерять за один день в худшем случае?"',
        '• Условная VaR (CVaR): Какие средние потери в чрезвычайных ситуациях?',
        '• Стресс-Тест: Рассматриваются сценарии крупных кризисов: "Что происходит с портфелем, если фондовый рынок падает на 20%?"',
        '• Анализ Чувствительности: Изучаются эффекты небольших изменений. Например: На сколько падают стоимости облигаций, если процент поднимается на 1%?',
        '• Симуляция: Возможные результаты предвидятся испытанием тысяч различных сценариев.'
      ]
    },
    example: { 
      tr: '📊 Portföyünüz 1 milyon TL ise, VaR hesabı "günlük en fazla 50.000 TL kaybedebilirsiniz" der.',
      en: '📊 If your portfolio is 1 million TL, VaR calculation says "you could lose maximum 50,000 TL daily".',
      es: '📊 Si tu cartera es 1 millón TL, el cálculo VaR dice "podrías perder máximo 50,000 TL diariamente".',
      fr: '📊 Si votre portefeuille est de 1 million TL, le calcul VaR dit "vous pourriez perdre maximum 50 000 TL quotidiennement".',
      ru: '📊 Если ваш портфель составляет 1 миллион лир, расчет VaR говорит "вы можете потерять максимум 50 000 лир ежедневно".'
    },
    icon: <BarChart3 className="w-16 h-16 text-blue-500" />
  },
  {
    title: { 
      tr: 'Portföyde Risk Yönetimi', 
      en: 'Portfolio Risk Management', 
      es: 'Gestión de Riesgo de Cartera', 
      fr: 'Gestion des Risques de Portefeuille', 
      ru: 'Управление рисками портфеля' 
    },
    content: { 
      tr: [
        '• Çeşitlendirme: "Tüm yumurtaları tek sepete koyma" mantığıdır.',
        '• Düzenli gözden geçirme: Piyasa değiştikçe portföy güncellenir.',
        '• Risk toleransı: Bazı yatırımcı yüksek risk sever, bazıları ise istikrarlı getiriyi. Bu dengeye göre dağılım yapılır.',
        '• Korelasyon takibi: Altın yükselirken borsa düşüyorsa, bu ilişkiyi bilerek risk azaltılabilir.'
      ],
      en: [
        '• Diversification: "Don\'t put all eggs in one basket" logic.',
        '• Regular review: Portfolio is updated as market changes.',
        '• Risk tolerance: Some investors like high risk, others prefer stable returns. Distribution is made according to this balance.',
        '• Correlation tracking: If gold rises while stock market falls, knowing this relationship can reduce risk.'
      ],
      es: [
        '• Diversificación: Lógica de "no pongas todos los huevos en una canasta".',
        '• Revisión regular: La cartera se actualiza cuando cambia el mercado.',
        '• Tolerancia al riesgo: Algunos inversores gustan del alto riesgo, otros prefieren retornos estables. La distribución se hace según este equilibrio.',
        '• Seguimiento de correlación: Si el oro sube mientras cae el mercado de valores, conocer esta relación puede reducir el riesgo.'
      ],
      fr: [
        '• Diversification: Logique "ne mettez pas tous les œufs dans le même panier".',
        '• Révision régulière: Le portefeuille est mis à jour quand le marché change.',
        '• Tolérance au risque: Certains investisseurs aiment le risque élevé, d\'autres préfèrent des rendements stables. La distribution se fait selon cet équilibre.',
        '• Suivi de corrélation: Si l\'or monte pendant que le marché boursier chute, connaître cette relation peut réduire le risque.'
      ],
      ru: [
        '• Диверсификация: Логика "не клади все яйца в одну корзину".',
        '• Регулярный пересмотр: Портфель обновляется по мере изменения рынка.',
        '• Толерантность к риску: Некоторые инвесторы любят высокий риск, другие предпочитают стабильную доходность. Распределение делается согласно этому балансу.',
        '• Отслеживание корреляции: Если золото растет, пока фондовый рынок падает, знание этой взаимосвязи может снизить риск.'
      ]
    },
    example: { 
      tr: '🎯 Yaşı 30 olan genç yatırımcı %70 hisse alabilir, 60 yaşında ise %30 hisse yeterli.',
      en: '🎯 Young investor aged 30 can buy 70% stocks, at 60 years old 30% stocks is enough.',
      es: '🎯 Joven inversor de 30 años puede comprar 70% acciones, a los 60 años 30% acciones es suficiente.',
      fr: '🎯 Jeune investisseur de 30 ans peut acheter 70% d\'actions, à 60 ans 30% d\'actions suffit.',
      ru: '🎯 Молодой инвестор в 30 лет может покупать 70% акций, в 60 лет достаточно 30% акций.'
    },
    icon: <PieChart className="w-16 h-16 text-green-500" />
  },
  {
    title: { 
      tr: 'Korunma (Hedging) Yöntemleri', 
      en: 'Hedging Methods', 
      es: 'Métodos de Cobertura', 
      fr: 'Méthodes de Couverture', 
      ru: 'Методы хеджирования' 
    },
    content: { 
      tr: [
        '• Vadeli işlemler: Bugünden gelecekteki fiyatı kilitlemek. (Örn: Çiftçi, buğdayı hasattan önce belirli fiyattan satma anlaşması yapar.)',
        '• Opsiyonlar: İstendiğinde alma/satma hakkı tanır. (Örn: "Bu hisse düşerse bile ben zarar etmeyeceğim" gibi bir sigorta.)',
        '• Swap anlaşmaları: Faiz veya döviz riskini dengelemek için değiş-tokuş yapılır.',
        '• Doğal korunma: Gelir ve gideri aynı para biriminde tutmak gibi basit çözümler.'
      ],
      en: [
        '• Futures contracts: Locking future price from today. (E.g.: Farmer makes agreement to sell wheat at specific price before harvest.)',
        '• Options: Give right to buy/sell when desired. (E.g.: Like insurance "even if this stock falls, I won\'t lose".)',
        '• Swap agreements: Exchange is made to balance interest or currency risk.',
        '• Natural hedging: Simple solutions like keeping income and expenses in same currency.'
      ],
      es: [
        '• Contratos de futuros: Bloquear precio futuro desde hoy. (Ej.: Agricultor hace acuerdo para vender trigo a precio específico antes de cosecha.)',
        '• Opciones: Dan derecho a comprar/vender cuando se desee. (Ej.: Como seguro "aunque esta acción caiga, no perderé".)',
        '• Acuerdos de swap: Se hace intercambio para equilibrar riesgo de interés o divisa.',
        '• Cobertura natural: Soluciones simples como mantener ingresos y gastos en misma moneda.'
      ],
      fr: [
        '• Contrats à terme: Verrouiller le prix futur dès aujourd\'hui. (Ex.: L\'agriculteur fait accord pour vendre blé à prix spécifique avant récolte.)',
        '• Options: Donnent droit d\'acheter/vendre quand désiré. (Ex.: Comme assurance "même si cette action tombe, je ne perdrai pas".)',
        '• Accords de swap: L\'échange est fait pour équilibrer risque d\'intérêt ou de devise.',
        '• Couverture naturelle: Solutions simples comme garder revenus et dépenses dans même devise.'
      ],
      ru: [
        '• Фьючерсные контракты: Блокировка будущей цены с сегодняшнего дня. (Например: Фермер заключает соглашение продать пшеницу по определенной цене до урожая.)',
        '• Опционы: Дают право покупать/продавать по желанию. (Например: Как страховка "даже если эта акция упадет, я не потеряю".)',
        '• Своп-соглашения: Производится обмен для балансировки процентного или валютного риска.',
        '• Естественное хеджирование: Простые решения, такие как содержание доходов и расходов в одной валюте.'
      ]
    },
    example: { 
      tr: '✈️ Havayolu şirketi yakıt fiyatı yükselmesin diye önceden satın alma anlaşması yapar.',
      en: '✈️ Airline company makes advance purchase agreement so fuel prices don\'t rise.',
      es: '✈️ Compañía aérea hace acuerdo de compra anticipada para que no suban precios de combustible.',
      fr: '✈️ Compagnie aérienne fait accord d\'achat à l\'avance pour que les prix du carburant ne montent pas.',
      ru: '✈️ Авиакомпания заключает соглашение о предварительной покупке, чтобы цены на топливо не росли.'
    },
    icon: <Umbrella className="w-16 h-16 text-purple-500" />
  },
  {
    title: { 
      tr: 'Operasyonel Risk Yönetimi', 
      en: 'Operational Risk Management', 
      es: 'Gestión de Riesgo Operacional', 
      fr: 'Gestion du Risque Opérationnel', 
      ru: 'Управление операционными рисками' 
    },
    content: { 
      tr: [
        '• İş süreçleri net kurallarla yönetilir.',
        '• Siber güvenlik ve veri yedekleme olmazsa olmazdır.',
        '• Çalışanlara düzenli eğitim verilerek hata oranı azaltılır.',
        '• Kriz anları için "acil durum planı" hazır tutulur. (Örn: Deprem sonrası yedek ofis planı.)'
      ],
      en: [
        '• Business processes are managed with clear rules.',
        '• Cyber security and data backup are essential.',
        '• Error rate is reduced by giving regular training to employees.',
        '• "Emergency plan" is kept ready for crisis moments. (E.g.: Backup office plan after earthquake.)'
      ],
      es: [
        '• Los procesos empresariales se gestionan con reglas claras.',
        '• La ciberseguridad y respaldo de datos son esenciales.',
        '• La tasa de error se reduce dando entrenamiento regular a empleados.',
        '• "Plan de emergencia" se mantiene listo para momentos de crisis. (Ej.: Plan de oficina de respaldo después de terremoto.)'
      ],
      fr: [
        '• Les processus métier sont gérés avec des règles claires.',
        '• La cybersécurité et sauvegarde de données sont essentielles.',
        '• Le taux d\'erreur est réduit en donnant formation régulière aux employés.',
        '• "Plan d\'urgence" est gardé prêt pour moments de crise. (Ex.: Plan de bureau de secours après tremblement de terre.)'
      ],
      ru: [
        '• Бизнес-процессы управляются четкими правилами.',
        '• Кибербезопасность и резервное копирование данных - это необходимость.',
        '• Уровень ошибок снижается регулярным обучением сотрудников.',
        '• "План действий в чрезвычайных ситуациях" держится наготове для кризисных моментов. (Например: план резервного офиса после землетрясения.)'
      ]
    },
    example: { 
      tr: '💻 Banka sistemleri hacklenirse 1 saat içinde yedek sistemler devreye girer.',
      en: '💻 If bank systems are hacked, backup systems activate within 1 hour.',
      es: '💻 Si los sistemas bancarios son hackeados, los sistemas de respaldo se activan en 1 hora.',
      fr: '💻 Si les systèmes bancaires sont piratés, les systèmes de sauvegarde s\'activent en 1 heure.',
      ru: '💻 Если банковские системы взломаны, резервные системы активируются в течение 1 часа.'
    },
    icon: <Zap className="w-16 h-16 text-orange-500" />
  },
  {
    title: { 
      tr: 'Düzenleyici Uyum', 
      en: 'Regulatory Compliance', 
      es: 'Cumplimiento Regulatorio', 
      fr: 'Conformité Réglementaire', 
      ru: 'Соблюдение требований регулятора' 
    },
    content: { 
      tr: [
        '• Banka ve şirketler, uluslararası kurallara uyar.',
        '• Müşteri kimlik doğrulama (KYC) ve kara para aklamayı önleme (AML) kontrolleri yapılır.',
        '• Kişisel veriler güvenle saklanır, aksi halde ağır cezalar gelir.'
      ],
      en: [
        '• Banks and companies comply with international rules.',
        '• Customer identity verification (KYC) and anti-money laundering (AML) controls are performed.',
        '• Personal data is stored securely, otherwise heavy penalties come.'
      ],
      es: [
        '• Bancos y empresas cumplen con reglas internacionales.',
        '• Se realizan controles de verificación de identidad del cliente (KYC) y antilavado de dinero (AML).',
        '• Los datos personales se almacenan de forma segura, de lo contrario vienen penalidades severas.'
      ],
      fr: [
        '• Banques et entreprises respectent les règles internationales.',
        '• Des contrôles de vérification d\'identité client (KYC) et anti-blanchiment (AML) sont effectués.',
        '• Les données personnelles sont stockées en sécurité, sinon de lourdes pénalités arrivent.'
      ],
      ru: [
        '• Банки и компании соблюдают международные правила.',
        '• Проводятся проверки идентификации клиентов (KYC) и противодействия отмыванию денег (AML).',
        '• Персональные данные хранятся безопасно, иначе следуют тяжелые штрафы.'
      ]
    },
    example: { 
      tr: '🏛️ Avrupa GDPR kurallarına uymayan şirketlere yılda milyonlarca euro ceza kesiliyor.',
      en: '🏛️ Companies not complying with European GDPR rules are fined millions of euros annually.',
      es: '🏛️ Empresas que no cumplen con reglas GDPR europeas son multadas millones de euros anualmente.',
      fr: '🏛️ Entreprises ne respectant pas les règles GDPR européennes sont amendées de millions d\'euros annuellement.',
      ru: '🏛️ Компании, не соблюдающие европейские правила GDPR, штрафуются на миллионы евро ежегодно.'
    },
    icon: <Users className="w-16 h-16 text-blue-600" />
  },
  {
    title: { 
      tr: 'Çevresel, Sosyal ve Yönetişim (ESG) Riskleri', 
      en: 'Environmental, Social and Governance (ESG) Risks', 
      es: 'Riesgos Ambientales, Sociales y de Gobernanza (ESG)', 
      fr: 'Risques Environnementaux, Sociaux et de Gouvernance (ESG)', 
      ru: 'Экологические, социальные риски и риски управления (ESG)' 
    },
    content: { 
      tr: [
        '• İklim değişikliği şirketin işini etkileyebilir.',
        '• Çalışan hakları, çeşitlilik ve şeffaflık artık yatırımcıların önem verdiği konular.',
        '• Bu kriterlere uyan şirketler uzun vadede daha güvenilir görülür.'
      ],
      en: [
        '• Climate change can affect company\'s business.',
        '• Employee rights, diversity and transparency are now topics investors care about.',
        '• Companies meeting these criteria are seen as more reliable in long term.'
      ],
      es: [
        '• El cambio climático puede afectar el negocio de la empresa.',
        '• Derechos de empleados, diversidad y transparencia son ahora temas que importan a los inversores.',
        '• Empresas que cumplen estos criterios se ven como más confiables a largo plazo.'
      ],
      fr: [
        '• Le changement climatique peut affecter les affaires de l\'entreprise.',
        '• Droits des employés, diversité et transparence sont maintenant des sujets qui importent aux investisseurs.',
        '• Entreprises répondant à ces critères sont vues comme plus fiables à long terme.'
      ],
      ru: [
        '• Изменение климата может повлиять на бизнес компании.',
        '• Права сотрудников, разнообразие и прозрачность теперь темы, которые важны инвесторам.',
        '• Компании, соответствующие этим критериям, рассматриваются как более надежные в долгосрочной перспективе.'
      ]
    },
    example: { 
      tr: '🌱 Volkswagen emisyon skandalından sonra %30 değer kaybetti - ESG riski gerçekleşti.',
      en: '🌱 Volkswagen lost 30% value after emission scandal - ESG risk materialized.',
      es: '🌱 Volkswagen perdió 30% de valor después del escándalo de emisiones - riesgo ESG se materializó.',
      fr: '🌱 Volkswagen a perdu 30% de valeur après le scandale des émissions - risque ESG s\'est matérialisé.',
      ru: '🌱 Volkswagen потерял 30% стоимости после скандала с выбросами - ESG риск материализовался.'
    },
    icon: <Leaf className="w-16 h-16 text-green-600" />
  },
  {
    title: { 
      tr: 'Teknolojinin Rolü', 
      en: 'Role of Technology', 
      es: 'Papel de la Tecnología', 
      fr: 'Rôle de la Technologie', 
      ru: 'Роль технологий' 
    },
    content: { 
      tr: [
        '• Yapay zeka: Milyonlarca veriyi işleyerek risk sinyallerini erken yakalar.',
        '• Büyük veri: Anlık piyasa değişimlerini analiz eder.',
        '• Blockchain: Şeffaf ve güvenli kayıt tutar.',
        '• Otomatik raporlama: İnsan hatasını azaltır, hız kazandırır.'
      ],
      en: [
        '• Artificial intelligence: Catches risk signals early by processing millions of data.',
        '• Big data: Analyzes instant market changes.',
        '• Blockchain: Keeps transparent and secure records.',
        '• Automatic reporting: Reduces human error, gains speed.'
      ],
      es: [
        '• Inteligencia artificial: Captura señales de riesgo temprano procesando millones de datos.',
        '• Big data: Analiza cambios instantáneos del mercado.',
        '• Blockchain: Mantiene registros transparentes y seguros.',
        '• Reporte automático: Reduce error humano, gana velocidad.'
      ],
      fr: [
        '• Intelligence artificielle: Capture les signaux de risque tôt en traitant des millions de données.',
        '• Big data: Analyse les changements instantanés du marché.',
        '• Blockchain: Tient des registres transparents et sécurisés.',
        '• Rapport automatique: Réduit l\'erreur humaine, gagne en vitesse.'
      ],
      ru: [
        '• Искусственный интеллект: Рано улавливает сигналы риска, обрабатывая миллионы данных.',
        '• Большие данные: Анализирует мгновенные изменения рынка.',
        '• Блокчейн: Ведет прозрачные и безопасные записи.',
        '• Автоматическая отчетность: Снижает человеческие ошибки, добавляет скорость.'
      ]
    },
    example: { 
      tr: '🤖 JPMorgan yapay zeka ile kredi riskini %40 daha hızlı hesaplıyor.',
      en: '🤖 JPMorgan calculates credit risk 40% faster with artificial intelligence.',
      es: '🤖 JPMorgan calcula riesgo de crédito 40% más rápido con inteligencia artificial.',
      fr: '🤖 JPMorgan calcule le risque de crédit 40% plus vite avec intelligence artificielle.',
      ru: '🤖 JPMorgan рассчитывает кредитный риск на 40% быстрее с искусственным интеллектом.'
    },
    icon: <Cpu className="w-16 h-16 text-cyan-500" />
  },
  {
    title: { 
      tr: 'Gelecek Trendler', 
      en: 'Future Trends', 
      es: 'Tendencias Futuras', 
      fr: 'Tendances Futures', 
      ru: 'Будущие тренды' 
    },
    content: { 
      tr: [
        '• İklim değişikliği ve yeşil ekonomi daha çok konuşulacak.',
        '• Riskler anlık olarak takip edilip hemen aksiyon alınacak.',
        '• Yatırımcı psikolojisi dikkate alınarak daha gerçekçi analizler yapılacak.',
        '• Yeni teknolojiler (ör. kuantum bilgisayarlar) risk hesaplarını çok daha hızlı yapacak.'
      ],
      en: [
        '• Climate change and green economy will be discussed more.',
        '• Risks will be tracked instantly and immediate action will be taken.',
        '• More realistic analyses will be made considering investor psychology.',
        '• New technologies (e.g. quantum computers) will make risk calculations much faster.'
      ],
      es: [
        '• Cambio climático y economía verde se discutirán más.',
        '• Los riesgos se rastrearán instantáneamente y se tomará acción inmediata.',
        '• Se harán análisis más realistas considerando psicología del inversor.',
        '• Nuevas tecnologías (ej. computadoras cuánticas) harán cálculos de riesgo mucho más rápidos.'
      ],
      fr: [
        '• Changement climatique et économie verte seront plus discutés.',
        '• Les risques seront suivis instantanément et action immédiate sera prise.',
        '• Analyses plus réalistes seront faites en considérant psychologie de l\'investisseur.',
        '• Nouvelles technologies (ex. ordinateurs quantiques) feront calculs de risque beaucoup plus vite.'
      ],
      ru: [
        '• Изменение климата и зеленая экономика будут обсуждаться больше.',
        '• Риски будут отслеживаться мгновенно и будут приняты немедленные действия.',
        '• Будут делаться более реалистичные анализы с учетом психологии инвестора.',
        '• Новые технологии (например, квантовые компьютеры) будут делать расчеты рисков намного быстрее.'
      ]
    },
    example: { 
      tr: '🚀 2030\'da kuantum bilgisayarlar 1 saniyede binlerce risk senaryosu hesaplayabilecek.',
      en: '🚀 By 2030, quantum computers will be able to calculate thousands of risk scenarios in 1 second.',
      es: '🚀 Para 2030, computadoras cuánticas podrán calcular miles de escenarios de riesgo en 1 segundo.',
      fr: '🚀 D\'ici 2030, ordinateurs quantiques pourront calculer des milliers de scénarios de risque en 1 seconde.',
      ru: '🚀 К 2030 году квантовые компьютеры смогут рассчитать тысячи сценариев риска за 1 секунду.'
    },
    icon: <Sparkles className="w-16 h-16 text-purple-600" />
  }
]

// Risk Management Quiz
export const riskManagementQuiz = [
  {
    question: {
      tr: 'Risk yönetiminin temel amacı nedir?',
      en: 'What is the main purpose of risk management?',
      es: '¿Cuál es el propósito principal de la gestión de riesgos?',
      fr: 'Quel est l\'objectif principal de la gestion des risques?',
      ru: 'Какова основная цель управления рисками?'
    },
    options: {
      tr: ['Sadece yüksek kazanç sağlamak', 'Sermaye korunması ve getiri optimizasyonu', 'Piyasa trendlerini tahmin etmek', 'Yatırımcıları bilgilendirmek'],
      en: ['Only ensuring high profits', 'Capital preservation and return optimization', 'Predicting market trends', 'Informing investors'],
      es: ['Solo asegurar altas ganancias', 'Preservación de capital y optimización de retorno', 'Predecir tendencias del mercado', 'Informar inversores'],
      fr: ['Seulement assurer des profits élevés', 'Préservation du capital et optimisation du rendement', 'Prédire tendances marché', 'Informer investisseurs'],
      ru: ['Только обеспечение высокой прибыли', 'Сохранение капитала и оптимизация доходности', 'Прогнозирование рыночных трендов', 'Информирование инвесторов']
    },
    correct: 1
  },
  {
    question: {
      tr: 'Piyasa riski hangi durumu kapsamaz?',
      en: 'Which situation does market risk not cover?',
      es: '¿Qué situación no cubre el riesgo de mercado?',
      fr: 'Quelle situation ne couvre pas le risque de marché?',
      ru: 'Какую ситуацию не покрывает рыночный риск?'
    },
    options: {
      tr: ['Hisse senedi fiyat dalgalanmaları', 'Faiz oranı değişiklikleri', 'İnsan hataları', 'Döviz kuru dalgalanmaları'],
      en: ['Stock price fluctuations', 'Interest rate changes', 'Human errors', 'Exchange rate fluctuations'],
      es: ['Fluctuaciones precio acciones', 'Cambios tasa interés', 'Errores humanos', 'Fluctuaciones tipo cambio'],
      fr: ['Fluctuations prix actions', 'Changements taux intérêt', 'Erreurs humaines', 'Fluctuations taux change'],
      ru: ['Колебания цен акций', 'Изменения процентных ставок', 'Человеческие ошибки', 'Колебания валютных курсов']
    },
    correct: 2
  },
  {
    question: {
      tr: 'Kredi riskleri yalnızca müşterilerin temerrüt etme olasılığı ile ilgilidir.',
      en: 'Credit risks are only related to the probability of customer default.',
      es: 'Los riesgos crediticios solo están relacionados con la probabilidad de incumplimiento del cliente.',
      fr: 'Les risques de crédit ne concernent que la probabilité de défaut du client.',
      ru: 'Кредитные риски связаны только с вероятностью дефолта клиента.'
    },
    type: 'true_false',
    correct: false,
    explanation: {
      tr: 'Kredi riskleri temerrüt riski, kredi konsantrasyonu riski, karşı taraf riski ve kredi derecelendirmesi değişim riskini de kapsar.',
      en: 'Credit risks also include concentration risk, counterparty risk, and credit rating change risk.',
      es: 'Los riesgos crediticios también incluyen riesgo de concentración, riesgo de contraparte y riesgo de cambio de calificación.',
      fr: 'Les risques de crédit incluent aussi risque de concentration, risque de contrepartie et risque de changement de notation.',
      ru: 'Кредитные риски также включают риск концентрации, риск контрагента и риск изменения кредитного рейтинга.'
    }
  },
  {
    question: {
      tr: 'Value at Risk (VaR) neyi ölçer?',
      en: 'What does Value at Risk (VaR) measure?',
      es: '¿Qué mide el Valor en Riesgo (VaR)?',
      fr: 'Que mesure la Valeur à Risque (VaR)?',
      ru: 'Что измеряет стоимость под риском (VaR)?'
    },
    options: {
      tr: ['Portföyün ortalama getirisi', 'Belirli bir güven aralığında maksimum potansiyel kayıp', 'Likidite oranlarını', 'Sadece hisse senedi riskini'],
      en: ['Portfolio average return', 'Maximum potential loss within a confidence interval', 'Liquidity ratios', 'Only stock risk'],
      es: ['Retorno promedio cartera', 'Pérdida potencial máxima dentro intervalo confianza', 'Ratios liquidez', 'Solo riesgo acciones'],
      fr: ['Rendement moyen portefeuille', 'Perte potentielle maximale dans intervalle confiance', 'Ratios liquidité', 'Seulement risque actions'],
      ru: ['Средняя доходность портфеля', 'Максимальная потенциальная потеря в доверительном интервале', 'Коэффициенты ликвидности', 'Только риск акций']
    },
    correct: 1
  },
  {
    question: {
      tr: 'Conditional VaR (CVaR) hangi durumu ölçer?',
      en: 'What does Conditional VaR (CVaR) measure?',
      es: '¿Qué mide el VaR Condicional (CVaR)?',
      fr: 'Que mesure le VaR Conditionnel (CVaR)?',
      ru: 'Что измеряет условный VaR (CVaR)?'
    },
    options: {
      tr: ['Ortalama portföy getirisi', 'VaR seviyesini aşan kayıpların ortalaması', 'Günlük volatilite', 'Faiz riski'],
      en: ['Average portfolio return', 'Average of losses exceeding VaR level', 'Daily volatility', 'Interest rate risk'],
      es: ['Retorno promedio cartera', 'Promedio pérdidas que exceden nivel VaR', 'Volatilidad diaria', 'Riesgo tasa interés'],
      fr: ['Rendement moyen portefeuille', 'Moyenne pertes dépassant niveau VaR', 'Volatilité quotidienne', 'Risque taux intérêt'],
      ru: ['Средняя доходность портфеля', 'Среднее потерь, превышающих уровень VaR', 'Дневная волатильность', 'Процентный риск']
    },
    correct: 1
  },
  {
    question: {
      tr: 'Stress testing nedir ve neden önemlidir?',
      en: 'What is stress testing and why is it important?',
      es: '¿Qué es el testing de estrés y por qué es importante?',
      fr: 'Qu\'est-ce que le test de stress et pourquoi est-il important?',
      ru: 'Что такое стресс-тестирование и почему оно важно?'
    },
    type: 'short_answer',
    correct_answer: {
      tr: 'Aşırı piyasa koşullarında portföy performansını test etme yöntemidir; kriz senaryolarına hazırlık sağlar.',
      en: 'Method to test portfolio performance under extreme market conditions; provides preparation for crisis scenarios.',
      es: 'Método para probar rendimiento cartera bajo condiciones extremas mercado; proporciona preparación para escenarios crisis.',
      fr: 'Méthode pour tester performance portefeuille sous conditions marché extrêmes; fournit préparation pour scénarios crise.',
      ru: 'Метод тестирования производительности портфеля в экстремальных рыночных условиях; обеспечивает подготовку к кризисным сценариям.'
    }
  },
  {
    question: {
      tr: 'Portföy diversifikasyonu neden önemlidir?',
      en: 'Why is portfolio diversification important?',
      es: '¿Por qué es importante la diversificación de cartera?',
      fr: 'Pourquoi la diversification de portefeuille est-elle importante?',
      ru: 'Почему важна диверсификация портфеля?'
    },
    options: {
      tr: ['Sadece hisse senedi alımını optimize eder', 'Riskleri farklı varlıklar arasında yayarak azaltır', 'Likiditeyi düşürür', 'Getiriyi garanti eder'],
      en: ['Only optimizes stock purchases', 'Reduces risks by spreading across different assets', 'Reduces liquidity', 'Guarantees returns'],
      es: ['Solo optimiza compras acciones', 'Reduce riesgos distribuyendo entre diferentes activos', 'Reduce liquidez', 'Garantiza retornos'],
      fr: ['Optimise seulement achats actions', 'Réduit risques en répartissant entre différents actifs', 'Réduit liquidité', 'Garantit rendements'],
      ru: ['Только оптимизирует покупки акций', 'Снижает риски, распределяя по разным активам', 'Снижает ликвидность', 'Гарантирует доходность']
    },
    correct: 1
  },
  {
    question: {
      tr: 'Hedging stratejilerinde "protective put" ne sağlar?',
      en: 'What does "protective put" provide in hedging strategies?',
      es: '¿Qué proporciona "protective put" en estrategias de cobertura?',
      fr: 'Que fournit "protective put" dans stratégies de couverture?',
      ru: 'Что обеспечивает "защитный пут" в стратегиях хеджирования?'
    },
    options: {
      tr: ['Yukarı yönlü kazanç', 'Aşağı yönlü kayıptan korunma', 'Likidite artışı', 'Volatilite düşüşü'],
      en: ['Upside gains', 'Downside loss protection', 'Liquidity increase', 'Volatility decrease'],
      es: ['Ganancias alcistas', 'Protección pérdidas bajistas', 'Aumento liquidez', 'Disminución volatilidad'],
      fr: ['Gains haussiers', 'Protection pertes baissières', 'Augmentation liquidité', 'Diminution volatilité'],
      ru: ['Восходящие прибыли', 'Защита от нисходящих потерь', 'Увеличение ликвидности', 'Снижение волатильности']
    },
    correct: 1
  },
  {
    question: {
      tr: 'Swap anlaşmaları yalnızca faiz oranı değişimlerini kapsar.',
      en: 'Swap agreements only cover interest rate exchanges.',
      es: 'Los acuerdos swap solo cubren intercambios de tasas de interés.',
      fr: 'Les accords swap ne couvrent que les échanges de taux d\'intérêt.',
      ru: 'Своп-соглашения охватывают только обмен процентными ставками.'
    },
    type: 'true_false',
    correct: false,
    explanation: {
      tr: 'Swap anlaşmaları faiz oranı, döviz kuru, emtia fiyatları, kredi riski ve diğer finansal değişkenleri kapsar.',
      en: 'Swap agreements cover interest rates, exchange rates, commodity prices, credit risk and other financial variables.',
      es: 'Los acuerdos swap cubren tasas de interés, tipos de cambio, precios materias primas, riesgo crédito y otras variables financieras.',
      fr: 'Les accords swap couvrent taux intérêt, taux change, prix matières premières, risque crédit et autres variables financières.',
      ru: 'Своп-соглашения охватывают процентные ставки, валютные курсы, цены на товары, кредитный риск и другие финансовые переменные.'
    }
  },
  {
    question: {
      tr: 'Operasyonel risk kaynakları arasında hangisi bulunmaz?',
      en: 'Which is not among operational risk sources?',
      es: '¿Cuál no está entre las fuentes de riesgo operacional?',
      fr: 'Lequel n\'est pas parmi les sources de risque opérationnel?',
      ru: 'Что не является источником операционного риска?'
    },
    options: {
      tr: ['İnsan hataları', 'Sistem arızaları', 'Döviz kuru değişimi', 'Doğal afetler'],
      en: ['Human errors', 'System failures', 'Exchange rate changes', 'Natural disasters'],
      es: ['Errores humanos', 'Fallas sistema', 'Cambios tipo cambio', 'Desastres naturales'],
      fr: ['Erreurs humaines', 'Pannes système', 'Changements taux change', 'Catastrophes naturelles'],
      ru: ['Человеческие ошибки', 'Системные сбои', 'Изменения валютного курса', 'Стихийные бедствия']
    },
    correct: 2
  },
  {
    question: {
      tr: 'Basel III çerçevesinde hangi gösterge sermaye yeterliliğini ölçer?',
      en: 'Which indicator measures capital adequacy in Basel III framework?',
      es: '¿Qué indicador mide la suficiencia de capital en el marco Basel III?',
      fr: 'Quel indicateur mesure l\'adéquation du capital dans le cadre Bâle III?',
      ru: 'Какой показатель измеряет достаточность капитала в рамках Ба��ель III?'
    },
    options: {
      tr: ['VaR', 'LCR (Liquidity Coverage Ratio)', 'RSI', 'Sharpe Oranı'],
      en: ['VaR', 'LCR (Liquidity Coverage Ratio)', 'RSI', 'Sharpe Ratio'],
      es: ['VaR', 'LCR (Ratio Cobertura Liquidez)', 'RSI', 'Ratio Sharpe'],
      fr: ['VaR', 'LCR (Ratio Couverture Liquidité)', 'RSI', 'Ratio Sharpe'],
      ru: ['VaR', 'LCR (Коэффициент покрытия ликвидности)', 'RSI', 'Коэффициент Шарпа']
    },
    correct: 1
  },
  {
    question: {
      tr: 'ESG risk yönetimi neden önemlidir?',
      en: 'Why is ESG risk management important?',
      es: '¿Por qué es importante la gestión de riesgos ESG?',
      fr: 'Pourquoi la gestion des risques ESG est-elle importante?',
      ru: 'Почему важно управление ESG-рисками?'
    },
    type: 'short_answer',
    correct_answer: {
      tr: 'Çevresel, sosyal ve yönetişim faktörlerinin yatırım performansı ve kurumsal sürdürülebilirlik üzerindeki etkilerini yönetmek için önemlidir.',
      en: 'Important for managing the impact of environmental, social and governance factors on investment performance and corporate sustainability.',
      es: 'Importante para gestionar impacto de factores ambientales, sociales y gobernanza en rendimiento inversión y sostenibilidad corporativa.',
      fr: 'Important pour gérer impact facteurs environnementaux, sociaux et gouvernance sur performance investissement et durabilité corporate.',
      ru: 'Важно для управления влиянием экологических, социальных факторов и факторов управления на инвестиционную производительность и корпоративную устойчивость.'
    }
  },
  {
    question: {
      tr: 'AI ve Big Data risk yönetiminde hangi alanlarda kullanılır?',
      en: 'In which areas are AI and Big Data used in risk management?',
      es: '¿En qué áreas se usan AI y Big Data en gestión de riesgos?',
      fr: 'Dans quels domaines l\'IA et Big Data sont-ils utilisés dans gestion des risques?',
      ru: 'В каких областях используются ИИ и большие данные в управлении рисками?'
    },
    options: {
      tr: ['Pattern recognition, anomaly detection, predictive analytics', 'Sadece manuel raporlama', 'Sadece finansal tablolarda', 'Pazarlama stratejilerinde'],
      en: ['Pattern recognition, anomaly detection, predictive analytics', 'Only manual reporting', 'Only in financial statements', 'In marketing strategies'],
      es: ['Reconocimiento patrones, detección anomalías, análisis predictivo', 'Solo reportes manuales', 'Solo estados financieros', 'Estrategias marketing'],
      fr: ['Reconnaissance motifs, détection anomalies, analyses prédictives', 'Seulement rapports manuels', 'Seulement états financiers', 'Stratégies marketing'],
      ru: ['Распознавание паттернов, обнаружение аномалий, прогнозная аналитика', 'Только ручная отчетность', 'Только в финансовых отчетах', 'В маркетинговых стратегиях']
    },
    correct: 0
  },
  {
    question: {
      tr: 'Risk yönetiminde quantum computing gelecekte portföy optimizasyonunu hızlandırabilir.',
      en: 'In risk management, quantum computing can accelerate portfolio optimization in the future.',
      es: 'En gestión de riesgos, computación cuántica puede acelerar optimización cartera en futuro.',
      fr: 'Dans gestion risques, informatique quantique peut accélérer optimisation portefeuille dans futur.',
      ru: 'В управлении рисками квантовые вычисления могут ускорить оптимизацию портфеля в будущем.'
    },
    type: 'true_false',
    correct: true,
    explanation: {
      tr: 'Quantum computing karmaşık portföy optimizasyonu hesaplamalarını çok daha hızlı gerçekleştirebilir ve risk senaryolarını anlık analiz edebilir.',
      en: 'Quantum computing can perform complex portfolio optimization calculations much faster and analyze risk scenarios instantly.',
      es: 'Computación cuántica puede realizar cálculos optimización cartera complejos mucho más rápido y analizar escenarios riesgo instantáneamente.',
      fr: 'Informatique quantique peut effectuer calculs optimisation portefeuille complexes beaucoup plus vite et analyser scénarios risque instantanément.',
      ru: 'Квантовые вычисления могут выполнять сложные расчеты оптимизации портфеля намного быстрее и мгновенно анализировать сценарии рисков.'
    }
  },
  {
    question: {
      tr: 'Dynamic hedging stratejisi neye göre ayarlanır?',
      en: 'How is dynamic hedging strategy adjusted?',
      es: '¿Cómo se ajusta la estrategia de cobertura dinámica?',
      fr: 'Comment la stratégie de couverture dynamique est-elle ajustée?',
      ru: 'Как корректируется стратегия динамического хеджирования?'
    },
    options: {
      tr: ['Sabit olarak belirlenmiş risk toleransına', 'Piyasa koşullarına göre hedge oranını ayarlayarak', 'Yalnızca döviz kurlarına', 'Tarihsel volatiliteye göre'],
      en: ['Fixed predetermined risk tolerance', 'By adjusting hedge ratio according to market conditions', 'Only to exchange rates', 'According to historical volatility'],
      es: ['Tolerancia riesgo predeterminada fija', 'Ajustando ratio cobertura según condiciones mercado', 'Solo tipos cambio', 'Según volatilidad histórica'],
      fr: ['Tolérance risque prédéterminée fixe', 'En ajustant ratio couverture selon conditions marché', 'Seulement taux change', 'Selon volatilité historique'],
      ru: ['Фиксированная заранее установленная толерантность к риску', 'Корректируя коэффициент хеджирования согласно рыночным условиям', 'Только к валютным курсам', 'Согласно исторической волатильности']
    },
    correct: 1
  }
]