import React from 'react'
import { useLanguage } from './useLanguage'
import { Button } from './ui/button'
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover'
import { Check, Filter, BookOpen, Target, TrendingUp, Trophy } from 'lucide-react'

interface LevelFilterProps {
  selectedLevel: string
  onLevelChange: (level: string) => void
  courseCounts: {
    all: number
    Beginner: number
    Intermediate: number
    Advanced: number
  }
}

export function LevelFilter({ selectedLevel, onLevelChange, courseCounts }: LevelFilterProps) {
  const { t } = useLanguage()

  const levels = [
    { 
      id: 'all', 
      name: t('categories.all'), 
      count: courseCounts.all, 
      icon: BookOpen, 
      color: 'text-slate-600',
      bgColor: 'bg-slate-100'
    },
    { 
      id: 'Beginner', 
      name: t('level.beginner'), 
      count: courseCounts.Beginner, 
      icon: Target, 
      color: 'text-green-600',
      bgColor: 'bg-green-100'
    },
    { 
      id: 'Intermediate', 
      name: t('level.intermediate'), 
      count: courseCounts.Intermediate, 
      icon: TrendingUp, 
      color: 'text-yellow-600',
      bgColor: 'bg-yellow-100'
    },
    { 
      id: 'Advanced', 
      name: t('level.advanced'), 
      count: courseCounts.Advanced, 
      icon: Trophy, 
      color: 'text-red-600',
      bgColor: 'bg-red-100'
    }
  ]

  const currentLevel = levels.find(level => level.id === selectedLevel)

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button 
          variant="outline" 
          size="sm" 
          className="flex items-center space-x-2 min-w-[140px] justify-start bg-background/50 backdrop-blur-sm border-border/50 hover:bg-background/80"
        >
          <Filter className="w-4 h-4" />
          {currentLevel && (
            <>
              <div className={`w-2 h-2 rounded-full ${currentLevel.bgColor}`}></div>
              <span className="text-sm font-medium">{currentLevel.name}</span>
              <span className="text-xs bg-muted px-1.5 py-0.5 rounded-full">
                {currentLevel.count}
              </span>
            </>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-56 p-2" align="end">
        <div className="space-y-1">
          <div className="px-3 py-2 text-xs font-medium text-muted-foreground uppercase tracking-wider">
            {t('level.filter')}
          </div>
          {levels.map((level) => {
            const IconComponent = level.icon
            return (
              <button
                key={level.id}
                onClick={() => onLevelChange(level.id)}
                className={`
                  w-full flex items-center justify-between px-3 py-2.5 rounded-md text-sm transition-colors
                  ${selectedLevel === level.id 
                    ? 'bg-primary text-primary-foreground' 
                    : 'hover:bg-muted text-foreground'
                  }
                `}
              >
                <div className="flex items-center space-x-3">
                  <div className={`w-6 h-6 rounded-md ${level.bgColor} flex items-center justify-center`}>
                    <IconComponent className={`w-3 h-3 ${level.color}`} />
                  </div>
                  <div className="flex flex-col items-start">
                    <span className="font-medium">{level.name}</span>
                    <span className="text-xs text-muted-foreground">
                      {level.count} {level.count === 1 ? t('course.course') : t('course.courses')}
                    </span>
                  </div>
                </div>
                {selectedLevel === level.id && (
                  <Check className="w-4 h-4" />
                )}
              </button>
            )
          })}
        </div>
        <div className="mt-3 pt-2 border-t border-border">
          <p className="text-xs text-muted-foreground text-center">
            {t('level.filterHelp')}
          </p>
        </div>
      </PopoverContent>
    </Popover>
  )
}