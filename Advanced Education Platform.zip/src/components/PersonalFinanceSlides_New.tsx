import { DollarSign, Target, TrendingUp, BarChart3, LineChart, Coins, ShieldCheck, Zap, Heart, Coffee, Brain } from 'lucide-react'

export const personalFinanceSlides = [
  {
    title: { 
      tr: 'Kişisel Finans Nedir?', 
      en: 'What is Personal Finance?', 
      es: '¿Qué son las Finanzas Personales?', 
      fr: 'Qu\'est-ce que la Finance Personnelle?', 
      ru: 'Что такое личные финансы?' 
    },
    content: { 
      tr: [
        '• Kişisel finans, aylık gelirinizi (maaş, yan gelir, yatırım getirisi) planlı şekilde yönetmek, günlük harcamalarınızı (market, faturalar, ulaşım) kontrol altında tutmak, tasarruf hedefleri belirleyerek düzenli para biriktirmek ve uzun vadeli finansal güvenlik için akıllı yatırımlar yapmak anlamına gelir',
        '• Temel prensipler: Her ay Gelir > Gider dengesini korumak (örn: 5000 TL gelir varsa 4000 TL harcayıp 1000 TL biriktirmek), 1-5-10 yıllık finansal hedefler belirlemek (tatil, ev, emeklilik) ve beklenmedik durumlar için risk yönetimi yaparak kendimizi korumak',
        '• Finansal özgürlük sağlar: Kredi kartı borcu, tüketici kredisi gibi yüksek faizli borçlarınız olmadığında, iş yerinde baskı hissetmeden "hayır" diyebilir, hobilerinize zaman ayırabilir ve istediğiniz hayat tarzını sürdürebilirsiniz',
        '• Stres azaltır: Mali güvenlik sayesinde fatura ödeme endişesi yaşamaz, ani masraflar (araba tamiri, sağlık gideri) karşısında panik yapmaz, gelecek planları konusunda kendine güvenir ve daha mutlu, huzurlu bir yaşam sürersiniz'
      ],
      en: [
        '• Personal finance means managing your monthly income ($3,000-$6,000 salary, side income, investment returns) in a planned manner, controlling daily expenses (groceries, bills, transportation), setting savings goals and making smart investments for long-term financial security',
        '• Basic principles: Maintain Income > Expenses balance each month (e.g., $5,000 income spend $4,000 save $1,000), set 1-5-10 year financial goals (vacation, house, retirement), and manage risks for protection against unexpected situations',
        '• Provides financial freedom: When you have no high-interest debt like credit cards or consumer loans, you can say "no" at work without pressure, spend time on hobbies, and maintain your desired lifestyle',
        '• Reduces stress: Financial security means no bill payment anxiety, no panic over sudden expenses (car repair, medical bills), confidence in future plans, and a happier, more peaceful life'
      ],
      es: [
        '• Las finanzas personales significan gestionar tus ingresos mensuales (€1,500-€3,000 salario, ingresos secundarios, retornos de inversión) de manera planificada, controlar gastos diarios (supermercado, facturas, transporte), establecer objetivos de ahorro y hacer inversiones inteligentes para seguridad financiera a largo plazo',
        '• Principios básicos: Mantener balance Ingresos > Gastos cada mes (ej: €2,500 ingresos gastar €2,000 ahorrar €500), establecer objetivos financieros de 1-5-10 años (vacaciones, casa, jubilación), y gestionar riesgos para protección contra situaciones inesperadas',
        '• Proporciona libertad financiera: Cuando no tienes deudas de alto interés como tarjetas de crédito o préstamos al consumidor, puedes decir "no" en el trabajo sin presión, dedicar tiempo a aficiones y mantener el estilo de vida deseado',
        '• Reduce el estrés: La seguridad financiera significa no tener ansiedad por pagar facturas, no entrar en pánico por gastos súbitos (reparación de auto, gastos médicos), confianza en planes futuros y una vida más feliz y tranquila'
      ],
      fr: [
        '• La finance personnelle signifie gérer vos revenus mensuels (€2,000-€4,000 salaire, revenus secondaires, retours d\'investissement) de manière planifiée, contrôler les dépenses quotidiennes (courses, factures, transport), fixer des objectifs d\'épargne et faire des investissements intelligents pour la sécurité financière à long terme',
        '• Principes de base: Maintenir l\'équilibre Revenus > Dépenses chaque mois (ex: €3,000 revenus dépenser €2,400 épargner €600), fixer des objectifs financiers de 1-5-10 ans (vacances, maison, retraite), et gérer les risques pour se protéger contre les situations imprévues',
        '• Fournit la liberté financière: Quand vous n\'avez pas de dettes à taux élevé comme les cartes de crédit ou prêts à la consommation, vous pouvez dire "non" au travail sans pression, consacrer du temps aux loisirs et maintenir le style de vie souhaité',
        '• Réduit le stress: La sécurité financière signifie pas d\'anxiété pour payer les factures, pas de panique face aux dépenses soudaines (réparation auto, frais médicaux), confiance dans les projets d\'avenir et une vie plus heureuse et paisible'
      ],
      ru: [
        '• Личные финансы означают управление ежемесячными доходами (60,000-120,000 руб зарплата, дополнительные доходы, инвестиционные доходы) планомерно, контроль ежедневных расходов (продукты, счета, транспорт), постановка целей сбережений и умные инвестиции для долгосрочной финансовой безопасности',
        '• Основные принципы: Поддерживать баланс Доходы > Расходы каждый месяц (напр: 100,000 руб доход тратить 80,000 откладывать 20,000), ставить финансовые цели на 1-5-10 лет (отпуск, дом, пенсия), и управлять рисками для защиты от неожиданных ситуаций',
        '• Обеспечивает финансовую свободу: Когда у вас нет высокопроцентных долгов как кредитные карты или потребительские кредиты, вы можете сказать "нет" на работе без давления, тратить время на хобби и поддерживать желаемый образ жизни',
        '• Снижает стресс: Финансовая безопасность означает отсутствие беспокойства о счетах, отсутствие паники от внезапных расходов (ремонт авто, медицинские счета), уверенность в будущих планах и более счастливую, мирную жизнь'
      ]
    },
    example: { 
      tr: '💡 2025\'te ABD\'de enflasyon %3 civarında seyrederken, ortalama bir aile enflasyona karşı kişisel finans planı yaparak yıllık %5 tasarruf artışı sağladı (kaynak: Federal Reserve raporları).',
      en: '💡 In 2025, while inflation in the US was around 3%, an average family achieved 5% annual savings growth by making a personal finance plan against inflation (source: Federal Reserve reports).',
      es: '💡 En 2025, mientras la inflación en España rondaba el 4%, una familia promedio logró un crecimiento del 6% en ahorros anuales haciendo un plan de finanzas personales contra la inflación (fuente: Banco de España).',
      fr: '💡 En 2025, alors que l\'inflation en France était d\'environ 4%, une famille moyenne a réalisé une croissance de 6% d\'épargne annuelle en élaborant un plan de finance personnelle contre l\'inflation (source: Banque de France).',
      ru: '💡 В 2025 году, когда инфляция в России была около 7%, средняя семья добилась 10% годового роста сбережений, составив план личных финансов против инфляции (источник: Центробанк РФ).'
    },
    icon: <DollarSign className="w-16 h-16 text-green-500" />,
  },
  {
    title: { 
      tr: 'Finansal Hedefler Belirleme', 
      en: 'Setting Financial Goals', 
      es: 'Establecer Objetivos Financieros', 
      fr: 'Fixer des Objectifs Financiers', 
      ru: 'Постановка финансовых целей' 
    },
    content: { 
      tr: [
        '• Kısa vadeli hedefler (6-12 ay): Yıllık tatil için 10.000 TL biriktirmek, 3 aylık acil fon oluşturmak (15.000 TL), yeni telefon/laptop almak (5.000-15.000 TL) gibi somut ve kısa sürede ulaşılabilir hedefler belirleyin',
        '• Orta vadeli hedefler (2-5 yıl): Ev peşinatı için 100.000-200.000 TL biriktirmek, sıfır araç almak için 300.000 TL bütçe oluşturmak, master eğitimi için 50.000 TL fon kurmak gibi önemli yaşam değişiklikleri için planlama yapın',
        '• Uzun vadeli hedefler (5+ yıl): Emeklilik için aylık 2.000 TL BES/yatırım yapmak, çocukların üniversite eğitimi için 200.000 TL fon oluşturmak, kendi işinizi kurmak için 500.000 TL sermaye biriktirmek gibi hayallerinizi gerçekleştirecek büyük hedefler koyun',
        '• SMART kuralı uygulaması: "1 yılda tatil için 12.000 TL biriktireceğim" → Spesifik (tatil), Ölçülebilir (12.000 TL), Ulaşılabilir (aylık 1.000 TL), İlgili (kişisel mutluluk), Zaman sınırlı (1 yıl) şeklinde net hedefler belirleyin'
      ],
      en: [
        '• Short-term goals (6-12 months): Save $3,000 for annual vacation, build 3-month emergency fund ($9,000), buy new phone/laptop ($800-$2,500) - concrete goals achievable in short time',
        '• Medium-term goals (2-5 years): Save $50,000-$80,000 for house down payment, budget $25,000-$40,000 for new car, create $15,000 fund for master\'s degree - plan for important life changes',
        '• Long-term goals (5+ years): Invest $500/month for retirement in 401k/IRA, create $100,000 education fund for children, save $200,000 capital to start your own business - big goals to realize your dreams',
        '• SMART rule application: "I will save $3,600 for vacation in 1 year" → Specific (vacation), Measurable ($3,600), Achievable ($300/month), Relevant (personal happiness), Time-bound (1 year)'
      ],
      es: [
        '• Objetivos a corto plazo (6-12 meses): Ahorrar €2,500 para vacaciones anuales, construir fondo de emergencia de 3 meses (€7,500), comprar nuevo teléfono/portátil (€600-€2,000) - objetivos concretos alcanzables en poco tiempo',
        '• Objetivos a mediano plazo (2-5 años): Ahorrar €30,000-€50,000 para enganche de casa, presupuestar €20,000-€35,000 para auto nuevo, crear fondo de €12,000 para máster - planificar cambios importantes de vida',
        '• Objetivos a largo plazo (5+ años): Invertir €400/mes para jubilación en planes de pensiones, crear fondo educativo de €80,000 para hijos, ahorrar €150,000 capital para iniciar negocio propio - grandes objetivos para realizar sueños',
        '• Aplicación regla SMART: "Ahorraré €3,000 para vacaciones en 1 año" → Específico (vacaciones), Medible (€3,000), Alcanzable (€250/mes), Relevante (felicidad personal), Con límite tiempo (1 año)'
      ],
      fr: [
        '• Objectifs à court terme (6-12 mois): Économiser €3,000 pour vacances annuelles, constituer fonds d\'urgence 3 mois (€9,000), acheter nouveau téléphone/ordinateur (€700-€2,200) - objectifs concrets atteignables rapidement',
        '• Objectifs à moyen terme (2-5 ans): Économiser €40,000-€60,000 pour acompte maison, budgéter €25,000-€40,000 pour voiture neuve, créer fonds €15,000 pour master - planifier changements vie importants',
        '• Objectifs à long terme (5+ ans): Investir €500/mois pour retraite dans PER/assurance-vie, créer fonds éducation €100,000 pour enfants, économiser €180,000 capital pour créer entreprise - grands objectifs réaliser rêves',
        '• Application règle SMART: "J\'économiserai €3,600 pour vacances en 1 an" → Spécifique (vacances), Mesurable (€3,600), Atteignable (€300/mois), Pertinent (bonheur personnel), Temporellement défini (1 an)'
      ],
      ru: [
        '• Краткосрочные цели (6-12 месяцев): Накопить 200,000 руб на годовой отпуск, создать фонд экстренных ситуаций на 3 месяца (600,000 руб), купить новый телефон/ноутбук (50,000-150,000 руб) - конкретные цели, достижимые за короткое время',
        '• Среднесрочные цели (2-5 лет): Накопить 2,000,000-3,000,000 руб для первоначального взноса за дом, заложить 1,500,000-2,500,000 руб на новую машину, создать фонд 800,000 руб для магистратуры - планирование важных жизненных изменений',
        '• Долгосрочные цели (5+ лет): Инвестировать 30,000 руб/месяц для пенсии в ИИС/НПФ, создать образовательный фонд 6,000,000 руб для детей, накопить 10,000,000 руб капитала для старта собственного бизнеса - большие цели для реализации мечт',
        '• Применение правила SMART: "Я накоплю 240,000 руб на отпуск за 1 год" → Конкретный (отпуск), Измеримый (240,000 руб), Достижимый (20,000 руб/месяц), Релевантный (личное счастье), Ограниченный по времени (1 год)'
      ]
    },
    example: { 
      tr: '🎯 2025\'te Türkiye\'de gençler, ev alma hedefi için aylık 2.000 TL biriktirerek 5 yılda %20 peşinat topluyor; örneğin, bir yazılımcı bu yöntemle İstanbul\'da daire aldı.',
      en: '🎯 In 2025, young Americans save $800/month for home buying goal, collecting 20% down payment in 5 years; for example, a software developer bought a condo in Austin with this method.',
      es: '🎯 En 2025, jóvenes españoles ahorran €600/mes para objetivo de comprar casa, acumulando 20% de enganche en 5 años; por ejemplo, un desarrollador de software compró un piso en Madrid con este método.',
      fr: '🎯 En 2025, les jeunes français économisent €700/mois pour objectif d\'achat maison, accumulant 20% d\'acompte en 5 ans; par exemple, un développeur logiciel a acheté un appartement à Lyon avec cette méthode.',
      ru: '🎯 В 2025 году молодые россияне откладывают 40,000 руб/месяц для цели покупки дома, накапливая 20% первоначального взноса за 5 лет; например, разработчик ПО купил ��вартиру в Москве этим методом.'
    },
    icon: <Target className="w-16 h-16 text-blue-500" />,
  },
  {
    title: { 
      tr: 'Gelir Kaynaklarını Çeşitlendirme', 
      en: 'Diversifying Income Sources', 
      es: 'Diversificar Fuentes de Ingresos', 
      fr: 'Diversifier les Sources de Revenus', 
      ru: 'Диверсификация источников дохода' 
    },
    content: { 
      tr: [
        '• Ana gelir kaynağı: Tam zamanlı işinizden aldığınız aylık net maaş (örn: 8.000-15.000 TL), kendi işinizden elde ettiğiniz düzenli aylık gelir veya ortaklık payları. Bu gelir yaşam giderlerinizin %80\'ini karşılamalı',
        '• Yan gelir kaynakları: Akşam/hafta sonu freelance işleri (grafik tasarım, yazılım, çeviri), online ders verme, danışmanlık, e-ticaret mağazası işletme. Hedef: Ana gelirin %20-30\'u kadar ek gelir (1.500-3.000 TL)',
        '• Pasif gelir imkânları: Kiraladığınız daireden aylık gelir (2.000-4.000 TL), hisse senedi temettüleri (yıllık %5-10), vadeli hesap/tahvil faizi (yıllık %15-25), kitap/içerik royalty gelirleri. Uzun vadede ana gelirle eşitlenmeyi hedefleyin',
        '• Risk azaltma stratejisi: İş kaybı durumunda yan gelirleriniz temel ihtiyaçlarınızı karşılasın. Pasif gelirleriniz artarsa finansal bağımsızlığa yaklaşırsınız. 3 farklı gelir kaynağına sahip olmak ideal güvenlik sağlar'
      ],
      en: [
        '• Main income source: Monthly net salary from full-time job ($4,000-$8,000), regular monthly income from your business or partnership shares. This income should cover 80% of your living expenses',
        '• Side income sources: Evening/weekend freelance work (graphic design, software, translation), online tutoring, consulting, e-commerce store operation. Target: 20-30% additional income relative to main income ($800-$1,600)',
        '• Passive income opportunities: Monthly income from rental property ($1,200-$2,400), stock dividends (5-10% annually), savings account/bond interest (3-5% annually), book/content royalties. Aim to match main income long-term',
        '• Risk reduction strategy: In case of job loss, side incomes should cover basic needs. As passive income grows, you approach financial independence. Having 3 different income sources provides ideal security'
      ],
      es: [
        '• Fuente principal de ingresos: Salario neto mensual de trabajo tiempo completo (€2,000-€4,000), ingreso mensual regular de tu negocio o participaciones societarias. Este ingreso debe cubrir 80% de gastos de vida',
        '• Fuentes de ingresos secundarios: Trabajo freelance nocturno/fines de semana (diseño gráfico, software, traducción), tutoría online, consultoría, operación tienda e-commerce. Objetivo: 20-30% ingreso adicional relativo al principal (€400-€800)',
        '• Oportunidades ingresos pasivos: Ingreso mensual de propiedad alquilada (€800-€1,600), dividendos acciones (5-10% anual), interés cuenta ahorro/bonos (2-4% anual), regalías libros/contenido. Apuntar igualar ingreso principal largo plazo',
        '• Estrategia reducción riesgo: En caso pérdida empleo, ingresos secundarios deben cubrir necesidades básicas. Conforme crecen ingresos pasivos, te acercas independencia financiera. Tener 3 fuentes ingresos diferentes proporciona seguridad ideal'
      ],
      fr: [
        '• Source principale de revenus: Salaire net mensuel d\'emploi temps plein (€2,500-€5,000), revenus mensuels réguliers de votre entreprise ou parts de partenariat. Ce revenu devrait couvrir 80% de vos dépenses de vie',
        '• Sources de revenus secondaires: Travail freelance soir/week-end (design graphique, logiciel, traduction), tutorat en ligne, conseil, exploitation boutique e-commerce. Objectif: 20-30% revenus supplémentaires par rapport au principal (€500-€1,000)',
        '• Opportunités revenus passifs: Revenus mensuels de propriété locative (€1,000-€2,000), dividendes actions (5-10% annuel), intérêts compte épargne/obligations (1-3% annuel), redevances livres/contenu. Viser égaler revenu principal long terme',
        '• Stratégie réduction risque: En cas perte emploi, revenus secondaires devraient couvrir besoins basiques. À mesure que revenus passifs croissent, vous approchez indépendance financière. Avoir 3 sources revenus différentes fournit sécurité idéale'
      ],
      ru: [
        '• Основной источник дохода: Ежемесячная чистая зарплата с работы полный день (120,000-240,000 руб), регулярный месячный доход от собственного бизнеса или долей в партнерстве. Этот доход должен покрывать 80% ваших жизненных расходов',
        '• Побочные источники дохода: Вечерняя/выходная фриланс работа (графический дизайн, программирование, переводы), онлайн репетиторство, консультации, управление интернет-магазином. Цель: 20-30% дополнительного дохода относительно основного (24,000-48,000 руб)',
        '• Возможности пассивного дохода: Ежемесячный доход от сдачи жилья (60,000-120,000 руб), дивиденды по акциям (5-10% годовых), проценты по депозитам/облигациям (8-15% годовых), роялти от книг/контента. Стремитесь сравняться с основным доходом долгосрочно',
        '• Стратегия снижения рисков: В случае потери работы побочные доходы должны покрывать базовые потребности. По мере роста пассивных доходов приближаетесь к финансовой независимости. Наличие 3 разных источников дохода обеспечивает идеальную безопасность'
      ]
    },
    example: { 
      tr: '💼 2025\'te freelance platformlarında (Upwork) çalışanlar, ana maaşlarına ek %30 gelir elde ediyor; örneğin, bir grafik tasarımcı aylık 1.500 USD ekstra kazanıyor.',
      en: '💼 In 2025, workers on freelance platforms (Upwork) earn 30% additional income on top of their main salaries; for example, a graphic designer earns an extra $1,500 USD monthly.',
      es: '💼 En 2025, trabajadores en plataformas freelance (Upwork) obtienen 30% ingresos adicionales sobre sus salarios principales; por ejemplo, un diseñador gráfico gana €1,200 extra mensualmente.',
      fr: '💼 En 2025, les travailleurs sur plateformes freelance (Upwork) gagnent 30% revenus supplémentaires en plus de leurs salaires principaux; par exemple, un graphiste gagne €1,400 supplémentaires mensuellement.',
      ru: '💼 В 2025 году работники на фриланс-платформах (Upwork) получают 30% дополнительного дохода сверх основной зарплаты; например, графический дизайнер зарабатывает дополнительно 80,000 руб в месяц.'
    },
    icon: <TrendingUp className="w-16 h-16 text-purple-500" />,
  }
  {
    title: { 
      tr: 'Bütçe Oluşturma Temelleri', 
      en: 'Budget Creation Fundamentals', 
      es: 'Fundamentos de Creación de Presupuesto', 
      fr: 'Fondamentaux de Création de Budget', 
      ru: 'Основы создания бюджета' 
    },
    content: { 
      tr: [
        '• 50/30/20 kuralı detayı: 10.000 TL net gelirle → %50 (5.000 TL) zorunlu ihtiyaçlar (kira 2.500 TL, market 1.500 TL, faturalar 800 TL, ulaşım 200 TL), %30 (3.000 TL) kişisel istekler (dışarıda yemek, sinema, kıyafet, hobi), %20 (2.000 TL) tasarruf ve yatırım',
        '• Bütçe takip araçları önerileri: Akbank/İş Bankası mobil uygulaması harcama kategorileri, Tosla (Türkiye), YNAB (global), basit Excel şablonu veya not defterinde kategorilere ayırarak günlük harcamalarınızı kaydedin',
        '• Aylık bütçe analizi rutini: Her ayın son günü 1 saat ayırın, harcama kategorilerini gözden geçirin (hangi alanda fazla harcamış, hangi hedeflere ulaşmış), gelecek ay için düzeltmeler yapın ve yeni hedefler belirleyin',
        '• Esneklik buffer sistemi: Bütçenizin %5-10\'unu (500-1.000 TL) "beklenmedik giderler" kategorisinde tutun (ani araba tamiri, sağlık gideri, arkadaş düğünü hediyesi gibi). Bu para harcanmazsa tasarruf hesabına ekleyin'
      ],
      en: [
        '• 50/30/20 rule detail: With $5,000 net income → 50% ($2,500) essential needs (rent $1,200, groceries $800, utilities $300, transportation $200), 30% ($1,500) personal wants (dining out, movies, clothes, hobbies), 20% ($1,000) savings and investment',
        '• Budget tracking tools recommendations: Chase/Bank of America mobile app spending categories, Mint (US), YNAB (global), simple Excel template or notebook with daily expense categories',
        '• Monthly budget analysis routine: Set aside 1 hour on last day of each month, review spending categories (which areas overspent, which goals achieved), make adjustments for next month and set new targets',
        '• Flexibility buffer system: Keep 5-10% of budget ($250-$500) in "unexpected expenses" category (sudden car repair, medical expense, friend\'s wedding gift). If unspent, add to savings account'
      ],
      es: [
        '• Detalle regla 50/30/20: Con €2,500 ingresos netos → 50% (€1,250) necesidades esenciales (alquiler €700, supermercado €350, servicios €150, transporte €50), 30% (€750) deseos personales (comer fuera, cine, ropa, aficiones), 20% (€500) ahorros e inversión',
        '• Recomendaciones herramientas seguimiento presupuesto: Aplicación móvil BBVA/Santander categorías gastos, Fintonic (España), YNAB (global), plantilla Excel simple o cuaderno con categorías gastos diarios',
        '• Rutina análisis presupuesto mensual: Reservar 1 hora último día cada mes, revisar categorías gastos (qué áreas gastaron demás, qué objetivos lograron), hacer ajustes próximo mes y establecer nuevas metas',
        '• Sistema buffer flexibilidad: Mantener 5-10% presupuesto (€125-€250) en categoría "gastos inesperados" (reparación auto súbita, gasto médico, regalo boda amigo). Si no se gasta, añadir a cuenta ahorros'
      ],
      fr: [
        '• Détail règle 50/30/20: Avec €3,000 revenus nets → 50% (€1,500) besoins essentiels (loyer €900, courses €400, services €150, transport €50), 30% (€900) envies personnelles (restaurants, cinéma, vêtements, loisirs), 20% (€600) épargne et investissement',
        '• Recommandations outils suivi budget: Application mobile BNP/Crédit Agricole catégories dépenses, Bankin\' (France), YNAB (global), modèle Excel simple ou carnet avec catégories dépenses quotidiennes',
        '• Routine analyse budget mensuelle: Réserver 1 heure dernier jour chaque mois, réviser catégories dépenses (quels domaines ont dépassé, quels objectifs atteints), faire ajustements mois prochain et fixer nouvelles cibles',
        '• Système tampon flexibilité: Garder 5-10% budget (€150-€300) dans catégorie "dépenses imprévues" (réparation auto soudaine, dépense médicale, cadeau mariage ami). Si non dépensé, ajouter au compte épargne'
      ],
      ru: [
        '• Детали правила 50/30/20: С доходом 100,000 руб нетто → 50% (50,000 руб) основные потребности (аренда 30,000 руб, продукты 12,000 руб, коммунальные 6,000 руб, транспорт 2,000 руб), 30% (30,000 руб) личные желания (ресторан, кино, одежда, хобби), 20% (20,000 руб) сбережения и инвестиции',
        '• Рекомендации инструментов отслеживания бюджета: Мобильное приложение Сбербанк/ВТБ категории расходов, Дзен-мани (Россия), YNAB (глобальный), простой шаблон Excel или блокнот с категориями ежедневных расходов',
        '• Рутина анализа месячного бюджета: Выделить 1 час в последний день каждого месяца, просмотреть категории расходов (какие области превысили бюджет, какие цели достигнуты), внести корректировки на следующий месяц и установить новые цели',
        '• Система буфера гибкости: Держать 5-10% бюджета (5,000-10,000 руб) в категории "неожиданные расходы" (внезапный ремонт авто, медицинские расходы, подарок на свадьбу друга). Если не потрачено, добавить на сберегательный счет'
      ]
    },
    example: { 
      tr: '📊 2025\'te Avrupa\'da enflasyon nedeniyle aileler bütçelerini %10 kısarak, yıllık 5.000 Euro tasarruf etti; bir İtalyan aile bu kuralı uygulayarak tatil fonu oluşturdu.',
      en: '📊 In 2025, due to inflation in the US, families cut their budgets by 8%, saving $4,000 annually; an American family applied this rule and created a vacation fund.',
      es: '📊 En 2025, debido a la inflación en España, las familias recortaron sus presupuestos en un 10%, ahorrando €3,500 anualmente; una familia española aplicó esta regla y creó un fondo de vacaciones.',
      fr: '📊 En 2025, en raison de l\'inflation en France, les familles ont réduit leurs budgets de 9%, économisant €4,200 par an; une famille française a appliqué cette règle et créé un fonds de vacances.',
      ru: '📊 В 2025 году из-за инфляции в России семьи сократили бюджеты на 12%, сэкономив 300,000 руб в год; российская семья применила это правило и создала фонд для отпуска.'
    },
    icon: <BarChart3 className="w-16 h-16 text-blue-500" />,
  },
  {
    title: { 
      tr: 'Gider Takibi ve Azaltma', 
      en: 'Expense Tracking and Reduction', 
      es: 'Seguimiento y Reducción de Gastos', 
      fr: 'Suivi et Réduction des Dépenses', 
      ru: 'Отслеживание и сокращение расходов' 
    },
    content: { 
      tr: [
        '• Harcama kategorilerini detaylı ayırın: Sabit giderler (kira 2.500 TL, sigorta 300 TL, internet 100 TL), değişken giderler (market 800-1.200 TL, benzin 400-600 TL, eğlence 500-1.000 TL), acil/beklenmedik giderler (hekim, tamir, hediye 200-500 TL)',
        '• Gereksiz harcama avcılığı: Netflix, Spotify, spor salonu gibi abonelikleri listeleyin (aylık 150-300 TL), son 3 ayda kullanmadıklarınızı iptal edin. İmpuls alışverişi engellemek için "24 saat kuralı" uygulayın (istek duyduğunuz şeyi 1 gün sonra değerlendirin)',
        '• Akıllı takip sistemleri: Banka SMS\'lerini analiz edin, haftalık harcama limitlerini belirleyin (market 300 TL/hafta), Papara/Tosla gibi uygulamalarda otomatik kategorilendirme aktif edin, QR kod ile fiş tarama özelliklerini kullanın',
        '• Mikro tasarruf hileleri: Günlük Starbucks (25 TL) → evde kahve (3 TL) = aylık 660 TL tasarruf, haftada 1 dışarıda yemek (200 TL) → evde yapma = aylık 600 TL tasarruf, toplu taşıma + yürüyüş → taksi yerine aylık 400 TL tasarruf'
      ],
      en: [
        '• Categorize expenses in detail: Fixed expenses (rent $1,200, insurance $150, internet $50), variable expenses (groceries $400-$600, gas $200-$300, entertainment $250-$500), emergency/unexpected expenses (doctor, repair, gifts $100-$250)',
        '• Unnecessary expense hunting: List subscriptions like Netflix, Spotify, gym ($75-$150/month), cancel ones unused in last 3 months. Apply "24-hour rule" to prevent impulse buying (evaluate desired item after 1 day)',
        '• Smart tracking systems: Analyze bank SMS alerts, set weekly spending limits (groceries $150/week), activate automatic categorization in apps like Mint/YNAB, use receipt scanning features with QR codes',
        '• Micro-saving tricks: Daily Starbucks ($6) → home coffee ($0.50) = $165/month savings, weekly dining out ($50) → home cooking = $200/month savings, public transit + walking → instead of Uber saves $150/month'
      ],
      es: [
        '• Categorizar gastos detalladamente: Gastos fijos (alquiler €700, seguro €80, internet €30), gastos variables (supermercado €250-€400, gasolina €120-€180, entretenimiento €150-€300), gastos emergencia/inesperados (médico, reparación, regalos €60-€150)',
        '• Caza gastos innecesarios: Listar suscripciones como Netflix, Spotify, gimnasio (€45-€90/mes), cancelar las no usadas en últimos 3 meses. Aplicar "regla 24 horas" para prevenir compras impulsivas (evaluar artículo deseado después 1 día)',
        '• Sistemas seguimiento inteligentes: Analizar alertas SMS banco, establecer límites gasto semanal (supermercado €100/semana), activar categorización automática en apps como Fintonic/YNAB, usar funciones escaneo recibos con códigos QR',
        '• Trucos micro-ahorro: Starbucks diario (€4) → café casa (€0.30) = €111/mes ahorro, cena fuera semanal (€35) → cocinar casa = €140/mes ahorro, transporte público + caminar → en lugar Uber ahorra €80/mes'
      ],
      fr: [
        '• Catégoriser dépenses en détail: Dépenses fixes (loyer €900, assurance €100, internet €35), dépenses variables (courses €300-€500, essence €150-€220, divertissement €180-€350), dépenses urgence/imprévues (médecin, réparation, cadeaux €70-€180)',
        '• Chasse dépenses inutiles: Lister abonnements comme Netflix, Spotify, salle sport (€50-€110/mois), annuler ceux non utilisés 3 derniers mois. Appliquer "règle 24 heures" prévenir achats impulsifs (évaluer article désiré après 1 jour)',
        '• Systèmes suivi intelligents: Analyser alertes SMS banque, fixer limites dépenses hebdomadaires (courses €120/semaine), activer catégorisation automatique apps comme Bankin\'/YNAB, utiliser fonctions scan reçus codes QR',
        '• Astuces micro-épargne: Starbucks quotidien (€4.50) → café maison (€0.40) = €123/mois économie, dîner dehors hebdomadaire (€40) → cuisiner maison = €160/mois économie, transport public + marche → au lieu Uber économise €90/mois'
      ],
      ru: [
        '• Детальная категоризация расходов: Фиксированные расходы (аренда 30,000 руб, страхование 5,000 руб, интернет 800 руб), переменные расходы (продукты 15,000-25,000 руб, бензин 8,000-12,000 руб, развлечения 10,000-20,000 руб), экстренные/неожиданные расходы (врач, ремонт, подарки 3,000-8,000 руб)',
        '• Охота на ненужные расходы: Составить список подписок Netflix, Spotify, спортзал (2,500-5,500 руб/месяц), отменить неиспользуемые последние 3 месяца. Применять "правило 24 часов" для предотвращения импульсивных покупок (оценить желаемый товар через 1 день)',
        '• Умные системы отслеживания: Анализировать SMS-уведомления банка, установить недельные лимиты трат (продукты 6,000 руб/неделя), активировать автоматическую категоризацию в приложениях Дзен-мани/YNAB, использовать функции сканирования чеков с QR-кодами',
        '• Трюки микро-экономии: Ежедневный Starbucks (350 руб) → кофе дома (25 руб) = экономия 9,750 руб/месяц, еженедельный ужин в ресторане (2,500 руб) → готовка дома = экономия 10,000 руб/месяц, общественный транспорт + ходьба → вместо такси экономия 6,000 руб/месяц'
      ]
    },
    example: { 
      tr: '☕ 2025\'te ABD\'de kahve zincirleri (Starbucks) harcamalarını azaltan bireyler, yıllık 1.000 USD tasarruf etti; bir ofis çalışanı app ile takip ederek araba taksitini erken bitirdi.',
      en: '☕ In 2025, individuals in the US who reduced coffee chain (Starbucks) expenses saved $1,000 USD annually; an office worker finished car payments early by tracking with an app.',
      es: '☕ En 2025, individuos en España que redujeron gastos en cadenas de café (Starbucks) ahorraron €800 anualmente; un trabajador de oficina terminó los pagos del auto temprano rastreando con una app.',
      fr: '☕ En 2025, les individus en France qui ont réduit les dépenses de chaînes de café (Starbucks) ont économisé €900 par an; un employé de bureau a terminé les paiements de voiture plus tôt en suivant avec une app.',
      ru: '☕ В 2025 году люди в России, которые сократили расходы на кофейные сети (Starbucks), сэкономили 60,000 руб в год; офисный работник досрочно закончил выплаты за машину, отслеживая через приложение.'
    },
    icon: <LineChart className="w-16 h-16 text-red-500" />,
  },
  {
    title: { 
      tr: 'Tasarruf Stratejileri', 
      en: 'Savings Strategies', 
      es: 'Estrategias de Ahorro', 
      fr: 'Stratégies d\'Épargne', 
      ru: 'Стратегии сбережений' 
    },
    content: { 
      tr: [
        '• Otomatik transfer disiplini: Maaş geldikten sonraki ilk gün %15-20\'sini (1.500-2.000 TL) otomatik olarak farklı bankadaki tasarruf hesabına aktarın. "Önce kendini öde" prensibi ile bu parayı hiç elinde bulundurmaması için EFT talimatı verin',
        '• Yüksek getirili hesap stratejisi: 2025\'te Türkiye\'de vadeli hesaplar %20-25 getiri veriyor. 10.000 TL\'yi 6 ay vadeli hesapta değerlendirin (1.000-1.250 TL kar). Altın, dolar, euro da enflasyon korunması için alternatif',
        '• Eğlenceli tasarruf oyunları: 52 hafta meydan okuması (1. hafta 1 TL, 2. hafta 2 TL... 52. hafta 52 TL = yıl sonu 1.378 TL), 365 gün 5 TL meydan okuması (günde 5 TL = yıl sonu 1.825 TL), "5 TL jar" sistemi (her gün cebinizdeki 5 TL\'leri kavanoza atın)',
        '• Hedef bankacılığı: Tatil hesabı (aylık 800 TL), ev peşinat hesabı (aylık 3.000 TL), acil durum hesabı (aylık 1.000 TL) açın. Her hesaba görsel etiket koyun, hedef tutarları yazın, ilerlemeyi takip edin'
      ],
      en: [
        '• Automatic transfer discipline: First day after salary, automatically transfer 15-20% ($750-$1,000) to savings account at different bank. Apply "pay yourself first" principle with automatic EFT instruction so you never handle this money',
        '• High-yield account strategy: In 2025 US, high-yield savings accounts offer 4-5% returns. Invest $10,000 in 6-month CD (earn $200-$250 profit). Consider Treasury bonds, I-bonds for inflation protection',
        '• Fun savings games: 52-week challenge (week 1: $1, week 2: $2... week 52: $52 = year-end $1,378), 365-day $5 challenge (daily $5 = year-end $1,825), "$5 jar" system (put all $5 bills from pocket into jar daily)',
        '• Goal banking: Open vacation account (monthly $400), house down payment account (monthly $1,500), emergency account (monthly $500). Put visual labels on each account, write target amounts, track progress'
      ],
      es: [
        '• Disciplina transferencia automática: Primer día después salario, transferir automáticamente 15-20% (€375-€500) a cuenta ahorros en banco diferente. Aplicar principio "págarte primero" con instrucción transferencia automática para nunca manejar este dinero',
        '• Estrategia cuenta alto rendimiento: En 2025 España, cuentas ahorro alto rendimiento ofrecen 2-3% retornos. Invertir €10,000 en depósito 6 meses (ganar €100-€150 beneficio). Considerar bonos estado, letras tesoro para protección inflación',
        '• Juegos ahorro divertidos: Desafío 52 semanas (semana 1: €1, semana 2: €2... semana 52: €52 = fin año €1,378), desafío 365 días €5 (diario €5 = fin año €1,825), sistema "€5 jar" (poner todos billetes €5 del bolsillo en tarro diariamente)',
        '• Banca objetivos: Abrir cuenta vacaciones (mensual €300), cuenta enganche casa (mensual €1,200), cuenta emergencia (mensual €400). Poner etiquetas visuales cada cuenta, escribir cantidades objetivo, seguir progreso'
      ],
      fr: [
        '• Discipline transfert automatique: Premier jour après salaire, transférer automatiquement 15-20% (€450-€600) vers compte épargne banque différente. Appliquer principe "se payer d\'abord" avec instruction virement automatique pour jamais manipuler cet argent',
        '• Stratégie compte haut rendement: En 2025 France, comptes épargne haut rendement offrent 2-4% retours. Investir €10,000 dans dépôt 6 mois (gagner €100-€200 profit). Considérer obligations état, livrets réglementés protection inflation',
        '• Jeux épargne amusants: Défi 52 semaines (semaine 1: €1, semaine 2: €2... semaine 52: €52 = fin année €1,378), défi 365 jours €5 (quotidien €5 = fin année €1,825), système "€5 bocal" (mettre tous billets €5 poche dans bocal quotidiennement)',
        '• Banque objectifs: Ouvrir compte vacances (mensuel €350), compte acompte maison (mensuel €1,400), compte urgence (mensuel €500). Mettre étiquettes visuelles chaque compte, écrire montants objectifs, suivre progrès'
      ],
      ru: [
        '• Дисциплина автоматических переводов: В первый день после зарплаты автоматически переводить 15-20% (18,000-24,000 руб) на сберегательный счет в другом банке. Применять принцип "сначала заплати себе" с автоматическим поручением, чтобы никогда не касаться этих денег',
        '• Стратегия высокодоходных счетов: В 2025 в России срочные вклады предлагают 15-20% доходность. Вложить 500,000 руб в депозит на 6 месяцев (заработать 37,500-50,000 руб прибыли). Рассмотреть ОФЗ, валютные депозиты для защиты от инфляции',
        '• Веселые игры сбережений: Вызов 52 недели (неделя 1: 100 руб, неделя 2: 200 руб... неделя 52: 5,200 руб = конец года 137,800 руб), вызов 365 дней по 500 руб (ежедневно 500 руб = конец года 182,500 руб), система "500 руб банка" (класть все банкноты 500 руб из кармана в банку ежедневно)',
        '• Целевое банковское дело: Открыть счет отпуска (ежемесячно 20,000 руб), счет первоначального взноса дома (ежемесячно 60,000 руб), счет экстренных ситуаций (ежемесячно 25,000 руб). Поставить визуальные ярлыки на каждый счет, написать целевые суммы, отслеживать прогресс'
      ]
    },
    example: { 
      tr: '🏦 2025\'te Türkiye\'de faiz oranları %25\'lerdeyken, vadeli hesaplar yıllık %20 getiri sağladı; bir öğretmen 10.000 TL biriktirerek acil durum fonu kurdu.',
      en: '🏦 In 2025, when interest rates in the US were around 5%, high-yield savings provided 4.5% annual returns; a teacher saved $8,000 and established an emergency fund.',
      es: '🏦 En 2025, cuando las tasas de interés en España rondaban el 3%, los depósitos a plazo proporcionaron retornos anuales del 2.5%; un maestro ahorró €6,000 y estableció un fondo de emergencia.',
      fr: '🏦 En 2025, lorsque les taux d\'intérêt en France étaient d\'environ 3%, les dépôts à terme ont fourni des rendements annuels de 2.8%; un enseignant a économisé €7,000 et établi un fonds d\'urgence.',
      ru: '🏦 В 2025 году, когда процентные ставки в России были около 18%, срочные вклады давали 16% годовой доходности; учитель накопил 400,000 руб и создал фонд экстренных ситуаций.'
    },
    icon: <Coins className="w-16 h-16 text-yellow-500" />,
  },
  {
    title: { 
      tr: 'Acil Fon Oluşturma', 
      en: 'Building Emergency Fund', 
      es: 'Construir Fondo de Emergencia', 
      fr: 'Construire un Fonds d\'Urgence', 
      ru: 'Создание фонда экстренных ситуаций' 
    },
    content: { 
      tr: [
        '• Hedef tutar hesaplama: Aylık yaşam gideriniz 6.000 TL ise → 3 ay için 18.000 TL, 6 ay için 36.000 TL acil fon biriktirin. Bu kira (2.500), market (1.200), faturalar (800), ulaşım (300), diğer zorunlu giderler (1.200) toplamınızdır',
        '• Likit erişim önceliği: Acil fonunuzu vadesiz tasarruf hesabında tutun (günde 3-5 kez para çekme hakkı), vadeli hesaba koymayın (erken çekimde ceza var). ATM kartınız olsun ama günlük limit belirleyin (1.000 TL) ki gereksiz harcamayasınız',
        '• Sadece gerçek acil durumlar: İş kaybı (3-6 ay geçim), ani sağlık giderleri (ameliyat, tedavi), beklenmedik büyük tamirler (buzdolabı, araba, ev). Tatil, alışveriş, istek alımları acil durum DEĞİLDİR',
        '• Adım adım biriktirme planı: 1. ay 2.000 TL (başlangıç), 3. ay 6.000 TL (1 aylık gider), 6. ay 12.000 TL (2 aylık), 12. ay 24.000 TL (4 aylık), 18. ay 36.000 TL (6 aylık) şeklinde kademeli artırın'
      ],
      en: [
        '• Target amount calculation: If monthly living expenses $3,000 → save $9,000 for 3 months, $18,000 for 6 months emergency fund. This includes rent ($1,200), groceries ($600), utilities ($300), transportation ($200), other essentials ($700)',
        '• Liquid access priority: Keep emergency fund in no-penalty savings account (3-5 daily withdrawals allowed), don\'t put in CD (early withdrawal penalty). Have ATM card but set daily limit ($500) to prevent unnecessary spending',
        '• Only real emergencies: Job loss (3-6 months living), sudden medical expenses (surgery, treatment), unexpected major repairs (refrigerator, car, home). Vacation, shopping, want purchases are NOT emergencies',
        '• Step-by-step saving plan: Month 1: $1,000 (starter), Month 3: $3,000 (1-month expenses), Month 6: $6,000 (2-month), Month 12: $12,000 (4-month), Month 18: $18,000 (6-month) gradual increase'
      ],
      es: [
        '• Cálculo cantidad objetivo: Si gastos vida mensuales €2,000 → ahorrar €6,000 para 3 meses, €12,000 para 6 meses fondo emergencia. Esto incluye alquiler (€700), supermercado (€400), servicios (€200), transporte (€100), otros esenciales (€600)',
        '• Prioridad acceso líquido: Mantener fondo emergencia en cuenta ahorros sin penalización (3-5 retiros diarios permitidos), no poner en depósito plazo (penalización retiro temprano). Tener tarjeta cajero pero establecer límite diario (€300) prevenir gasto innecesario',
        '• Solo emergencias reales: Pérdida empleo (3-6 meses vida), gastos médicos súbitos (cirugía, tratamiento), reparaciones mayores inesperadas (refrigerador, auto, casa). Vacaciones, compras, compras deseo NO son emergencias',
        '• Plan ahorro paso a paso: Mes 1: €600 (inicial), Mes 3: €2,000 (gastos 1 mes), Mes 6: €4,000 (2 meses), Mes 12: €8,000 (4 meses), Mes 18: €12,000 (6 meses) aumento gradual'
      ],
      fr: [
        '• Calcul montant objectif: Si dépenses vie mensuelles €2,500 → économiser €7,500 pour 3 mois, €15,000 pour 6 mois fonds urgence. Ceci inclut loyer (€900), courses (€500), services (€250), transport (€150), autres essentiels (€700)',
        '• Priorité accès liquide: Garder fonds urgence dans compte épargne sans pénalité (3-5 retraits quotidiens autorisés), ne pas mettre dans dépôt terme (pénalité retrait anticipé). Avoir carte distributeur mais fixer limite quotidienne (€400) prévenir dépense inutile',
        '• Seulement vraies urgences: Perte emploi (3-6 mois vie), dépenses médicales soudaines (chirurgie, traitement), réparations majeures inattendues (réfrigérateur, auto, maison). Vacances, achats, achats envie ne sont PAS urgences',
        '• Plan épargne étape par étape: Mois 1: €800 (démarrage), Mois 3: €2,500 (dépenses 1 mois), Mois 6: €5,000 (2 mois), Mois 12: €10,000 (4 mois), Mois 18: €15,000 (6 mois) augmentation graduelle'
      ],
      ru: [
        '• Расчет целевой суммы: Если ежемесячные расходы на жизнь 80,000 руб → накопить 240,000 руб на 3 месяца, 480,000 руб на 6 месяцев фонда экстренных ситуаций. Это включает аренду (30,000), продукты (20,000), коммунальные (10,000), транспорт (5,000), другие необходимые (15,000)',
        '• Приоритет ликвидного доступа: Держать фонд экстренных ситуаций на беспроцентном сберегательном счете (3-5 ежедневных снятий разрешено), не класть в срочный вклад (штраф за досрочное снятие). Иметь банкомат карту но установить дневной лимит (25,000 руб) для предотвращения ненужных трат',
        '• Только настоящие чрезвычайные ситуации: Потеря работы (3-6 месяцев жизни), внезапные медицинские расходы (опе��ация, лечение), неожиданные крупные ремонты (холодильник, авто, дом). Отпуск, покупки, покупки желаний НЕ являются чрезвычайными ситуациями',
        '• Пошаговый план сбережений: Месяц 1: 40,000 руб (стартовый), Месяц 3: 80,000 руб (расходы 1 месяц), Месяц 6: 160,000 руб (2 месяца), Месяц 12: 320,000 руб (4 месяца), Месяц 18: 480,000 руб (6 месяцев) постепенное увеличение'
      ]
    },
    example: { 
      tr: '🛡️ 2025\'te pandemi sonrası işsizlik dalgasında, acil fonu olan bireyler %40 daha az stres yaşadı; bir freelancer 20.000 TL fonla 3 ay geçindi.',
      en: '🛡️ In 2025, during post-pandemic unemployment waves, individuals with emergency funds experienced 40% less stress; a freelancer survived 3 months with a $12,000 fund.',
      es: '🛡️ En 2025, durante las olas de desempleo post-pandemia, individuos con fondos de emergencia experimentaron 40% menos estrés; un freelancer sobrevivió 3 meses con un fondo de €8,000.',
      fr: '🛡️ En 2025, pendant les vagues de chômage post-pandémie, les individus avec des fonds d\'urgence ont connu 40% moins de stress; un freelancer a survécu 3 mois avec un fonds de €10,000.',
      ru: '🛡️ В 2025 году, во время волн безработицы после пандемии, люди с фондами экстренных ситуаций испытывали на 40% меньше стресса; фрилансер прожил 3 месяца на фонд в 600,000 руб.'
    },
    icon: <ShieldCheck className="w-16 h-16 text-green-500" />,
  },
  {
    title: { 
      tr: 'Borç Yönetimi', 
      en: 'Debt Management', 
      es: 'Gestión de Deudas', 
      fr: 'Gestion des Dettes', 
      ru: 'Управление долгами' 
    },
    content: { 
      tr: [
        '• İyi borç örnekleri: Ev kredisi (aylık 3.000 TL taksit, %1.5 faiz, ev değer kazanıyor), eğitim kredisi (aylık 800 TL, %1 faiz, gelir artışı sağlıyor), iş kredisi (makine alımı, gelir getiriyor). Kötü borç: Kredi kartı (aylık %5-8 faiz), tüketici kredisi (%3-5 faiz, değer kaybeden eşya)',
        '• Kar topu (Snowball) yöntemi örneği: 1) Kredi kartı 5.000 TL (min. 500 TL) → önce bunu kapat, 2) Tüketici kredisi 15.000 TL → sonra bunu, 3) Ev kredisi 200.000 TL → en son. Psikolojik motivasyon sağlar, küçük başarılar morali yükseltir',
        '• Çığ (Avalanche) matematik yöntemi: 1) Kredi kartı %60 yıllık faiz → önce bunu kapat, 2) Tüketici kredisi %36 faiz → sonra bunu, 3) Ev kredisi %18 faiz → en son. Matematik olarak daha az faiz ödersiniz',
        '• Borç birleştirme stratejisi: 3 kredi kartı borcunu (toplam 30.000 TL, %5-8 aylık faiz) tek ihtiyaç kredisinde (30.000 TL, %2.5 aylık faiz) birleştirin. Aylık ödeme azalır, kontrol kolaylaşır'
      ],
      en: [
        '• Good debt examples: Mortgage (monthly $1,500 payment, 4% interest, house appreciates), student loan (monthly $400, 3% interest, increases income), business loan (equipment purchase, generates income). Bad debt: Credit card (monthly 18-24% APR), consumer loan (8-15% APR, depreciating items)',
        '• Snowball method example: 1) Credit card $3,000 (min. $300) → pay this first, 2) Personal loan $8,000 → then this, 3) Mortgage $150,000 → last. Provides psychological motivation, small wins boost morale',
        '• Avalanche mathematical method: 1) Credit card 24% annual interest → pay this first, 2) Personal loan 12% interest → then this, 3) Mortgage 4% interest → last. Mathematically you pay less interest',
        '• Debt consolidation strategy: Combine 3 credit card debts (total $15,000, 18-24% APR) into single personal loan ($15,000, 8% APR). Monthly payment decreases, control becomes easier'
      ],
      es: [
        '• Ejemplos deuda buena: Hipoteca (pago mensual €800, 3% interés, casa se aprecia), préstamo estudiante (mensual €200, 2% interés, aumenta ingresos), préstamo negocio (compra equipo, genera ingresos). Deuda mala: Tarjeta crédito (mensual 15-20% TAE), préstamo consumidor (6-12% TAE, artículos depreciación)',
        '• Ejemplo método bola nieve: 1) Tarjeta crédito €2,000 (mín. €150) → pagar primero, 2) Préstamo personal €6,000 → luego esto, 3) Hipoteca €120,000 → último. Proporciona motivación psicológica, pequeños triunfos impulsan moral',
        '• Método avalancha matemático: 1) Tarjeta crédito 20% interés anual → pagar primero, 2) Préstamo personal 8% interés → luego esto, 3) Hipoteca 3% interés → último. Matemáticamente pagas menos interés',
        '• Estrategia consolidación deuda: Combinar 3 deudas tarjeta crédito (total €12,000, 15-20% TAE) en préstamo personal único (€12,000, 6% TAE). Pago mensual disminuye, control se vuelve más fácil'
      ],
      fr: [
        '• Exemples bonne dette: Hypothèque (paiement mensuel €1,000, 2.5% intérêt, maison s\'apprécie), prêt étudiant (mensuel €250, 1.5% intérêt, augmente revenus), prêt entreprise (achat équipement, génère revenus). Mauvaise dette: Carte crédit (mensuel 12-18% TAEG), prêt consommateur (4-10% TAEG, articles dépréciation)',
        '• Exemple méthode boule neige: 1) Carte crédit €2,500 (min. €180) → payer d\'abord, 2) Prêt personnel €7,000 → ensuite ceci, 3) Hypothèque €140,000 → dernier. Fournit motivation psychologique, petites victoires stimulent moral',
        '• Méthode avalanche mathématique: 1) Carte crédit 16% intérêt annuel → payer d\'abord, 2) Prêt personnel 6% intérêt → ensuite ceci, 3) Hypothèque 2.5% intérêt → dernier. Mathématiquement vous payez moins d\'intérêts',
        '• Stratégie consolidation dette: Combiner 3 dettes carte crédit (total €14,000, 12-18% TAEG) en prêt personnel unique (€14,000, 5% TAEG). Paiement mensuel diminue, contrôle devient plus facile'
      ],
      ru: [
        '• Примеры хорошего долга: Ипотека (ежемесячный платеж 80,000 руб, 8% процент, дом дорожает), образовательный кредит (ежемесячно 15,000 руб, 5% процент, увеличивает доходы), бизнес-кредит (покупка оборудования, генерирует доходы). Плохой долг: Кредитная карта (ежемесячно 25-35% годовых), потребительский кредит (15-25% годовых, обесценивающиеся товары)',
        '• Пример метода снежного кома: 1) Кредитная карта 150,000 руб (мин. 15,000 руб) → платить сначала, 2) Потребительский кредит 400,000 руб → затем это, 3) Ипотека 8,000,000 руб → последний. Обеспечивает психологическую мотивацию, малые победы поднимают моральный дух',
        '• Математический метод лавины: 1) Кредитная карта 30% годовых → платить сначала, 2) Потребительский кредит 20% → затем это, 3) Ипотека 8% → последний. Математически платите меньше процентов',
        '• Стратегия консолидации долгов: Объединить 3 долга по кредитным картам (всего 800,000 руб, 25-35% годовых) в один потребительский кредит (800,000 руб, 15% годовых). Ежемесячный платеж уменьшается, контроль становится легче'
      ]
    },
    example: { 
      tr: '⚡ 2025\'te ABD\'de öğrenci borçları ortalama 30.000 USD; bir mezun kar topu yöntemiyle 5 yılda %50 azalttı.',
      en: '⚡ In 2025, student debts in the US averaged $30,000 USD; a graduate reduced it by 50% in 5 years using the snowball method.',
      es: '⚡ En 2025, las deudas estudiantiles en España promediaron €20,000; un graduado la redujo en 50% en 5 años usando el método bola de nieve.',
      fr: '⚡ En 2025, les dettes étudiantes en France étaient en moyenne de €25,000; un diplômé l\'a réduite de 50% en 5 ans en utilisant la méthode boule de neige.',
      ru: '⚡ В 2025 году студенческие долги в России составляли в среднем 1,500,000 руб; выпускник сократил их на 50% за 5 лет, используя метод снежного кома.'
    },
    icon: <Zap className="w-16 h-16 text-orange-500" />,
  },
  {
    title: { 
      tr: 'Finansal Hatalardan Kaçınma ve Sonuç', 
      en: 'Avoiding Financial Mistakes and Conclusion', 
      es: 'Evitar Errores Financieros y Conclusión', 
      fr: 'Éviter les Erreurs Financières et Conclusion', 
      ru: 'Избегание финансовых ошибок и заключение' 
    },
    content: { 
      tr: [
        '• Yaygın finansal hatalar ve çözümleri: Duygusal harcama (üzgünken alışveriş → 24 saat bekle kuralı), FOMO yatırımları (kripto, hisse acele alımı → araştırma yap), bütçesiz yaşam (→ 50/30/20 kuralı uygula), acil fon yok (→ ilk hedef 5.000 TL)',
        '• Sürekli eğitim kaynakları: "Zengin Baba Yoksul Baba" kitabı, "Para Konuşuyor" podcast\'i, Arzum Doğan YouTube kanalı, Borsa İstanbul\'un ücretsiz webinarları, yerel bankacılık eğitimleri. Ayda 1 finansal kitap okuma hedefi koyun',
        '• Sabır ve disiplin gerçekleri: İlk 6 ay zorlayıcı (alışkanlık oluşturma), 1. yıl sonunda belirgin farklılık (10.000+ TL tasarruf), 3. yıl sonunda güven (acil fon + yatırım başlangıcı), 5. yıl sonunda özgürlük hissi',
        '• Kişisel finans başarı sonuçları: Mali özgürlük (borçsuz yaşam), stres azalması (%70 daha az finansal endişe), fırsat yakalama gücü (yatırım, iş değişikliği), gelecek güveni (emeklilik planı), ilişkilerde huzur (para tartışmaları yok)'
      ],
      en: [
        '• Common financial mistakes and solutions: Emotional spending (shopping when upset → apply 24-hour rule), FOMO investments (crypto, stock rush buying → do research), living without budget (→ apply 50/30/20 rule), no emergency fund (→ first goal $2,000)',
        '• Continuous education resources: "Rich Dad Poor Dad" book, "The Dave Ramsey Show" podcast, Suze Orman YouTube channel, free webinars from financial institutions, local banking education. Set goal to read 1 financial book per month',
        '• Patience and discipline realities: First 6 months challenging (habit formation), 1st year noticeable difference ($5,000+ savings), 3rd year confidence (emergency fund + investment start), 5th year freedom feeling',
        '• Personal finance success results: Financial freedom (debt-free living), stress reduction (70% less financial worry), opportunity capture power (investment, job change), future confidence (retirement plan), relationship peace (no money arguments)'
      ],
      es: [
        '• Errores financieros comunes y soluciones: Gasto emocional (comprar cuando molesto → aplicar regla 24 horas), inversiones FOMO (cripto, compra acciones apresurada → investigar), vivir sin presupuesto (→ aplicar regla 50/30/20), sin fondo emergencia (→ primera meta €1,500)',
        '• Recursos educación continua: Libro "Padre Rico Padre Pobre", podcast "Finanzas Para Mortales", canal YouTube de educación financiera, webinars gratuitos instituciones financieras, educación bancaria local. Establecer meta leer 1 libro financiero por mes',
        '• Realidades paciencia y disciplina: Primeros 6 meses desafiantes (formación hábito), 1er año diferencia notable (€3,500+ ahorros), 3er año confianza (fondo emergencia + inicio inversión), 5to año sensación libertad',
        '• Resultados éxito finanzas personales: Libertad financiera (vida sin deudas), reducción estrés (70% menos preocupación financiera), poder capturar oportunidades (inversión, cambio trabajo), confianza futuro (plan jubilación), paz relaciones (sin discusiones dinero)'
      ],
      fr: [
        '• Erreurs financières courantes et solutions: Dépenses émotionnelles (acheter quand contrarié → appliquer règle 24 heures), investissements FOMO (crypto, achat actions précipité → faire recherche), vivre sans budget (→ appliquer règle 50/30/20), pas fonds urgence (→ premier objectif €2,000)',
        '• Ressources éducation continue: Livre "Père Riche Père Pauvre", podcast "Les Experts de l\'Épargne", chaîne YouTube éducation financière, webinaires gratuits institutions financières, éducation bancaire locale. Fixer objectif lire 1 livre financier par mois',
        '• Réalités patience et discipline: Premiers 6 mois difficiles (formation habitude), 1ère année différence notable (€4,000+ épargne), 3ème année confiance (fonds urgence + début investissement), 5ème année sensation liberté',
        '• Résultats succès finances personnelles: Liberté financière (vie sans dettes), réduction stress (70% moins inquiétude financière), pouvoir saisir opportunités (investissement, changement travail), confiance futur (plan retraite), paix relations (pas disputes argent)'
      ],
      ru: [
        '• Распространенные финансовые ошибки и решения: Эмоциональные траты (покупки в расстройстве → применять правило 24 часов), FOMO инвестиции (криптовалюты, поспешная покупка акций → исследовать), жизнь без бюджета (→ применять правило 50/30/20), нет фонда экстренных ситуаций (→ первая цель 100,000 руб)',
        '• Ресурсы непрерывного образования: Книга "Богатый папа Бедный папа", подкаст "Деньги не спят", YouTube канал финансового образования, бесплатные вебинары финансовых учреждений, местное банковское образование. Поставить цель читать 1 финансовую книгу в месяц',
        '• Реалии терпения и дисциплины: Первые 6 месяцев сложные (формирование привычки), 1-й год заметная разница (250,000+ руб сбережений), 3-й год уверенность (фонд экстренных ситуаций + начало инвестиций), 5-й год ощущение свободы',
        '• Результаты успеха личных финансов: Финансовая свобода (жизнь без долгов), снижение стресса (на 70% меньше финансовых беспокойств), сила захвата возможностей (инвестиции, смена работы), уверенность в будущем (пенсионный план), мир в отношениях (нет споров о деньгах)'
      ]
    },
    example: { 
      tr: '🎯 2025\'te kripto çöküşünde acele edenler %50 kaybetti; sabırlı olanlar Bitcoin\'de %20 kazandı.',
      en: '🎯 In 2025, those who rushed during crypto crash lost 50%; patient ones gained 20% in Bitcoin.',
      es: '🎯 En 2025, quienes se apresuraron durante la caída cripto perdieron 50%; los pacientes ganaron 20% en Bitcoin.',
      fr: '🎯 En 2025, ceux qui se sont précipités pendant le crash crypto ont perdu 50%; les patients ont gagné 20% en Bitcoin.',
      ru: '🎯 В 2025 году те, кто поспешил во время краха криптовалют, потеряли 50%; терпеливые заработали 20% на Bitcoin.'
    },
    icon: <Brain className="w-16 h-16 text-purple-500" />,
  }
]
]