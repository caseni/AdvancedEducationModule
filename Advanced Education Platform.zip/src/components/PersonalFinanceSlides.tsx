import { DollarSign, Target, TrendingUp, BarChart3, LineChart, Coins, ShieldCheck, Zap, Heart, Coffee, Brain } from 'lucide-react'

export const personalFinanceSlides = [
  {
    title: { 
      tr: 'Kişisel Finans Nedir?', 
      en: 'What is Personal Finance?', 
      es: '¿Qué son las Finanzas Personales?', 
      fr: 'Qu\'est-ce que la Finance Personnelle?', 
      ru: 'Что такое личные финансы?' 
    },
    content: { 
      tr: [
        '• Kişisel finans, aylık gelirinizi (25.000-50.000 TL maaş, yan gelir, yatırım getirisi) planlı şekilde yönetmek, günlük harcamalarınızı (market 4.000 TL, faturalar 2.500 TL, ulaşım 800 TL) kontrol altında tutmak, tasarruf hedefleri belirleyerek düzenli para biriktirmek ve uzun vadeli finansal güvenlik için akıllı yatırımlar yapmak anlamına gelir',
        '• Temel prensipler: Her ay Gelir > Gider dengesini korumak (örn: 40.000 TL gelir varsa 32.000 TL harcayıp 8.000 TL biriktirmek), 1-5-10 yıllık finansal hedefler belirlemek (tatil, ev, emeklilik) ve beklenmedik durumlar için risk yönetimi yaparak kendimizi korumak',
        '• Finansal özgürlük sağlar: Kredi kartı borcu, tüketici kredisi gibi yüksek faizli borçlarınız olmadığında, iş yerinde baskı hissetmeden "hayır" diyebilir, hobilerinize zaman ayırabilir ve istediğiniz hayat tarzını sürdürebilirsiniz',
        '• Stres azaltır: Mali güvenlik sayesinde fatura ödeme endişesi yaşamaz, ani masraflar (araba tamiri 8.000 TL, sağlık gideri 5.000 TL) karşısında panik yapmaz, gelecek planları konusunda kendine güvenir ve daha mutlu, huzurlu bir yaşam sürersiniz'
      ],
      en: [
        '• Personal finance means managing your monthly income ($6,000-$12,000 salary, side income, investment returns) in a planned manner, controlling daily expenses (groceries $1,200, bills $800, transportation $400), setting savings goals and making smart investments for long-term financial security',
        '• Basic principles: Maintain Income > Expenses balance each month (e.g., $8,000 income spend $6,400 save $1,600), set 1-5-10 year financial goals (vacation, house, retirement), and manage risks for protection against unexpected situations',
        '• Provides financial freedom: When you have no high-interest debt like credit cards or consumer loans, you can say "no" at work without pressure, spend time on hobbies, and maintain your desired lifestyle',
        '• Reduces stress: Financial security means no bill payment anxiety, no panic over sudden expenses (car repair $2,500, medical bills $1,500), confidence in future plans, and a happier, more peaceful life'
      ],
      es: [
        '• Las finanzas personales significan gestionar tus ingresos mensuales (€2,500-€5,000 salario, ingresos secundarios, retornos de inversión) de manera planificada, controlar gastos diarios (supermercado €700, facturas €400, transporte €180), establecer objetivos de ahorro y hacer inversiones inteligentes para seguridad financiera a largo plazo',
        '• Principios básicos: Mantener balance Ingresos > Gastos cada mes (ej: €4,000 ingresos gastar €3,200 ahorrar €800), establecer objetivos financieros de 1-5-10 años (vacaciones, casa, jubilación), y gestionar riesgos para protección contra situaciones inesperadas',
        '• Proporciona libertad financiera: Cuando no tienes deudas de alto interés como tarjetas de crédito o préstamos al consumidor, puedes decir "no" en el trabajo sin presión, dedicar tiempo a aficiones y mantener el estilo de vida deseado',
        '• Reduce el estrés: La seguridad financiera significa no tener ansiedad por pagar facturas, no entrar en pánico por gastos súbitos (reparación auto €1,800, gastos médicos €1,200), confianza en planes futuros y una vida más feliz y tranquila'
      ],
      fr: [
        '• La finance personnelle signifie gérer vos revenus mensuels (€3,000-€6,000 salaire, revenus secondaires, retours d\'investissement) de manière planifiée, contrôler les dépenses quotidiennes (courses €800, factures €450, transport €200), fixer des objectifs d\'épargne et faire des investissements intelligents pour la sécurité financière à long terme',
        '• Principes de base: Maintenir l\'équilibre Revenus > Dépenses chaque mois (ex: €4,500 revenus dépenser €3,600 épargner €900), fixer des objectifs financiers de 1-5-10 ans (vacances, maison, retraite), et gérer les risques pour se protéger contre les situations imprévues',
        '• Fournit la liberté financière: Quand vous n\'avez pas de dettes à taux élevé comme les cartes de crédit ou prêts à la consommation, vous pouvez dire "non" au travail sans pression, consacrer du temps aux loisirs et maintenir le style de vie souhaité',
        '• Réduit le stress: La sécurité financière signifie pas d\'anxiété pour payer les factures, pas de panique face aux dépenses soudaines (réparation auto €2,000, frais médicaux €1,400), confiance dans les projets d\'avenir et une vie plus heureuse et paisible'
      ],
      ru: [
        '• Личные финансы означают управление ежемесячными доходами (80,000-150,000 руб зарплата, дополнительные доходы, инвестиционные доходы) планомерно, контроль ежедневных расходов (продукты 25,000 руб, счета 15,000 руб, транспорт 5,000 руб), постановка целей сбережений и умные инвестиции для долгосрочной финансовой безопасности',
        '• Основные принципы: Поддерживать баланс Доходы > Расходы каждый месяц (напр: 120,000 руб доход тратить 96,000 откладывать 24,000), ставить финансовые цели на 1-5-10 лет (отпуск, дом, пенсия), и управлять рисками для защиты от неожиданных ситуаций',
        '• Обеспечивает финансовую свободу: Когда у вас нет высокопроцентных долгов как кредитные карты или потребительские кредиты, вы можете сказать "нет" на работе без давления, тратить время на хобби и поддерживать желаемый образ жизни',
        '• Снижает стресс: Финансовая безопасность означает отсутствие беспокойства о счетах, отсутствие паники от внезапных расходов (ремонт авто 80,000 руб, медицинские счета 50,000 руб), уверенность в будущих планах и более счастливую, мирную жизнь'
      ]
    },
    example: { 
      tr: '💡 2025\'te Türkiye\'de enflasyon %47 seviyesindeyken, ortalama bir aile kişisel finans planı yaparak reel bazda yıllık %8 tasarruf artışı sağladı (kaynak: TÜİK raporları).',
      en: '💡 In 2025, while inflation in the US was around 3.2%, an average family achieved 6% annual savings growth by making a personal finance plan against inflation (source: Federal Reserve reports).',
      es: '💡 En 2025, mientras la inflación en España rondaba el 2.8%, una familia promedio logró un crecimiento del 5% en ahorros anuales haciendo un plan de finanzas personales contra la inflación (fuente: Banco de España).',
      fr: '💡 En 2025, alors que l\'inflation en France était d\'environ 2.5%, une famille moyenne a réalisé une croissance de 4.8% d\'épargne annuelle en élaborant un plan de finance personnelle contre l\'inflation (source: Banque de France).',
      ru: '💡 В 2025 году, когда инфляция в России была около 6.5%, средняя семья добилась 9% годового роста сбережений, составив план личных финансов против инфляции (источник: Центробанк РФ).'
    },
    icon: <DollarSign className="w-16 h-16 text-green-500" />,
  },
  {
    title: { 
      tr: 'Finansal Hedefler Belirleme', 
      en: 'Setting Financial Goals', 
      es: 'Establecer Objetivos Financieros', 
      fr: 'Fixer des Objectifs Financiers', 
      ru: 'Постановка финансовых целей' 
    },
    content: { 
      tr: [
        '• Kısa vadeli hedefler (6-12 ay): Yıllık tatil için 35.000 TL biriktirmek, 3 aylık acil fon oluşturmak (90.000 TL), yeni telefon/laptop almak (25.000-60.000 TL) gibi somut ve kısa sürede ulaşılabilir hedefler belirleyin',
        '• Orta vadeli hedefler (2-5 yıl): Ev peşinatı için 400.000-800.000 TL biriktirmek, sıfır araç almak için 1.200.000 TL bütçe oluşturmak, master eğitimi için 200.000 TL fon kurmak gibi önemli yaşam değişiklikleri için planlama yapın',
        '• Uzun vadeli hedefler (5+ yıl): Emeklilik için aylık 8.000 TL BES/yatırım yapmak, çocukların üniversite eğitimi için 800.000 TL fon oluşturmak, kendi işinizi kurmak için 2.000.000 TL sermaye biriktirmek gibi hayallerinizi gerçekleştirecek büyük hedefler koyun',
        '• SMART kuralı uygulaması: "1 yılda tatil için 42.000 TL biriktireceğim" → Spesifik (tatil), Ölçülebilir (42.000 TL), Ulaşılabilir (aylık 3.500 TL), İlgili (kişisel mutluluk), Zaman sınırlı (1 yıl) şeklinde net hedefler belirleyin'
      ],
      en: [
        '• Short-term goals (6-12 months): Save $8,000 for annual vacation, build 3-month emergency fund ($18,000), buy new phone/laptop ($1,500-$4,000) - concrete goals achievable in short time',
        '• Medium-term goals (2-5 years): Save $120,000-$200,000 for house down payment, budget $45,000-$65,000 for new car, create $35,000 fund for master\'s degree - plan for important life changes',
        '• Long-term goals (5+ years): Invest $1,200/month for retirement in 401k/IRA, create $250,000 education fund for children, save $500,000 capital to start your own business - big goals to realize your dreams',
        '• SMART rule application: "I will save $9,600 for vacation in 1 year" → Specific (vacation), Measurable ($9,600), Achievable ($800/month), Relevant (personal happiness), Time-bound (1 year)'
      ],
      es: [
        '• Objetivos a corto plazo (6-12 meses): Ahorrar €6,000 para vacaciones anuales, construir fondo de emergencia de 3 meses (€15,000), comprar nuevo teléfono/portátil (€1,200-€3,000) - objetivos concretos alcanzables en poco tiempo',
        '• Objetivos a mediano plazo (2-5 años): Ahorrar €80,000-€130,000 para enganche de casa, presupuestar €35,000-€55,000 para auto nuevo, crear fondo de €25,000 para máster - planificar cambios importantes de vida',
        '• Objetivos a largo plazo (5+ años): Invertir €800/mes para jubilación en planes de pensiones, crear fondo educativo de €180,000 para hijos, ahorrar €350,000 capital para iniciar negocio propio - grandes objetivos para realizar sueños',
        '• Aplicación regla SMART: "Ahorraré €7,200 para vacaciones en 1 año" → Específico (vacaciones), Medible (€7,200), Alcanzable (€600/mes), Relevante (felicidad personal), Con límite tiempo (1 año)'
      ],
      fr: [
        '• Objectifs à court terme (6-12 mois): Économiser €7,500 pour vacances annuelles, constituer fonds d\'urgence 3 mois (€18,000), acheter nouveau téléphone/ordinateur (€1,400-€3,500) - objectifs concrets atteignables rapidement',
        '• Objectifs à moyen terme (2-5 ans): Économiser €90,000-€150,000 pour acompte maison, budgéter €40,000-€60,000 pour voiture neuve, créer fonds €30,000 pour master - planifier changements vie importants',
        '• Objectifs à long terme (5+ ans): Investir €1,000/mois pour retraite dans PER/assurance-vie, créer fonds éducation €200,000 pour enfants, économiser €400,000 capital pour créer entreprise - grands objectifs réaliser rêves',
        '• Application règle SMART: "J\'économiserai €8,400 pour vacances en 1 an" → Spécifique (vacances), Mesurable (€8,400), Atteignable (€700/mois), Pertinent (bonheur personnel), Temporellement défini (1 an)'
      ],
      ru: [
        '• Краткосрочные цели (6-12 месяцев): Накопить 400,000 руб на годовой отпуск, создать фонд экстренных ситуаций на 3 месяца (1,200,000 руб), купить новый телефон/ноутбук (80,000-200,000 руб) - конкретные цели, достижимые за короткое время',
        '• Среднесрочные цели (2-5 лет): Накопить 5,000,000-8,000,000 руб для первоначального взноса за дом, заложить 3,500,000-5,500,000 руб на новую машину, создать фонд 1,500,000 руб для магистратуры - планирование важных жизненных изменений',
        '• Долгосрочные цели (5+ лет): Инвестировать 60,000 руб/месяц для пенсии в ИИС/НПФ, создать образовательный фонд 12,000,000 руб для детей, накопить 25,000,000 руб капитала для старта собственного бизнеса - большие цели для реализации мечт',
        '• Применение правила SMART: "Я накоплю 480,000 руб на отпуск за 1 год" → Конкретный (отпуск), Измеримый (480,000 руб), Достижимый (40,000 руб/месяц), Релевантный (личное счастье), Ограниченный по времени (1 год)'
      ]
    },
    example: { 
      tr: '🎯 2025\'te Türkiye\'de gençler, ev alma hedefi için aylık 15.000 TL biriktirerek 5 yılda %20 peş ödemesi topluyor; örneğin, bir yazılımcı bu yöntemle İstanbul\'da daire aldı.',
      en: '🎯 In 2025, young Americans save $2,000/month for home buying goal, collecting 20% down payment in 5 years; for example, a software developer bought a condo in Austin with this method.',
      es: '🎯 En 2025, jóvenes españoles ahorran €1,300/mes para objetivo de comprar casa, acumulando 20% de enganche en 5 años; por ejemplo, un desarrollador de software compró un piso en Madrid con este método.',
      fr: '🎯 En 2025, les jeunes français économisent €1,500/mois pour objectif d\'achat maison, accumulant 20% d\'acompte en 5 ans; par exemple, un développeur logiciel a acheté un appartement à Lyon avec cette méthode.',
      ru: '🎯 В 2025 году молодые россияне откладывают 100,000 руб/месяц для цели покупки дома, накапливая 20% первоначального взноса за 5 лет; например, разработчик ПО купил квартиру в Москве этим методом.'
    },
    icon: <Target className="w-16 h-16 text-blue-500" />,
  },
  {
    title: { 
      tr: 'Gelir Kaynaklarını Çeşitlendirme', 
      en: 'Diversifying Income Sources', 
      es: 'Diversificar Fuentes de Ingresos', 
      fr: 'Diversifier les Sources de Revenus', 
      ru: 'Диверсификация источников дохода' 
    },
    content: { 
      tr: [
        '• Ana gelir kaynağı: Tam zamanlı işinizden aldığınız aylık net maaş (30.000-60.000 TL), kendi işinizden elde ettiğiniz düzenli aylık gelir veya ortaklık payları. Bu gelir yaşam giderlerinizin %80\'ini karşılamalı',
        '• Yan gelir kaynakları: Akşam/hafta sonu freelance işleri (grafik tasarım, yazılım, çeviri), online ders verme, danışmanlık, e-ticaret mağazası işletme. Hedef: Ana gelirin %20-30\'u kadar ek gelir (6.000-15.000 TL)',
        '• Pasif gelir imkânları: Kiraladığınız daireden aylık gelir (8.000-20.000 TL), hisse senedi temettüleri (yıllık %8-15), vadeli hesap/tahvil faizi (yıllık %45-50), kitap/içerik royalty gelirleri. Uzun vadede ana gelirle eşitlenmeyi hedefleyin',
        '• Risk azaltma stratejisi: İş kaybı durumunda yan gelirleriniz temel ihtiyaçlarınızı karşılasın. Pasif gelirleriniz artarsa finansal bağımsızlığa yaklaşırsınız. 3 farklı gelir kaynağına sahip olmak ideal güvenlik sağlar'
      ],
      en: [
        '• Main income source: Monthly net salary from full-time job ($7,000-$14,000), regular monthly income from your business or partnership shares. This income should cover 80% of your living expenses',
        '• Side income sources: Evening/weekend freelance work (graphic design, software, translation), online tutoring, consulting, e-commerce store operation. Target: 20-30% additional income relative to main income ($1,400-$2,800)',
        '• Passive income opportunities: Monthly income from rental property ($2,500-$5,000), stock dividends (6-9% annually), savings account/bond interest (4-6% annually), book/content royalties. Aim to match main income long-term',
        '• Risk reduction strategy: In case of job loss, side incomes should cover basic needs. As passive income grows, you approach financial independence. Having 3 different income sources provides ideal security'
      ],
      es: [
        '• Fuente principal de ingresos: Salario neto mensual de trabajo tiempo completo (€3,500-€7,000), ingreso mensual regular de tu negocio o participaciones societarias. Este ingreso debe cubrir 80% de gastos de vida',
        '• Fuentes de ingresos secundarios: Trabajo freelance nocturno/fines de semana (diseño gráfico, software, traducción), tutoría online, consultoría, operación tienda e-commerce. Objetivo: 20-30% ingreso adicional relativo al principal (€700-€1,400)',
        '• Oportunidades ingresos pasivos: Ingreso mensual de propiedad alquilada (€1,500-€3,200), dividendos acciones (4-7% anual), interés cuenta ahorro/bonos (2-4% anual), regalías libros/contenido. Apuntar igualar ingreso principal largo plazo',
        '• Estrategia reducción riesgo: En caso pérdida empleo, ingresos secundarios deben cubrir necesidades básicas. Conforme crecen ingresos pasivos, te acercas independencia financiera. Tener 3 fuentes ingresos diferentes proporciona seguridad ideal'
      ],
      fr: [
        '• Source principale de revenus: Salaire net mensuel d\'emploi temps plein (€4,000-€8,000), revenus mensuels réguliers de votre entreprise ou parts de partenariat. Ce revenu devrait couvrir 80% de vos dépenses de vie',
        '• Sources de revenus secondaires: Travail freelance soir/week-end (design graphique, logiciel, traduction), tutorat en ligne, conseil, exploitation boutique e-commerce. Objectif: 20-30% revenus supplémentaires par rapport au principal (€800-€1,600)',
        '• Opportunités revenus passifs: Revenus mensuels de propriété locative (€1,800-€3,800), dividendes actions (3-6% annuel), intérêts compte épargne/obligations (2-4% annuel), redevances livres/contenu. Viser égaler revenu principal long terme',
        '• Stratégie réduction risque: En cas perte emploi, revenus secondaires devraient couvrir besoins basiques. À mesure que revenus passifs croissent, vous approchez indépendance financière. Avoir 3 sources revenus différentes fournit sécurité idéale'
      ],
      ru: [
        '• Основной источник дохода: Ежемесячная чистая зарплата с работы полный день (150,000-300,000 руб), регулярный месячный доход от собственного бизнеса или долей в партнерстве. Этот доход должен покрывать 80% ваших жизненных расходов',
        '• Побочные источники дохода: Вечерняя/выходная фриланс работа (графический дизайн, программирование, переводы), онлайн репетиторство, консультации, управление интернет-магазином. Цель: 20-30% дополнительного дохода относительно основного (30,000-60,000 руб)',
        '• Возможности пассивного дохода: Ежемесячный доход от сдачи жилья (80,000-180,000 руб), дивиденды по акциям (8-12% годовых), проценты по депозитам/облигациям (15-20% годовых), роялти от книг/контента. Стремитесь сравняться с основным доходом долгосрочно',
        '• Стратегия снижения рисков: В случае потери работы побочные доходы должны покрывать базовые потребности. По мере роста пассивных доходов приближаетесь к финансовой независимости. Наличие 3 разных источников дохода обеспечивает идеальную безопасность'
      ]
    },
    example: { 
      tr: '💼 2025\'te freelance platformlarında (Upwork) çalışanlar, ana maaşlarına ek %30 gelir elde ediyor; örneğin, bir grafik tasarımcı aylık 12.000 TL ekstra kazanıyor.',
      en: '💼 In 2025, workers on freelance platforms (Upwork) earn 30% additional income on top of their main salaries; for example, a graphic designer earns an extra $2,400 monthly.',
      es: '💼 En 2025, trabajadores en plataformas freelance (Upwork) obtienen 30% ingresos adicionales sobre sus salarios principales; por ejemplo, un diseñador gráfico gana €1,800 extra mensualmente.',
      fr: '💼 En 2025, les travailleurs sur plateformes freelance (Upwork) gagnent 30% revenus supplémentaires en plus de leurs salaires principaux; par exemple, un graphiste gagne €2,100 supplémentaires mensuellement.',
      ru: '💼 В 2025 году работники на фриланс-платформах (Upwork) получают 30% дополнительного дохода сверх основной зарплаты; например, графический дизайнер зарабатывает дополнительно 120,000 руб в месяц.'
    },
    icon: <TrendingUp className="w-16 h-16 text-purple-500" />,
  },
  {
    title: { 
      tr: 'Bütçe Oluşturma Temelleri', 
      en: 'Budget Creation Fundamentals', 
      es: 'Fundamentos de Creación de Presupuesto', 
      fr: 'Fondamentaux de Création de Budget', 
      ru: 'Основы создания бюджета' 
    },
    content: { 
      tr: [
        '• 50/30/20 kuralı detayı: 40.000 TL net gelirle → %50 (20.000 TL) zorunlu ihtiyaçlar (kira 12.000 TL, market 4.000 TL, faturalar 2.500 TL, ulaşım 1.500 TL), %30 (12.000 TL) kişisel istekler (dışarıda yemek, sinema, kıyafet, hobi), %20 (8.000 TL) tasarruf ve yatırım',
        '• Bütçe takip araçları önerileri: Akbank/İş Bankası mobil uygulaması harcama kategorileri, Tosla (Türkiye), YNAB (global), basit Excel şablonu veya not defterinde kategorilere ayırarak günlük harcamalarınızı kaydedin',
        '• Aylık bütçe analizi rutini: Her ayın son günü 1 saat ayırın, harcama kategorilerini gözden geçirin (hangi alanda fazla harcamış, hangi hedeflere ulaşmış), gelecek ay için düzeltmeler yapın ve yeni hedefler belirleyin',
        '• Esneklik buffer sistemi: Bütçenizin %5-10\'unu (2.000-4.000 TL) "beklenmedik giderler" kategorisinde tutun (ani araba tamiri, sağlık gideri, arkadaş düğünü hediyesi gibi). Bu para harcanmazsa tasarruf hesabına ekleyin'
      ],
      en: [
        '• 50/30/20 rule detail: With $8,000 net income → 50% ($4,000) essential needs (rent $2,400, groceries $1,000, utilities $400, transportation $200), 30% ($2,400) personal wants (dining out, movies, clothes, hobbies), 20% ($1,600) savings and investment',
        '• Budget tracking tools recommendations: Chase/Bank of America mobile app spending categories, Mint (US), YNAB (global), simple Excel template or notebook with daily expense categories',
        '• Monthly budget analysis routine: Set aside 1 hour on last day of each month, review spending categories (which areas overspent, which goals achieved), make adjustments for next month and set new targets',
        '• Flexibility buffer system: Keep 5-10% of budget ($400-$800) in "unexpected expenses" category (sudden car repair, medical expense, friend\'s wedding gift). If unspent, add to savings account'
      ],
      es: [
        '• Detalle regla 50/30/20: Con €4,000 ingresos netos → 50% (€2,000) necesidades esenciales (alquiler €1,200, supermercado €500, servicios €200, transporte €100), 30% (€1,200) deseos personales (comer fuera, cine, ropa, aficiones), 20% (€800) ahorros e inversión',
        '• Recomendaciones herramientas seguimiento presupuesto: Aplicación móvil BBVA/Santander categorías gastos, Fintonic (España), YNAB (global), plantilla Excel simple o cuaderno con categorías gastos diarios',
        '• Rutina análisis presupuesto mensual: Reservar 1 hora último día cada mes, revisar categorías gastos (qué áreas gastaron demás, qué objetivos lograron), hacer ajustes próximo mes y establecer nuevas metas',
        '• Sistema buffer flexibilidad: Mantener 5-10% presupuesto (€200-€400) en categoría "gastos inesperados" (reparación auto súbita, gasto médico, regalo boda amigo). Si no se gasta, añadir a cuenta ahorros'
      ],
      fr: [
        '• Détail règle 50/30/20: Avec €4,500 revenus nets → 50% (€2,250) besoins essentiels (loyer €1,400, courses €500, services €250, transport €100), 30% (€1,350) envies personnelles (restaurants, cinéma, vêtements, loisirs), 20% (€900) épargne et investissement',
        '• Recommandations outils suivi budget: Application mobile BNP/Crédit Agricole catégories dépenses, Bankin\' (France), YNAB (global), modèle Excel simple ou carnet avec catégories dépenses quotidiennes',
        '• Routine analyse budget mensuelle: Réserver 1 heure dernier jour chaque mois, réviser catégories dépenses (quels domaines ont dépassé, quels objectifs atteints), faire ajustements mois prochain et fixer nouvelles cibles',
        '• Système tampon flexibilité: Garder 5-10% budget (€225-€450) dans catégorie "dépenses imprévues" (réparation auto soudaine, dépense médicale, cadeau mariage ami). Si non dépensé, ajouter au compte épargne'
      ],
      ru: [
        '• Детали правила 50/30/20: С доходом 120,000 руб нетто → 50% (60,000 руб) основные потребности (аренда 40,000 руб, продукты 15,000 руб, коммунальные 8,000 руб, транспорт 7,000 руб), 30% (36,000 руб) личные желания (ресторан, кино, одежда, хобби), 20% (24,000 руб) сбережения и инвестиции',
        '• Рекомендации инструментов отслеживания бюджета: Мобильное приложение Сбербанк/ВТБ категории расходов, Дзен-мани (Россия), YNAB (глобальный), простой шаблон Excel или блокнот с категориями ежедневных расходов',
        '• Рутина анализа месячного бюджета: Выделить 1 час в последний день каждого месяца, просмотреть категории расходов (какие области превысили бюджет, какие цели достигнуты), внести корректировки на следующий месяц и установить новые цели',
        '• Система буфера гибкости: Держать 5-10% бюджета (6,000-12,000 руб) в категории "неожиданные расходы" (внезапный ремонт авто, медицинские расходы, подарок на свадьбу друга). Если не потрачено, добавить на сберегательный счет'
      ]
    },
    example: { 
      tr: '📊 2025\'te Türkiye\'de enflasyon nedeniyle aileler bütçelerini %15 optimize ederek, yıllık 48.000 TL tasarruf etti; bir İstanbul ailesi bu kuralı uygulayarak tatil fonu oluşturdu.',
      en: '📊 In 2025, due to inflation in the US, families optimized their budgets by 12%, saving $9,600 annually; an American family applied this rule and created a vacation fund.',
      es: '📊 En 2025, debido a la inflación en España, las familias optimizaron sus presupuestos en un 10%, ahorrando €4,800 anualmente; una familia española aplicó esta regla y creó un fondo de vacaciones.',
      fr: '📊 En 2025, en raison de l\'inflation en France, les familles ont optimisé leurs budgets de 9%, économisant €5,400 par an; une famille française a appliqué cette règle et créé un fonds de vacances.',
      ru: '📊 В 2025 году из-за инфляции в России семьи оптимизировали бюджеты на 8%, сэкономив 345,000 руб в год; российская семья применила это правило и создала фонд для отпуска.'
    },
    icon: <BarChart3 className="w-16 h-16 text-blue-500" />,
  },
  {
    title: { 
      tr: 'Gider Takibi ve Azaltma', 
      en: 'Expense Tracking and Reduction', 
      es: 'Seguimiento y Reducción de Gastos', 
      fr: 'Suivi et Réduction des Dépenses', 
      ru: 'Отслеживание и сокращение расходов' 
    },
    content: { 
      tr: [
        '• Harcama kategorilerini detaylı ayırın: Sabit giderler (kira 12.000 TL, sigorta 800 TL, internet 300 TL), değişken giderler (market 3.000-4.000 TL, benzin 1.500-2.000 TL, eğlence 2.000-3.000 TL), acil/beklenmedik giderler (hekim, tamir, hediye 800-2.000 TL)',
        '• Gereksiz harcama avcılığı: Netflix, Spotify, spor salonu gibi abonelikleri listeleyin (aylık 600-1.200 TL), son 3 ayda kullanmadıklarınızı iptal edin. İmpuls alışverişi engellemek için "24 saat kuralı" uygulayın (istek duyduğunuz şeyi 1 gün sonra değerlendirin)',
        '• Akıllı takip sistemleri: Banka SMS\'lerini analiz edin, haftalık harcama limitlerini belirleyin (market 1.000 TL/hafta), Papara/Tosla gibi uygulamalarda otomatik kategorilendirme aktif edin, QR kod ile fiş tarama özelliklerini kullanın',
        '• Mikro tasarruf hileleri: Günlük Starbucks (80 TL) → evde kahve (8 TL) = aylık 2.160 TL tasarruf, haftada 1 dışarıda yemek (600 TL) → evde yapma = aylık 2.400 TL tasarruf, toplu taşıma + yürüyüş → taksi yerine aylık 1.200 TL tasarruf'
      ],
      en: [
        '• Categorize expenses in detail: Fixed expenses (rent $2,400, insurance $200, internet $80), variable expenses (groceries $800-$1,200, gas $300-$500, entertainment $400-$800), emergency/unexpected expenses (doctor, repair, gifts $200-$500)',
        '• Unnecessary expense hunting: List subscriptions like Netflix, Spotify, gym ($120-$250/month), cancel ones unused in last 3 months. Apply "24-hour rule" to prevent impulse buying (evaluate desired item after 1 day)',
        '• Smart tracking systems: Analyze bank SMS alerts, set weekly spending limits (groceries $250/week), activate automatic categorization in apps like Mint/YNAB, use receipt scanning features with QR codes',
        '• Micro-saving tricks: Daily Starbucks ($8) → home coffee ($0.80) = $216/month savings, weekly dining out ($80) → home cooking = $320/month savings, public transit + walking → instead of Uber saves $240/month'
      ],
      es: [
        '• Categorizar gastos detalladamente: Gastos fijos (alquiler €1,200, seguro €120, internet €50), gastos variables (supermercado €500-€800, gasolina €200-€350, entretenimiento €250-€500), gastos emergencia/inesperados (médico, reparación, regalos €120-€300)',
        '• Caza gastos innecesarios: Listar suscripciones como Netflix, Spotify, gimnasio (€80-€180/mes), cancelar las no usadas en últimos 3 meses. Aplicar "regla 24 horas" para prevenir compras impulsivas (evaluar artículo deseado después 1 día)',
        '• Sistemas seguimiento inteligentes: Analizar alertas SMS banco, establecer límites gasto semanal (supermercado €180/semana), activar categorización automática en apps como Fintonic/YNAB, usar funciones escaneo recibos con códigos QR',
        '• Trucos micro-ahorro: Starbucks diario (€5) → café casa (€0.50) = €135/mes ahorro, cena fuera semanal (€50) → cocinar casa = €200/mes ahorro, transporte público + caminar → en lugar Uber ahorra €120/mes'
      ],
      fr: [
        '• Catégoriser dépenses en détail: Dépenses fixes (loyer €1,400, assurance €150, internet €60), dépenses variables (courses €600-€1,000, essence €250-€400, divertissement €300-€600), dépenses urgence/imprévues (médecin, réparation, cadeaux €150-€350)',
        '• Chasse dépenses inutiles: Lister abonnements comme Netflix, Spotify, salle sport (€90-€220/mois), annuler ceux non utilisés 3 derniers mois. Appliquer "règle 24 heures" prévenir achats impulsifs (évaluer article désiré après 1 jour)',
        '• Systèmes suivi intelligents: Analyser alertes SMS banque, fixer limites dépenses hebdomadaires (courses €200/semaine), activer catégorisation automatique apps comme Bankin\'/YNAB, utiliser fonctions scan reçus codes QR',
        '• Astuces micro-épargne: Starbucks quotidien (€5.50) → café maison (€0.60) = €147/mois économie, dîner dehors hebdomadaire (€60) → cuisiner maison = €240/mois économie, transport public + marche → au lieu Uber économise €140/mois'
      ],
      ru: [
        '• Детальная категоризация расходов: Фиксированные расходы (аренда 40,000 руб, страхование 8,000 руб, интернет 1,500 руб), переменные расходы (продукты 20,000-30,000 руб, бензин 12,000-18,000 руб, развлечения 15,000-25,000 руб), экстренные/неожиданные расходы (врач, ремонт, подарки 5,000-12,000 руб)',
        '• Охота на ненужные расходы: Составить список подписок Netflix, Spotify, спортзал (4,000-8,000 руб/месяц), отменить неиспользуемые последние 3 месяца. Применять "правило 24 часов" для предотвращения импульсивных покупок (оценить желаемый товар через 1 день)',
        '• Умные системы отслеживания: Анализировать SMS-уведомления банка, установить недельные лимиты трат (продукты 8,000 руб/неделя), активировать автоматическую категоризацию в приложениях Дзен-мани/YNAB, использовать функции сканирования чеков с QR-кодами',
        '• Трюки микро-экономии: Ежедневный Starbucks (500 руб) → кофе дома (50 руб) = экономия 13,500 руб/месяц, еженедельный ужин в ресторане (3,500 руб) → готовка дома = экономия 14,000 руб/месяц, общественный транспорт + ходьба → вместо такси экономия 9,000 руб/месяц'
      ]
    },
    example: { 
      tr: '☕ 2025\'te Türkiye\'de kahve zincirleri (Starbucks) harcamalarını azaltan bireyler, yıllık 25.000 TL tasarruf etti; bir ofis çalışanı app ile takip ederek araba taksitini erken bitirdi.',
      en: '☕ In 2025, individuals in the US who reduced coffee chain (Starbucks) expenses saved $2,600 annually; an office worker finished car payments early by tracking with an app.',
      es: '☕ En 2025, individuos en España que redujeron gastos en cadenas de café (Starbucks) ahorraron €1,620 anualmente; un trabajador de oficina terminó los pagos del auto temprano rastreando con una app.',
      fr: '☕ En 2025, les individus en France qui ont réduit les dépenses de chaînes de café (Starbucks) ont économisé €1,764 par an; un employé de bureau a terminé les paiements de voiture plus tôt en suivant avec une app.',
      ru: '☕ В 2025 году люди в России, которые сократили расходы на кофейные сети (Starbucks), сэкономили 162,000 руб в год; офисный работник досрочно закончил выплаты за машину, отслеживая через приложение.'
    },
    icon: <LineChart className="w-16 h-16 text-red-500" />,
  },
  {
    title: { 
      tr: 'Tasarruf Stratejileri', 
      en: 'Savings Strategies', 
      es: 'Estrategias de Ahorro', 
      fr: 'Stratégies d\'Épargne', 
      ru: 'Стратегии сбережений' 
    },
    content: { 
      tr: [
        '• Otomatik transfer disiplini: Maaş geldikten sonraki ilk gün %15-20\'sini (6.000-8.000 TL) otomatik olarak farklı bankadaki tasarruf hesabına aktarın. "Önce kendini öde" prensibi ile bu parayı hiç elinde bulundurmaması için EFT talimatı verin',
        '• Yüksek getirili hesap stratejisi: 2025\'te Türkiye\'de vadeli hesaplar %45-50 getiri veriyor. 100.000 TL\'yi 6 ay vadeli hesapta değerlendirin (22.500-25.000 TL kar). Altın, dolar, euro da enflasyon korunması için alternatif',
        '• Eğlenceli tasarruf oyunları: 52 hafta meydan okuması (1. hafta 50 TL, 2. hafta 100 TL... 52. hafta 2.600 TL = yıl sonu 67.600 TL), 365 gün 200 TL meydan okuması (günde 200 TL = yıl sonu 73.000 TL), "200 TL jar" sistemi (her gün cebinizdeki 200 TL\'leri kavanoza atın)',
        '• Hedef bankacılığı: Tatil hesabı (aylık 3.000 TL), ev peşinat hesabı (aylık 12.000 TL), acil durum hesabı (aylık 4.000 TL) açın. Her hesaba görsel etiket koyun, hedef tutarları yazın, ilerlemeyi takip edin'
      ],
      en: [
        '• Automatic transfer discipline: First day after salary, automatically transfer 15-20% ($1,200-$1,600) to savings account at different bank. Apply "pay yourself first" principle with automatic EFT instruction so you never handle this money',
        '• High-yield account strategy: In 2025 US, high-yield savings accounts offer 4.5-5.5% returns. Invest $50,000 in 6-month CD (earn $1,125-$1,375 profit). Consider Treasury bonds, I-bonds for inflation protection',
        '• Fun savings games: 52-week challenge (week 1: $20, week 2: $40... week 52: $1,040 = year-end $27,040), 365-day $10 challenge (daily $10 = year-end $3,650), "$20 jar" system (put all $20 bills from pocket into jar daily)',
        '• Goal banking: Open vacation account (monthly $800), house down payment account (monthly $3,000), emergency account (monthly $1,000). Put visual labels on each account, write target amounts, track progress'
      ],
      es: [
        '• Disciplina transferencia automática: Primer día después salario, transferir automáticamente 15-20% (€600-€800) a cuenta ahorros en banco diferente. Aplicar principio "págarte primero" con instrucción transferencia automática para nunca manejar este dinero',
        '• Estrategia cuenta alto rendimiento: En 2025 España, cuentas ahorro alto rendimiento ofrecen 2.5-3.5% retornos. Invertir €30,000 en depósito 6 meses (ganar €375-€525 beneficio). Considerar bonos estado, letras tesoro para protección inflación',
        '• Juegos ahorro divertidos: Desafío 52 semanas (semana 1: €15, semana 2: €30... semana 52: €780 = fin año €20,280), desafío 365 días €8 (diario €8 = fin año €2,920), sistema "€20 jar" (poner todos billetes €20 del bolsillo en tarro diariamente)',
        '• Banca objetivos: Abrir cuenta vacaciones (mensual €600), cuenta enganche casa (mensual €2,200), cuenta emergencia (mensual €700). Poner etiquetas visuales cada cuenta, escribir cantidades objetivo, seguir progreso'
      ],
      fr: [
        '• Discipline transfert automatique: Premier jour après salaire, transférer automatiquement 15-20% (€675-€900) vers compte épargne banque différente. Appliquer principe "se payer d\'abord" avec instruction virement automatique pour jamais manipuler cet argent',
        '• Stratégie compte haut rendement: En 2025 France, comptes épargne haut rendement offrent 3-4% retours. Investir €35,000 dans dépôt 6 mois (gagner €525-€700 profit). Considérer obligations état, livrets réglementés protection inflation',
        '• Jeux épargne amusants: Défi 52 semaines (semaine 1: €18, semaine 2: €36... semaine 52: €936 = fin année €24,336), défi 365 jours €9 (quotidien €9 = fin année €3,285), système "€20 bocal" (mettre tous billets €20 poche dans bocal quotidiennement)',
        '• Banque objectifs: Ouvrir compte vacances (mensuel €700), compte acompte maison (mensuel €2,500), compte urgence (mensuel €800). Mettre étiquettes visuelles chaque compte, écrire montants objectifs, suivre progrès'
      ],
      ru: [
        '• Дисциплина автоматических переводов: В первый день после зарплаты автоматически переводить 15-20% (22,500-30,000 руб) на сберегательный счет в другом банке. Применять принцип "сначала заплати себе" с автоматическим поручением, чтобы никогда не касаться этих денег',
        '• Стратегия высокодоходных счетов: В 2025 в России срочные вклады предлагают 15-20% доходность. Вложить 2,000,000 руб в депозит на 6 месяцев (заработать 150,000-200,000 руб прибыли). Рассмотреть ОФЗ, валютные депозиты для защиты от инфляции',
        '• Веселые игры сбережений: Вызов 52 недели (неделя 1: 1,000 руб, неделя 2: 2,000 руб... неделя 52: 52,000 руб = конец года 1,378,000 руб), вызов 365 дней по 500 руб (ежедневно 500 руб = конец года 182,500 руб), система "1,000 руб банка" (класть все банкноты 1,000 руб из кармана в банку ежедневно)',
        '• Целевое банковское дело: Открыть счет отпуска (ежемесячно 25,000 руб), счет первоначального взноса дома (ежемесячно 80,000 руб), счет экстренных ситуаций (ежемесячно 30,000 руб). Поставить визуальные ярлыки на каждый счет, написать целевые суммы, отслеживать прогресс'
      ]
    },
    example: { 
      tr: '🏦 2025\'te Türkiye\'de faiz oranları %45\'lerdeyken, vadeli hesaplar yıllık %40+ getiri sağladı; bir öğretmen 150.000 TL biriktirerek acil durum fonu kurdu.',
      en: '🏦 In 2025, when interest rates in the US were around 5.5%, high-yield savings provided 5% annual returns; a teacher saved $40,000 and established an emergency fund.',
      es: '🏦 En 2025, cuando las tasas de interés en España rondaban el 3.5%, los depósitos a plazo proporcionaron retornos anuales del 3%; un maestro ahorró €25,000 y estableció un fondo de emergencia.',
      fr: '🏦 En 2025, lorsque les taux d\'intérêt en France étaient d\'environ 4%, les dépôts à terme ont fourni des rendements annuels de 3.5%; un enseignant a économisé €30,000 et établi un fonds d\'urgence.',
      ru: '🏦 В 2025 году, когда процентные ставки в России были около 18%, срочные вклады давали 16% годовой доходности; учитель накопил 1,200,000 руб и создал фонд экстренных ситуаций.'
    },
    icon: <Coins className="w-16 h-16 text-yellow-500" />,
  },
  {
    title: { 
      tr: 'Acil Fon Oluşturma', 
      en: 'Building Emergency Fund', 
      es: 'Construir Fondo de Emergencia', 
      fr: 'Construire un Fonds d\'Urgence', 
      ru: 'Создание фонда экстренных ситуаций' 
    },
    content: { 
      tr: [
        '• Hedef tutar hesaplama: Aylık yaşam gideriniz 25.000 TL ise → 3 ay için 75.000 TL, 6 ay için 150.000 TL acil fon biriktirin. Bu kira (12.000), market (4.000), faturalar (2.500), ulaşım (1.500), diğer zorunlu giderler (5.000) toplamınızdır',
        '• Likit erişim önceliği: Acil fonunuzu vadesiz tasarruf hesabında tutun (günde 3-5 kez para çekme hakkı), vadeli hesaba koymayın (erken çekimde ceza var). ATM kartınız olsun ama günlük limit belirleyin (5.000 TL) ki gereksiz harcamayasınız',
        '• Sadece gerçek acil durumlar: İş kaybı (3-6 ay geçim), ani sağlık giderleri (ameliyat, tedavi), beklenmedik büyük tamirler (buzdolabı, araba, ev). Tatil, alışveriş, istek alımları acil durum DEĞİLDİR',
        '• Adım adım biriktirme planı: 1. ay 10.000 TL (başlangıç), 3. ay 30.000 TL (1 aylık gider), 6. ay 60.000 TL (2 aylık), 12. ay 120.000 TL (4 aylık), 18. ay 180.000 TL (6 aylık) şeklinde kademeli artırın'
      ],
      en: [
        '• Target amount calculation: If monthly living expenses $6,000 → save $18,000 for 3 months, $36,000 for 6 months emergency fund. This includes rent ($2,400), groceries ($1,200), utilities ($800), transportation ($400), other essentials ($1,200)',
        '• Liquid access priority: Keep emergency fund in no-penalty savings account (3-5 daily withdrawals allowed), don\'t put in CD (early withdrawal penalty). Have ATM card but set daily limit ($1,000) to prevent unnecessary spending',
        '• Only real emergencies: Job loss (3-6 months living), sudden medical expenses (surgery, treatment), unexpected major repairs (refrigerator, car, home). Vacation, shopping, want purchases are NOT emergencies',
        '• Step-by-step saving plan: Month 1: $2,000 (starter), Month 3: $6,000 (1-month expenses), Month 6: $12,000 (2-month), Month 12: $24,000 (4-month), Month 18: $36,000 (6-month) gradual increase'
      ],
      es: [
        '• Cálculo cantidad objetivo: Si gastos vida mensuales €4,000 → ahorrar €12,000 para 3 meses, €24,000 para 6 meses fondo emergencia. Esto incluye alquiler (€1,200), supermercado (€700), servicios (€400), transporte (€180), otros esenciales (€1,520)',
        '�� Prioridad acceso líquido: Mantener fondo emergencia en cuenta ahorros sin penalización (3-5 retiros diarios permitidos), no poner en depósito plazo (penalización retiro temprano). Tener tarjeta cajero pero establecer límite diario (€600) prevenir gasto innecesario',
        '• Solo emergencias reales: Pérdida empleo (3-6 meses vida), gastos médicos súbitos (cirugía, tratamiento), reparaciones mayores inesperadas (refrigerador, auto, casa). Vacaciones, compras, compras deseo NO son emergencias',
        '• Plan ahorro paso a paso: Mes 1: €1,200 (inicial), Mes 3: €4,000 (gastos 1 mes), Mes 6: €8,000 (2 meses), Mes 12: €16,000 (4 meses), Mes 18: €24,000 (6 meses) aumento gradual'
      ],
      fr: [
        '• Calcul montant objectif: Si dépenses vie mensuelles €4,500 → économiser €13,500 pour 3 mois, €27,000 pour 6 mois fonds urgence. Ceci inclut loyer (€1,400), courses (€800), services (€450), transport (€200), autres essentiels (€1,650)',
        '• Priorité accès liquide: Garder fonds urgence dans compte épargne sans pénalité (3-5 retraits quotidiens autorisés), ne pas mettre dans dépôt terme (pénalité retrait anticipé). Avoir carte distributeur mais fixer limite quotidienne (€700) prévenir dépense inutile',
        '• Seulement vraies urgences: Perte emploi (3-6 mois vie), dépenses médicales soudaines (chirurgie, traitement), réparations majeures inattendues (réfrigérateur, auto, maison). Vacances, achats, achats envie ne sont PAS urgences',
        '• Plan épargne étape par étape: Mois 1: €1,400 (démarrage), Mois 3: €4,500 (dépenses 1 mois), Mois 6: €9,000 (2 mois), Mois 12: €18,000 (4 mois), Mois 18: €27,000 (6 mois) augmentation graduelle'
      ],
      ru: [
        '• Расчет целевой суммы: Если ежемесячные расходы на жизнь 120,000 руб → накопить 360,000 руб на 3 месяца, 720,000 руб на 6 месяцев фонда экстренных ситуаций. Это включает аренду (40,000), продукты (25,000), коммунальные (15,000), транспорт (5,000), другие необходимые (35,000)',
        '• Приоритет ликвидного доступа: Держать фонд экстренных ситуаций на беспроцентном сберегательном счете (3-5 ежедневных снятий разрешено), не класть в срочный вклад (штраф за досрочное снятие). Иметь банкомат карту но установить дневной лимит (50,000 руб) для предотвращения ненужных трат',
        '• Только настоящие чрезвычайные ситуации: Потеря работы (3-6 месяцев жизни), внезапные медицинские расходы (операция, лечение), неожиданные крупные ремонты (холодильник, авто, дом). Отпуск, покупки, покупки желаний НЕ являются чрезвычайными ситуациями',
        '• Пошаговый план сбережений: Месяц 1: 60,000 руб (стартовый), Месяц 3: 120,000 руб (расходы 1 месяц), Месяц 6: 240,000 руб (2 месяца), Месяц 12: 480,000 руб (4 месяца), Месяц 18: 720,000 руб (6 месяцев) постепенное увеличение'
      ]
    },
    example: { 
      tr: '🛡️ 2025\'te pandemi sonrası işsizlik dalgasında, acil fonu olan bireyler %40 daha az stres yaşadı; bir freelancer 100.000 TL fonla 3 ay geçindi.',
      en: '🛡️ In 2025, during post-pandemic unemployment waves, individuals with emergency funds experienced 40% less stress; a freelancer survived 3 months with a $24,000 fund.',
      es: '🛡️ En 2025, durante las olas de desempleo post-pandemia, individuos con fondos de emergencia experimentaron 40% menos estrés; un freelancer sobrevivió 3 meses con un fondo de €16,000.',
      fr: '🛡️ En 2025, pendant les vagues de chômage post-pandémie, les individus avec des fonds d\'urgence ont connu 40% moins de stress; un freelancer a survécu 3 mois avec un fonds de €18,000.',
      ru: '🛡️ В 2025 году, во время волн безработицы после пандемии, люди с фондами экстренных ситуаций испытывали на 40% меньше стресса; фрилансер прожил 3 месяца на фонд в 900,000 руб.'
    },
    icon: <ShieldCheck className="w-16 h-16 text-green-500" />,
  },
  {
    title: { 
      tr: 'Borç Yönetimi', 
      en: 'Debt Management', 
      es: 'Gestión de Deudas', 
      fr: 'Gestion des Dettes', 
      ru: 'Управление долгами' 
    },
    content: { 
      tr: [
        '• İyi borç örnekleri: Ev kredisi (aylık 12.000 TL taksit, %3 faiz, ev değer kazanıyor), eğitim kredisi (aylık 3.000 TL, %2 faiz, gelir artışı sağlıyor), iş kredisi (makine alımı, gelir getiriyor). Kötü borç: Kredi kartı (aylık %8-12 faiz), tüketici kredisi (%5-8 faiz, değer kaybeden eşya)',
        '• Kar topu (Snowball) yöntemi örneği: 1) Kredi kartı 25.000 TL (min. 2.500 TL) → önce bunu kapat, 2) Tüketici kredisi 80.000 TL → sonra bunu, 3) Ev kredisi 800.000 TL → en son. Psikolojik motivasyon sağlar, küçük başarılar morali yükseltir',
        '• Çığ (Avalanche) matematik yöntemi: 1) Kredi kartı %120 yıllık faiz → önce bunu kapat, 2) Tüketici kredisi %60 faiz → sonra bunu, 3) Ev kredisi %36 faiz → en son. Matematik olarak daha az faiz ödersiniz',
        '• Borç birleştirme stratejisi: 3 kredi kartı borcunu (toplam 120.000 TL, %8-12 aylık faiz) tek ihtiyaç kredisinde (120.000 TL, %4 aylık faiz) birleştirin. Aylık ödeme azalır, kontrol kolaylaşır'
      ],
      en: [
        '• Good debt examples: Mortgage (monthly $3,000 payment, 6% interest, house appreciates), student loan (monthly $800, 4% interest, increases income), business loan (equipment purchase, generates income). Bad debt: Credit card (monthly 18-28% APR), consumer loan (12-20% APR, depreciating items)',
        '• Snowball method example: 1) Credit card $8,000 (min. $800) → pay this first, 2) Personal loan $20,000 → then this, 3) Mortgage $300,000 → last. Provides psychological motivation, small wins boost morale',
        '• Avalanche mathematical method: 1) Credit card 24% annual interest → pay this first, 2) Personal loan 15% interest → then this, 3) Mortgage 6% interest → last. Mathematically you pay less interest',
        '• Debt consolidation strategy: Combine 3 credit card debts (total $30,000, 20-28% APR) into single personal loan ($30,000, 12% APR). Monthly payment decreases, control becomes easier'
      ],
      es: [
        '• Ejemplos deuda buena: Hipoteca (pago mensual €1,600, 4% interés, casa se aprecia), préstamo estudiante (mensual €500, 3% interés, aumenta ingresos), préstamo negocio (compra equipo, genera ingresos). Deuda mala: Tarjeta crédito (mensual 18-25% TAE), préstamo consumidor (10-18% TAE, artículos depreciación)',
        '• Ejemplo método bola nieve: 1) Tarjeta crédito €5,000 (mín. €350) → pagar primero, 2) Préstamo personal €15,000 → luego esto, 3) Hipoteca €180,000 → último. Proporciona motivación psicológica, pequeños triunfos impulsan moral',
        '• Método avalancha matemático: 1) Tarjeta crédito 22% interés anual → pagar primero, 2) Préstamo personal 12% interés → luego esto, 3) Hipoteca 4% interés → último. Matemáticamente pagas menos interés',
        '• Estrategia consolidación deuda: Combinar 3 deudas tarjeta crédito (total €20,000, 18-25% TAE) en préstamo personal único (€20,000, 10% TAE). Pago mensual disminuye, control se vuelve más fácil'
      ],
      fr: [
        '• Exemples bonne dette: Hypothèque (paiement mensuel €1,800, 3.5% intérêt, maison s\'apprécie), prêt étudiant (mensuel €600, 2.5% intérêt, augmente revenus), prêt entreprise (achat équipement, génère revenus). Mauvaise dette: Carte crédit (mensuel 15-22% TAEG), prêt consommateur (8-15% TAEG, articles dépréciation)',
        '• Exemple méthode boule neige: 1) Carte crédit €6,000 (min. €420) → payer d\'abord, 2) Prêt personnel €18,000 → ensuite ceci, 3) Hypothèque €200,000 → dernier. Fournit motivation psychologique, petites victoires stimulent moral',
        '• Méthode avalanche mathématique: 1) Carte crédit 19% intérêt annuel → payer d\'abord, 2) Prêt personnel 9% intérêt → ensuite ceci, 3) Hypothèque 3.5% intérêt → dernier. Mathématiquement vous payez moins d\'intérêts',
        '• Stratégie consolidation dette: Combiner 3 dettes carte crédit (total €22,000, 15-22% TAEG) en prêt personnel unique (€22,000, 8% TAEG). Paiement mensuel diminue, contrôle devient plus facile'
      ],
      ru: [
        '• Примеры хорошего долга: Ипотека (ежемесячный платеж 120,000 руб, 12% процент, дом дорожает), образовательный кредит (ежемесячно 25,000 руб, 8% процент, увеличивает доходы), бизнес-кредит (поку��ка оборудования, генерирует доходы). Плохой долг: Кредитная карта (ежемесячно 30-40% годовых), потребительский кредит (20-30% годовых, обесценивающиеся товары)',
        '• Пример метода снежного кома: 1) Кредитная карта 400,000 руб (мин. 40,000 руб) → платить сначала, 2) Потребительский кредит 1,200,000 руб → затем это, 3) Ипотека 15,000,000 руб → последний. Обеспечивает психологическую мотивацию, малые победы поднимают моральный дух',
        '• Математический метод лавины: 1) Кредитная карта 35% годовых → платить сначала, 2) Потребительский кредит 25% → затем это, 3) Ипотека 12% → последний. Математически платите меньше процентов',
        '• Стратегия консолидации долгов: Объединить 3 долга по кредитным картам (всего 2,000,000 руб, 30-40% годовых) в один потребительский кредит (2,000,000 руб, 20% годовых). Ежемесячный платеж уменьшается, контроль становится легче'
      ]
    },
    example: { 
      tr: '⚡ 2025\'te Türkiye\'de öğrenci borçları ortalama 150.000 TL; bir mezun kar topu yöntemiyle 5 yılda %50 azalttı.',
      en: '⚡ In 2025, student debts in the US averaged $45,000; a graduate reduced it by 50% in 5 years using the snowball method.',
      es: '⚡ En 2025, las deudas estudiantiles en España promediaron €30,000; un graduado la redujo en 50% en 5 años usando el método bola de nieve.',
      fr: '⚡ En 2025, les dettes étudiantes en France étaient en moyenne de €35,000; un diplômé l\'a réduite de 50% en 5 ans en utilisant la méthode boule de neige.',
      ru: '⚡ В 2025 году студенческие долги в России составляли в среднем 2,500,000 руб; выпускник сократил их на 50% за 5 лет, используя метод снежного кома.'
    },
    icon: <Zap className="w-16 h-16 text-orange-500" />,
  },
  {
    title: { 
      tr: 'Finansal Hatalardan Kaçınma ve Sonuç', 
      en: 'Avoiding Financial Mistakes and Conclusion', 
      es: 'Evitar Errores Financieros y Conclusión', 
      fr: 'Éviter les Erreurs Financières et Conclusion', 
      ru: 'Избегание финансовых ошибок и заключение' 
    },
    content: { 
      tr: [
        '• Yaygın finansal hatalar ve çözümleri: Duygusal harcama (üzgünken alışveriş → 24 saat bekle kuralı), FOMO yatırımları (kripto, hisse acele alımı → araştırma yap), bütçesiz yaşam (→ 50/30/20 kuralı uygula), acil fon yok (→ ilk hedef 25.000 TL)',
        '• Sürekli eğitim kaynakları: "Zengin Baba Yoksul Baba" kitabı, "Para Konuşuyor" podcast\'i, Arzum Doğan YouTube kanalı, Borsa İstanbul\'un ücretsiz webinarları, yerel bankacılık eğitimleri. Ayda 1 finansal kitap okuma hedefi koyun',
        '• Sabır ve disiplin gerçekleri: İlk 6 ay zorlayıcı (alışkanlık oluşturma), 1. yıl sonunda belirgin farklılık (50.000+ TL tasarruf), 3. yıl sonunda güven (acil fon + yatırım başlangıcı), 5. yıl sonunda özgürlük hissi',
        '• Kişisel finans başarı sonuçları: Mali özgürlük (borçsuz yaşam), stres azalması (%70 daha az finansal endişe), fırsat yakalama gücü (yatırım, iş değişikliği), gelecek güveni (emeklilik planı), ilişkilerde huzur (para tartışmaları yok)'
      ],
      en: [
        '• Common financial mistakes and solutions: Emotional spending (shopping when upset → apply 24-hour rule), FOMO investments (crypto, stock rush buying → do research), living without budget (→ apply 50/30/20 rule), no emergency fund (→ first goal $5,000)',
        '• Continuous education resources: "Rich Dad Poor Dad" book, "The Dave Ramsey Show" podcast, Suze Orman YouTube channel, free webinars from financial institutions, local banking education. Set goal to read 1 financial book per month',
        '• Patience and discipline realities: First 6 months challenging (habit formation), 1st year noticeable difference ($12,000+ savings), 3rd year confidence (emergency fund + investment start), 5th year freedom feeling',
        '• Personal finance success results: Financial freedom (debt-free living), stress reduction (70% less financial worry), opportunity capture power (investment, job change), future confidence (retirement plan), relationship peace (no money arguments)'
      ],
      es: [
        '• Errores financieros comunes y soluciones: Gasto emocional (comprar cuando molesto → aplicar regla 24 horas), inversiones FOMO (cripto, compra acciones apresurada → investigar), vivir sin presupuesto (→ aplicar regla 50/30/20), sin fondo emergencia (→ primera meta €3,000)',
        '• Recursos educación continua: Libro "Padre Rico Padre Pobre", podcast "Finanzas Para Mortales", canal YouTube de educación financiera, webinars gratuitos instituciones financieras, educación bancaria local. Establecer meta leer 1 libro financiero por mes',
        '• Realidades paciencia y disciplina: Primeros 6 meses desafiantes (formación hábito), 1er año diferencia notable (€8,000+ ahorros), 3er año confianza (fondo emergencia + inicio inversión), 5to año sensación libertad',
        '• Resultados éxito finanzas personales: Libertad financiera (vida sin deudas), reducción estrés (70% menos preocupación financiera), poder capturar oportunidades (inversión, cambio trabajo), confianza futuro (plan jubilación), paz relaciones (sin discusiones dinero)'
      ],
      fr: [
        '• Erreurs financières courantes et solutions: Dépenses émotionnelles (acheter quand contrarié → appliquer règle 24 heures), investissements FOMO (crypto, achat actions précipité → faire recherche), vivre sans budget (→ appliquer règle 50/30/20), pas fonds urgence (→ premier objectif €3,500)',
        '• Ressources éducation continue: Livre "Père Riche Père Pauvre", podcast "Les Experts de l\'Épargne", chaîne YouTube éducation financière, webinaires gratuits institutions financières, éducation bancaire locale. Fixer objectif lire 1 livre financier par mois',
        '• Réalités patience et discipline: Premiers 6 mois difficiles (formation habitude), 1ère année différence notable (€9,000+ épargne), 3ème année confiance (fonds urgence + début investissement), 5ème année sensation liberté',
        '• Résultats succès finances personnelles: Liberté financière (vie sans dettes), réduction stress (70% moins inquiétude financière), pouvoir saisir opportunités (investissement, changement travail), confiance futur (plan retraite), paix relations (pas disputes argent)'
      ],
      ru: [
        '• Распространенные финансовые ошибки и решения: Эмоциональные траты (покупки в расстройстве → применять правило 24 часов), FOMO инвестиции (криптовалюты, поспешная покупка акций → исследовать), жизнь без бюджета (→ применять правило 50/30/20), нет фонда экстренных ситуаций (→ первая цель 200,000 руб)',
        '• Ресурсы непрерывного образования: Книга "Богатый папа Бедный папа", подкаст "Деньги не спят", YouTube канал финансового образования, бесплатные вебинары финансовых учреждений, местное банковское образование. Поставить цель читать 1 финансовую книгу в месяц',
        '• Реалии терпения и дисциплины: Первые 6 месяцев сложные (формирование привычки), 1-й год заметная разница (600,000+ руб сбережений), 3-й год уверенность (фонд экстренных ситуаций + начало инвестиций), 5-й год ощущение свободы',
        '• Результаты успеха личных финансов: Финансовая свобода (жизнь без долгов), снижение стресса (на 70% меньше финансовых беспокойств), сила захвата возможностей (инвестиции, смена работы), уверенность в будущем (пенсионный план), мир в отношениях (нет споров о деньгах)'
      ]
    },
    example: { 
      tr: '🎯 2025\'te kripto çöküşünde acele edenler %50 kaybetti; sabırlı olanlar Bitcoin\'de %20 kazandı.',
      en: '🎯 In 2025, those who rushed during crypto crash lost 50%; patient ones gained 20% in Bitcoin.',
      es: '🎯 En 2025, quienes se apresuraron durante la caída cripto perdieron 50%; los pacientes ganaron 20% en Bitcoin.',
      fr: '🎯 En 2025, ceux qui se sont précipités pendant le crash crypto ont perdu 50%; les patients ont gagné 20% en Bitcoin.',
      ru: '🎯 В 2025 году те, кто поспешил во время краха криптовалют, потеряли 50%; терпеливые заработали 20% на Bitcoin.'
    },
    icon: <Brain className="w-16 h-16 text-purple-500" />,
  }
]

// Quiz soruları
export const personalFinanceQuiz = [
  // 1. Kişisel Finans Nedir? - Quiz
  {
    id: 1,
    question: {
      tr: 'Kişisel finansın temel amacı nedir?',
      en: 'What is the main purpose of personal finance?',
      es: '¿Cuál es el propósito principal de las finanzas personales?',
      fr: 'Quel est l\'objectif principal de la finance personnelle?',
      ru: 'Какова основная цель личных финансов?',
      de: 'Was ist das Hauptziel der persönlichen Finanzen?',
      pt: 'Qual é o objetivo principal das finanças pessoais?'
    },
    type: 'multiple-choice',
    answers: {
      tr: [
        'Daha çok harcama yapmak',
        'Para yönetimini planlayarak hedeflere ulaşmak',
        'Banka kredisi kullanmak',
        'Sadece yatırım yapmak'
      ],
      en: [
        'Spending more money',
        'Managing money planning to reach goals',
        'Using bank loans',
        'Only investing'
      ],
      es: [
        'Gastar más dinero',
        'Gestionar la planificación del dinero para alcanzar objetivos',
        'Usar préstamos bancarios',
        'Solo invertir'
      ],
      fr: [
        'Dépenser plus d\'argent',
        'Gérer la planification de l\'argent pour atteindre les objectifs',
        'Utiliser des prêts bancaires',
        'Seulement investir'
      ],
      ru: [
        'Тратить больше денег',
        'Управлять планированием денег для достижения целей',
        'Использовать банковские кредиты',
        'Только инвестировать'
      ],
      de: [
        'Mehr Geld ausgeben',
        'Geldplanung verwalten, um Ziele zu erreichen',
        'Bankkredite nutzen',
        'Nur investieren'
      ],
      pt: [
        'Gastar mais dinheiro',
        'Gerenciar o planejamento de dinheiro para atingir objetivos',
        'Usar empréstimos bancários',
        'Apenas investir'
      ]
    },
    correct: 1,
    explanation: {
      tr: 'Kişisel finansın temel amacı, para yönetimini planlayarak finansal hedeflere ulaşmak ve finansal güvenlik sağlamaktır.',
      en: 'The main purpose of personal finance is to reach financial goals and achieve financial security through planned money management.',
      es: 'El propósito principal de las finanzas personales es alcanzar objetivos financieros y lograr seguridad financiera a través de la gestión planificada del dinero.',
      fr: 'L\'objectif principal de la finance personnelle est d\'atteindre les objectifs financiers et d\'assurer la sécurité financière grâce à une gestion planifiée de l\'argent.',
      ru: 'Основная цель личных финансов - достижение финансовых целей и обеспечение финансовой безопасности через планомерное управление деньгами.',
      de: 'Das Hauptziel der persönlichen Finanzen ist es, finanzielle Ziele zu erreichen und finanzielle Sicherheit durch geplante Geldverwaltung zu gewährleisten.',
      pt: 'O objetivo principal das finanças pessoais é atingir objetivos financeiros e conseguir segurança financeira através da gestão planejada do dinheiro.'
    }
  },
  {
    id: 2,
    question: {
      tr: 'Acil fon genellikle kaç aylık gideri kapsamalıdır?',
      en: 'How many months of expenses should an emergency fund typically cover?',
      es: '¿Cuántos meses de gastos debería cubrir típicamente un fondo de emergencia?',
      fr: 'Combien de mois de dépenses un fonds d\'urgence devrait-il généralement couvrir?',
      ru: 'Сколько месяцев расходов должен покрывать аварийный фонд?',
      de: 'Wie viele Monate Ausgaben sollte ein Notfallfonds typischerweise abdecken?',
      pt: 'Quantos meses de despesas um fundo de emergência deveria cobrir tipicamente?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['1–2 ay', '3–6 ay', '12 ay', 'Sadece borç bitene kadar'],
      en: ['1–2 months', '3–6 months', '12 months', 'Only until debt is paid'],
      es: ['1–2 meses', '3–6 meses', '12 meses', 'Solo hasta que se pague la deuda'],
      fr: ['1–2 mois', '3–6 mois', '12 mois', 'Seulement jusqu\'à ce que la dette soit payée'],
      ru: ['1–2 месяца', '3–6 месяцев', '12 месяцев', 'Только до погашения долга'],
      de: ['1–2 Monate', '3–6 Monate', '12 Monate', 'Nur bis die Schulden bezahlt sind'],
      pt: ['1–2 meses', '3–6 meses', '12 meses', 'Apenas até a dívida ser paga']
    },
    correct: 1,
    explanation: {
      tr: 'Acil fon genellikle 3-6 aylık yaşam giderini kapsamalıdır. Bu, iş kaybı veya beklenmedik durumlar için yeterli güvenlik sağlar.',
      en: 'An emergency fund should typically cover 3-6 months of living expenses. This provides adequate security for job loss or unexpected situations.',
      es: 'Un fondo de emergencia debería cubrir típicamente 3-6 meses de gastos de vida. Esto proporciona seguridad adecuada para pérdida de empleo o situaciones inesperadas.',
      fr: 'Un fonds d\'urgence devrait généralement couvrir 3-6 mois de frais de subsistance. Cela fournit une sécurité adéquate pour la perte d\'emploi ou les situations inattendues.',
      ru: 'Аварийный фонд должен покрывать 3-6 месяцев расходов на жизнь. Это обеспечивает адекватную безопасность при потере работы или неожиданных ситуациях.',
      de: 'Ein Notfallfonds sollte typischerweise 3-6 Monate Lebenshaltungskosten abdecken. Dies bietet angemessene Sicherheit bei Jobverlust oder unerwarteten Situationen.',
      pt: 'Um fundo de emergência deveria cobrir tipicamente 3-6 meses de despesas de vida. Isso fornece segurança adequada para perda de emprego ou situações inesperadas.'
    }
  },
  {
    id: 3,
    question: {
      tr: 'Aşağıdakilerden hangisi finansal wellness göstergesidir?',
      en: 'Which of the following is an indicator of financial wellness?',
      es: '¿Cuál de los siguientes es un indicador de bienestar financiero?',
      fr: 'Lequel des éléments suivants est un indicateur de bien-être financier?',
      ru: 'Что из следующего является показателем финансового благополучия?',
      de: 'Welches der folgenden ist ein Indikator für finanzielles Wohlbefinden?',
      pt: 'Qual dos seguintes é um indicador de bem-estar financeiro?'
    },
    type: 'multiple-choice',
    answers: {
      tr: [
        'Sürekli borç stresi yaşamak',
        'Beklenmedik giderleri rahat karşılayabilmek',
        'Daha çok kredi kartı açmak',
        'Lüks tüketimi artırmak'
      ],
      en: [
        'Constantly experiencing debt stress',
        'Being able to comfortably handle unexpected expenses',
        'Opening more credit cards',
        'Increasing luxury consumption'
      ],
      es: [
        'Experimentar constantemente estrés por deudas',
        'Poder manejar cómodamente gastos inesperados',
        'Abrir más tarjetas de crédito',
        'Aumentar el consumo de lujo'
      ],
      fr: [
        'Éprouver constamment du stress lié aux dettes',
        'Pouvoir gérer confortablement les dépenses imprévues',
        'Ouvrir plus de cartes de crédit',
        'Augmenter la consommation de luxe'
      ],
      ru: [
        'Постоянно испытывать стресс от долгов',
        'Уметь комфортно справляться с неожиданными расходами',
        'Открывать больше кредитных карт',
        'Увеличивать роскошное потребление'
      ],
      de: [
        'Ständig Schuldenstress erleben',
        'Unerwartete Ausgaben bequem bewältigen können',
        'Mehr Kreditkarten eröffnen',
        'Luxuskonsum steigern'
      ],
      pt: [
        'Experimentar constantemente estresse de dívidas',
        'Ser capaz de lidar confortavelmente com despesas inesperadas',
        'Abrir mais cartões de crédito',
        'Aumentar o consumo de luxo'
      ]
    },
    correct: 1,
    explanation: {
      tr: 'Beklenmedik giderleri rahat karşılayabilmek, finansal wellness\'ın temel göstergelerinden biridir. Bu, acil fon ve iyi finansal planlama sayesinde mümkün olur.',
      en: 'Being able to comfortably handle unexpected expenses is one of the key indicators of financial wellness. This is possible through emergency funds and good financial planning.',
      es: 'Poder manejar cómodamente gastos inesperados es uno de los indicadores clave del bienestar financiero. Esto es posible a través de fondos de emergencia y buena planificación financiera.',
      fr: 'Pouvoir gérer confortablement les dépenses imprévues est l\'un des indicateurs clés du bien-être financier. Cela est possible grâce aux fonds d\'urgence et à une bonne planification financière.',
      ru: 'Способность комфортно справляться с неожиданными расходами - один из ключевых показателей финансового благополучия. Это возможно благодаря аварийным фондам и хорошему финансовому планированию.',
      de: 'Unerwartete Ausgaben bequem bewältigen zu können ist einer der Schlüsselindikatoren für finanzielles Wohlbefinden. Dies ist durch Notfallfonds und gute Finanzplanung möglich.',
      pt: 'Ser capaz de lidar confortavelmente com despesas inesperadas é um dos principais indicadores de bem-estar financeiro. Isso é possível através de fundos de emergência e bom planejamento financeiro.'
    }
  },
  {
    id: 4,
    question: {
      tr: 'Kahveye günlük 80 TL harcamanın uzun vadeli maliyeti hangi kavramla açıklanır?',
      en: 'What concept explains the long-term cost of spending $8 daily on coffee?',
      es: '¿Qué concepto explica el costo a largo plazo de gastar $8 diarios en café?',
      fr: 'Quel concept explique le coût à long terme de dépenser 8€ par jour en café?',
      ru: 'Какая концепция объясняет долгосрочную стоимость ежедневных трат 500 рублей на кофе?',
      de: 'Welches Konzept erklärt die langfristigen Kosten von täglich 8€ für Kaffee?',
      pt: 'Qual conceito explica o custo a longo prazo de gastar $8 diários em café?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['Oportunite maliyeti', 'Nakit akışı', 'Değerleme', 'Portföy yönetimi'],
      en: ['Opportunity cost', 'Cash flow', 'Valuation', 'Portfolio management'],
      es: ['Costo de oportunidad', 'Flujo de caja', 'Valoración', 'Gestión de cartera'],
      fr: ['Coût d\'opportunité', 'Flux de trésorerie', 'Évaluation', 'Gestion de portefeuille'],
      ru: ['Альтернативная стоимость', 'Денежный поток', 'Оценка', 'Управление портфелем'],
      de: ['Opportunitätskosten', 'Cashflow', 'Bewertung', 'Portfoliomanagement'],
      pt: ['Custo de oportunidade', 'Fluxo de caixa', 'Avaliação', 'Gestão de portfólio']
    },
    correct: 0,
    explanation: {
      tr: 'Oportunite maliyeti, bir seçeneği tercih ettiğimizde vazgeçtiğimiz diğer seçeneklerin değeridir. Günlük kahve parası ile tasarruf veya yatırım yapabilirdik.',
      en: 'Opportunity cost is the value of alternatives we give up when choosing one option. The daily coffee money could have been saved or invested instead.',
      es: 'El costo de oportunidad es el valor de las alternativas que renunciamos al elegir una opción. El dinero diario del café podría haberse ahorrado o invertido en su lugar.',
      fr: 'Le coût d\'opportunité est la valeur des alternatives auxquelles nous renonçons en choisissant une option. L\'argent quotidien du café aurait pu être économisé ou investi à la place.',
      ru: 'Альтернативная стоимость - это ценность альтернатив, от которых мы отказываемся, выбирая один вариант. Ежедневные деньги на кофе могли бы быть сбережены или инвестированы.',
      de: 'Opportunitätskosten sind der Wert der Alternativen, auf die wir verzichten, wenn wir eine Option wählen. Das tägliche Kaffeegeld hätte stattdessen gespart oder investiert werden können.',
      pt: 'Custo de oportunidade é o valor das alternativas que abandonamos ao escolher uma opção. O dinheiro diário do café poderia ter sido poupado ou investido em vez disso.'
    }
  },
  {
    id: 5,
    question: {
      tr: 'Uzun vadeli hedeflerden biri değildir:',
      en: 'Which is NOT a long-term goal:',
      es: 'Cuál NO es un objetivo a largo plazo:',
      fr: 'Lequel n\'est PAS un objectif à long terme:',
      ru: 'Что НЕ является долгосрочной целью:',
      de: 'Was ist KEIN langfristiges Ziel:',
      pt: 'O que NÃO é um objetivo de longo prazo:'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['Emeklilik planı', 'Ev alma', 'Çocuk eğitimi', 'Günlük market alışverişi'],
      en: ['Retirement plan', 'Buying a house', 'Child education', 'Daily grocery shopping'],
      es: ['Plan de jubilación', 'Comprar una casa', 'Educación infantil', 'Compras diarias de supermercado'],
      fr: ['Plan de retraite', 'Acheter une maison', 'Éducation des enfants', 'Courses quotidiennes'],
      ru: ['Пенсионный план', 'Покупка дома', 'Образование детей', 'Ежедневные покупки продуктов'],
      de: ['Rentenplan', 'Hauskauf', 'Kindererziehung', 'Tägliche Lebensmitteleinkäufe'],
      pt: ['Plano de aposentadoria', 'Comprar uma casa', 'Educação dos filhos', 'Compras diárias no supermercado']
    },
    correct: 3,
    explanation: {
      tr: 'Günlük market alışverişi kısa vadeli, rutin bir giderdir. Emeklilik, ev alma ve çocuk eğitimi uzun vadeli finansal hedeflerdir.',
      en: 'Daily grocery shopping is a short-term, routine expense. Retirement, house buying, and child education are long-term financial goals.',
      es: 'Las compras diarias de supermercado son un gasto rutinario a corto plazo. La jubilación, comprar una casa y la educación infantil son objetivos financieros a largo plazo.',
      fr: 'Les courses quotidiennes sont une dépense routinière à court terme. La retraite, l\'achat d\'une maison et l\'éducation des enfants sont des objectifs financiers à long terme.',
      ru: 'Ежедневные покупки продуктов - это краткосрочные, рутинные расходы. Пенсия, покупка дома и образование детей - долгосрочные финансовые цели.',
      de: 'Tägliche Lebensmitteleinkäufe sind kurzfristige, routinemäßige Ausgaben. Rente, Hauskauf und Kindererziehung sind langfristige finanzielle Ziele.',
      pt: 'Compras diárias no supermercado são despesas rotineiras de curto prazo. Aposentadoria, comprar uma casa e educação dos filhos são objetivos financeiros de longo prazo.'
    }
  },

  // 2. Bütçe Oluşturma Temelleri - Quiz
  {
    id: 6,
    question: {
      tr: '50/30/20 kuralında %20 hangi alana ayrılır?',
      en: 'In the 50/30/20 rule, what is the 20% allocated to?',
      es: 'En la regla 50/30/20, ¿a qué se destina el 20%?',
      fr: 'Dans la règle 50/30/20, à quoi sont alloués les 20% ?',
      ru: 'В правиле 50/30/20, на что выделяется 20%?',
      de: 'In der 50/30/20-Regel, wofür werden die 20% verwendet?',
      pt: 'Na regra 50/30/20, para que são destinados os 20%?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['Borç ödemeleri', 'İstekler', 'Tasarruf ve yatırım', 'Lüks alışveriş'],
      en: ['Debt payments', 'Wants', 'Savings and investment', 'Luxury shopping'],
      es: ['Pagos de deuda', 'Deseos', 'Ahorros e inversión', 'Compras de lujo'],
      fr: ['Paiements de dettes', 'Envies', 'Épargne et investissement', 'Achats de luxe'],
      ru: ['Выплаты по долгам', 'Желания', 'Сбережения и инвестиции', 'Роскошные покупки'],
      de: ['Schuldenzahlungen', 'Wünsche', 'Sparen und Investition', 'Luxuseinkäufe'],
      pt: ['Pagamentos de dívidas', 'Desejos', 'Poupança e investimento', 'Compras de luxo']
    },
    correct: 2,
    explanation: {
      tr: '50/30/20 kuralında %20\'lik kısım tasarruf ve yatırımlara ayrılır. Bu, finansal geleceğinizi güvence altına almak için kritik bir orandır.',
      en: 'In the 50/30/20 rule, the 20% portion is allocated to savings and investments. This is a critical percentage for securing your financial future.',
      es: 'En la regla 50/30/20, la porción del 20% se destina a ahorros e inversiones. Este es un porcentaje crítico para asegurar tu futuro financiero.',
      fr: 'Dans la règle 50/30/20, la portion de 20% est allouée à l\'épargne et aux investissements. C\'est un pourcentage critique pour sécuriser votre avenir financier.',
      ru: 'В правиле 50/30/20, 20% выделяется на сбережения и инвестиции. Это критический процент для обеспечения вашего финансового будущего.',
      de: 'In der 50/30/20-Regel werden die 20% für Sparen und Investitionen verwendet. Dies ist ein kritischer Prozentsatz zur Sicherung Ihrer finanziellen Zukunft.',
      pt: 'Na regra 50/30/20, os 20% são destinados a poupança e investimentos. Este é um percentual crítico para garantir seu futuro financeiro.'
    }
  },
  {
    id: 7,
    question: {
      tr: '"Önce kendini öde" prensibi neyi ifade eder?',
      en: 'What does the "pay yourself first" principle mean?',
      es: '¿Qué significa el principio "págarte a ti mismo primero"?',
      fr: 'Que signifie le principe "payez-vous d\'abord" ?',
      ru: 'Что означает принцип "сначала плати себе"?',
      de: 'Was bedeutet das Prinzip "Bezahle dich zuerst"?',
      pt: 'O que significa o princípio "pague-se primeiro"?'
    },
    type: 'multiple-choice',
    answers: {
      tr: [
        'Maaşı alınca ilk harcamayı yapmak',
        'Maaştan önce tasarruf payını ayırmak',
        'Maaşı harcayıp kalanla yatırım yapmak',
        'Kredi kartını kapatmak'
      ],
      en: [
        'Making the first purchase when receiving salary',
        'Setting aside savings portion before spending salary',
        'Spending salary and investing what remains',
        'Closing the credit card'
      ],
      es: [
        'Hacer la primera compra al recibir el salario',
        'Apartar la porción de ahorros antes de gastar el salario',
        'Gastar el salario e invertir lo que queda',
        'Cerrar la tarjeta de crédito'
      ],
      fr: [
        'Faire le premier achat en recevant le salaire',
        'Mettre de côté la portion d\'épargne avant de dépenser le salaire',
        'Dépenser le salaire et investir ce qui reste',
        'Fermer la carte de crédit'
      ],
      ru: [
        'Совершать первую покупку при получении зарплаты',
        'Откладывать часть на сбережения до трат зарплаты',
        'Тратить зарплату и инвестировать остаток',
        'Закрывать кредитную карту'
      ],
      de: [
        'Den ersten Kauf beim Erhalt des Gehalts tätigen',
        'Den Sparanteil vor Ausgabe des Gehalts beiseite legen',
        'Das Gehalt ausgeben und den Rest investieren',
        'Die Kreditkarte schließen'
      ],
      pt: [
        'Fazer a primeira compra ao receber o salário',
        'Separar a parte de poupança antes de gastar o salário',
        'Gastar o salário e investir o que sobra',
        'Fechar o cartão de crédito'
      ]
    },
    correct: 1,
    explanation: {
      tr: '"Önce kendini öde" prensibi, maaş aldığınızda ilk olarak tasarruf payınızı ayırıp, kalan parayla harcama yapmanızı önerir. Bu sayede tasarruf garanti altına alınır.',
      en: 'The "pay yourself first" principle suggests setting aside your savings portion first when you receive your salary, then spending with the remaining money. This ensures savings are guaranteed.',
      es: 'El principio "págarte a ti mismo primero" sugiere apartar tu porción de ahorros primero cuando recibes tu salario, luego gastar con el dinero restante. Esto asegura que los ahorros estén garantizados.',
      fr: 'Le principe "payez-vous d\'abord" suggère de mettre de côté votre portion d\'épargne d\'abord quand vous recevez votre salaire, puis de dépenser avec l\'argent restant. Cela garantit que les économies soient assurées.',
      ru: 'Принцип "сначала плати себе" предлагает сначала откладывать часть на сбережения при получении зарплаты, а затем тратить оставшиеся деньги. Это гарантирует сбережения.',
      de: 'Das Prinzip "Bezahle dich zuerst" schlägt vor, zuerst Ihren Sparanteil beiseite zu legen, wenn Sie Ihr Gehalt erhalten, dann mit dem verbleibenden Geld auszugeben. Dies stellt sicher, dass Ersparnisse garantiert sind.',
      pt: 'O princípio "pague-se primeiro" sugere separar sua parte de poupança primeiro quando receber seu salário, depois gastar com o dinheiro restante. Isso garante que as economias sejam asseguradas.'
    }
  },
  {
    id: 8,
    question: {
      tr: 'Bütçede "buffer" kategorisi ne işe yarar?',
      en: 'What is the purpose of a "buffer" category in a budget?',
      es: '¿Cuál es el propósito de una categoría "buffer" en un presupuesto?',
      fr: 'Quel est le but d\'une catégorie "tampon" dans un budget ?',
      ru: 'Какова цель категории "буфер" в бюджете?',
      de: 'Was ist der Zweck einer "Puffer"-Kategorie in einem Budget?',
      pt: 'Qual é o propósito de uma categoria "buffer" em um orçamento?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['Eğlence fonu', 'Beklenmedik giderleri karşılamak', 'Borç faizi ödemek', 'Tatil için birikim yapmak'],
      en: ['Entertainment fund', 'Covering unexpected expenses', 'Paying debt interest', 'Saving for vacation'],
      es: ['Fondo de entretenimiento', 'Cubrir gastos inesperados', 'Pagar intereses de deuda', 'Ahorrar para vacaciones'],
      fr: ['Fonds de divertissement', 'Couvrir les dépenses imprévues', 'Payer les intérêts de la dette', 'Économiser pour les vacances'],
      ru: ['Фонд развлечений', 'Покрытие неожиданных расходов', 'Выплата процентов по долгам', 'Накопления на отпуск'],
      de: ['Unterhaltungsfonds', 'Unerwartete Ausgaben abdecken', 'Schuldzinsen zahlen', 'Für Urlaub sparen'],
      pt: ['Fundo de entretenimento', 'Cobrir despesas inesperadas', 'Pagar juros de dívida', 'Economizar para férias']
    },
    correct: 1,
    explanation: {
      tr: 'Buffer kategorisi, bütçede öngörülmeyen beklenmedik giderleri (araba tamiri, sağlık gideri vb.) karşılamak için ayrılan esneklik fonudur.',
      en: 'The buffer category is a flexibility fund set aside in the budget to cover unforeseen unexpected expenses (car repair, medical expenses, etc.).',
      es: 'La categoría buffer es un fondo de flexibilidad apartado en el presupuesto para cubrir gastos inesperados no previstos (reparación de auto, gastos médicos, etc.).',
      fr: 'La catégorie tampon est un fonds de flexibilité mis de côté dans le budget pour couvrir les dépenses imprévues non prévues (réparation de voiture, frais médicaux, etc.).',
      ru: 'Категория буфер - это фонд гибкости, отложенный в бюджете для покрытия непредвиденных неожиданных расходов (ремонт автомобиля, медицинские расходы и т.д.).',
      de: 'Die Puffer-Kategorie ist ein Flexibilitätsfonds, der im Budget vorgesehen ist, um unvorhergesehene unerwartete Ausgaben (Autoreparatur, Arztkosten usw.) abzudecken.',
      pt: 'A categoria buffer é um fundo de flexibilidade reservado no orçamento para cobrir despesas inesperadas imprevistas (reparo de carro, despesas médicas, etc.).'
    }
  },
  {
    id: 9,
    question: {
      tr: '40.000 TL gelirde 50/30/20 kuralına göre tasarruf kaç TL olur?',
      en: 'With an income of $8,000, how much would savings be according to the 50/30/20 rule?',
      es: 'Con un ingreso de $8,000, ¿cuánto serían los ahorros según la regla 50/30/20?',
      fr: 'Avec un revenu de 8 000€, combien seraient les économies selon la règle 50/30/20 ?',
      ru: 'При доходе 240,000 рублей, сколько составят сбережения по правилу 50/30/20?',
      de: 'Bei einem Einkommen von 8.000€, wie viel wären die Ersparnisse nach der 50/30/20-Regel?',
      pt: 'Com uma renda de $8,000, quanto seriam as economias de acordo com a regra 50/30/20?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['20.000', '12.000', '8.000', '4.000'],
      en: ['$4,000', '$2,400', '$1,600', '$800'],
      es: ['$4,000', '$2,400', '$1,600', '$800'],
      fr: ['8 000€', '4 800€', '1 600€', '800€'],
      ru: ['120,000', '72,000', '48,000', '24,000'],
      de: ['4.000€', '2.400€', '1.600€', '800€'],
      pt: ['$4,000', '$2,400', '$1,600', '$800']
    },
    correct: 2,
    explanation: {
      tr: '50/30/20 kuralında %20 tasarrufa ayrılır. 40.000 TL\'nin %20\'si = 8.000 TL tasarruf edilmelidir.',
      en: 'In the 50/30/20 rule, 20% goes to savings. 20% of $8,000 = $1,600 should be saved.',
      es: 'En la regla 50/30/20, el 20% va a ahorros. El 20% de $8,000 = $1,600 debería ahorrarse.',
      fr: 'Dans la règle 50/30/20, 20% va aux économies. 20% de 8 000€ = 1 600€ devrait être économisé.',
      ru: 'В правиле 50/30/20, 20% идет на сбережения. 20% от 240,000 рублей = 48,000 рублей следует откладывать.',
      de: 'In der 50/30/20-Regel gehen 20% an Ersparnisse. 20% von 8.000€ = 1.600€ sollten gespart werden.',
      pt: 'Na regra 50/30/20, 20% vai para economias. 20% de $8,000 = $1,600 deveria ser poupado.'
    }
  },
  {
    id: 10,
    question: {
      tr: 'Bütçelemenin en büyük katkısı nedir?',
      en: 'What is the biggest contribution of budgeting?',
      es: '¿Cuál es la mayor contribución del presupuesto?',
      fr: 'Quelle est la plus grande contribution de la budgétisation ?',
      ru: 'Каков наибольший вклад бюджетирования?',
      de: 'Was ist der größte Beitrag der Budgetierung?',
      pt: 'Qual é a maior contribuição do orçamento?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['Geliri artırır', 'Giderleri optimize eder', 'Borçları siler', 'Banka kredisi kazandırır'],
      en: ['Increases income', 'Optimizes expenses', 'Eliminates debts', 'Provides bank loans'],
      es: ['Aumenta ingresos', 'Optimiza gastos', 'Elimina deudas', 'Proporciona préstamos bancarios'],
      fr: ['Augmente les revenus', 'Optimise les dépenses', 'Élimine les dettes', 'Fournit des prêts bancaires'],
      ru: ['Увеличивает доходы', 'Оптимизирует расходы', 'Устраняет долги', 'Предоставляет банковские кредиты'],
      de: ['Erhöht das Einkommen', 'Optimiert Ausgaben', 'Beseitigt Schulden', 'Bietet Bankkredite'],
      pt: ['Aumenta a renda', 'Otimiza despesas', 'Elimina dívidas', 'Fornece empréstimos bancários']
    },
    correct: 1,
    explanation: {
      tr: 'Bütçelemenin en büyük katkısı giderleri optimize etmek, yani harcamalarınızı planlı ve verimli hale getirmektir. Bu sayede tasarruf imkanı yaratır.',
      en: 'The biggest contribution of budgeting is optimizing expenses, making your spending planned and efficient. This creates opportunities for savings.',
      es: 'La mayor contribución del presupuesto es optimizar gastos, haciendo que tu gasto sea planificado y eficiente. Esto crea oportunidades para ahorros.',
      fr: 'La plus grande contribution de la budgétisation est d\'optimiser les dépenses, rendant vos dépenses planifiées et efficaces. Cela crée des opportunités d\'économies.',
      ru: 'Наибольший вклад бюджетирования - оптимизация расходов, делая ваши тр��ты планируемыми и эффективными. Это создает возможности для сбережений.',
      de: 'Der größte Beitrag der Budgetierung ist die Optimierung von Ausgaben, wodurch Ihre Ausgaben geplant und effizient werden. Dies schafft Sparmöglichkeiten.',
      pt: 'A maior contribuição do orçamento é otimizar despesas, tornando seus gastos planejados e eficientes. Isso cria oportunidades para economias.'
    }
  },

  // 3. Gider Takibi ve Azaltma - Quiz  
  {
    id: 11,
    question: {
      tr: 'Sabit gider örneği nedir?',
      en: 'What is an example of a fixed expense?',
      es: '¿Cuál es un ejemplo de gasto fijo?',
      fr: 'Quel est un exemple de dépense fixe ?',
      ru: 'Что является примером постоянного расхода?',
      de: 'Was ist ein Beispiel für eine feste Ausgabe?',
      pt: 'O que é um exemplo de despesa fixa?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['Kira', 'Market', 'Eğlence', 'Hediye'],
      en: ['Rent', 'Groceries', 'Entertainment', 'Gifts'],
      es: ['Alquiler', 'Supermercado', 'Entretenimiento', 'Regalos'],
      fr: ['Loyer', 'Courses', 'Divertissement', 'Cadeaux'],
      ru: ['Аренда', 'Продукты', 'Развлечения', 'Подарки'],
      de: ['Miete', 'Lebensmittel', 'Unterhaltung', 'Geschenke'],
      pt: ['Aluguel', 'Supermercado', 'Entretenimento', 'Presentes']
    },
    correct: 0,
    explanation: {
      tr: 'Kira sabit bir giderdir çünkü her ay aynı miktarda ödenir ve değişmez. Market, eğlence ve hediye giderleri değişken giderlerdir.',
      en: 'Rent is a fixed expense because it is paid in the same amount every month and doesn\'t change. Groceries, entertainment, and gifts are variable expenses.',
      es: 'El alquiler es un gasto fijo porque se paga la misma cantidad cada mes y no cambia. Supermercado, entretenimiento y regalos son gastos variables.',
      fr: 'Le loyer est une dépense fixe car il est payé du même montant chaque mois et ne change pas. Les courses, le divertissement et les cadeaux sont des dépenses variables.',
      ru: 'Аренда - это постоянный расход, потому что она выплачивается в одинаковой сумме каждый месяц и не изменяется. Продукты, развлечения и подарки - переменные расходы.',
      de: 'Miete ist eine feste Ausgabe, weil sie jeden Monat in derselben Höhe bezahlt wird und sich nicht ändert. Lebensmittel, Unterhaltung und Geschenke sind variable Ausgaben.',
      pt: 'Aluguel é uma despesa fixa porque é paga no mesmo valor todo mês e não muda. Supermercado, entretenimento e presentes são despesas variáveis.'
    }
  },
  {
    id: 12,
    question: {
      tr: '24 saat kuralı hangi durumda uygulanır?',
      en: 'In which situation is the 24-hour rule applied?',
      es: '¿En qué situación se aplica la regla de 24 horas?',
      fr: 'Dans quelle situation la règle des 24 heures est-elle appliquée ?',
      ru: 'В какой ситуации применяется правило 24 часов?',
      de: 'In welcher Situation wird die 24-Stunden-Regel angewendet?',
      pt: 'Em que situação é aplicada a regra de 24 horas?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['Fatura ödemesi', 'İmpuls alışverişi', 'Borç kapatma', 'Kira kontratı'],
      en: ['Bill payment', 'Impulse shopping', 'Debt closure', 'Rent contract'],
      es: ['Pago de facturas', 'Compras impulsivas', 'Cierre de deuda', 'Contrato de alquiler'],
      fr: ['Paiement de factures', 'Achats impulsifs', 'Clôture de dette', 'Contrat de location'],
      ru: ['Оплата счетов', 'Импульсивные покупки', 'Закрытие долга', 'Договор аренды'],
      de: ['Rechnungszahlung', 'Impulskäufe', 'Schuldenschluss', 'Mietvertrag'],
      pt: ['Pagamento de contas', 'Compras por impulso', 'Fechamento de dívida', 'Contrato de aluguel']
    },
    correct: 1,
    explanation: {
      tr: '24 saat kuralı, impuls alışverişini önlemek için uygulanır. Bir şey satın almak istediğinizde 24 saat bekleyip gerçekten ihtiyacınız olup olmadığını değerlendirirsiniz.',
      en: 'The 24-hour rule is applied to prevent impulse shopping. When you want to buy something, you wait 24 hours and evaluate whether you really need it.',
      es: 'La regla de 24 horas se aplica para prevenir compras impulsivas. Cuando quieres comprar algo, esperas 24 horas y evalúas si realmente lo necesitas.',
      fr: 'La règle des 24 heures est appliquée pour prévenir les achats impulsifs. Quand vous voulez acheter quelque chose, vous attendez 24 heures et évaluez si vous en avez vraiment besoin.',
      ru: 'Правило 24 часов применяется для предотвращения импульсивных покупок. Когда вы хотите что-то купить, вы ждете 24 часа и оцениваете, действительно ли это вам нужно.',
      de: 'Die 24-Stunden-Regel wird angewendet, um Impulskäufe zu verhindern. Wenn Sie etwas kaufen möchten, warten Sie 24 Stunden und bewerten, ob Sie es wirklich brauchen.',
      pt: 'A regra de 24 horas é aplicada para prevenir compras por impulso. Quando você quer comprar algo, espera 24 horas e avalia se realmente precisa.'
    }
  },
  {
    id: 13,
    question: {
      tr: 'Starbucks yerine evde kahve yaparak ayda yaklaşık ne kadar tasarruf edilir?',
      en: 'How much can you save monthly by making coffee at home instead of Starbucks?',
      es: '¿Cuánto puedes ahorrar mensalmente haciendo café en casa en lugar de Starbucks?',
      fr: 'Combien pouvez-vous économiser mensuellement en faisant du café à la maison au lieu de Starbucks ?',
      ru: 'Сколько можно сэкономить в месяц, готовя кофе дома вместо Starbucks?',
      de: 'Wie viel können Sie monatlich sparen, indem Sie Kaffee zu Hause machen anstatt bei Starbucks?',
      pt: 'Quanto você pode economizar mensalmente fazendo café em casa em vez de Starbucks?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['500 TL', '1.200 TL', '2.160 TL', '4.000 TL'],
      en: ['$50', '$120', '$216', '$400'],
      es: ['€50', '€120', '€216', '€400'],
      fr: ['50€', '120€', '216€', '400€'],
      ru: ['3,000 руб', '7,500 руб', '13,500 руб', '25,000 руб'],
      de: ['50€', '120€', '216€', '400€'],
      pt: ['$50', '$120', '$216', '$400']
    },
    correct: 2,
    explanation: {
      tr: 'Günlük 80 TL Starbucks yerine 8 TL evde kahve = 72 TL/gün tasarruf. Ayda 30 gün × 72 TL = 2.160 TL tasarruf sağlanır.',
      en: 'Daily $8 Starbucks vs $0.80 home coffee = $7.20/day savings. Monthly 30 days × $7.20 = $216 savings.',
      es: 'Diario €8 Starbucks vs €0.80 café casero = €7.20/día ahorro. Mensual 30 días × €7.20 = €216 ahorro.',
      fr: 'Quotidien 8€ Starbucks vs 0.80€ café maison = 7.20€/jour d\'économie. Mensuel 30 jours × 7.20€ = 216€ d\'économie.',
      ru: 'Ежедневно 500 руб Starbucks против 50 руб домашний кофе = 450 руб/день экономии. В месяц 30 дней × 450 руб = 13,500 руб экономии.',
      de: 'Täglich 8€ Starbucks vs 0.80€ Kaffee zu Hause = 7.20€/Tag Ersparnis. Monatlich 30 Tage × 7.20€ = 216€ Ersparnis.',
      pt: 'Diário $8 Starbucks vs $0.80 café caseiro = $7.20/dia economia. Mensalmente 30 dias × $7.20 = $216 economia.'
    }
  },
  {
    id: 14,
    question: {
      tr: 'Abonelik harcamalarını azaltmanın ilk adımı nedir?',
      en: 'What is the first step to reduce subscription expenses?',
      es: '¿Cuál es el primer paso para reducir gastos de suscripción?',
      fr: 'Quelle est la première étape pour réduire les dépenses d\'abonnement ?',
      ru: 'Каков первый шаг к сокращению расходов на подписки?',
      de: 'Was ist der erste Schritt zur Reduzierung von Abonnementausgaben?',
      pt: 'Qual é o primeiro passo para reduzir despesas de assinatura?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['Tümünü iptal etmek', 'Kullanılmayanları belirlemek', 'Aylık kart limitini artırmak', 'Yeni bir uygulama almak'],
      en: ['Cancel all of them', 'Identify unused ones', 'Increase monthly card limit', 'Get a new app'],
      es: ['Cancelar todas', 'Identificar las no utilizadas', 'Aumentar límite mensual de tarjeta', 'Obtener una nueva app'],
      fr: ['Les annuler toutes', 'Identifier celles non utilisées', 'Augmenter la limite mensuelle de carte', 'Obtenir une nouvelle app'],
      ru: ['Отменить все', 'Определить неиспользуемые', 'Увеличить месячный лимит карты', 'Получить новое приложение'],
      de: ['Alle kündigen', 'Ungenutzte identifizieren', 'Monatliches Kartenlimit erhöhen', 'Eine neue App bekommen'],
      pt: ['Cancelar todas', 'Identificar as não utilizadas', 'Aumentar limite mensal do cartão', 'Obter um novo app']
    },
    correct: 1,
    explanation: {
      tr: 'Abonelik giderlerini azaltmanın ilk adımı, hangi abonelikleri kullanmadığınızı belirlemektir. Sonra kullanılmayanları iptal edebilirsiniz.',
      en: 'The first step to reduce subscription expenses is to identify which subscriptions you don\'t use. Then you can cancel the unused ones.',
      es: 'El primer paso para reducir gastos de suscripción es identificar qué suscripciones no usas. Luego puedes cancelar las no utilizadas.',
      fr: 'La première étape pour réduire les dépenses d\'abonnement est d\'identifier quels abonnements vous n\'utilisez pas. Ensuite, vous pouvez annuler ceux non utilisés.',
      ru: 'Первый шаг к сокращению расходов на подписки - определить, какие подписки вы не используете. Затем можно отменить неиспользуемые.',
      de: 'Der erste Schritt zur Reduzierung von Abonnementausgaben ist zu identifizieren, welche Abonnements Sie nicht nutzen. Dann können Sie die ungenutzten kündigen.',
      pt: 'O primeiro passo para reduzir despesas de assinatura é identificar quais assinaturas você não usa. Depois pode cancelar as não utilizadas.'
    }
  },
  {
    id: 15,
    question: {
      tr: 'Gereksiz harcamaların finansal karşılığı hangi kavramdır?',
      en: 'What concept represents the financial equivalent of unnecessary expenses?',
      es: '¿Qué concepto representa el equivalente financiero de gastos innecesarios?',
      fr: 'Quel concept représente l\'équivalent financier des dépenses inutiles ?',
      ru: 'Какая концепция представляет финансовый эквивалент ненужных расходов?',
      de: 'Welches Konzept repräsentiert das finanzielle Äquivalent unnötiger Ausgaben?',
      pt: 'Que conceito representa o equivalente financeiro de despesas desnecessárias?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['Borç yönetimi', 'Oportunite maliyeti', 'Nakit akışı', 'Faiz gideri'],
      en: ['Debt management', 'Opportunity cost', 'Cash flow', 'Interest expense'],
      es: ['Gestión de deudas', 'Costo de oportunidad', 'Flujo de caja', 'Gasto de interés'],
      fr: ['Gestion des dettes', 'Coût d\'opportunité', 'Flux de trésorerie', 'Charge d\'intérêt'],
      ru: ['Управление долгами', 'Альтернативная стоимость', 'Денежный поток', 'Процентные расходы'],
      de: ['Schuldenmanagement', 'Opportunitätskosten', 'Cashflow', 'Zinsaufwand'],
      pt: ['Gestão de dívidas', 'Custo de oportunidade', 'Fluxo de caixa', 'Despesa de juros']
    },
    correct: 1,
    explanation: {
      tr: 'Gereksiz harcamaların finansal karşılığı oportunite maliyetidir. Bu para yerine tasarruf edilseydi veya yatırım yapılsaydı elde edilebilecek faydadır.',
      en: 'The financial equivalent of unnecessary expenses is opportunity cost. This is the benefit that could have been gained if this money had been saved or invested instead.',
      es: 'El equivalente financiero de gastos innecesarios es el costo de oportunidad. Este es el beneficio que se podría haber obtenido si este dinero se hubiera ahorrado o invertido en su lugar.',
      fr: 'L\'équivalent financier des dépenses inutiles est le coût d\'opportunité. C\'est l\'avantage qui aurait pu être obtenu si cet argent avait été économisé ou investi à la place.',
      ru: 'Финансовый эквивалент ненужных расходов - это альтернативная стоимость. Это выгода, которая могла бы быть получена, если бы эти деньги были сбережены или инвестированы.',
      de: 'Das finanzielle Äquivalent unnötiger Ausgaben sind Opportunitätskosten. Dies ist der Nutzen, der hätte erzielt werden können, wenn dieses Geld stattdessen gespart oder investiert worden wäre.',
      pt: 'O equivalente financeiro de despesas desnecessárias é o custo de oportunidade. Este é o benefício que poderia ter sido obtido se este dinheiro tivesse sido poupado ou investido em vez disso.'
    }
  },

  // 4. Tasarruf Stratejileri - Quiz
  {
    id: 16,
    question: {
      tr: '"Önce kendini öde" prensibinde maaşın % kaçını tasarrufa ayırmak idealdir?',
      en: 'In the "pay yourself first" principle, what percentage of salary is ideal to set aside for savings?',
      es: 'En el principio "págarte a ti mismo primero", ¿qué porcentaje del salario es ideal apartar para ahorros?',
      fr: 'Dans le principe "payez-vous d\'abord", quel pourcentage du salaire est idéal à mettre de côté pour l\'épargne ?',
      ru: 'В принципе "сначала плати себе", какой процент зарплаты идеален для откладывания на сбережения?',
      de: 'Im Prinzip "Bezahle dich zuerst", welcher Prozentsatz des Gehalts ist ideal für Ersparnisse?',
      pt: 'No princípio "pague-se primeiro", que porcentagem do salário é ideal separar para poupança?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['%5', '%15–20', '%30', '%50'],
      en: ['5%', '15–20%', '30%', '50%'],
      es: ['5%', '15–20%', '30%', '50%'],
      fr: ['5%', '15–20%', '30%', '50%'],
      ru: ['5%', '15–20%', '30%', '50%'],
      de: ['5%', '15–20%', '30%', '50%'],
      pt: ['5%', '15–20%', '30%', '50%']
    },
    correct: 1,
    explanation: {
      tr: 'Finansal uzmanlar genellikle maaşın %15-20\'sini tasarrufa ayırmayı önerir. Bu, hem günlük ihtiyaçları karşılar hem de gelecek için birikim sağlar.',
      en: 'Financial experts generally recommend setting aside 15-20% of salary for savings. This both covers daily needs and provides accumulation for the future.',
      es: 'Los expertos financieros generalmente recomiendan apartar el 15-20% del salario para ahorros. Esto tanto cubre necesidades diarias como proporciona acumulación para el futuro.',
      fr: 'Les experts financiers recommandent généralement de mettre de côté 15-20% du salaire pour l\'épargne. Cela couvre à la fois les besoins quotidiens et fournit une accumulation pour l\'avenir.',
      ru: 'Финансовые эксперты обычно рекомендуют откладывать 15-20% зарплаты на сбережения. Это покрывает ежедневные потребности и обеспечивает накопления на будущее.',
      de: 'Finanzexperten empfehlen im Allgemeinen, 15-20% des Gehalts für Ersparnisse beiseite zu legen. Dies deckt sowohl tägliche Bedürfnisse ab als auch ermöglicht Ansammlung für die Zukunft.',
      pt: 'Especialistas financeiros geralmente recomendam separar 15-20% do salário para poupança. Isso cobre necessidades diárias e proporciona acumulação para o futuro.'
    }
  },
  {
    id: 17,
    question: {
      tr: '100.000 TL\'yi %45 faizli vadeli hesaba 6 ay koyarsanız yaklaşık kazanç ne olur?',
      en: 'If you put $20,000 in a 9% interest term deposit for 6 months, what would be the approximate gain?',
      es: 'Si pones €20,000 en un depósito a plazo del 9% de interés por 6 meses, ¿cuál sería la ganancia aproximada?',
      fr: 'Si vous placez 20 000€ dans un dépôt à terme à 9% d\'intérêt pendant 6 mois, quel serait le gain approximatif ?',
      ru: 'Если вы положите 1,500,000 рублей на срочный депозит под 18% годовых на 6 месяцев, какой будет примерный доход?',
      de: 'Wenn Sie 20.000€ für 6 Monate in eine Festgeldanlage mit 9% Zinsen anlegen, wie hoch wäre der ungefähre Gewinn?',
      pt: 'Se você colocar $20,000 em um depósito a prazo de 9% de juros por 6 meses, qual seria o ganho aproximado?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['10.000 TL', '22.500 TL', '40.000 TL', '50.000 TL'],
      en: ['$500', '$900', '$1,800', '$2,500'],
      es: ['€500', '€900', '€1,800', '€2,500'],
      fr: ['500€', '900€', '1 800€', '2 500€'],
      ru: ['75,000 руб', '135,000 руб', '270,000 руб', '375,000 руб'],
      de: ['500€', '900€', '1.800€', '2.500€'],
      pt: ['$500', '$900', '$1,800', '$2,500']
    },
    correct: 1,
    explanation: {
      tr: '100.000 TL × %45 yıllık faiz ÷ 2 (6 ay) = 22.500 TL kazanç. Vadeli hesaplar sabit getiri sağlar ancak enflasyona karşı korunma sağlamayabilir.',
      en: '$20,000 × 9% annual interest ÷ 2 (6 months) = $900 gain. Term deposits provide fixed returns but may not protect against inflation.',
      es: '€20,000 × 9% interés anual ÷ 2 (6 meses) = €900 ganancia. Los depósitos a plazo proporcionan rendimientos fijos pero pueden no proteger contra la inflación.',
      fr: '20 000€ × 9% d\'intérêt annuel ÷ 2 (6 mois) = 900€ de gain. Les dépôts à terme fournissent des rendements fixes mais peuvent ne pas protéger contre l\'inflation.',
      ru: '1,500,000 руб × 18% годовых ÷ 2 (6 месяцев) = 135,000 руб дохода. Срочные депозиты обеспечивают фиксированную доходность, но могут не защищать от инфляции.',
      de: '20.000€ × 9% jährliche Zinsen ÷ 2 (6 Monate) = 900€ Gewinn. Festgeldanlagen bieten feste Renditen, schützen aber möglicherweise nicht vor Inflation.',
      pt: '$20,000 × 9% juros anuais ÷ 2 (6 meses) = $900 ganho. Depósitos a prazo fornecem retornos fixos mas podem não proteger contra inflação.'
    }
  },
  {
    id: 18,
    question: {
      tr: '52 hafta meydan okuması yıl sonunda yaklaşık kaç TL biriktirir?',
      en: 'How much does the 52-week challenge save by year-end approximately?',
      es: '¿Cuánto ahorra el desafío de 52 semanas al final del año aproximadamente?',
      fr: 'Combien le défi de 52 semaines épargne-t-il à la fin de l\'année approximativement ?',
      ru: 'Сколько экономит вызов 52 недели к концу года приблизительно?',
      de: 'Wie viel spart die 52-Wochen-Challenge bis zum Jahresende ungefähr?',
      pt: 'Quanto o desafio de 52 semanas economiza até o final do ano aproximadamente?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['20.000 TL', '40.000 TL', '67.600 TL', '100.000 TL'],
      en: ['$800', '$1,600', '$1,378', '$2,000'],
      es: ['€800', '€1,600', '€1,378', '€2,000'],
      fr: ['800€', '1 600€', '1 378€', '2 000€'],
      ru: ['50,000 руб', '100,000 руб', '86,450 руб', '150,000 руб'],
      de: ['800€', '1.600€', '1.378€', '2.000€'],
      pt: ['$800', '$1,600', '$1,378', '$2,000']
    },
    correct: 2,
    explanation: {
      tr: '52 hafta meydan okumasında 1. hafta 50 TL, 2. hafta 100 TL... 52. hafta 2.600 TL biriktirirsiniz. Toplam: (1+2+...+52) × 50 = 67.600 TL.',
      en: 'In the 52-week challenge you save $1 week 1, $2 week 2... $52 week 52. Total: (1+2+...+52) = $1,378.',
      es: 'En el desafío de 52 semanas ahorras €1 semana 1, €2 semana 2... €52 semana 52. Total: (1+2+...+52) = €1,378.',
      fr: 'Dans le défi de 52 semaines vous épargnez 1€ semaine 1, 2€ semaine 2... 52€ semaine 52. Total: (1+2+...+52) = 1 378€.',
      ru: 'В вызове 52 недели вы откладываете 625 руб неделя 1, 1250 руб неделя 2... 32500 руб неделя 52. Итого: (1+2+...+52) × 625 = 86,450 руб.',
      de: 'In der 52-Wochen-Challenge sparen Sie 1€ Woche 1, 2€ Woche 2... 52€ Woche 52. Gesamt: (1+2+...+52) = 1.378€.',
      pt: 'No desafio de 52 semanas você economiza $1 semana 1, $2 semana 2... $52 semana 52. Total: (1+2+...+52) = $1,378.'
    }
  },
  {
    id: 19,
    question: {
      tr: '"Hedef Bankacılığı" nedir?',
      en: 'What is "Goal-based Banking"?',
      es: '¿Qué es la "Banca Basada en Objetivos"?',
      fr: 'Qu\'est-ce que la "Banque Basée sur les Objectifs" ?',
      ru: 'Что такое "Банкинг по целям"?',
      de: 'Was ist "Zielbasiertes Banking"?',
      pt: 'O que é "Banco Baseado em Objetivos"?'
    },
    type: 'multiple-choice',
    answers: {
      tr: [
        'Farklı bankalarda hesap açmak',
        'Her hedef için ayrı hesap ayırmak',
        'Kredileri tek bankada toplamak',
        'Yalnızca altın hesabı açmak'
      ],
      en: [
        'Opening accounts at different banks',
        'Setting aside separate accounts for each goal',
        'Consolidating loans at one bank',
        'Only opening gold accounts'
      ],
      es: [
        'Abrir cuentas en diferentes bancos',
        'Apartar cuentas separadas para cada objetivo',
        'Consolidar préstamos en un banco',
        'Solo abrir cuentas de oro'
      ],
      fr: [
        'Ouvrir des comptes dans différentes banques',
        'Mettre de côté des comptes séparés pour chaque objectif',
        'Consolider les prêts dans une banque',
        'Ouvrir seulement des comptes or'
      ],
      ru: [
        'Открытие счетов в разных банках',
        'Выделение отдельных счетов для каждой цели',
        'Консолидация кредитов в одном банке',
        'Открытие только золотых счетов'
      ],
      de: [
        'Konten bei verschiedenen Banken eröffnen',
        'Separate Konten für jedes Ziel einrichten',
        'Kredite bei einer Bank konsolidieren',
        'Nur Goldkonten eröffnen'
      ],
      pt: [
        'Abrir contas em bancos diferentes',
        'Separar contas diferentes para cada objetivo',
        'Consolidar empréstimos em um banco',
        'Apenas abrir contas ouro'
      ]
    },
    correct: 1,
    explanation: {
      tr: 'Hedef Bankacılığı, her finansal hedef için (tatil, ev, araba) ayrı hesaplar açarak tasarruf yapmak anlamına gelir. Bu yöntem hedeflere odaklanmayı sağlar.',
      en: 'Goal-based Banking means saving by opening separate accounts for each financial goal (vacation, house, car). This method helps focus on goals.',
      es: 'La Banca Basada en Objetivos significa ahorrar abriendo cuentas separadas para cada objetivo financiero (vacaciones, casa, auto). Este método ayuda a enfocarse en objetivos.',
      fr: 'La Banque Basée sur les Objectifs signifie épargner en ouvrant des comptes séparés pour chaque objectif financier (vacances, maison, voiture). Cette méthode aide à se concentrer sur les objectifs.',
      ru: 'Банкинг по целям означает сбережения путем открытия отдельных счетов для каждой финансовой цели (отпуск, дом, машина). Этот метод помогает сосредоточиться на целях.',
      de: 'Zielbasiertes Banking bedeutet Sparen durch Eröffnung separater Konten für jedes finanzielle Ziel (Urlaub, Haus, Auto). Diese Methode hilft, sich auf Ziele zu konzentrieren.',
      pt: 'Banco Baseado em Objetivos significa economizar abrindo contas separadas para cada objetivo financeiro (férias, casa, carro). Este método ajuda a focar nos objetivos.'
    }
  },
  {
    id: 20,
    question: {
      tr: 'Eğlenceli tasarruf oyunu olmayan hangisidir?',
      en: 'Which is NOT a fun savings game?',
      es: '¿Cuál NO es un juego divertido de ahorros?',
      fr: 'Lequel n\'est PAS un jeu d\'épargne amusant ?',
      ru: 'Что НЕ является веселой игрой в сбережения?',
      de: 'Welches ist KEIN lustiges Sparspiel?',
      pt: 'Qual NÃO é um jogo divertido de poupança?'
    },
    type: 'multiple-choice',
    answers: {
      tr: [
        '52 hafta meydan okuması',
        '365 gün 200 TL meydan okuması',
        '200 TL jar sistemi',
        'Kredi kartı puan biriktirme'
      ],
      en: [
        '52-week challenge',
        '365-day $5 challenge',
        '$5 jar system',
        'Credit card points accumulation'
      ],
      es: [
        'Desafío de 52 semanas',
        'Desafío de 365 días de €5',
        'Sistema de frasco de €5',
        'Acumulación de puntos de tarjeta de crédito'
      ],
      fr: [
        'Défi de 52 semaines',
        'Défi de 365 jours de 5€',
        'Système de pot de 5€',
        'Accumulation de points de carte de crédit'
      ],
      ru: [
        'Вызов 52 недели',
        'Вызов 365 дней по 300 руб',
        'Система банки 300 руб',
        'Накопление баллов кредитной карты'
      ],
      de: [
        '52-Wochen-Challenge',
        '365-Tage 5€-Challenge',
        '5€-Glas-System',
        'Kreditkarten-Punkte-Sammlung'
      ],
      pt: [
        'Desafio de 52 semanas',
        'Desafio de 365 dias de $5',
        'Sistema de pote de $5',
        'Acumulação de pontos de cartão de crédito'
      ]
    },
    correct: 3,
    explanation: {
      tr: 'Kredi kartı puan biriktirme, tasarruf oyunu değil, ödül programıdır. Diğerleri gerçek para biriktirme challange\'larıdır.',
      en: 'Credit card points accumulation is not a savings game, it\'s a rewards program. The others are actual money-saving challenges.',
      es: 'La acumulación de puntos de tarjeta de crédito no es un juego de ahorros, es un programa de recompensas. Los otros son desafíos reales de ahorro de dinero.',
      fr: 'L\'accumulation de points de carte de crédit n\'est pas un jeu d\'épargne, c\'est un programme de récompenses. Les autres sont de vrais défis d\'économie d\'argent.',
      ru: 'Накопление баллов кредитной карты - это не игра в сбережения, а программа вознаграждений. Остальные - настоящие вызовы экономии денег.',
      de: 'Kreditkarten-Punkte-Sammlung ist kein Sparspiel, sondern ein Belohnungsprogramm. Die anderen sind echte Geld-spar-Herausforderungen.',
      pt: 'Acumulação de pontos de cartão de crédito não é um jogo de poupança, é um programa de recompensas. Os outros são desafios reais de economia de dinheiro.'
    }
  },

  // 5. Acil Fon - Quiz
  {
    id: 21,
    question: {
      tr: 'Aylık gideri 25.000 TL olan biri için 6 aylık acil fon ne kadardır?',
      en: 'For someone with monthly expenses of $5,000, how much is a 6-month emergency fund?',
      es: 'Para alguien con gastos mensuales de €5,000, ¿cuánto es un fondo de emergencia de 6 meses?',
      fr: 'Pour quelqu\'un avec des dépenses mensuelles de 5 000€, combien représente un fonds d\'urgence de 6 mois ?',
      ru: 'Для человека с ежемесячными расходами 150,000 рублей, сколько составляет аварийный фонд на 6 месяцев?',
      de: 'Für jemanden mit monatlichen Ausgaben von 5.000€, wie viel beträgt ein 6-Monats-Notfallfonds?',
      pt: 'Para alguém com despesas mensais de $5,000, quanto é um fundo de emergência de 6 meses?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['50.000 TL', '75.000 TL', '150.000 TL', '250.000 TL'],
      en: ['$15,000', '$20,000', '$30,000', '$50,000'],
      es: ['€15,000', '€20,000', '€30,000', '€50,000'],
      fr: ['15 000€', '20 000€', '30 000€', '50 000€'],
      ru: ['450,000 руб', '600,000 руб', '900,000 руб', '1,500,000 руб'],
      de: ['15.000€', '20.000€', '30.000€', '50.000€'],
      pt: ['$15,000', '$20,000', '$30,000', '$50,000']
    },
    correct: 2,
    explanation: {
      tr: '6 aylık acil fon = Aylık gider × 6 = 25.000 TL × 6 = 150.000 TL. Bu miktar işsizlik veya acil durumlar için güvenlik sağlar.',
      en: '6-month emergency fund = Monthly expenses × 6 = $5,000 × 6 = $30,000. This amount provides security for unemployment or emergencies.',
      es: 'Fondo de emergencia de 6 meses = Gastos mensuales × 6 = €5,000 × 6 = €30,000. Esta cantidad proporciona seguridad para desempleo o emergencias.',
      fr: 'Fonds d\'urgence de 6 mois = Dépenses mensuelles × 6 = 5 000€ × 6 = 30 000€. Ce montant fournit une sécurité pour le chômage ou les urgences.',
      ru: 'Аварийный фонд на 6 месяцев = Ежемесячные расходы × 6 = 150,000 руб × 6 = 900,000 руб. Эта сумма обеспечивает безопасность при безработице или чрезвычайных ситуациях.',
      de: '6-Monats-Notfallfonds = Monatliche Ausgaben × 6 = 5.000€ × 6 = 30.000€. Dieser Betrag bietet Sicherheit bei Arbeitslosigkeit oder Notfällen.',
      pt: 'Fundo de emergência de 6 meses = Despesas mensais × 6 = $5,000 × 6 = $30,000. Este valor fornece segurança para desemprego ou emergências.'
    }
  },
  {
    id: 22,
    question: {
      tr: 'Acil fon hangi hesapta tutulmalı?',
      en: 'In which type of account should an emergency fund be kept?',
      es: '¿En qué tipo de cuenta debe mantenerse un fondo de emergencia?',
      fr: 'Dans quel type de compte un fonds d\'urgence doit-il être conservé ?',
      ru: 'На каком типе счета следует держать аварийный фонд?',
      de: 'In welcher Art von Konto sollte ein Notfallfonds geführt werden?',
      pt: 'Em que tipo de conta um fundo de emergência deve ser mantido?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['Vadeli hesap', 'Kripto borsası', 'Vadesiz likit hesap', 'Hisse senedi'],
      en: ['Term deposit', 'Crypto exchange', 'Liquid savings account', 'Stock investment'],
      es: ['Depósito a plazo', 'Exchange de cripto', 'Cuenta de ahorros líquida', 'Inversión en acciones'],
      fr: ['Dépôt à terme', 'Exchange crypto', 'Compte d\'épargne liquide', 'Investissement en actions'],
      ru: ['Срочный вклад', 'Криптобиржа', 'Ликвидный сберегательный счет', 'Инвестиции в акции'],
      de: ['Festgeld', 'Krypto-Börse', 'Liquides Sparkonto', 'Aktieninvestition'],
      pt: ['Depósito a prazo', 'Exchange de cripto', 'Conta poupança líquida', 'Investimento em ações']
    },
    correct: 2,
    explanation: {
      tr: 'Acil fon vadesiz likit hesapta tutulmalıdır çünkü acil durumlarda hızlıca erişilebilir olması gerekir. Vadeli hesap veya yatırımlar gecikmeli erişim sağlar.',
      en: 'Emergency fund should be kept in a liquid savings account because it needs to be quickly accessible in emergencies. Term deposits or investments provide delayed access.',
      es: 'El fondo de emergencia debe mantenerse en una cuenta de ahorros líquida porque necesita ser rápidamente accesible en emergencias. Los depósitos a plazo o inversiones proporcionan acceso retrasado.',
      fr: 'Le fonds d\'urgence doit être conservé dans un compte d\'épargne liquide car il doit être rapidement accessible en cas d\'urgence. Les dépôts à terme ou investissements fournissent un accès retardé.',
      ru: 'Аварийный фонд должен храниться на ликвидном сберегательном счете, потому что к нему нужен быстрый доступ в чрезвычайных ситуациях. Срочные депозиты или инвестиции обеспечивают отложенный доступ.',
      de: 'Der Notfallfonds sollte auf einem liquiden Sparkonto geführt werden, da er in Notfällen schnell zugänglich sein muss. Festgelder oder Investitionen bieten verzögerten Zugriff.',
      pt: 'O fundo de emergência deve ser mantido em uma conta poupança líquida porque precisa ser rapidamente acessível em emergências. Depósitos a prazo ou investimentos fornecem acesso atrasado.'
    }
  },
  {
    id: 23,
    question: {
      tr: 'Gerçek acil durum olmayan nedir?',
      en: 'Which is NOT a real emergency?',
      es: '¿Cuál NO es una emergencia real?',
      fr: 'Laquelle n\'est PAS une vraie urgence ?',
      ru: 'Что НЕ является настоящей чрезвычайной ситуацией?',
      de: 'Was ist KEIN echter Notfall?',
      pt: 'O que NÃO é uma emergência real?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['İş kaybı', 'Sağlık gideri', 'Tatil', 'Araba tamiri'],
      en: ['Job loss', 'Medical expense', 'Vacation', 'Car repair'],
      es: ['Pérdida de empleo', 'Gasto médico', 'Vacaciones', 'Reparación de auto'],
      fr: ['Perte d\'emploi', 'Dépense médicale', 'Vacances', 'Réparation de voiture'],
      ru: ['Потеря работы', 'Медицинские расходы', 'Отпуск', 'Ремонт автомобиля'],
      de: ['Jobverlust', 'Arztkosten', 'Urlaub', 'Autoreparatur'],
      pt: ['Perda de emprego', 'Despesa médica', 'Férias', 'Reparo do carro']
    },
    correct: 2,
    explanation: {
      tr: 'Tatil gerçek bir acil durum değildir, planlanabilir bir harcamadır. İş kaybı, sağlık giderleri ve araba tamiri öngörülemez acil durumlardır.',
      en: 'Vacation is not a real emergency, it\'s a plannable expense. Job loss, medical expenses, and car repairs are unpredictable emergencies.',
      es: 'Las vacaciones no son una emergencia real, es un gasto planificable. La pérdida de empleo, gastos médicos y reparaciones de auto son emergencias impredecibles.',
      fr: 'Les vacances ne sont pas une vraie urgence, c\'est une dépense planifiable. La perte d\'emploi, les dépenses médicales et les réparations de voiture sont des urgences imprévisibles.',
      ru: 'Отпуск не является настоящей чрезвычайной ситуацией, это планируемый расход. Потеря работы, медицинские расходы и ремонт автомобиля - непредсказуемые чрезвычайные ситуации.',
      de: 'Urlaub ist kein echter Notfall, sondern eine planbare Ausgabe. Jobverlust, Arztkosten und Autoreparaturen sind unvorhersehbare Notfälle.',
      pt: 'Férias não é uma emergência real, é uma despesa planejável. Perda de emprego, despesas médicas e reparos de carro são emergências imprevisíveis.'
    }
  },
  {
    id: 24,
    question: {
      tr: 'Adım adım biriktirme planında 12. ayda hedef ne kadardır?',
      en: 'In a step-by-step savings plan, what is the target amount in the 12th month?',
      es: 'En un plan de ahorro paso a paso, ¿cuál es la cantidad objetivo en el mes 12?',
      fr: 'Dans un plan d\'épargne étape par étape, quel est le montant cible au 12ème mois ?',
      ru: 'В пошаговом плане сбережений, какова целевая сумма на 12-м месяце?',
      de: 'In einem schrittweisen Sparplan, wie hoch ist der Zielbetrag im 12. Monat?',
      pt: 'Em um plano de poupança passo a passo, qual é o valor alvo no 12º mês?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['60.000 TL', '120.000 TL', '150.000 TL', '180.000 TL'],
      en: ['$12,000', '$24,000', '$30,000', '$36,000'],
      es: ['€12,000', '€24,000', '€30,000', '€36,000'],
      fr: ['12 000€', '24 000€', '30 000€', '36 000€'],
      ru: ['900,000 руб', '1,800,000 руб', '2,250,000 руб', '2,700,000 руб'],
      de: ['12.000€', '24.000€', '30.000€', '36.000€'],
      pt: ['$12,000', '$24,000', '$30,000', '$36,000']
    },
    correct: 1,
    explanation: {
      tr: 'Adım adım biriktirme planında 1. ay 10.000 TL\'den başlayıp her ay aynı miktarı eklerseniz, 12. ayda toplam (1+2+...+12) × 10.000 = 120.000 TL birikir.',
      en: 'In a step-by-step savings plan starting with $2,000 in month 1 and adding the same amount each month, by month 12 total (1+2+...+12) × $2,000 = $24,000 accumulates.',
      es: 'En un plan de ahorro paso a paso comenzando con €2,000 en el mes 1 y agregando la misma cantidad cada mes, para el mes 12 total (1+2+...+12) × €2,000 = €24,000 se acumula.',
      fr: 'Dans un plan d\'épargne étape par étape commençant avec 2 000€ au mois 1 et ajoutant le même montant chaque mois, au 12ème mois total (1+2+...+12) × 2 000€ = 24 000€ s\'accumule.',
      ru: 'В пошаговом плане сбережений, начиная со 150,000 руб в 1-м месяце и добавляя ту же сумму каждый месяц, к 12-му месяцу общий итог (1+2+...+12) × 150,000 = 1,800,000 руб накапливается.',
      de: 'In einem schrittweisen Sparplan, der mit 2.000€ in Monat 1 beginnt und jeden Monat den gleichen Betrag hinzufügt, sammeln sich bis Monat 12 insgesamt (1+2+...+12) × 2.000€ = 24.000€ an.',
      pt: 'Em um plano de poupança passo a passo começando com $2,000 no mês 1 e adicionando a mesma quantia a cada mês, no 12º mês total (1+2+...+12) × $2,000 = $24,000 se acumula.'
    }
  },
  {
    id: 25,
    question: {
      tr: 'Acil fonun psikolojik faydası nedir?',
      en: 'What is the psychological benefit of an emergency fund?',
      es: '¿Cuál es el beneficio psicológico de un fondo de emergencia?',
      fr: 'Quel est l\'avantage psychologique d\'un fonds d\'urgence ?',
      ru: 'Каково психологическое преимущество аварийного фонда?',
      de: 'Was ist der psychologische Vorteil eines Notfallfonds?',
      pt: 'Qual é o benefício psicológico de um fundo de emergência?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['Borcu siler', 'Daha az stres', 'Faizi düşürür', 'Geliri artırır'],
      en: ['Eliminates debt', 'Less stress', 'Lowers interest', 'Increases income'],
      es: ['Elimina deuda', 'Menos estrés', 'Reduce interés', 'Aumenta ingresos'],
      fr: ['Élimine la dette', 'Moins de stress', 'Réduit les intérêts', 'Augmente les revenus'],
      ru: ['Устраняет долг', 'Меньше стресса', 'Снижает проценты', 'Увеличивает доходы'],
      de: ['Beseitigt Schulden', 'Weniger Stress', 'Senkt Zinsen', 'Erhöht Einkommen'],
      pt: ['Elimina dívida', 'Menos estresse', 'Reduz juros', 'Aumenta renda']
    },
    correct: 1,
    explanation: {
      tr: 'Acil fonun en büyük psikolojik faydası daha az stres yaşamaktır. Beklenmedik durumlar karşısında finansal güvenlik hissi sağlar ve kaygıyı azaltır.',
      en: 'The biggest psychological benefit of an emergency fund is experiencing less stress. It provides a sense of financial security against unexpected situations and reduces anxiety.',
      es: 'El mayor beneficio psicológico de un fondo de emergencia es experimentar menos estrés. Proporciona una sensación de seguridad financiera contra situaciones inesperadas y reduce la ansiedad.',
      fr: 'Le plus grand avantage psychologique d\'un fonds d\'urgence est de ressentir moins de stress. Il procure un sentiment de sécurité financière face aux situations inattendues et réduit l\'anxiété.',
      ru: 'Наибольшее психологическое преимущество аварийного фонда - меньше стресса. Он обеспечивает чувство финансовой безопасности против неожиданных ситуаций и снижает тревогу.',
      de: 'Der größte psychologische Vorteil eines Notfallfonds ist weniger Stress zu erleben. Er bietet ein Gefühl finanzieller Sicherheit gegen unerwartete Situationen und reduziert Angst.',
      pt: 'O maior benefício psicológico de um fundo de emergência é experimentar menos estresse. Ele fornece uma sensação de segurança financeira contra situações inesperadas e reduz a ansiedade.'
    }
  },

  // 6. Borç Yönetimi - Quiz
  {
    id: 26,
    question: {
      tr: 'Aşağıdakilerden hangisi "iyi borç"tur?',
      en: 'Which of the following is "good debt"?',
      es: '¿Cuál de los siguientes es "deuda buena"?',
      fr: 'Lequel des suivants est une "bonne dette" ?',
      ru: 'Что из следующего является "хорошим долгом"?',
      de: 'Welches der folgenden ist "gute Schuld"?',
      pt: 'Qual dos seguintes é "dívida boa"?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['Kredi kartı borcu', 'Eğitim kredisi', 'Tüketici kredisi', 'Tatil kredisi'],
      en: ['Credit card debt', 'Student loan', 'Consumer loan', 'Vacation loan'],
      es: ['Deuda de tarjeta de crédito', 'Préstamo estudiantil', 'Préstamo al consumidor', 'Préstamo de vacaciones'],
      fr: ['Dette de carte de crédit', 'Prêt étudiant', 'Prêt à la consommation', 'Prêt vacances'],
      ru: ['Долг по кредитной карте', 'Образовательный кредит', 'Потребительский кредит', 'Кредит на отпуск'],
      de: ['Kreditkartenschuld', 'Studienkredit', 'Verbraucherkredit', 'Urlaubskredit'],
      pt: ['Dívida de cartão de crédito', 'Empréstimo estudantil', 'Empréstimo ao consumidor', 'Empréstimo para férias']
    },
    correct: 1,
    explanation: {
      tr: 'Eğitim kredisi "iyi borç"tur çünkü gelecekteki kazancınızı artırabilir ve yatırım niteliği taşır. Kredi kartı ve tüketici kredileri yüksek faizli "kötü borç"lardır.',
      en: 'Student loan is "good debt" because it can increase your future earnings and has investment qualities. Credit card and consumer loans are high-interest "bad debts".',
      es: 'El préstamo estudiantil es "deuda buena" porque puede aumentar tus ganancias futuras y tiene cualidades de inversión. Tarjetas de crédito y préstamos al consumidor son "deudas malas" de alto interés.',
      fr: 'Le prêt étudiant est une "bonne dette" car il peut augmenter vos gains futurs et a des qualités d\'investissement. Les cartes de crédit et prêts à la consommation sont des "mauvaises dettes" à taux élevé.',
      ru: 'Образовательный кредит - "хороший долг", потому что он может увеличить ваши будущие доходы и имеет инвестиционные качества. Кредитные карты и потребительские кредиты - высокопроцентные "плохие долги".',
      de: 'Studienkredit ist "gute Schuld", weil er Ihre zukünftigen Verdienste steigern kann und Investitionsqualitäten hat. Kreditkarten und Verbraucherkredite sind hochverzinsliche "schlechte Schulden".',
      pt: 'Empréstimo estudantil é "dívida boa" porque pode aumentar seus ganhos futuros e tem qualidades de investimento. Cartões de crédito e empréstimos ao consumidor são "dívidas ruins" de juros altos.'
    }
  },
  {
    id: 27,
    question: {
      tr: 'Kar topu yöntemi hangi avantaja sahiptir?',
      en: 'What advantage does the snowball method have?',
      es: '¿Qué ventaja tiene el método bola de nieve?',
      fr: 'Quel avantage a la méthode boule de neige ?',
      ru: 'Какое преимущество имеет метод снежного кома?',
      de: 'Welchen Vorteil hat die Schneeball-Methode?',
      pt: 'Que vantagem tem o método bola de neve?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['Faizi azaltır', 'Psikolojik motivasyon sağlar', 'Yüksek borcu önce kapatır', 'Daha çok kredi verir'],
      en: ['Reduces interest', 'Provides psychological motivation', 'Pays off high debt first', 'Provides more credit'],
      es: ['Reduce interés', 'Proporciona motivación psicológica', 'Paga deuda alta primero', 'Proporciona más crédito'],
      fr: ['Réduit les intérêts', 'Fournit une motivation psychologique', 'Rembourse d\'abord la dette élevée', 'Fournit plus de crédit'],
      ru: ['Снижает проценты', 'Обеспечивает психологическую мотивацию', 'Сначала погашает высокий долг', 'Предоставляет больше кредита'],
      de: ['Reduziert Zinsen', 'Bietet psychologische Motivation', 'Zahlt hohe Schulden zuerst ab', 'Bietet mehr Kredit'],
      pt: ['Reduz juros', 'Fornece motivação psicológica', 'Paga dívida alta primeiro', 'Fornece mais crédito']
    },
    correct: 1,
    explanation: {
      tr: 'Kar topu yöntemi, küçük borçları önce kapatarak psikolojik motivasyon sağlar. Her kapatılan borç başarı hissi verir ve devam etme gücü kazandırır.',
      en: 'Snowball method provides psychological motivation by paying off small debts first. Each debt closure gives a sense of achievement and provides momentum to continue.',
      es: 'El método bola de nieve proporciona motivación psicológica pagando primero deudas pequeñas. Cada cierre de deuda da sensación de logro y proporciona impulso para continuar.',
      fr: 'La méthode boule de neige fournit une motivation psychologique en remboursant d\'abord les petites dettes. Chaque clôture de dette donne un sentiment d\'accomplissement et fournit un élan pour continuer.',
      ru: 'Метод снежного кома обеспечивает психологическую мотивацию, погашая сначала мелкие долги. Каждое закрытие долга дает чувство достижения и обеспечивает импульс для продолжения.',
      de: 'Die Schneeball-Methode bietet psychologische Motivation, indem sie zuerst kleine Schulden abbezahlt. Jeder Schuldenabbau gibt ein Erfolgsgefühl und liefert Schwung zum Weitermachen.',
      pt: 'O método bola de neve fornece motivação psicológica pagando dívidas pequenas primeiro. Cada fechamento de dívida dá sensação de conquista e fornece impulso para continuar.'
    }
  },
  {
    id: 28,
    question: {
      tr: 'Çığ (Avalanche) yöntemi hangi avantajı sağlar?',
      en: 'What advantage does the Avalanche method provide?',
      es: '¿Qué ventaja proporciona el método Avalancha?',
      fr: 'Quel avantage fournit la méthode Avalanche ?',
      ru: 'Какое преимущество обеспечивает метод лавины?',
      de: 'Welchen Vorteil bietet die Lawinen-Methode?',
      pt: 'Que vantagem fornece o método Avalanche?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['Daha az faiz ödemek', 'Küçük borçları hızlı kapatmak', 'Motivasyon artırmak', 'Borç birleştirmek'],
      en: ['Paying less interest', 'Quickly closing small debts', 'Increasing motivation', 'Debt consolidation'],
      es: ['Pagar menos interés', 'Cerrar rápidamente deudas pequeñas', 'Aumentar motivación', 'Consolidación de deuda'],
      fr: ['Payer moins d\'intérêts', 'Fermer rapidement les petites dettes', 'Augmenter la motivation', 'Consolidation de dette'],
      ru: ['Платить меньше процентов', 'Быстро закрывать мелкие долги', 'Увеличивать мотивацию', 'Консолидация долгов'],
      de: ['Weniger Zinsen zahlen', 'Kleine Schulden schnell schließen', 'Motivation steigern', 'Schuldenkonsolidierung'],
      pt: ['Pagar menos juros', 'Fechar rapidamente dívidas pequenas', 'Aumentar motivação', 'Consolidação de dívida']
    },
    correct: 0,
    explanation: {
      tr: 'Çığ (Avalanche) yöntemi, en yüksek faizli borçları önce kapatarak toplam faiz ödemesini minimize eder. Matematik açısından en verimli yöntemdir.',
      en: 'Avalanche method minimizes total interest payment by paying off highest interest debts first. It\'s the most efficient method mathematically.',
      es: 'El método Avalancha minimiza el pago total de intereses pagando primero las deudas de mayor interés. Es el método más eficiente matemáticamente.',
      fr: 'La méthode Avalanche minimise le paiement total d\'intérêts en remboursant d\'abord les dettes à taux d\'intérêt le plus élevé. C\'est la méthode la plus efficace mathématiquement.',
      ru: 'Метод лавины минимизирует общую выплату процентов, погашая сначала долги с самыми высокими процентами. Это математически наиболее эффективный метод.',
      de: 'Die Lawinen-Methode minimiert die Gesamtzinszahlung, indem sie zuerst die höchstverzinslichen Schulden abbezahlt. Es ist mathematisch die effizienteste Methode.',
      pt: 'O método Avalanche minimiza o pagamento total de juros pagando primeiro as dívidas de juros mais altos. É o método mais eficiente matematicamente.'
    }
  },
  {
    id: 29,
    question: {
      tr: 'Borç birleştirme stratejisi hangi faydayı sağlar?',
      en: 'What benefit does debt consolidation strategy provide?',
      es: '¿Qué beneficio proporciona la estrategia de consolidación de deuda?',
      fr: 'Quel avantage fournit la stratégie de consolidation de dette ?',
      ru: 'Какую выгоду обеспечивает стратегия консолидации долгов?',
      de: 'Welchen Vorteil bietet die Schuldenkonsolidierungsstrategie?',
      pt: 'Que benefício fornece a estratégia de consolidação de dívida?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['Ödemeleri azaltır', 'Faizi artırır', 'Borcu iki katına çıkarır', 'Geliri düşürür'],
      en: ['Reduces payments', 'Increases interest', 'Doubles the debt', 'Reduces income'],
      es: ['Reduce pagos', 'Aumenta interés', 'Duplica la deuda', 'Reduce ingresos'],
      fr: ['Réduit les paiements', 'Augmente les intérêts', 'Double la dette', 'Réduit les revenus'],
      ru: ['Сокращает платежи', 'Увеличивает проценты', 'Удваивает долг', 'Снижает доходы'],
      de: ['Reduziert Zahlungen', 'Erhöht Zinsen', 'Verdoppelt die Schuld', 'Reduziert Einkommen'],
      pt: ['Reduz pagamentos', 'Aumenta juros', 'Dobra a dívida', 'Reduz renda']
    },
    correct: 0,
    explanation: {
      tr: 'Borç birleştirme stratejisi, birden fazla yüksek faizli borcu tek düşük faizli kredide toplayarak aylık ödemeleri azaltır ve yönetimi kolaylaştırır.',
      en: 'Debt consolidation strategy reduces monthly payments by combining multiple high-interest debts into a single low-interest loan and makes management easier.',
      es: 'La estrategia de consolidación de deuda reduce pagos mensuales combinando múltiples deudas de alto interés en un solo préstamo de bajo interés y facilita la gestión.',
      fr: 'La stratégie de consolidation de dette réduit les paiements mensuels en combinant plusieurs dettes à taux élevé en un seul prêt à faible taux et facilite la gestion.',
      ru: 'Стратегия консолидации долгов сокращает месячные платежи, объединяя несколько высокопроцентных долгов в один низкопроцентный кредит и упрощает управление.',
      de: 'Die Schuldenkonsolidierungsstrategie reduziert monatliche Zahlungen, indem sie mehrere hochverzinsliche Schulden in einem einzigen niedrigverzinslichen Kredit kombiniert und das Management erleichtert.',
      pt: 'A estratégia de consolidação de dívida reduz pagamentos mensais combinando múltiplas dívidas de juros altos em um único empréstimo de juros baixos e facilita o gerenciamento.'
    }
  },
  {
    id: 30,
    question: {
      tr: 'Türkiye\'de kredi kartı faizleri aylık yaklaşık kaç aralığındadır?',
      en: 'What is the approximate monthly range of credit card interest rates in the US?',
      es: '¿Cuál es el rango mensual aproximado de tasas de interés de tarjetas de crédito en España?',
      fr: 'Quelle est la fourchette mensuelle approximative des taux d\'intérêt des cartes de crédit en France ?',
      ru: 'Каков примерный месячный диапазон процентных ставок по кредитным картам в России?',
      de: 'Wie hoch ist die ungefähre monatliche Spanne der Kreditkartenzinsen in Deutschland?',
      pt: 'Qual é a faixa mensal aproximada das taxas de juros de cartão de crédito no Brasil?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['%2–3', '%4–6', '%8–12', '%15–20'],
      en: ['1.5–2.5%', '2–3%', '3–4%', '4–6%'],
      es: ['1–2%', '2–3%', '3–4%', '4–5%'],
      fr: ['1–2%', '2–3%', '3–4%', '4–5%'],
      ru: ['2–3%', '3–4%', '4–5%', '5–7%'],
      de: ['1–2%', '2–3%', '3–4%', '4–5%'],
      pt: ['8–12%', '12–15%', '15–18%', '18–25%']
    },
    correct: 2,
    explanation: {
      tr: 'Türkiye\'de kredi kartı faizleri aylık %8-12 aralığındadır, bu da yıllık %96-144\'e denk gelir. Bu nedenle kredi kartı borçları öncelikli olarak kapatılmalıdır.',
      en: 'In the US, credit card interest rates are typically 3-4% monthly (18-24% annually). Therefore, credit card debts should be prioritized for payoff.',
      es: 'En España, las tasas de interés de tarjetas de crédito están típicamente en el rango mensual del 3-4% (18-24% anual). Por lo tanto, las deudas de tarjetas de crédito deben priorizarse para el pago.',
      fr: 'En France, les taux d\'intérêt des cartes de crédit sont typiquement dans la fourchette mensuelle de 3-4% (18-24% annuel). Par conséquent, les dettes de cartes de crédit doivent être priorisées pour le remboursement.',
      ru: 'В России процентные ставки по кредитным картам обычно находятся в диапазоне 4-5% в месяц (25-35% годовых). Поэтому долги по кредитным картам должны быть приоритетными для погашения.',
      de: 'In Deutschland liegen die Kreditkartenzinsen typischerweise im monatlichen Bereich von 3-4% (18-24% jährlich). Daher sollten Kreditkartenschulden vorrangig abbezahlt werden.',
      pt: 'No Brasil, as taxas de juros de cartão de crédito estão tipicamente na faixa mensal de 15-18% (180-216% ao ano). Portanto, dívidas de cartão de crédito devem ser priorizadas para pagamento.'
    }
  },

  // 7. Finansal Hatalar ve Sonuç - Quiz
  {
    id: 31,
    question: {
      tr: 'FOMO yatırımı nedir?',
      en: 'What is FOMO investing?',
      es: '¿Qué es la inversión FOMO?',
      fr: 'Qu\'est-ce que l\'investissement FOMO ?',
      ru: 'Что такое FOMO инвестирование?',
      de: 'Was ist FOMO-Investition?',
      pt: 'O que é investimento FOMO?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['Mantıklı yatırım', 'Araştırmadan aceleyle yapılan yatırım', 'Borçla yatırım', 'Uzun vadeli yatırım'],
      en: ['Logical investment', 'Investment made hastily without research', 'Debt-funded investment', 'Long-term investment'],
      es: ['Inversión lógica', 'Inversión hecha apresuradamente sin investigación', 'Inversión financiada con deuda', 'Inversión a largo plazo'],
      fr: ['Investissement logique', 'Investissement fait à la hâte sans recherche', 'Investissement financé par dette', 'Investissement à long terme'],
      ru: ['Логическая инвестиция', 'Инвестиция, сделанная поспешно без исследования', 'Инвестиция на заемные средства', 'Долгосрочная инвестиция'],
      de: ['Logische Investition', 'Hastily gemachte Investition ohne Recherche', 'Schuldenfinanzierte Investition', 'Langfristige Investition'],
      pt: ['Investimento lógico', 'Investimento feito apressadamente sem pesquisa', 'Investimento financiado por dívida', 'Investimento de longo prazo']
    },
    correct: 1,
    explanation: {
      tr: 'FOMO (Fear of Missing Out) yatırımı, "fırsatı kaçırma korkusu" ile araştırma yapmadan aceleyle yapılan yatırımdır. Genellikle kayıpla sonuçlanır.',
      en: 'FOMO (Fear of Missing Out) investing is investment made hastily without research due to "fear of missing out". It usually results in losses.',
      es: 'La inversión FOMO (Fear of Missing Out) es inversión hecha apresuradamente sin investigación debido al "miedo de perderse algo". Usualmente resulta en pérdidas.',
      fr: 'L\'investissement FOMO (Fear of Missing Out) est un investissement fait à la hâte sans recherche en raison de la "peur de rater quelque chose". Il résulte généralement en pertes.',
      ru: 'FOMO (Fear of Missing Out) инвестирование - это инвестиция, сделанная поспешно без исследования из-за "страха упустить возможность". Обычно приводит к потерям.',
      de: 'FOMO (Fear of Missing Out) Investition ist eine hastig gemachte Investition ohne Recherche aufgrund der "Angst, etwas zu verpassen". Sie führt normalerweise zu Verlusten.',
      pt: 'Investimento FOMO (Fear of Missing Out) é investimento feito apressadamente sem pesquisa devido ao "medo de perder algo". Geralmente resulta em perdas.'
    }
  },
  {
    id: 32,
    question: {
      tr: 'Bütçesiz yaşamın en büyük riski nedir?',
      en: 'What is the biggest risk of living without a budget?',
      es: '¿Cuál es el mayor riesgo de vivir sin presupuesto?',
      fr: 'Quel est le plus grand risque de vivre sans budget ?',
      ru: 'Каков наибольший риск жизни без бюджета?',
      de: 'Was ist das größte Risiko des Lebens ohne Budget?',
      pt: 'Qual é o maior risco de viver sem orçamento?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['Daha çok kredi', 'Kontrolsüz harcama', 'Vergi borcu', 'Yatırım fırsatı'],
      en: ['More credit', 'Uncontrolled spending', 'Tax debt', 'Investment opportunity'],
      es: ['Más crédito', 'Gasto descontrolado', 'Deuda fiscal', 'Oportunidad de inversión'],
      fr: ['Plus de crédit', 'Dépenses incontrôlées', 'Dette fiscale', 'Opportunité d\'investissement'],
      ru: ['Больше кредита', 'Неконтролируемые расходы', 'Налоговый долг', 'Инвестиционная возможность'],
      de: ['Mehr Kredit', 'Unkontrollierte Ausgaben', 'Steuerschuld', 'Investitionsmöglichkeit'],
      pt: ['Mais crédito', 'Gastos descontrolados', 'Dívida fiscal', 'Oportunidade de investimento']
    },
    correct: 1,
    explanation: {
      tr: 'Bütçesiz yaşamın en büyük riski kontrolsüz harcama yapmaktır. Neye ne kadar harcadığınızı bilmezseniz, gelirinizi aşan harcamalar yapabilirsiniz.',
      en: 'The biggest risk of living without a budget is uncontrolled spending. If you don\'t know what you spend and how much, you can spend beyond your income.',
      es: 'El mayor riesgo de vivir sin presupuesto es el gasto descontrolado. Si no sabes qué gastas y cuánto, puedes gastar más allá de tus ingresos.',
      fr: 'Le plus grand risque de vivre sans budget est les dépenses incontrôlées. Si vous ne savez pas ce que vous dépensez et combien, vous pouvez dépenser au-delà de vos revenus.',
      ru: 'Наибольший риск жизни без бюджета - неконтролируемые расходы. Если вы не знаете, что тратите и сколько, вы можете тратить сверх своих доходов.',
      de: 'Das größte Risiko des Lebens ohne Budget sind unkontrollierte Ausgaben. Wenn Sie nicht wissen, was Sie ausgeben und wie viel, können Sie über Ihr Einkommen hinaus ausgeben.',
      pt: 'O maior risco de viver sem orçamento são gastos descontrolados. Se você não sabe o que gasta e quanto, pode gastar além de sua renda.'
    }
  },
  {
    id: 33,
    question: {
      tr: 'Finansal eğitim kaynakları arasında olmayan nedir?',
      en: 'Which is NOT among financial education resources?',
      es: '¿Cuál NO está entre los recursos de educación financiera?',
      fr: 'Lequel n\'est PAS parmi les ressources d\'éducation financière ?',
      ru: 'Что НЕ входит в ресурсы финансового образования?',
      de: 'Was ist NICHT unter den Ressourcen für Finanzbildung?',
      pt: 'O que NÃO está entre os recursos de educação financeira?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['Podcast', 'YouTube', 'Borsa İstanbul webinarı', 'Lüks marka katalogları'],
      en: ['Podcast', 'YouTube', 'Stock exchange webinar', 'Luxury brand catalogs'],
      es: ['Podcast', 'YouTube', 'Webinar de bolsa de valores', 'Catálogos de marcas de lujo'],
      fr: ['Podcast', 'YouTube', 'Webinaire de bourse', 'Catalogues de marques de luxe'],
      ru: ['Подкаст', 'YouTube', 'Вебинар фондовой биржи', 'Каталоги люксовых брендов'],
      de: ['Podcast', 'YouTube', 'Börsen-Webinar', 'Luxusmarken-Kataloge'],
      pt: ['Podcast', 'YouTube', 'Webinar da bolsa de valores', 'Catálogos de marcas de luxo']
    },
    correct: 3,
    explanation: {
      tr: 'Lüks marka katalogları finansal eğitim kaynağı değil, tüketimi teşvik eden pazarlama materyalleridir. Podcast, YouTube ve webinarlar eğitime katkı sağlar.',
      en: 'Luxury brand catalogs are not financial education resources, they are marketing materials that encourage consumption. Podcasts, YouTube and webinars contribute to education.',
      es: 'Los catálogos de marcas de lujo no son recursos de educación financiera, son materiales de marketing que fomentan el consumo. Podcasts, YouTube y webinars contribuyen a la educación.',
      fr: 'Les catalogues de marques de luxe ne sont pas des ressources d\'éducation financière, ce sont des matériaux de marketing qui encouragent la consommation. Podcasts, YouTube et webinaires contribuent à l\'éducation.',
      ru: 'Каталоги люксовых брендов не являются ресурсами финансового образования, это маркетинговые материалы, которые поощряют потребление. Подкасты, YouTube и вебинары способствуют образованию.',
      de: 'Luxusmarken-Kataloge sind keine Finanzbildungsressourcen, sondern Marketingmaterialien, die den Konsum fördern. Podcasts, YouTube und Webinare tragen zur Bildung bei.',
      pt: 'Catálogos de marcas de luxo não são recursos de educação financeira, são materiais de marketing que incentivam o consumo. Podcasts, YouTube e webinars contribuem para a educação.'
    }
  },
  {
    id: 34,
    question: {
      tr: 'Finansal alışkanlıkların oturması genelde kaç ay sürer?',
      en: 'How many months does it generally take for financial habits to settle?',
      es: '¿Cuántos meses generalmente toma para que se establezcan los hábitos financieros?',
      fr: 'Combien de mois faut-il généralement pour que les habitudes financières s\'installent ?',
      ru: 'Сколько месяцев обычно требуется для установления финансовых привычек?',
      de: 'Wie viele Monate dauert es normalerweise, bis sich finanzielle Gewohnheiten festsetzen?',
      pt: 'Quantos meses geralmente leva para os hábitos financeiros se estabelecerem?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['1 ay', '3 ay', '6 ay', '12 ay'],
      en: ['1 month', '3 months', '6 months', '12 months'],
      es: ['1 mes', '3 meses', '6 meses', '12 meses'],
      fr: ['1 mois', '3 mois', '6 mois', '12 mois'],
      ru: ['1 месяц', '3 месяца', '6 месяцев', '12 месяцев'],
      de: ['1 Monat', '3 Monate', '6 Monate', '12 Monate'],
      pt: ['1 mês', '3 meses', '6 meses', '12 meses']
    },
    correct: 2,
    explanation: {
      tr: 'Finansal alışkanlıkların oturması genellikle 6 ay sürer. İlk 3 ay zorlayıcı, sonraki 3 ay ise alışkanlık haline gelme dönemidir.',
      en: 'Financial habits generally take 6 months to settle. The first 3 months are challenging, and the next 3 months are the period of becoming habitual.',
      es: 'Los hábitos financieros generalmente toman 6 meses para establecerse. Los primeros 3 meses son desafiantes, y los siguientes 3 meses son el período de volverse habituales.',
      fr: 'Les habitudes financières prennent généralement 6 mois pour s\'installer. Les 3 premiers mois sont difficiles, et les 3 mois suivants sont la période de devenir habituelles.',
      ru: 'Финансовые привычки обычно устанавливаются за 6 месяцев. Первые 3 месяца сложные, а следующие 3 месяца - период превращения в привычку.',
      de: 'Finanzielle Gewohnheiten brauchen normalerweise 6 Monate, um sich zu festigen. Die ersten 3 Monate sind herausfordernd, und die nächsten 3 Monate sind die Periode des Zur-Gewohnheit-Werdens.',
      pt: 'Hábitos financeiros geralmente levam 6 meses para se estabelecer. Os primeiros 3 meses são desafiadores, e os próximos 3 meses são o período de se tornarem habituais.'
    }
  },
  {
    id: 35,
    question: {
      tr: 'Finansal özgürlüğün en büyük getirisi nedir?',
      en: 'What is the biggest return of financial freedom?',
      es: '¿Cuál es el mayor retorno de la libertad financiera?',
      fr: 'Quel est le plus grand retour de la liberté financière ?',
      ru: 'Каков наибольший доход от финансовой свободы?',
      de: 'Was ist die größte Rendite der finanziellen Freiheit?',
      pt: 'Qual é o maior retorno da liberdade financeira?'
    },
    type: 'multiple-choice',
    answers: {
      tr: ['Daha çok alışveriş', 'Daha az stres', 'Yüksek faiz', 'Daha çok kredi'],
      en: ['More shopping', 'Less stress', 'High interest', 'More credit'],
      es: ['Más compras', 'Menos estrés', 'Alto interés', 'Más crédito'],
      fr: ['Plus d\'achats', 'Moins de stress', 'Intérêt élevé', 'Plus de crédit'],
      ru: ['Больше покупок', 'Меньше стресса', 'Высокие проценты', 'Больше кредита'],
      de: ['Mehr Einkaufen', 'Weniger Stress', 'Hohe Zinsen', 'Mehr Kredit'],
      pt: ['Mais compras', 'Menos estresse', 'Juros altos', 'Mais crédito']
    },
    correct: 1,
    explanation: {
      tr: 'Finansal özgürlüğün en büyük getirisi daha az stres yaşamaktır. Para endişesi olmadan yaşamak, ruh sağlığı ve yaşam kalitesi açısından paha biçilemezdir.',
      en: 'The biggest return of financial freedom is experiencing less stress. Living without money worries is invaluable for mental health and quality of life.',
      es: 'El mayor retorno de la libertad financiera es experimentar menos estrés. Vivir sin preocupaciones de dinero es invaluable para la salud mental y calidad de vida.',
      fr: 'Le plus grand retour de la liberté financière est de ressentir moins de stress. Vivre sans soucis d\'argent est inestimable pour la santé mentale et la qualité de vie.',
      ru: 'Наибольший доход от финансовой свободы - меньше стресса. Жизнь без денежных забот бесценна для психического здоровья и качества жизни.',
      de: 'Die größte Rendite der finanziellen Freiheit ist weniger Stress zu erleben. Ein Leben ohne Geldsorgen ist unbezahlbar für die geistige Gesundheit und Lebensqualität.',
      pt: 'O maior retorno da liberdade financeira é experimentar menos estresse. Viver sem preocupações com dinheiro é inestimável para a saúde mental e qualidade de vida.'
    }
  }
]