import React, { Suspense } from "react";
import { EducationPlatform } from "./components/EducationPlatform";
import { LanguageProvider } from "./components/useLanguage";

function LoadingSpinner() {
  return (
    <div className="flex items-center justify-center min-h-screen">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
    </div>
  );
}

export default function App() {
  return (
    <Suspense fallback={<LoadingSpinner />}>
      <LanguageProvider>
        <EducationPlatform />
      </LanguageProvider>
    </Suspense>
  );
}